/*
 * inet.h
 */
#ifndef __INET_H__
#define __INET_H__

/*
 * Align to word (2 byte) boundary
 */
#define	align(n)	(((n) + 1) & ~1)

/*
 * IP address type
 */
typedef unsigned long ipaddr_t;		/* IP address type */

/*
 * Useful routines ...
 */
char		*inet_ntoa(ipaddr_t);
ipaddr_t	inet_aton(char *);
unsigned short	inet_checksum(void *, int);

unsigned short	htons(unsigned short);
unsigned short	ntohs(unsigned short);
unsigned long	htonl(unsigned long);
unsigned long	ntohl(unsigned long);

#endif /* __INET_H__ */

/*
 * inet.c
 *
 * Internet support utilities.
 *
 * Author:
 *	Leendert van Doorn
 *      25-04-94: Fixed problem on little endian machines in inet_checksum,
                  Stefan Baltus
 */
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>

#include "inet.h"

#ifndef IP_ANYADDR
#define	IP_ANYADDR	((ipaddr_t) 0)
#endif

/*
 * internet address type (only used for printing address)
 */
typedef union {
    ipaddr_t a;
    struct { unsigned char a0, a1, a2, a3; } s;
} inetaddr_t;

/*
 * Convert ip address to ASCII representation
 */
char *
inet_ntoa(ipaddr_t ipaddr)
{
    static char buffer[17];
    inetaddr_t addr;

    addr.a = ipaddr;
    sprintf(buffer, "%d.%d.%d.%d",
	addr.s.a0, addr.s.a1, addr.s.a2, addr.s.a3);
    return buffer;
}

static char *
number(char *s, unsigned char *n)
{
    for (*n = 0; *s >= '0' && *s <= '9'; s++)
	*n = (*n * 10) + *s - '0';
    return s;
}

/*
 * Convert ASCII representation to an ip address
 */
ipaddr_t
inet_aton(char *p)
{
    inetaddr_t addr;

    if (p == (char *)0 || *p == '\0')
	return IP_ANYADDR;
    p = number(p, &addr.s.a0);
    if (*p == '\0' || *p++ != '.')
	return IP_ANYADDR;
    p = number(p, &addr.s.a1);
    if (*p == '\0' || *p++ != '.')
	return IP_ANYADDR;
    p = number(p, &addr.s.a2);
    if (*p == '\0' || *p++ != '.')
	return IP_ANYADDR;
    p = number(p, &addr.s.a3);
    if (*p != '\0')
	return IP_ANYADDR;
    return addr.a;
}

/*
 * 16-bit one complement check sum
 */
unsigned short
inet_checksum(void *dp, int counter)
{
    register unsigned short *sp;
    unsigned long sum, oneword = 0x00010000;
    register int count;

    count = counter >> 1;
    for (sum = 0, sp = (unsigned short *)dp; count--; ) {
	sum += *sp++;
	if (sum >= oneword) { /* wrap carry into low bit */
	    sum -= oneword;
	    sum++;
	}
    }
    if (counter & 1) {
#ifdef LITTLE_ENDIAN
	sum += ((unsigned short) *((char *) sp)) &  0x00ff; 
#else
	sum += ((unsigned short) *((char *) sp)) << 8;
#endif
	if (sum >= oneword) { /* wrap carry into low bit */
	    sum -= oneword;
	    sum++;
	}
    }
    return ~sum;
}

/*
 * Traditional byte order conversion routines
 */
unsigned short
htons(unsigned short hs)
{
#ifdef LITTLE_ENDIAN
    char ns[2];
    ns[0] = ((char *) &hs)[1];
    ns[1] = ((char *) &hs)[0];
    return *(unsigned short *) ns;
#else
    return hs;
#endif
}

unsigned short
ntohs(unsigned short ns)
{
#ifdef LITTLE_ENDIAN
    char hs[2];
    hs[0] = ((char *) &ns)[1];
    hs[1] = ((char *) &ns)[0];
    return *(short *) hs;
#else
    return ns;
#endif
}

unsigned long
htonl(unsigned long hl)
{
#ifdef LITTLE_ENDIAN
    char nl[4];
    nl[0] = ((char *) &hl)[3];
    nl[1] = ((char *) &hl)[2];
    nl[2] = ((char *) &hl)[1];
    nl[3] = ((char *) &hl)[0];
    return *(unsigned long *) nl;
#else
    return hl;
#endif
}

unsigned long
ntohl(unsigned long nl)
{
#ifdef LITTLE_ENDIAN
    char hl[4];
    hl[0] = ((char *) &nl)[3];
    hl[1] = ((char *) &nl)[2];
    hl[2] = ((char *) &nl)[1];
    hl[3] = ((char *) &nl)[0];
    return *(unsigned long *) hl;
#else
    return nl;
#endif
}

/*
 * ether.c
 *
 * Bare bone ethernet interface for Minix.
 */
#include <sys/types.h>
#include <sys/ioctl.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <net/hton.h>
#include <net/netlib.h>
#include <net/gen/ether.h>
#include <net/gen/eth_io.h>
#if __minix_vmd
#include <net/gen/in.h>
#include <net/gen/ip_io.h>
#endif

#include "ether.h"

#ifndef	BUFSIZE
#define	BUFSIZE		2048
#endif

ethaddr_t my_ethaddr;

static int eth_fd= -1;

/*
 * We need eth_init to initialize my_ethaddr.
 */
void
eth_init(void)
{
    nwio_ethopt_t ethopt;
    nwio_ethstat_t ethstat;
#if __minix_vmd
    nwio_ipconf_t ipconf;
    char *eth_env, *end;
    unsigned long eth_vnr;
    int ip_fd;

    if ((eth_env = getenv("ETH")) == NULL) {
	fprintf(stderr, "eth_init: ETH environment variable not set\n");
	exit(1);
    }
    eth_vnr = strtoul(eth_env, &end, 10);
    if (eth_env == end || *end != 0 || eth_vnr >= 0x100) {
	fprintf(stderr,
	    "eth_init: Don't understand 'ENV=%s', expect as small number\n",
	    eth_env);
	exit(1);
    }
#endif

    if ((eth_fd = open(ETH_DEVICE, O_RDWR)) == -1) {
	fprintf(stderr, "eth_init: Can't open %s: %s\n",
	    ETH_DEVICE, strerror(errno));
	exit(1);
    }
    ethopt.nweo_flags = NWEO_COPY | NWEO_EN_LOC | NWEO_EN_BROAD |
	NWEO_EN_MULTI | NWEO_REMANY | NWEO_TYPEANY | NWEO_RWDATALL;
#if __minix_vmd
    ethopt.nweo_flags |= NWEO_EN_PROMISC;
#endif
    if (ioctl(eth_fd, NWIOSETHOPT, &ethopt) == -1) {
	fprintf(stderr, "eth_init: ioctl NWIOSETHOPT: %s\n", strerror(errno));
	exit(1);
    }
#if __minix_vmd
    if ((ip_fd = open(IP_DEVICE, O_RDWR)) == -1) {
	fprintf(stderr, "eth_init: Can't open %s: %s\n",
	    IP_DEVICE, strerror(errno));
	exit(1);
    }
    if (ioctl(ip_fd, NWIOGIPCONF, &ipconf) == -1) {
	fprintf(stderr, "eth_init: ioctl NWIOGIPCONF: %s\n", strerror(errno));
	exit(1);
    }
    close(ip_fd);
    ((u8_t*)&my_ethaddr)[0] = 'v';
    ((u8_t*)&my_ethaddr)[1] = eth_vnr;
    memcpy((u8_t*)&my_ethaddr + 2, &ipconf.nwic_ipaddr, 4);
#else
    if (ioctl(eth_fd, NWIOGETHSTAT, &ethstat) == -1) {
	fprintf(stderr, "eth_init: ioctl NWIOGETHSTAT: %s\n", strerror(errno));
	exit(1);
    }
    my_ethaddr = *(ethaddr_t *)&ethstat.nwes_addr;
#endif
}

/*
 * Send an ethernet packet with protocol number ``proto''
 * (in host byte order), and destination address ``daddr''.
 */
int
eth_send(ethaddr_t *daddr, u16_t proto, void *msg, int len)
{
    char buf[BUFSIZE];
    int rv;
    u16_t nproto;

    if (len < ETH_MINTU || len > ETH_MAXTU) {
	fprintf(stderr, "eth_send: too %s data bytes: %d\n",
		len > ETH_MAXTU ? "many" : "few", len);
	fprintf(stderr, "\tproto= 0x%x\n", proto);
	errno = EINVAL;
	return -1;
    }
    memcpy(buf + 0, daddr, 6);
    memcpy(buf + 6, &my_ethaddr, 6);
    nproto = htons(proto);
    memcpy(buf + 12, &nproto, 2);
    memcpy(buf + 14, msg, len);
    rv = write(eth_fd, buf, 14 + len);
    return rv < 14 ? -1 : rv - 14;
}

/*
 * Receive any ether packet. The packet's protocol
 * field is stored in ``proto'' in the host byte order.
 * ``msg'' contains the packet data. Since a caller
 * should always prepared to handle up to a maximum
 * sized ethernet packet, size is fixed to 1500.
 */
int
eth_receive(ethaddr_t *saddr, ethaddr_t *daddr, u16_t *proto,
    void *msg, int size)
{
    unsigned char buf[BUFSIZE];
    int r;
    u16_t nproto;

    if (size < 0) { errno = EINVAL; return -1; }

    for (;;) {
	r = read(eth_fd, buf, 1514);
	if (r < 0)
	    return -1;
	r -= 14; /* ethhdr_t */
	if (r < ETH_MINTU) {
	    fprintf(stderr, "eth_receive: strange eth size: %d\n", r);
	    errno = EIO;
	    return -1;
	}
	/* ignore reflected packets. */
	if (memcmp(buf + 6, &my_ethaddr, sizeof(ethaddr_t)) == 0) continue;

	/* destination is me or broadcast */
	if (!(buf[0] & 0x01) && memcmp(buf + 0, &my_ethaddr, 6) != 0) continue;

	memcpy(daddr, buf + 0, 6);
	memcpy(saddr, buf + 6, 6);
	memcpy(&nproto, buf + 12, 2);
	*proto = ntohs(nproto);
	memcpy(msg, buf + 14, size < r ? size : r);
	return r;
    }
}

#ifdef TEST
ethaddr_t bcastaddr = { { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF } };

int main(void)
{
    u8_t buf[ETH_MAXTU];
    ethaddr_t saddr, daddr;
    u16_t proto;
    int len, i;
    int r;
    static char junk[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    for (i = 0; i < ETH_MAXTU; i++)
	buf[i] = (u8_t) i;

    eth_init();

    proto = 0x8045;
    for (;;) {
	printf("send\n");
	r = eth_send(&bcastaddr, ++proto, junk, ETH_MINTU);
	if (r < 0) {
	    perror("eth_send");
	    exit(1);
	}
	len = eth_receive(&saddr, &daddr, &proto, buf, ETH_MAXTU);
	printf("%02x:%02x:%02x:%02x:%02x:%02x -> ",
	    daddr.addr[0], daddr.addr[1], daddr.addr[2],
	    daddr.addr[3], daddr.addr[4], daddr.addr[5]);
	printf("%02x:%02x:%02x:%02x:%02x:%02x, %04x, %d\n",
	    saddr.addr[0], saddr.addr[1], saddr.addr[2],
	    saddr.addr[3], saddr.addr[4], saddr.addr[5], proto, len);
	sleep(1);
    }
}
#endif /* TEST */

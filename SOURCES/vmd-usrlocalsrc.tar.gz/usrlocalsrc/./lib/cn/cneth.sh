#!/bin/sh
#
#	cneth 1.1 - Shown CN added ethernet interface and stuff
#							Author: Kees J. Bot
#								8 Jan 2001

case "$#:$ETH" in
0:)
    echo "\$ETH is not set, showing ETH=[0-2]"
    set -- 0 1 2
    ;;
0:?*)
    set -- "$ETH"
esac

ifs0="$IFS"

for ETH
do
    # This machine's IP address.
    ip=$(hostaddr -i)

    # Translate to a private Ethernet address.  First octet is the letter 'v'
    # (0x76, bit 0x02 measn "private"), second octet is $ETH, and the remaining
    # octets are this hosts IP address.
    IFS='.'
    set -- $ip
    IFS="$ifs0"
    eth="$(printf "76:$ETH:%x:%x:%x:%x" $*)"

    # The Minix-vmd RARP server will translate this Ethernet address by
    # splicing in the second octet after this machine's name, for example:
    # flotsam.cs.vu.nl --> flotsam-$ETH.cs.vu.nl.
    name="$(hostaddr -a | sed "s/\\./-$ETH./")"

    # The ip address to this name.
    ip="$(host "$name" | sed 's/.* //')"

    # The netmask and gateway on this network is found in the DHCP information.
    netmask="$(dhcpd -q | sed '/netmask/!d;s/.* //')"
    gateway="$(dhcpd -q | sed '/gateway/!d;s/.* //')"

    # Tell all.
    echo "Information for additional ethernet tap $ETH:
	ETH = $ETH
	Ethernet address = $eth
	IP address = $ip / $netmask
	gateway = $gateway"
done

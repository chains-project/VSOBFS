/*
 * ether.h
 */
#ifndef __ETHER_H__
#define __ETHER_H__

#include <sys/types.h>

#define	ETH_MINTU	(60-14)		/* minimal tranmission unit */
#define	ETH_MAXTU	1500		/* maximum transmission unit */
#define	ETH_ADDRSIZE	6		/* size of ethernet addresses */

#define	ETHTYPE_IP	0x0800		/* IP protocol */
#define	ETHTYPE_ARP	0x0806		/* ARP protocol */
#define	ETHTYPE_RARP	0x8035		/* Reverse ARP protocol */

/*
 * Ethernet address
 */
typedef struct {
    unsigned char	addr[ETH_ADDRSIZE];	/* 48 bit address */
} ethaddr_t;

/*
 * Ethernet packet header
 */
typedef struct {
    ethaddr_t		eth_dst;		/* destination address */
    ethaddr_t		eth_src;		/* source address */
    unsigned short	eth_proto;		/* protocol type */
} ethhdr_t;

extern ethaddr_t my_ethaddr;

void eth_init(void);
int eth_send(ethaddr_t *, u16_t, void *, int);
int eth_receive(ethaddr_t *, ethaddr_t *, u16_t *, void *, int);

#endif /* __ETHER_H__ */


/*	sema_maybedown()
 */
#include "loc_incl.h"

size_t sema_maybedown(s, l) semaphore *s; size_t l;
{
	if (*s >= l)
		*s-= l;
	else {
		l= *s;
		*s= 0;
	}
	return l;
}
/* Kees J. Bot 19-10-91. */

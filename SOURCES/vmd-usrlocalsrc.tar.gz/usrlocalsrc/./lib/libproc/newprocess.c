/*	newprocess()
 */
#include "loc_incl.h"

process _main_proc= { &_main_proc, nil };
process *_last= &_main_proc, *_active= &_main_proc;

unsigned _nprocs= 1;
unsigned deadlock= 0;

void newprocess(coX, stack, st_len) void (*coX)(); void *stack; size_t st_len;
{
	/* Use part of stack for a process struct. */

	_last= _last->next= (process *) stack;
	_last->next= _active;

	stack= (void *) ((char *) stack + sizeof(process));
	st_len-= sizeof(process);

	_last->stack= newcoroutine(coX, stack, st_len);
	_nprocs++;
}
/* Kees J. Bot 1-5-88. */

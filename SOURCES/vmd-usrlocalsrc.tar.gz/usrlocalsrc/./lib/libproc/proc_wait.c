/*	proc_wait()
 */
#include "loc_incl.h"

void proc_wait()
{
	deadlock= 0;
	while (_nprocs > 1) proc_next();
}
/* Kees J. Bot 1-5-88. */

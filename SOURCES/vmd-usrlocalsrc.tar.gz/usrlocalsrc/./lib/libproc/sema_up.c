/*	sema_up()
 */
#include "loc_incl.h"

#undef sema_up

void sema_up(s, l) semaphore *s; size_t l;
{
	*s+= l;
}
/* Kees J. Bot 19-10-91. */

/*	sema_level()
 */
#include "loc_incl.h"

#undef sema_level

size_t sema_level(s) semaphore *s;
{
	return *s;
}
/* Kees J. Bot 19-10-91. */

/*	proc_next()
 */
#include "loc_incl.h"

void proc_next()
{
	if (++deadlock > _nprocs) {
		write(2, "\r\nDEADLOCK\r\n", 12);
		exit(-1);
	}
	_last= _active;
	_active= _active->next;

	transfer(&_last->stack, _active->stack);
}
/* Kees J. Bot 1-5-88. */

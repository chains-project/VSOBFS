/*	proc_exit()
 */
#include "loc_incl.h"

void proc_exit()
{
	void *junk;

	if (--_nprocs == 0) exit(0);

	_last->next= _active= _active->next;

	transfer(&junk, _active->stack);
}
/* Kees J. Bot 1-5-88. */

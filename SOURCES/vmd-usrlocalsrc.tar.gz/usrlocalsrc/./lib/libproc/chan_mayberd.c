/*	chan_mayberead()
 */
#include "loc_incl.h"

size_t chan_mayberead(c, b, l) channel *c; void *b; size_t l;
{
	if (l > c->len) l= c->len;

	chan_read(c, b, l);

	return l;
}
/* Kees J. Bot 19-10-91. */

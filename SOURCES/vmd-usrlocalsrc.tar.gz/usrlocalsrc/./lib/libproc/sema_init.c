/*	sema_init()
 */
#include "loc_incl.h"

#undef sema_init

void sema_init(s, l) semaphore *s; size_t l;
{
	*s= l;
}
/* Kees J. Bot 19-10-91. */

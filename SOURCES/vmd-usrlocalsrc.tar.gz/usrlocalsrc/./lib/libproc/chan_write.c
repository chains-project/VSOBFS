/*	chan_write()
 */
#include "loc_incl.h"

void chan_write(c, b, l) channel *c; void *b; size_t l;
{
	deadlock= 0;
	while (c->buf != nil) proc_next();

	c->buf= (char *) b;	c->len= l;

	deadlock= 0;
	while (c->len > 0) proc_next();

	c->buf= nil;
}
/* Kees J. Bot 5-1-88. */

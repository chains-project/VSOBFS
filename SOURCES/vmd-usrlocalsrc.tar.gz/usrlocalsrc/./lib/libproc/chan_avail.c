/*	chan_avail()
 */
#include "loc_incl.h"

#undef chan_avail

size_t chan_avail(c) channel *c;
{
	return c->len;
}
/* Kees J. Bot 19-10-91. */

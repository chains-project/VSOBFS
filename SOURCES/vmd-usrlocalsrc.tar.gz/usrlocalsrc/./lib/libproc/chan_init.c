/*	chan_init()
 */
#include "loc_incl.h"

void chan_init(c) channel *c;
{
	c->buf= nil;
	c->len= 0;
}
/* Kees J. Bot 5-1-88. */

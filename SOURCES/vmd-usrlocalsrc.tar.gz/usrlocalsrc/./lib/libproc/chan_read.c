/*	chan_read()
 */
#include "loc_incl.h"
#include "string.h"

void chan_read(c, _b, l) channel *c; void *_b; size_t l;
{
	char *b= (char *) _b;

	while (l > 0) {
		size_t n;

		deadlock= 0;
		while (c->len == 0) proc_next();

		n= c->len > l ? l : c->len;

		memmove(b, c->buf, n);
		c->buf+= n;	c->len-= n;
		b+= n;		l-= n;
	}
}
/* Kees J. Bot 5-1-88. */

/*	loc_incl.h - get process.h, channel.h and semaphore.h
 */
#define nil 0
#include "stddef.h"
#include "process.h"
#include "channel.h"
#include "semaphore.h"

typedef struct process {
	struct process *next;
	void *stack;
} process;

extern process *_last, *_active;
extern unsigned _nprocs;

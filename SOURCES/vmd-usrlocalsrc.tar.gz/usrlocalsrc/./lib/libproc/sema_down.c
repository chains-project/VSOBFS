/*	sema_down()
 */
#include "loc_incl.h"

void sema_down(s, l) semaphore *s; size_t l;
{
	deadlock= 0;
	while (*s < l) proc_next();

	*s -= l;
}
/* Kees J. Bot 1-5-88. */

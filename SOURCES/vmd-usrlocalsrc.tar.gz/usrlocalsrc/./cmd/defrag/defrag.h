#include <sys/types.h>
#if 0
#include <sys/dir.h>
#endif
#include <sys/stat.h>
#include <stdio.h>
#include <fcntl.h>
#include <limits.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <time.h> /* ctime et al */
#include <string.h>
#include <minix/config.h>
#include <minix/const.h>
#include <minix/type.h>
#undef EXTERN
#define EXTERN /* get rid of extern by making it NIL */
#include <fs/const.h>
#include <fs/type.h>
#include <fs/super.h>
#if __minix_vmd
#define super_block v12_super_block
#endif

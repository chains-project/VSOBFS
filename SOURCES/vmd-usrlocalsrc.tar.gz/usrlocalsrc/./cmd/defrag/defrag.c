/* defrag.c, v8 */
/* (c) Ruediger Weis, 2003 under GPL!-) */
/***************************************************************/
/* Headers */
/* Minix */

#include "defrag.h"
/* #include "defraglinux.h"  */

#define DEBUG /* turn on debugging output */ 

/* Prototypes */

void panicexit(char* errorstring, int errnum);
int statistic(char* path);
void testio(char* path);
/* Guido: I've not made prototypes of my functions yet. */
void pexit (char* errorstring, int errnum);
int get_block(int fd, block_t n, char*  buf);
int put_block(int fd, block_t n, char* buf, int bit);
int read_bit (char* bitmap, int bit);
void copy_file (int inip);
void mkemptyinode(int m);
int read_inode (int inip, d2_inode* ip);
int put_inode (int outip, d2_inode* ip);
void set_bit (char* bitmap, int bit);

/* Global var*/
int in_ip = 0;  /* input inode pointer */
int out_ip = 0; /* Inode 0 is unused (see fs/super.h) */
block_t in_bp;  /* input block pointer (unsigned long!)*/
block_t out_bp; /* output block pointer */

char* input_devnam;
char* output_devnam;

int in_fd; /* fd for input device */
int out_fd; /* fd for output device */

struct super_block* sbo; /* to store copy of superblock of input device */
struct super_block* sbi; /* will contain  superblock of input device */

char buf[BLOCK_SIZE]; /* scratch buffers - to use at will. */
char buf1[BLOCK_SIZE];
char buf2[BLOCK_SIZE];
char buf3[BLOCK_SIZE]; /* we need a lot for double indirect loop.. */
char buf4[BLOCK_SIZE]; 

int i,j,k,l,m,n; /* often-used scratch variables (for counters, etc.) */

char* in_imap; /* inode bitmap */ 
char* in_zmap; /* zone (==block) bitmap */
char* out_imap; /* idem for output device */
char* out_zmap;

int out_imap_start_block;
int in_first_inode_block;
int out_first_inode_block;

/* The first inode should be there but is not used. However, 
 * it appears crucial to copy it explicitly (?) */
int in_inodes_used = 0;
int out_inodes_used = 0;
int in_zones_used = 0;
int out_zones_used = 0;
int max_inode_used = 0; /* to check if output fs has enough inodes avail */

/***********************************************************************
 * Main
 ***********************************************************************/

int main (int argc, char** argv) {
  int b, b1;

  if (argc != 3) 
    pexit ("Usage: defrag <oldfs> <newfs>",1); 
  input_devnam = argv[1];
  output_devnam = argv[2];

  in_fd = open (input_devnam, O_RDONLY);
  if (in_fd <= 0) 
    pexit("Could not open input device",3);

  out_fd = open (output_devnam, O_RDWR); 
  if (out_fd <= 0) 
    pexit ("could not open output device",3); 

  /* Bypass bootblock and read superblock of input device and output device */
  /* Blockpointers of input and output device should be set to 2 for both 
   * devices after this, which is the block where the inode bitmap starts.
   * get_block returns the second argument incremented with one. */

  in_bp = get_block(in_fd, 1, buf);    /* Read out block 1 (second block) */
  out_bp = get_block(out_fd, 1, buf2); 
  sbi = malloc(sizeof(struct super_block));
  sbo =  malloc (sizeof (struct super_block)); 
  memcpy((void*) sbi, (void*) buf, sizeof(struct super_block)); /* copy super */
  memcpy((void*) sbo, (void*) buf2, sizeof(struct super_block)); 
  printf("1");
  if (sbo->s_magic != SUPER_V2) 
    pexit("newfs is not a Minix V2 filesystem",2);

  if (sbi->s_magic != SUPER_V2) 
   pexit("oldfs is not a Minix V2 filesystem",2);

  /* Get the inode and block bitmaps */
  /* Input fs: */
  i = sbi->s_imap_blocks;
  j = sbi->s_zmap_blocks;

  in_imap = malloc (i * BLOCK_SIZE); 
  in_zmap = malloc (j * BLOCK_SIZE);

  while (i > 0) { in_bp = get_block (in_fd, in_bp, in_imap); i--; }
  while (j > 0) { in_bp = get_block (in_fd, in_bp, in_zmap); j--; }
  /* Same for output fs */
  i = sbo->s_imap_blocks; 
  j = sbo->s_zmap_blocks;   
  out_imap = malloc (i* BLOCK_SIZE);
  out_zmap = malloc (j* BLOCK_SIZE);
  out_imap_start_block = out_bp;

  while (i > 0) {out_bp = get_block (out_fd, out_bp, out_imap); i--;}  
  while (j > 0) {out_bp = get_block (out_fd, out_bp, out_zmap); j--;}

  /* Now notate somewhere where the inode blocks begin. They start just
   * after the zone-bitmaps, so this is the place to store those
   * values */ 

  in_first_inode_block = in_bp;
  out_first_inode_block = out_bp;
  in_bp = sbi->s_firstdatazone;
  out_bp = sbo->s_firstdatazone;

  printf("First datazone of input device: %d\n",in_bp);
  printf("First datazone of output device: %d\n",out_bp);

  /* check some sizes. How many inodes / zones are in use? */
  for (i=0; i<sbi->s_ninodes; i++) 
     if (read_bit (in_imap, i) ) {   /* inode used */
     	in_inodes_used++; max_inode_used = i; 
     }
  for (i=0; i<sbo->s_ninodes; i++)
     if (read_bit (out_imap, i) ) /* inode used */
     	out_inodes_used++;
  for (i=0; i<sbi->s_zones; i++) 
     if (read_bit (in_zmap, i) ) /* zone (block) used */
        in_zones_used++;
  for (i=0; i<sbo->s_zones; i++)
     if (read_bit (out_zmap, i) ) /* zone (block) used */
        out_zones_used++;

  printf("Input inodes / output inodes in use: %d, %d\n",in_inodes_used,
          out_inodes_used);
  printf("Input zones / output zones in use: %d, %d\n",in_zones_used,
          out_zones_used);

  if (out_inodes_used > 2) /* always one (0) marked as used + root-dir. */
    pexit ("Output fs not empty (inodes in use)",4); 

  /* The following is not correct: TODO p.456 (nonfatal) */ 
  if (out_zones_used > (2 + sbo->s_imap_blocks + sbo->s_zmap_blocks
  	     + (sbo->s_ninodes/V2_INODES_PER_BLOCK) ) )
    pexit ("Output fs is not empty: blocks in use.",4);

   /* Now we are about past the initialization phase. The block pointers are
    * set at the first empty blocks (in_bp and out_bp). The inode pointers
    * (in_ip and out_ip) were already initialized to 1 (inode 0 is unused). 
    * Now we should be about able to iterate through the inode table, and
    * copy the blocks that belong to each inode to the output filesystem. 
    */

    printf("Input file: max no of inodes that can be used: %d\n",
            sbi->s_ninodes);

    /* iterate through input-FS'es inode table, copy each file whose
     * inode-bit is set. 
     * I expected to start from 1, but then . and .. missed in /. Same
     * problem found presently with m=0. Inode 0 is unused, should make
     * no difference if we copy it or not.  
     */ 
    for (m=0; m <= sbi->s_ninodes; m++) { 
      if (read_bit (in_imap, m) ) 
    	   copy_file (m);   
      else 
    	   mkemptyinode(m); /* fill the empty output slots */
     }

     for (i=m; i<sbo->s_ninodes; i++)
        mkemptyinode(i);  /* Write remaining inodes as I_NOT_ALLOC */  

    /* Write the output-FS bitmaps (Kees, I made an error here before. Fixed)*/
    j = out_imap_start_block;
    for (i=0; i< sbo->s_imap_blocks; i++) 
       j = put_block(out_fd, j, &out_imap[i],0);
    for (i=0; i<sbo->s_zmap_blocks; i++) 
       j = put_block (out_fd, j, &out_zmap[i],0); 

    close (in_fd);
    close (out_fd);
    pexit("\nNo Panic !\n\n",0);
}
/* End of MAIN */

/************************************************************************
 * Copy_file
 ************************************************************************/

/* This function walks, given a given inode number, through all the
 * direct and indirect blocks, and copies the file block by block in 
 * a sequential order to the output device. 
 * The function increases the in_ip and out_ip and the block 
 * numbers automatically. TODO Statistics.  */

void copy_file (int inip) {
  d2_inode *ip = malloc (sizeof(d2_inode)); 
  d2_inode *ip2 = malloc (sizeof(d2_inode)); 
  int b,b1,b2; /* for bit */
  block_t ibuf[V2_INDIRECTS];  /* Avoid casting problems between char and */
  block_t ibuf1[V2_INDIRECTS]; /* block_t arrays. */
  block_t ibuf2[V2_INDIRECTS]; 
  block_t ibuf3[V2_INDIRECTS];
  block_t ibuf4[V2_INDIRECTS]; 
 
  printf("\nEntering copy_file..inode %d \n",inip);

  in_ip = read_inode (inip, ip);

  /* First a few checks: we only want to copy the blocks of regular 
   * files and directories. If I am correct (?), char / block special 
   * files or named pipe inodes never point to a block.
   */
  if ( ip->d2_mode  == I_NOT_ALLOC )  { 
     /* pexit("Input filesystem inconsistency (I_NOT_ALLOC)",6); */ 
     put_inode (inip, ip); 
     printf("Copied I_NOT_ALLOC inode %d !\nExit copy_file.\n",inip);
     free (ip); free (ip2); return;  
  }
  if ((ip->d2_mode & I_TYPE) == I_CHAR_SPECIAL)
  { put_inode (inip, ip); printf("Inode %d: I_CHAR_SPECIAL\n",inip);
#ifdef DEBUG
    for (i=0; i<V2_NR_TZONES-1; i++) { 
      if (ip->d2_zone[i] != NO_ZONE)
        printf("  zone %d contains data: %d\n",i,ip->d2_zone[i]);
    }
#endif      
    free (ip); free (ip2); return;
  }
  if ((ip->d2_mode & I_TYPE) == I_BLOCK_SPECIAL) {
    put_inode (inip, ip); printf("Inode %d is I_BLOCK_SPECIAL\n",inip);
#ifdef DEBUG
    for (i=0; i<V2_NR_TZONES-1; i++)  {
    	if (ip->d2_zone[i] != NO_ZONE)
    	  printf("  zone %d contains data: %d\n",i,ip->d2_zone[i]); 
    }
#endif
    free (ip); free (ip2); return;
  }
  if ((ip->d2_mode & I_TYPE) == I_NAMED_PIPE) { 
    put_inode (inip, ip); printf("Inode %d is I_NAMED_PIPE\n",inip); 
#ifdef DEBUG
    for (i=0; i<=V2_NR_TZONES-1; i++) {
        if (ip->d2_zone[i] != NO_ZONE)
          printf("  zone %d contains data: %d\n",i,ip->d2_zone[i]); 
     } 
#endif
     free (ip); free (ip2); return;
   } 


  /* Now for the real copy_file */

  memcpy ((char*) ip2, (char*)ip, sizeof(d2_inode));

  printf("Inode has owner %d, gid %d, size %d, ctime %s and mtime %s\n",
          ip->d2_uid, ip->d2_gid, ip->d2_size, ctime(&ip->d2_ctime),
          ctime(&ip->d2_mtime));

  /* Initialize the target-ip. */
  for (i=0; i< V2_NR_TZONES-1; i++) ip2->d2_zone[i] = NO_ZONE;

  printf("Copying direct data-blocks..\n");
  for (i=0; i<V2_NR_DZONES; i++) {  /* Copy the direct blocks first */
     if (ip->d2_zone[i] != NO_ZONE) {
     	b = get_block (in_fd, ip->d2_zone[i], buf);
     	if (!b)  
     	  printf("Direct block %d input-fs marked not used\n",ip->d2_zone[i]);
     	  /* ip2->d2_zone[i] = NO_ZONE; fix inconsistency? */
     	 out_bp = put_block (out_fd, out_bp, buf,b); /* I copy */ 
     }
  }
  printf("Direct blocks copied\n",j);

  if (ip->d2_zone[V2_NR_DZONES] != NO_ZONE) {
     /* There is a single indirect block */
     printf("\nentering INDIRECT block loop\n");

     /* In my test on the fs that is in 'inputfs-dump', an inconsistency 
      * occurs. fsck on inputfs reveals no problems.. A particular 
      * block bit was not set.. How come?
      * It appeared that the direct blocks used where up and including 119,
      * and the indirect block pointed to was 121 - so inconsistency in 
      * input-fs? Observation: fs allocates first the datablock that the
      * indirect block points to (the first one), then the indirect block, 
      * and then the rest of the blocks that the indirect block points to..!?! 
      */
     b = get_block (in_fd, ip->d2_zone[V2_NR_DZONES], (char*)ibuf);
     if (!b) { 
        printf("The indirect block was not marked as in use...\n");
        printf("Non-zero content of \'unused\' indirect block\n");
        for (i=0; i<V2_INDIRECTS; i++) {
          if (ibuf[i] != NO_ZONE)
      	     printf("block %d\n",ibuf[i]);
      	}
      } /* if (!b) */ /* Output here seemed reasonable.. */

     printf("Indirect block %d read\n",ip->d2_zone[V2_NR_DZONES]);

     ip2->d2_zone[V2_NR_DZONES] = out_bp; /* reserve out_bp for ind. block */ 
     out_bp++;
     for (i=0; i< V2_INDIRECTS; i++) {
      if (ibuf[i] != NO_ZONE) { 
        ibuf3[i] = out_bp;      /* ibuf3 is output-indirect block */
        b1 = get_block(in_fd, ibuf[i], buf2); 
        if (!b1)         /* THIS HAPPENS: zmap bit equals zero.. */ 
            printf("Input block %d pointed to by ind block marked unused.\n");
            /* ibuf[i] = NO_ZONE; - repair? */ 
        out_bp = put_block (out_fd, out_bp, buf2, b1); /* I copy */ 
      } /* if */
     } /* for */

     /* if all blocks are copied, put the indirect block to disk */
     put_block (out_fd, ip2->d2_zone[V2_NR_DZONES], (char*)ibuf3, b);
     printf("Copied INDIRECT block\n");
  }

  /* and now for the really big stunt... */
  /* TODO Second indirect (not scrutinized or tested yet) */

  if (ip->d2_zone[V2_NR_DZONES +1] != NO_ZONE) { /* darn..*/
    printf("There is a double indirect.\n");
     b = get_block (in_fd, ip->d2_zone[V2_NR_DZONES+1], (char*)ibuf);
     ip2->d2_zone[V2_NR_DZONES+1] = out_bp;
     out_bp++; /* reserve space to store the intermediate block (ibuf1) */

     for (i=0; i<V2_INDIRECTS; i++) {
       if (ibuf[i] != NO_ZONE) { /* ibuf contains intermediate block */
         /* Note: students should not break here: holes allowed (?) */
         b1 = get_block (in_fd, ibuf[i], (char*)ibuf2); /* second indirect */
         ibuf1[i] = out_bp; 
         out_bp++; /* reserve space for it */
         for (j=0; j<V2_INDIRECTS; j++) {
          if (ibuf2[j] != NO_ZONE) { 
             b2 = get_block (in_fd, buf2[j], buf3); /* The datablocks */
             ibuf4[j] = out_bp;
     	     out_bp = put_block (out_fd, out_bp, buf3, b2); 
      	  } /* if */
         } /* for */
         put_block (out_fd, buf1[i], (char*)ibuf4, b1);
       } /* if */
     } /* for (i.. */
     /* We have followed all second indirects - intermediate is ready */
     put_block(out_fd, ip2->d2_zone[V2_NR_DZONES+1], (char*)ibuf1, b);
   } /* if */

   /* Something may live in triple indirect (named pipe) */
   /* TODO: is this correct? Does named pipe point to a block? */
   /* ACL does (but that's not official, Guido) */

   /* Guido: I think this does not belong here - triple indirect is now
    * handled above at the beginning of copy_file (I_NAMED_PIPE).  
    * TODO REMOVE? 
    */ 
   /* if (ip->d2_zone[V2_NR_TZONES-1] != NO_ZONE) { 
      printf("Copying block %d pointed to by triple indirect.\n",
              ip->d2_zone[V2_NR_TZONES-1]);
      b = get_block(in_fd,ip->d2_zone[V2_NR_TZONES-1],buf); 
      if (!b) printf("Triple indirect contains invalid block pointer\n"); 
      if (b) {
        ip2->d2_zone[V2_NR_TZONES-1] = out_bp;
        out_bp = put_block(out_fd, out_bp, buf, b);
     } 
   } */  

   /* We've handled direct, single indirect, double indirect and pipes. */

   printf("End of copy_file; writing inode %d\n",inip);

   out_ip = put_inode (inip, ip2);

   free (ip);
   free (ip2);
}


/***********************************************************************
 * Mkemptyinode
 ***********************************************************************/

void mkemptyinode(int m) {
    d2_inode dip;
    memset ((void*)&dip, 0 , sizeof(d2_inode)); 
    if (m <= max_inode_used)
       printf("Mkemptyinode: putting empty inode %d\n",m);
     dip.d2_mode = I_NOT_ALLOC; 
     put_inode (m, &dip);
}

/*************************************************************************
 * Read / put_inode
 *************************************************************************/


int read_inode (int inip, d2_inode* ip) {
   d2_inode ibuf[V2_INODES_PER_BLOCK];

#ifdef DEBUG
   if (!read_bit(in_imap, inip)) /* pexit? */
     printf("Read_inode: read inode whose bit is not set.\n");
#endif

    printf("\nRead_inode: inode %d supposed to be in zone %d, offset %d\n",
           inip, in_first_inode_block + (inip/V2_INODES_PER_BLOCK),
           inip%V2_INODES_PER_BLOCK);

   get_block(in_fd, in_first_inode_block + (inip / V2_INODES_PER_BLOCK), 
            (char*) ibuf);

   memcpy((char*) ip, 
          (char*) &ibuf[inip%V2_INODES_PER_BLOCK], 
          sizeof(d2_inode));
   return inip+1;
}

int put_inode (int outip, d2_inode* ip) {
  d2_inode ibuf[V2_INODES_PER_BLOCK];
  char str[40]; 
  int block = out_first_inode_block + (outip / V2_INODES_PER_BLOCK);
  int b; 

#ifdef DEBUG
  if (read_bit (out_imap, outip) ) {
      sprintf(str, "Put_inode: writing to inode (%d) whose bit is set!\n",
              outip);
      pexit(str,6);
  }
  if (outip <= max_inode_used) { /* Don't need to see those last inodes
  	                          * being written */
    printf("Put_inode: put inode %d (offset %d in block %d)\n",
    	 outip, outip%V2_INODES_PER_BLOCK, block);
  }
  if (outip >= sbo->s_ninodes-1) /* should not go > s_ninodes */   
        printf("Put_inode (mkemptyinode): final inode %d (offset %d block %d)\n",
               outip, outip%V2_INODES_PER_BLOCK, block);
#endif

  b = get_block(out_fd, block, (char*) ibuf);

  memcpy ( (char*) &ibuf [outip%V2_INODES_PER_BLOCK], 
           (char*)ip, sizeof (d2_inode) );

  put_block (out_fd, block, (char*)ibuf, b);

  /* To support mkemptyinode; empty inode's imap bit should be 0 */
  if (read_bit(in_imap, outip))
      set_bit (out_imap, outip); 

  return outip+1;
}


/********************************************************************
 * Panic exit / pexit 
 ********************************************************************/


void pexit (char* errorstring, int errnum) {
#ifdef DEBUG /* Official implementation does not write to stdout */
  printf("\n\nPANIC: ");
  printf(errorstring);
  printf("\n\n");
#endif
  exit(errnum);
}
void panicexit (char* str, int num) {
  pexit (str, num);
} 


/************************************************************************
 * Set / read_bit
 ************************************************************************/
/* Small functions for setting and checking a bit in the inode 
 * (imap) or zmap bitmaps. Simplified from what is done in the 
 * function insert_bit in mkfs.c. They use a word-array there, which
 * I am not sure what the use is of. 
 */

void set_bit (char* bitmap, int bit) {
  int w, s;
  w = bit / ( 8 ); /* find the index into bitmap[] byte-array */
  s = bit % ( 8 ); /* what remains */
  bitmap[w] |= (1 << s); /* is the bit (0-7 to the left) that needs to be 
  			  * turned on */
} /* That's all folks. Don't forget to put_block the bitmap later. */  			  

void turn_off_bit (char* bitmap, int bit) { 
   int w,s;
   w = bit /8;
   s = bit % 8;
   printf("Turn_off_bit (%d) called. Byte was: %d\n",bit,bitmap[w]);
   bitmap[w] &= ~(1 << s); 
   printf("Turned off bit %d in out_imap; byte is now %d\n",bit,bitmap[w]);
}


int read_bit (char* bitmap, int bit) { 
  /* If bit is set to 1: return 1, else: return 0. */
  char a = 0; /* to set as template  */
  int w, s;

  w = bit / 8; /* sizeof (short) ); */
  s = bit % 8; /* sizeof (short) ); */
  a |= (1 << s);  
  if ((bitmap[w] & a) == a) {
     if (bitmap == (char*) out_imap )
       printf("read_bit: bit %d in out_imap is on.\n",bit);
     return 1;
  }
  return 0;
}


/**************************************************************************
 * Get / put_block
 **************************************************************************/

int get_block(int fd, block_t n, char*  buf) { /* Buf to write block in. */
/* derived from mkfs. Read a block. */
struct super_block* s; 
char* str; 
int a=1;

#ifdef DEBUG
  /* consistency check */
  if (fd == in_fd) str = "input fs"; else str = "output fs"; 
  /* first zones are unmarked (?) but keep, among others, inodes */
  if (fd == out_fd) s = sbo; else s = sbi; 
    if (s != 0 && n > s->s_firstdatazone) /* boot and superblock bits appear not set */
      if (! (read_bit (in_zmap, n)) ) {
  	printf ("\ntried get_block on block %d: used bit not set\n",n);
  	 /* Exception  (maybe on indirect blocks?) return 0 for handling. */
        a=0;
      }
  if (s != 0 && n >= s->s_firstdatazone) /* don't want to print for inodes */
    printf("Get_block (%s): getting block %d\n",str,n);
#endif 

  lseek(fd, (off_t) n * BLOCK_SIZE, SEEK_SET);

  /* read call */
  k=0; 
  while (k < BLOCK_SIZE) {
     k += read(fd, buf, BLOCK_SIZE);
     if (k == -1)  /* does posix require return with all len data? */
	pexit("get_block couldn't read",errno);
     if (!k) {
       if (fd == out_fd) { printf("EOF (read failed) on output device\n"); }
       if (fd == in_fd) pexit ("read failed (EOF) on input device",42);
     }
  }
  if (a) return n+1; /* to set in_bp (optionally) */
  else return 0; /* when block read that had not bit on in zmap */
}


int put_block(int fd, block_t n, char* buf, int bit) {
/* Write a block. Derived from mkfs. */

  char* str; 

#ifdef DEBUG
  if (fd == in_fd) str = "input fs"; else str = "output fs";
  if (n >= sbo->s_firstdatazone) { /* avoid msg when reading inode */ 
    printf("Put_block (%s): putting block %d\n",str,n); 
    if (read_bit(out_zmap, n))
       printf("Put_block: putting an already set datablock!\n"); 
  } 
#endif 

  if (lseek(fd, (off_t) n * BLOCK_SIZE, SEEK_SET) == (off_t) -1) {
	pexit("put_block couldn't seek",23);
  }
  if (write(fd, buf, BLOCK_SIZE) != BLOCK_SIZE) {
	pexit("put_block couldn't write",23);
  }

  if (bit) 
     set_bit((char*) out_zmap, n); /* Important to set the bit! */

  /* if input fs has inconsistencies, just copy them. */

  return n+1; /* to (optionally) set out_fd. */
}

/***************************************************************************/
/* STATISTICAL / OUTPUT STUFF (TODO)
 ***************************************************************************/



#define percent(num, tot)  ((int) ((100L * (num) + ((tot) - 1)) / (tot)))

/* One must be careful printing all these _t types. */
#define L(n)	((long) (n))

int statistic(char* path)
{
  int fd;
  bit_t i_count, z_count;
  block_t totblocks, busyblocks;
  
  struct super_block super, *sp;

  fd= open(path, O_RDONLY);
  if ((fd)<= 0) {
	fprintf(stderr, "%s: %s\n", path, strerror(errno));
	return(1);
  }
  lseek((fd), (off_t) BLOCK_SIZE, SEEK_SET);	/* skip boot block */

  if (read((fd), (char *) &super, sizeof(super)) != (int) sizeof(super)) {
	fprintf(stderr, "Can't read super block of %s\n", path);
	close(fd);
	return(1);
  }

  lseek(fd, (off_t) BLOCK_SIZE * 2L, SEEK_SET);	/* skip rest of super block */
  sp = &super;

  if (sp->s_magic != SUPER_V2) {
	fprintf(stderr, "defrag: %s: Not a valid V2 file system\n", path);
	close(fd);
	return(1);
  }
 /* 
  i_count = bit_count(sp->s_imap_blocks, (bit_t) (sp->s_ninodes+1), fd);
  */
  if (i_count == -1) {
	fprintf(stderr, "defrag: Can't find bit maps of %s\n", path);
	close(fd);
	return(1);
  }
  i_count--;	/* There is no inode 0. */

  /* The first bit in the zone map corresponds with zone s_firstdatazone - 1
   * This means that there are s_zones - (s_firstdatazone - 1) bits in the map
   */ /*
  z_count = bit_count(sp->s_zmap_blocks,
	(bit_t) (sp->s_zones - (sp->s_firstdatazone - 1)), fd);
	*/
  if (z_count == -1) {
	fprintf(stderr, "defrag: Can't find bit maps of %s\n", path);
	close(fd);
	return(1);
  }
  /* Don't forget those zones before sp->s_firstdatazone - 1 */
  z_count += sp->s_firstdatazone - 1;

#if !__minix_vmd
  totblocks = (block_t) sp->s_zones << sp->s_log_zone_size;
  busyblocks = (block_t) z_count << sp->s_log_zone_size;
#else
  totblocks = (block_t) sp->s_zones;
  busyblocks = (block_t) z_count;
#endif


  /* Print results. */
  printf("%s", path);


  if (42) {
	printf(" %7ld  %7ld  %7ld %3d%%   %3d%%   %s\n",
		L(totblocks),				/* Blocks */
		L(totblocks - busyblocks),		/* free */
		L(busyblocks),				/* used */
		percent(busyblocks, totblocks),		/* % */
		percent(i_count, sp->s_ninodes) 	/* FUsed% */
	      	);
  }
  if (42) {
	printf(" %7ld  %7ld  %7ld %3d%%   %3d%%   %s\n",
		L(sp->s_ninodes),			/* Files */
		L(sp->s_ninodes - i_count),		/* free */
		L(i_count),				/* used */
		percent(i_count, sp->s_ninodes),	/* % */
		percent(busyblocks, totblocks)		/* BUsed% */
			);
  }
  if (42) {
  	if (42) {
  		/* 512-byte units please. */
  		totblocks *= 2;
  		busyblocks *= 2;
	}
	printf(" %7ld   %7ld  %7ld     %4d%%    %s\n",
		L(totblocks),				/* Blocks */
		L(busyblocks),				/* Used */
		totblocks - busyblocks,			/* Available */
		percent(busyblocks, totblocks)		/* Capacity */
			);
  }
  if (42) {
	printf(" %7ld   %7ld  %7ld     %4d%%    %s\n",
		L(sp->s_ninodes),			/* Inodes */
		L(i_count),				/* IUsed */
		L(sp->s_ninodes - i_count),		/* IAvail */
		percent(i_count, sp->s_ninodes)	/* Capacity */
	);
  }
  close(fd);
  return(0);
}

/*********************************************************************/
void testio(char* path)
{
#define O_RDWR             2	/* open(name, O_RDWR) opens read/write */

#define TESTLOCATION (42)

#define MAG1 0x42
#define MAG2 0x69

short  testblock[BLOCK_SIZE / sizeof(short)];
int fd,nread;

 printf("\n\n");
  fprintf(stderr,"Testing IO");
  printf("\n\n");

/* Open returns fd */

 printf("\n\n");
  fprintf(stderr,"Opening");
  printf("\n\n");
fd=open(path, O_RDWR);
if ((fd)<=0) panicexit("\n Could not target source device\n",3);
        
/* seek to first block */ 
printf("\n\n");
  fprintf(stderr,"Seeking");
  printf("\n\n");
lseek(fd, (off_t) (TESTLOCATION) * BLOCK_SIZE, SEEK_SET);
        
testblock[0] = MAG1;
testblock[1] = MAG2;

/* write testdata */
printf("\n\n");
  fprintf(stderr,"Write testdata");
  printf("\n\n");
if (write(fd, (char *) testblock, BLOCK_SIZE) != BLOCK_SIZE)
                panicexit("Write Error",2);
        
        
testblock[0] = 0;
testblock[1] = 0;

/* sync();    clear cache */                    

lseek((fd), (off_t) (TESTLOCATION) * BLOCK_SIZE, SEEK_SET);
printf("\n\n");
  fprintf(stderr,"Reading");
  printf("\n\n");
nread = read((fd), (char *) testblock, BLOCK_SIZE);

        
if (nread != BLOCK_SIZE || testblock[0] != MAG1 || testblock[1] != MAG2)
    panicexit("Read error",1);
        
/* clean up */
lseek(fd, (off_t) (TESTLOCATION) * BLOCK_SIZE, SEEK_SET);
testblock[0] = 0;
testblock[1] = 0;
if (write(fd, (char *) testblock, BLOCK_SIZE) != BLOCK_SIZE)
		panicexit("Write error",2);
lseek(fd, 0L, SEEK_SET);
 panicexit("Everything is going extremly well!",0);
}
/**************************************************/
/* END. */

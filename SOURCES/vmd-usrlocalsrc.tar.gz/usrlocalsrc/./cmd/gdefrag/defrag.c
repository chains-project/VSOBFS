/* defrag.c, v8 */
/* (c) Ruediger Weis, 2003 under GPL!-) */
/***************************************************************/
/* Headers */
/* Minix */

/* Works ok, but still may have some problems with holes. 
 * Not important at this stage - just avoid compacting fs-es with files
 * that contain holes (e.g., core dumps). I'll fix it later (Guido).  
 * 
 * -n mode is very convenient - you can use it to compare a student's input
 * and output filesystem's bitmaps, which contain the most common errors 
 * (e.g., off by one errors). 
 * Do defrag -n inputfs 1>out1
 * defrag -n outputfs 1>out2 
 * and compare the output-files. 
 * (may be useful to copy the defrag binary onto a floppy to take with 
 * you to the students. Don't leave it behind - ever !!!!!!!!! )
 * 
 * Inode bitmaps of input-fs and output-fs should be exactly the same ,
 * visual compare is typically easy since each line contains only 16 bits. 
 * Zone bitmaps should have the same number of used zones, but the output-
 * fs should be contiguous, so the last zone should be s_firstdatazone +
 * number of used zones. See the comment in the output-file, it is self-
 * explanatory. 
 */


#include "defrag.h"
/* #include "defraglinux.h"  */

#define DEBUG /* turn on debugging output */ 
#undef DEBUG 

/* Prototypes */

void panicexit(char* errorstring, int errnum);

int nulldev = 0; /* is 1 if 'null' (no) output-device. */

/* Global var*/
block_t in_bp;  /* input block pointer (unsigned long!)*/
block_t out_bp; /* output block pointer */

char* input_devnam;
char* output_devnam;

int in_fd; /* fd for input device */
int out_fd; /* fd for output device */

struct super_block* sbo; /* to store copy of superblock of input device */
struct super_block* sbi; /* will contain  superblock of input device */

char buf[BLOCK_SIZE]; /* scratch buffers - to use at will. */
char buf1[BLOCK_SIZE];
char buf2[BLOCK_SIZE];
char buf3[BLOCK_SIZE]; /* we need a lot for double indirect loop.. */
char buf4[BLOCK_SIZE]; 

char* in_imap; /* inode bitmap */ 
char* in_zmap; /* zone (==block) bitmap */
char* out_imap; /* idem for output device */
char* out_zmap;

int out_imap_start_block;
int in_first_inode_block;
int out_first_inode_block;

/* The first inode should be there but is not used. However, 
 * it appears crucial to copy it explicitly (?) */
int in_inodes_used = 0;
int out_inodes_used = 0;
int in_zones_used = 0;
int out_zones_used = 0;
int max_inode_used = 0; /* to check if output fs has enough inodes avail */


/********************************************************************
 * Panic exit / pexit 
 ********************************************************************/


void pexit (char* errorstring, int errnum) {
/* #ifdef DEBUG * Official implementation does not write to stdout */
  printf("\n\nPANIC: ");
  printf(errorstring);
  printf("\n\n");
/* #endif */
  exit(errnum);
}
void panicexit (char* str, int num) {
  pexit (str, num);
} 




/***************************************************************************/
/* STATISTICAL / OUTPUT STUFF (TODO)
 ***************************************************************************/



void display_some ( ) { /* Displays some info */
  int i,a; 
  int zonecount1=0; 
  int zonecount2=0;
  int lastsetzone1, lastsetzone2; 
  int inocount1 = 0; 
  int inocount2 = 0;
  int lastusedino1, lastusedino2; 

  printf("\n");
  printf("Input FS: max no of inodes that can be used: %d\n",
	 sbi->s_ninodes);
  printf("Input FS: inodes in use: %d\n",in_inodes_used);
  printf("Input FS: zones (blocks) in use: %d\n",in_zones_used);
  printf("First datazone of input device: %d\n",sbi->s_firstdatazone);

  printf("\nInput filesystem inode bitmap:\n");
  for (i=0; i<=sbi->s_ninodes; i++) {
    if ((i % V2_INODES_PER_BLOCK) == 0) {
      if (inocount1 == in_inodes_used)
        break;
      printf("\nInode %4d - %4d:",i, i+V2_INODES_PER_BLOCK-1); 
    }
    printf(" %d",read_bit(in_imap, IMAP, i));
    if (read_bit (in_imap, IMAP, i)) {
       inocount1++; lastusedino1 = i; 
    }
    
  }
  printf("\nSkipping rest of inodes (should be empty). Checking.)\n");
  for (; i<=sbi->s_ninodes; i++)
     if (read_bit(in_imap, IMAP, i))
         printf("Error: inode %d's bit found 1 (should be 0)\n",i); 
  printf("Inodes used (excluding ino 0): %d, last inode used: %d\n", 
          inocount1-1, lastusedino1); 
  printf("\n");
  
    
  /* Note: s_ninodes = 4 means that 5 bits will be on the disk: 
   * bit 0 (unused byt set) and bits 1-4 for files and directories. 
   */
  
  printf("\nInput FS zone bitmap:\n");

  for (i=sbi->s_firstdatazone; i<=sbi->s_zones+sbi->s_firstdatazone; i++) {
    if (((i-sbi->s_firstdatazone) %  V2_INODES_PER_BLOCK) == 0) {
        if (zonecount1 == in_zones_used)
            break;
    	printf("\nZones %5d - %5d:",i, i+V2_INODES_PER_BLOCK-1);
     } 
     printf(" %d",read_bit(in_zmap, ZMAP, i));
     if (read_bit(in_zmap, ZMAP, i)) { 
        zonecount1++; lastsetzone1 = i; 
     } 
  }
  printf("\nSkipping remainder of zones (should be empty). Checking.\n"); 
  for (; i<= sbi->s_zones + sbi->s_firstdatazone; i++)
  	if (read_bit (in_zmap, ZMAP, i))
  	   printf("Error: bit of zone %d in in_zmap is 1. Should be 0.\n",i);  
  printf("Zones used: %d, last zone used: %d\n",
          zonecount1, lastsetzone1); 
  printf("Difference between first and last datazone (+1): %d\n",
         lastsetzone1 - sbi->s_firstdatazone+1); 
  printf("Difference should be equal to Zones used after defrag!\n");  
  printf("\n");

  if (!nulldev) { /* Then it makes sense to display output-dev info */
    printf("\nOutput-FS zone bitmap:\n"); 

    for (i=sbo->s_firstdatazone; i<=sbo->s_firstdatazone + sbo->s_zones; i++){
      if (((i-sbo->s_firstdatazone)%V2_INODES_PER_BLOCK) == 0) {
         if (zonecount2 == in_zones_used)
            break;
         printf("\nZones %5d - %5d:", i, i+V2_INODES_PER_BLOCK-1); 
      }
      printf(" %d", read_bit(out_zmap, ZMAP, i));
      if (read_bit(out_zmap, ZMAP, i)) {
         zonecount2++; lastsetzone2 = i;
      }
    }
    printf("\nSkipped remainder of zones (should be unused). Checking.)\n"); 
    for (; i<=sbo->s_firstdatazone + sbo->s_zones; i++)
       if (read_bit (out_zmap, ZMAP, i))
          printf("Error: bit of zone %d is 1, should be 0!\n",i); 

    printf("Zones used in output-fs: %d, last zone used: %d\n",
    	zonecount2, lastsetzone2); 
    printf("Difference between first and last datazone (+1): %d\n",
           lastsetzone2 - sbo->s_firstdatazone+1);
    printf("Difference should be equal to Zones used after defrag!\n"); 

    printf("\n");

    printf("\nOutput FS inode bitmap:\n");

    for (i=0; i<=sbo->s_ninodes; i++) {
      if ((i % V2_INODES_PER_BLOCK) == 0) {
        if (inocount2 == in_inodes_used) 
          break; 
	printf("\nInode %4d - %4d:",i, i+V2_INODES_PER_BLOCK-1);
      } 
      printf(" %d",read_bit(out_imap, IMAP, i));
      if (read_bit(out_imap, IMAP, i)) {
          inocount2++; lastusedino2 = i; 
      } 
    }
    printf("\nSkipped remainder of inodes (should be empty). Checking.\n"); 

    for (; i<=sbo->s_ninodes; i++)
      if (read_bit(out_imap, IMAP, i))
	printf("Error: bit %d in output-imap is 1, should be 0!\n",i);

    printf("Inodes used (excluding ino 0): %d, last inode used: %d\n",
            inocount2 -1, lastusedino2);     
    printf("All output-fs imap-bits up to and including %d are there.\n\n",i);
  } /* !nulldev */

} 

/*************************************************************************
 * Read / put_inode
 *************************************************************************/

/* Kees says: compute block that ino lives in: inode 1 is first in block 0! */

int read_inode (int inip, d2_inode* ip) {
   d2_inode ibuf[V2_INODES_PER_BLOCK];

#ifdef DEBUG
   if (!read_bit(in_imap, IMAP, inip)) /* pexit? */
     pexit("Read_inode inconsistency: read inode whose bit is not set.",6);

    printf("\nRead_inode: inode %d supposed to be in zone %d, offset %d\n",
           inip, in_first_inode_block + ((inip-1)/V2_INODES_PER_BLOCK),
           (inip-1)%V2_INODES_PER_BLOCK);
#endif
   get_block(in_fd, in_first_inode_block + ((inip-1) / V2_INODES_PER_BLOCK), 
            (char*) ibuf);

   memcpy((char*) ip, 
          (char*) &ibuf[(inip-1)%V2_INODES_PER_BLOCK], 
          sizeof(d2_inode));
   return inip+1;
}

int put_inode (int outip, d2_inode* ip) {
  d2_inode ibuf[V2_INODES_PER_BLOCK];
  char str[40]; 
  int block = out_first_inode_block + ((outip-1) / V2_INODES_PER_BLOCK);
  int b; 

  if (read_bit (out_imap, IMAP, outip)  && outip > 2 ) {
      sprintf(str, "Put_inode: writing to inode (%d) whose bit is set!\n",
              outip);
      pexit(str,6); 
  }
#ifdef DEBUG
  if (outip <= max_inode_used) { /* Don't need to see those last inodes */
    printf("Put_inode: put inode %d (offset %d in block %d)\n",
    	 (outip-1), (outip-1)%V2_INODES_PER_BLOCK, block);
  }
  /* mkemptyinode depricated..
   * if (outip >= sbo->s_ninodes-1) * should not go > s_ninodes *   
   * printf("Put_inode (mkemptyinode): final inode %d (offset %d block %d)\n",
   * (outip-1), (outip-1)%V2_INODES_PER_BLOCK, block);
   */
#endif

  if (!get_block(out_fd, block, (char*) ibuf)) {
    printf("Problem getting block %d\n",block);
    pexit ("put_inode",6);
  } 

  memcpy ( (char*) &ibuf [(outip-1)%V2_INODES_PER_BLOCK], 
           (char*)ip, sizeof (d2_inode) );

  put_block (out_fd, block, (char*)ibuf);

  /* To support mkemptyinode; empty inode's imap bit should be 0 */
  /*  if ( (outip <= sbi->s_ninodes) && (read_bit(in_imap, IMAP, outip)) )
   *   set_bit (out_imap, IMAP, outip); 
   */

  if (!read_bit(in_imap, IMAP, outip))
  	pexit ("Consistency error (put_inode): inode bit not set in inp-fs",6); 

  set_bit(out_imap, IMAP, outip); 

  return outip+1;
}


/************************************************************************
 * Set / read_bit
 ************************************************************************/
/* Small functions for setting and checking a bit in the inode 
 * (imap) or zmap bitmaps. Simplified from what is done in the 
 * function insert_bit in mkfs.c. They use a word-array there, which
 * I am not sure what the use is of. 
 * Remark: on little endian (pentium) machine both byte as word
 * addressing / buffers work!
 */

void set_bit (char* bitmap, int map, int bit) {
  int w, s;
  bitchunk_t* bbuf = (bitchunk_t *) bitmap; 

  if (map == ZMAP) { /* Test this without -1 (off by one) Gives const err. */
    if (bitmap == in_zmap)
      bit -= (sbi->s_firstdatazone -1); /*  +1; */ 
    else 
      bit -= (sbo->s_firstdatazone -1); 
  }
  if (bit < 0)
    pexit("Internal consistency error: bit to set smaller than 0",7);

  w = bit / (8* sizeof(bitchunk_t));  /* index into bitmap[] byte-array */
  s = bit % (8* sizeof(bitchunk_t));  /* what remains */

  bbuf[w] |= (1 << s);  /* s is the bit that needs to be turned on */

} /* That's all folks. Don't forget to put_block the bitmap later. */  


int read_bit (char* bitmap, int map, int bit) { 
  /* If bit is set to 1: return 1, else: return 0. */
  bitchunk_t a = 0; /* to set as template  */ 
  int w, s;
  bitchunk_t* bbuf = (bitchunk_t*) bitmap; 

  if (map == ZMAP) {
    if (bitmap == in_zmap)
      bit -= (sbi->s_firstdatazone -1); /*  +1; */ 
    else 
      bit -= (sbo->s_firstdatazone -1); 
  }
  if (bit < 0)
    pexit ("Internal consistency - bit to read smaller than zero",7); 

  w = bit / (8*sizeof(bitchunk_t));
  s = bit % (8*sizeof(bitchunk_t));  

  /* return ((a >> s) & 1); is also valid.. */

  a |= (1 << s); 
  if ((bbuf[w] & a) == a) { 
     /* if (bitmap == (char*) out_imap ) */
      /* printf("read_bit: bit %d in out_imap is on.\n",bit); */
     return 1;
  }
  return 0;
}


/**************************************************************************
 * Get / put_block
 **************************************************************************/

int get_block(int fd, block_t n, char*  buf) { /* Buf to write block in. */
/* derived from mkfs. Read a block. */
struct super_block* s; 
char* str; 
int a=1;
int k;

#ifdef DEBUG
  if (fd == in_fd) 
    str = "input fs"; else str = "output fs"; 
#endif
  if (fd == out_fd) 
    s = sbo; 
  else 
    s = sbi;
#ifdef DEBUG 
  if (n >= s->s_firstdatazone) /* don't want to print for inodes */
  /*  printf("Get_block (%s): getting block %d\n",str,n); */ 
#endif 

  if (n >= s->s_firstdatazone) { /* avoid problems here */ 
  /* consistency check */
     if (! (read_bit (in_zmap, ZMAP, n)) ) 
        pexit ("Reading block whose bit is not set. Run fsck",6); 
        /* return 0; * Exception - handled by caller for verbosity. */
  }
  lseek(fd, (off_t) n * BLOCK_SIZE, SEEK_SET);

  /* read call */
  k=0; 
  while (k < BLOCK_SIZE) {
     k += read(fd, buf, BLOCK_SIZE);
     if (k == -1) 
       pexit("get_block couldn't read",7); /* E_GENERIC? */
     if (!k) {
       if (fd == out_fd) pexit("EOF (read failed) on output device",42); 
       if (fd == in_fd) pexit ("read failed (EOF) on input device",42);
     }
  }
  return n+1; /* to set in_bp (optionally) */
}


int put_block(int fd, block_t n, char* buf) {
/* Write a block. Derived from mkfs. */
  char* str; 
  char str1[80]; 

#ifdef DEBUG
  if (fd == in_fd) str = "input fs"; else str = "output fs";
  if (n >= sbo->s_firstdatazone) { /* avoid msg when reading inode */ 
   /*  printf("Put_block (%s): putting block %d\n",str,n); */ 
  } 
#endif  
  /* Consistency check. Beware of unused first block + used root-directory 
   * in output-fs. */
  if ((n >= sbo->s_firstdatazone+2) && read_bit(out_zmap, ZMAP, n)) {
    sprintf(str1,"Put_block: putting already set datablock %d !",n); 
    pexit(str1,6); /* inconsistency */
  }

  if (lseek(fd, (off_t) n * BLOCK_SIZE, SEEK_SET) == (off_t) -1) {
	pexit("put_block couldn't seek",7);
  }
  if (write(fd, buf, BLOCK_SIZE) != BLOCK_SIZE) {
	pexit("put_block couldn't write",7);
  }
  if (n >= sbo->s_firstdatazone) /* avoid problems putting system blocks */ 
    set_bit(out_zmap, ZMAP, n); /* Important to set the bit! */

  return n+1; /* to (optionally) set out_fd. */
}



/************************************************************************
 * Copy_file
 ************************************************************************/

/* This function walks, given a given inode number, through all the
 * direct and indirect blocks, and copies the file block by block in 
 * a sequential order to the output device. 
 * The function increases the in_ip and out_ip and the block 
 * numbers automatically. TODO Statistics.  */

void copy_file (int inip) {
  int frag,o; 
  d2_inode *ip = malloc (sizeof(d2_inode)); 
  d2_inode *ip2 = malloc (sizeof(d2_inode)); 
  int b,b1,b2,i,j,k,l,m,n; /* for bit */
  char str[80]; 

  block_t ibuf[V2_INDIRECTS];  /* Avoid casting problems between char and */
  block_t ibuf1[V2_INDIRECTS]; /* block_t arrays. */
  block_t ibuf2[V2_INDIRECTS]; 
  block_t ibuf3[V2_INDIRECTS];
  block_t ibuf4[V2_INDIRECTS]; 
 
  read_inode (inip, ip);
  if (ip == NULL) pexit ("NULL returned by read_inode",1);

  /* First a few checks: we only want to copy the blocks of regular 
   * files and directories. If I am correct (?), char / block special 
   * files or named pipe inodes never point to a block.
   */
   if ( ip->d2_mode  == I_NOT_ALLOC ) 
     pexit("Input filesystem inconsistency (I_NOT_ALLOC)",6);  
  
  switch (ip->d2_mode & I_TYPE) {
 /* case ((mode_t) 0120000): * important to evaluate before I_REG / DIR! */
  /*  goto skip1; */ 
  case I_REGULAR: 
  case I_DIRECTORY:
	break;  
  default: /* e.g., I_CHAR_SPECIAL, I_NAMED_PIPE, whatever else */
    put_inode (inip, ip);
    free (ip); free (ip2); 
    return;
  } 
 skip: /* file is regular or directory inode. Copy the blocks. */

  memcpy ((char*) ip2, (char*)ip, sizeof(d2_inode));
  
#ifdef DEBUG
  if (ip2->d2_mode & I_DIRECTORY) printf ("Copying directory ");
  if (ip2->d2_mode & I_REGULAR)   printf ("Copying file with ");
  if (ip2->d2_mode & ((mode_t) 0120000)) printf("LINK!!!!");  
  printf("owner %d, gid %d, size %d, ctime %s and mtime %s\n",
          ip->d2_uid, ip->d2_gid, ip->d2_size, ctime(&ip->d2_ctime),
          ctime(&ip->d2_mtime));
#endif

  /* Initialize the target-ip. */
  for (i=0; i< V2_NR_TZONES; i++) ip2->d2_zone[i] = NO_ZONE;

  for (i=0; i<V2_NR_DZONES; i++) {  /* Copy the direct blocks first */
     if (ip->d2_zone[i] != NO_ZONE) {
     	if (!get_block (in_fd, ip->d2_zone[i], buf)) {
     	  sprintf(str,
		  "Direct block %d in input-fs marked NOT USED\n",
		  ip->d2_zone[i]);
	  pexit(str,6);
	}
     	ip2->d2_zone[i] = out_bp;
     	out_bp = put_block (out_fd, out_bp, buf); 
     }
     else ip2->d2_zone[i] = NO_ZONE;  
  }

  if (ip->d2_zone[V2_NR_DZONES] != NO_ZONE) {
     /* There is a single indirect block */

     /* In my test on the fs that is in 'inputfs-dump', an inconsistency 
      * occurs. fsck on inputfs reveals no problems.. A particular 
      * block bit was not set.. How come?
      * It appeared that the direct blocks used where up and including 119,
      * and the indirect block pointed to was 121 - so inconsistency in 
      * input-fs? Observation: fs allocates first the datablock that the
      * indirect block points to (the first one), then the indirect block, 
      * and then the rest of the blocks that the indirect block points to..!?! 
      */

     if (!get_block (in_fd, ip->d2_zone[V2_NR_DZONES], (char*)ibuf)) { 
         sprintf(str,"Indirect block %d in input-fs marked not used",
          	ip->d2_zone[V2_NR_DZONES]); 
         pexit (str,6);
     } 
#ifdef DEBUG
     printf("Copied indirect block (inode %d). Content:\n",inip);
     for (i=0; i<V2_INDIRECTS; i++) 
           printf("block %d\n",ibuf[i]);
#endif

     ip2->d2_zone[V2_NR_DZONES] = out_bp; /* reserve out_bp for ind. block */
     out_bp++;

     for (i=0; i<V2_INDIRECTS; i++) /* ibuf3 will contain output indirect */
     	ibuf3[i] = NO_ZONE; 

     for (i=0; i< V2_INDIRECTS; i++) {
         if (ibuf[i] != NO_ZONE) { 
            if (!get_block(in_fd, ibuf[i], buf2)) {        
	       sprintf(str,
		    " Input-fs block %d pointed to by ind block marked NOT USED",
		    ibuf[i]);
	        pexit(str,6);
	     }
	     ibuf3[i] = out_bp;  /* output indirect block */
             out_bp = put_block (out_fd, out_bp, buf2); 
          } /* if */
          else  
            ibuf3[i] = NO_ZONE; /* THIS WAS THE BUG - when not there.. */
      } /* for */ 
      put_block (out_fd, ip2->d2_zone[V2_NR_DZONES], (char*)ibuf3);
  }

  /* and now for the really big stunt... */
  /* TODO Second indirect (not scrutinized or tested yet) */

  if (ip->d2_zone[V2_NR_DZONES +1] != NO_ZONE) { /* darn..*/
#ifdef DEBUG
    printf("Double indirect\n");
#endif
    if (!get_block (in_fd, ip->d2_zone[V2_NR_DZONES+1], (char*)ibuf)) {       
      sprintf(str,
	      "Input FS: double indirect intermediate block %d marked NOT USED",
	      ip->d2_zone[V2_NR_DZONES+1]);
      pexit(str,6);
    }
    /* ibuf contains the input intermediate block */
    ip2->d2_zone[V2_NR_DZONES+1] = out_bp;
    out_bp++; /* reserve space to store the intermediate block (ibuf1) */

    for (i=0; i<V2_INDIRECTS; i++) {
       ibuf1[i] = NO_ZONE;
    }

    for (i=0; i<V2_INDIRECTS; i++) {
      if (ibuf[i] != NO_ZONE) { /* ibuf contains intermediate block */
	/* Note: students should not break here: holes allowed (?) */
	if (!get_block (in_fd, ibuf[i], (char*) ibuf2)) { /* second indirect */ 
	  sprintf(str,
		  "Input FS: second indirect block %d marked NOT USED",
		  ibuf[i]);
	  pexit(str,6); 
	}
	/* ibuf2 contains the input-second indirect block */
	ibuf1[i] = out_bp; /* ibuf1 is intermediate block */
	out_bp++; /* reserve space for it */

	for (j=0; j<V2_INDIRECTS; j++)
	   ibuf4[j] = NO_ZONE; 

	for (j=0; j<V2_INDIRECTS; j++) {
          if (ibuf2[j] != NO_ZONE) { 
	    if (!get_block (in_fd, ibuf2[j], buf3)) {  
	      sprintf(str,
		      "Input FS: 2nd ind data-block %d marked NOT USED",
		       ibuf2[j]);
	      pexit(str,6); 
	    }
	    ibuf4[j] = out_bp; /* ibuf4 is double indirect block */
	    out_bp = put_block (out_fd, out_bp, buf3); 
          } 
          else 
            ibuf4[j] = NO_ZONE; /* also valid (no memset needed) */ 
        }
#ifdef DEBUG
        printf("Content of output double indirect block:\n");
        for (n=0; n<V2_INDIRECTS; n++)
	   printf("block %d\n",ibuf4[n]); 
#endif
        put_block (out_fd, buf1[i], (char*)ibuf4);
      }
      else 
    	ibuf1[i] = NO_ZONE; 
    } 
#ifdef DEBUG
    /* We have followed all second indirects - intermediate is ready */
    printf("Content of output intermediate block:\n"); 
    for (n=0; n<V2_INDIRECTS; n++)
    	printf("block %d\n",ibuf1[n]); 
#endif
    put_block(out_fd, ip2->d2_zone[V2_NR_DZONES+1], (char*) ibuf1);

  } /* if ip->d2_zone[V2_NR_DZONES+1] != NO_ZONE */
  
  /* We've handled direct, single indirect, and double indirect */
  
#ifdef DEBUG
  printf("\nEnd of copy_file; writing inode %d\n",inip);
#endif

  put_inode (inip, ip2);
  
  free (ip);
  free (ip2);
}




/***********************************************************************
 * Main
 ***********************************************************************/

int main (int argc, char** argv) {
  int b, b1, i, j, k,l,m,n;
  if (argc != 3) {
    printf ("Usage: defrag <oldfs> <newfs>\n");
    printf ("or:    defrag -n <fs> for displaying fs-data only.\n"); 
    exit (1); 
  }
  input_devnam = argv[1];
  output_devnam = argv[2];

  if (!strcmp(input_devnam,"-n")) {
    input_devnam = output_devnam; 
    nulldev = 1;                           
  }
  else 
    nulldev = 0;

  in_fd = open (input_devnam, O_RDONLY);
  if (in_fd <= 0) 
    pexit("Could not open input device",3);

  if (!nulldev) {
     out_fd = open (output_devnam, O_RDWR); 
     if (out_fd <= 0) 
       pexit ("could not open output device",3); 
  }

  /* Bypass bootblock and read superblock of input device and output device */
  /* Blockpointers of input and output device should be set to 2 for both 
   * devices after this, which is the block where the inode bitmap starts.
   * get_block returns the second argument incremented with one. */

  in_bp = get_block(in_fd, 1, buf);    /* Read out block 1 (second block) */
  sbi = malloc(sizeof(struct super_block));
  memcpy((void*) sbi, (void*) buf, sizeof(struct super_block)); /* copy super */
  if (sbi->s_magic != SUPER_V2) 
   pexit("oldfs is not a Minix V2 filesystem",2);

  /* Get the inode and block bitmaps */
  /* Input fs: */
  i = sbi->s_imap_blocks;
  j = sbi->s_zmap_blocks;

  /* Read IMAP / ZMAP blocks into memory */
  in_imap = malloc (i * BLOCK_SIZE); 
  in_zmap = malloc (j * BLOCK_SIZE);
  
  for (i=0; i<sbi->s_imap_blocks; i++)
  	in_bp = get_block (in_fd, in_bp, &in_imap[i*BLOCK_SIZE]); 

  for (i=0; i<sbi->s_zmap_blocks; i++) 
         in_bp = get_block (in_fd, in_bp, &in_zmap[i*BLOCK_SIZE]);

  in_first_inode_block = in_bp;
  in_bp = sbi->s_firstdatazone;

  
  if (nulldev) { /* testing / statistics-only  mode */
    /* Set some globals to fool our program */
    /* maybe some are not strictly needed. There is not output device. */ 
    printf("Inspection mode (null output device)\n"); 
    out_bp = in_bp; 
    sbo = sbi;
    /* Truly empty output-fs */
    out_imap = malloc (sbi->s_imap_blocks * BLOCK_SIZE); 
    out_zmap = malloc (sbi->s_zmap_blocks * BLOCK_SIZE); 
    memset (out_imap, 0, sbi->s_imap_blocks * BLOCK_SIZE); 
    memset (out_zmap, 0, sbi->s_zmap_blocks * BLOCK_SIZE); 
    out_imap_start_block = 2; /* Block just after boot and super block */
    out_first_inode_block = in_first_inode_block;  
  }
  else  {
    out_bp = get_block(out_fd, 1, buf2); 
    out_imap_start_block = out_bp;

    sbo =  malloc (sizeof (struct super_block)); 
    memcpy((void*) sbo, (void*) buf2, sizeof(struct super_block)); 
    
    if (sbo->s_magic != SUPER_V2) 
      pexit("newfs is not a Minix V2 filesystem",2);
    
    i = sbo->s_imap_blocks; 
    j = sbo->s_zmap_blocks;   
    out_imap = malloc (i* BLOCK_SIZE);
    out_zmap = malloc (j* BLOCK_SIZE);
    for (i=0; i<sbo->s_imap_blocks; i++)
         out_bp = get_block (out_fd, out_bp, &out_imap[i*BLOCK_SIZE]); 
    for (i=0; i<sbo->s_zmap_blocks; i++)  
         out_bp = get_block (out_fd, out_bp, &out_zmap[i*BLOCK_SIZE]);
    
    /* Now notate somewhere where the inode blocks begin. They start just
     * after the zone-bitmaps, so this is the place to store those
     * values */ 
    
    out_first_inode_block = out_bp;
    out_bp = sbo->s_firstdatazone;

  } /* !nulldev */

  /* check some sizes. How many inodes / zones are in use? */
  for (i=0; i<= sbi->s_ninodes; i++)   
    if (read_bit (in_imap, IMAP, i) ) 
      { in_inodes_used++; max_inode_used = i; }
   
  for (i=sbi->s_firstdatazone; i<sbi->s_zones+sbi->s_firstdatazone; i++) 
    if (read_bit (in_zmap, ZMAP, i) ) /* zone (block) used */
      in_zones_used++;
  for (i=0; i<=sbo->s_ninodes; i++)
    if (read_bit (out_imap, IMAP, i) ) 
      out_inodes_used++;
  for (i=sbo->s_firstdatazone; i<sbo->s_zones+sbo->s_firstdatazone; i++)
    if (read_bit (out_zmap, ZMAP, i) )
      out_zones_used++;

  if (!nulldev) { 
    if (out_inodes_used > 2) {/* unused first inode + root-inode */
      printf("Inodes in use: %d\n",out_inodes_used); 
      pexit ("Output fs not empty (inodes in use)",4); 
    } 
    if (out_zones_used > 2) /* There is an 'unused' block and the root-dir */
      pexit ("Output fs is not empty (too many blocks in use)",4);
  }

  /* Now we are about past the initialization phase. The block pointers are
   * set at the first empty blocks (in_bp and out_bp). The inode pointers
   * (in_ip and out_ip) were already initialized to 1 (inode 0 is unused). 
   * Now we should be about able to iterate through the inode table, and
   * copy the blocks that belong to each inode to the output filesystem. 
   */
  
  /* iterate through input-FS'es inode table, copy each file whose
   * inode-bit is set. 
   */
  if (!nulldev) {   
   /* inode 1 is first (index 0) in inode-list */
    for (m=1; m <= sbi->s_ninodes; m++) { 
      if (read_bit (in_imap, IMAP, m) ) 
    	   copy_file (m);    
      /* else mkemptyinode(m); */ /* fill the empty output slots */
    }

    /* Write the output-FS bitmaps */

    j = out_imap_start_block;
    for (i=0; i< sbo->s_imap_blocks; i++) 
       j = put_block(out_fd, j, &out_imap[i*BLOCK_SIZE]);
    for (i=0; i< sbo->s_zmap_blocks; i++) 
       j = put_block (out_fd, j, &out_zmap[i*BLOCK_SIZE]); 
  } /* if !nulldev */

  close (in_fd);
  close (out_fd);

  display_some(); 

  if (!nulldev) {
    printf("Defragmented filesystem written to %s\n",output_devnam); 
  }

  printf("\nDone\n");

  return 0; 
}


/* END. */

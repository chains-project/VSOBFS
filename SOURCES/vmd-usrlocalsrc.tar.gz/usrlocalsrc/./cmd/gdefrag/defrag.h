#include <sys/types.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <limits.h>
#include <errno.h>
#include <time.h> /* ctime et al */
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
/* Regular minix headers */
#include <minix/config.h>
#include <minix/const.h>
#include <minix/type.h>

/* Include minix fs-headers for definitions of various fs datastructures */
#undef EXTERN
#define EXTERN /* get rid of extern by making it NIL */
/* Avoid problems defining printf (it is defined to printk in const.h) */
#undef printf
#include "/usr/src/fs/const.h"
#include "/usr/src/fs/type.h"
#include "/usr/src/fs/super.h"

#undef printf /* define printf to normal printf */ 
#include <stdio.h>




/*	genwordptr - Generate wordptr.h with typedefs for int1, intw, intp ...
 *							Author: Kees J. Bot
 *								23 Sep 2000
 */
#define nil ((void*)0)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static struct type {
	char	*sname;
	char	*uname;
	char	*fmt;
	int	size;
} inttype[] = {
  {	"signed char",	"unsigned char",	"X",	sizeof(char)	},
  {	"short",	"unsigned short",	"X",	sizeof(short)	},
  {	"int",		"unsigned",		"X",	sizeof(int)	},
  {	"long",		"unsigned long",	"lX",	sizeof(long)	},
#if __GNUC__
  {	"__typeof(__extension__(0LL))",
	"__typeof(__extension__(0ULL))",  "llX",  sizeof(__extension__(0LL)) },
#endif
}, flttype[] = {
  {	"float",	nil,			"g",	sizeof(float)	},
  {	"double",	nil,			"g",	sizeof(double)	},
  {	"long double",	nil,			"lg",	sizeof(long double) },
};

static struct type *intof(int size)
{
    int i;

    for (i= 0; i < sizeof(inttype)/sizeof(inttype[0]); i++) {
	if (inttype[i].size == size) return &inttype[i];
    }
    return nil;
}

static struct type *fltof(int size)
{
    int i;

    for (i= 0; i < sizeof(flttype)/sizeof(flttype[0]); i++) {
	if (flttype[i].size == size) return &flttype[i];
    }
    return nil;
}

int main(void)
{
    int i, s;
    unsigned u;
    unsigned long map;

    /* Basic requirements for the interpreter. */
    i= -1;
    u= -1;
    if (sizeof(i) != sizeof(u)) {	/* I don't think C allows this... */
	fprintf(stderr, "Signed and unsigned types are not the same size.\n");
	exit(1);
    }
    if (memcmp(&i, &u, sizeof(u)) != 0) {
	fprintf(stderr, "This doesn't seem to be a two's complement machine\n");
	exit(1);
    }
    if ((i <<= 1) != -2) {
	fprintf(stderr, "(-1 << 1) != -2\n");
	exit(1);
    }
    if ((i >>= 1) != -1) {
	fprintf(stderr, "(-2 >> 1) != -1\n");
	exit(1);
    }
    if ((unsigned char) -1 != 0xFF) {
	fprintf(stderr, "Bytes must be exactly 8 bits\n");
	exit(1);
    }
    if (sizeof(float) != 4) {
	fprintf(stderr, "Type 'float' must be 4 bytes\n");
	exit(1);
    }
    if (sizeof(double) != 8) {
	fprintf(stderr, "Type 'double' must be 8 bytes\n");
	exit(1);
    }

    /* Emit definitions for the word and pointer types. */
    printf("/* Generated type definitions for CC=" CC " */\n");

    for (i= 0; i < 2; i++) {
	char *el= "";

	printf("\n");
	for (s= sizeof(short); s <= sizeof(long); s <<= 1) {
	    if (intof(s) == nil) {
		fprintf(stderr,
		    "genwordptr: Can't find a C integer type of size %d\n", s);
		exit(1);
	    }
	    printf("#%sif %c == %d\n", el, "WP"[i], s);
	    el= "el";
	    printf("typedef %s int%c;\n", intof(s)->sname, "wp"[i]);
	    printf("typedef %s uns%c;\n", intof(s)->uname, "wp"[i]);
	    printf("#define Pr%c \"%%0%d%s\"\n", "WP"[i], s*2, intof(s)->fmt);
	    if (i == 0 && intof(s*2) != nil) {
		printf("typedef %s intdw;\n", intof(s*2)->sname);
		printf("typedef %s unsdw;\n", intof(s*2)->uname);
		printf("#define PrDW \"%%0%d%s\"\n", s*2*2, intof(s*2)->fmt);
	    }
	    if (i == 0 && intof(s*2) == nil) {
		printf("typedef struct { %s _[2]; } unsdw;\n", intof(s)->uname);
		printf("#define PrDW \"%%0%d%s_%%0%d%s\"\n",
			s*2, intof(s)->fmt, s*2, intof(s)->fmt);
	    }
	}
	printf("#else\n#error No type for size %c\n#endif\n", "WP"[i]);
    }

    printf("\n");
    map= 0;
    for (s= 1; s < 0x1000; s <<= 1) {
	if (intof(s) == nil) continue;
	printf("typedef %s int%d;\n", intof(s)->sname, s);
	printf("typedef %s uns%d;\n", intof(s)->uname, s);
	printf("#define Pr%d \"%%0%d%s\"\n", s, s*2, intof(s)->fmt);
	map |= s;
    }
    printf("\n#define has_int(n) (((n) & 0x%lX) != 0)\n", map);

    printf("\n");
    map= 0;
    for (s= 1; s < 0x1000; s <<= 1) {
	if (fltof(s) == nil) continue;
	printf("typedef %s flt%d;\n", fltof(s)->sname, s);
	map |= s;
    }
    printf("\n#define has_flt(n) (((n) & 0x%lX) != 0)\n", map);

    if (intof(sizeof(size_t)) == nil) {
	fprintf(stderr,
	    "genwordptr: Can't find a C integer type same as size_t\n");
	exit(1);
    }
    printf("\n#define PrS \"%%0%d%s\"\n", (int)sizeof(size_t) * 2,
	intof(sizeof(size_t))->fmt);

    if (intof(sizeof(char *)) == nil) {
	fprintf(stderr,
	    "genwordptr: Can't find a C integer type of pointer size\n");
	exit(1);
    }
    printf("\n#define M %d\n", sizeof(char *));
    printf("typedef %s memory;\n", intof(sizeof(char *))->uname);
    printf("#define PrM \"%%0%d%s\"\n", (int)sizeof(char *) * 2,
	intof(sizeof(char *))->fmt);

    u= 1;
    printf("\n");
    printf("#define LITTLE_ENDIAN\t%d\n", * (char *) &u);
    printf("#define BIG_ENDIAN\t%d\n", ! * (char *) &u);
    return 0;
}

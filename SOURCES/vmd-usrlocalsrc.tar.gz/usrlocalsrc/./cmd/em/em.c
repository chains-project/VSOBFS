/*	em 1.0 - EM system interpreter.			Author: Kees J. Bot
 *								23 Sep 2000
 */

#if !(P == 2 || P == 4) || !(W == P)
#error Constraints on W and P not met.
#endif
#include "wordptr.h"

#define nil ((void*)0)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <math.h>

#define MEGS_DEFAULT	8	/* Default memory size in megabytes. */

static char *program;		/* Name of this program. */

static char *disk;		/* Disk file name. */
static int dfd;			/* Disk file descriptor. */
static char *log_file;		/* Log file name and open file pointer. */
static FILE *logfp;

/* Virtual memory uses pages of the size shown below.  It is up to the page
 * fault trap handler to fill our virtual memory mapping table.  This TLB is
 * indexed by a code/data space number and the low N bits of the page number.
 * The c/d space numbers for the trap handler (the kernel?) should be kept
 * reserved.  Note that a TLB implemented in hardware would use associative
 * memory indexed by (page, space) tuples.  In software we must do it as done
 * below, by using big arrays and simple indexing.  EM code shouldn't know the
 * difference.  EM code is only aware of the page size and the existence of
 * address spaces.  It must query the number of address spaces supported.
 */
#define PAGE_BITS	(8+P)		/* 1K / 4K */
#define PAGE_SIZE	((memory) 1 << PAGE_BITS)
#define PAGE_MASK	(PAGE_SIZE - 1)

/* Max number of TLB code/data address spaces supported. */
#define TSPACE_MAX	16	/* This many active processes. */

/* TLB page number bits (64K / 4M per process without chance of trashing). */
#define TPAGE_BITS	(2+2*P)
#define TPAGE_SIZE	(1 << TPAGE_BITS)
#define TPAGE_MASK	(TPAGE_SIZE - 1)

/* The stale TLB is a cache of old TLB entries.  It is twice the size of the
 * TLB, and it is rougher, i.e. several adjacent TLB entries share a cache
 * slot.  This means that 9 random memory accesses may clash at one TLB entry,
 * or three large memory ranges may compete.  (Ranges cut into random accesses
 * and vice-versa.)  The cache is maintained as a LRU lists.
 * The stale cache is important for some of the overly complex EM instructions
 * that follow lots of random pointers or copy huge blocks of memory.
 * XXX - Best size should be measured by fault hit/miss counting.
 */
#define STALE_SKEW	2	/* Bits put in the same cache bucket. */
#define STALE_BITS	(TPAGE_BITS - STALE_SKEW)
#define STALE_SIZE	(1 << STALE_BITS)
#define STALE_MASK	(STALE_SIZE - 1)
#define STALE_DEPTH	(1 << (STALE_SKEW + 1))

typedef struct tlb {
	memory	vir;		/* Virtual address and protection bits. */
	memory	v2p;		/* Add to Virtual to get Physical address. */
} tlb_t;

/* Protection bits; a certain access is granted if the protection bit is
 * *not* set in the 'vir' field.
 */
#define pMASK		0xF	/* Mask to select protection bits. */
#define pP		0x8	/* Present. */
#define pR		0x4	/* Read. */
#define pW		0x2	/* Write. */
#define pX		0x1	/* Execute. */

/* The first part of virtual memory may be linearly mapped, i.e. a fixed offset
 * between virtual and physical.  This mapping never gives TLB misses, and is
 * nice for an O.S. that doesn't do paging, or to map the kernel.  It is a
 * requirement for the trap handler.  Memory beyond the limit is paged and
 * causes faults that must be fixed by the trap handler by filling in the TLB.
 */
typedef struct linear {
	memory	lim;		/* Virtual addresses < lim are linear. */
	memory	v2p;		/* Add to Virtual to get Physical address. */
} linear_t;

static tlb_t tlb[TSPACE_MAX][TPAGE_SIZE];
				/* Virtual memory translation table. */
static tlb_t stale_tlb[TSPACE_MAX][STALE_SIZE][STALE_DEPTH];
				/* LRU Cache of stale TLB entries. */
static linear_t linear[TSPACE_MAX];
				/* Linear limits. */
#define CODE	0		/* Index selecting code space. */
#define DATA	1		/* Index selecting data space. */
static tlb_t *ctlb[2];		/* Current process' code and data TLBs. */
static memory mem;		/* Main memory. */
static memory mem_size;		/* Size of main memory. */

/* Boundaries of know good memory around the PC or SP.  As long as
 * ((PC - pc_base) < pc_size) there are no chances of faults.
 */
static memory pc_base, pc_size, sp_base, sp_size;

/* For code we rely on the TLB having good entries, but for the areas around
 * the PC and the SP we have a small cache of "vir2phys" translations.
 */
#define C_V2P_BITS	4
#define C_V2P_SIZE	(1 << C_V2P_BITS)
#define C_V2P_MASK	(C_V2P_SIZE - 1)
static memory pc_vir2phys[C_V2P_SIZE], sp_vir2phys[C_V2P_SIZE];

/* Memory objects of several sizes and types. */
#define imem1(a)	(* (int1 *) (a))
#define imem2(a)	(* (int2 *) (a))
#define imem4(a)	(* (int4 *) (a))
#define imemw(a)	(* (intw *) (a))
#define imemp(a)	(* (intp *) (a))
#define umem1(a)	(* (uns1 *) (a))
#define umem2(a)	(* (uns2 *) (a))
#define umem4(a)	(* (uns4 *) (a))
#define umemw(a)	(* (unsw *) (a))
#define umemp(a)	(* (unsp *) (a))
#define fmem4(a)	(* (flt4 *) (a))
#define fmem8(a)	(* (flt8 *) (a))

/* Task state: CPU Registers and flags. */
typedef struct task {
    unsp lb;			/* Local base (stack frame pointer). */
    unsp sp;			/* Stack pointer. */
    unsp hp;			/* Heap pointer. */
    unsp pc;			/* Program counter. */
    unsw ret[4];		/* Return area / Fault state. */
    unsp pd;			/* Procedure descriptor table. */
    unsw line;			/* Source file line number. */
    unsp file;			/* Source file name. */
    unsp tmp[2];		/* Global temporaries. */
    unsw flags;			/* Special flags. */
    unsw space[2];		/* Code/data space numbers. */
} task_t;

/* CPU flags. */
#define F_(t)	    (1 << (t))	/* Trap inhibit flag for trap code t. */

task_t T;			/* Currently running task. */
memory context;			/* Address of current register set. */
memory trap_context;		/* Address of trap context. */

static void tlb_expunge(unsigned s)
/* Remove all TLB entries for address space s by marking all as "not present".
 * Used when a new process takes ownership of an address space number.
 */
{
    unsigned d, p;

    for (p= 0; p < TPAGE_SIZE; p++) tlb[s][p].vir= pP;

    for (p= 0; p < STALE_SIZE; p++) {
	for (d= 0; d < STALE_DEPTH; d++) stale_tlb[s][p][d].vir= pP;
    }
}

#define arraysize(a)	(sizeof(a) / sizeof((a)[0]))
#define arraylimit(a)	((a) + arraysize(a))

static void where(void)
/* Show task state for debug purposes. */
{
    static char *regnames[] = {
	"lb", "sp", "hp", "pc",
	"ret[0]", "ret[1]", "ret[2]", "ret[3]",
	"pd", "line", "file", "tmp[0]",
	"tmp[1]", "flags", "space[0]", "space[1]",
    };
    int i;
    unsp sp;

    for (i= 0; i < 16; i++) {
	fprintf(logfp, "%8s = "PrW"%c",
	    regnames[i], ((unsw *) &T)[i],
	    i % 4 == 3 ? '\n' : ' ');
    }

    fprintf(logfp, "STACK:");
    sp= T.sp;
    for (i= 0; i < (80 - 6) / (1 + W*2); i++) {
	if ((sp - sp_base) >= sp_size) break;
	fprintf(logfp, " "PrW,
	    umemw((sp + sp_vir2phys[(sp >> PAGE_BITS) & C_V2P_MASK])));
	sp += W;
    }
    fputc('\n', logfp);
    fflush(logfp);
    if (ferror(logfp)) {
	fprintf(stderr, "%s: Can't write to %s: %s\n",
	    program, log_file, strerror(errno));
	exit(1);
    }
}

static void context_switch(memory newc)
/* Perform a context switch by dumping the current registers and loading a
 * new set.  The new set must have been checked beforehand.
 */
{
    int i;
    memory oldc;

    oldc= context;

    /* Save old context and load new context. */
    for (i= 0; i < sizeof(T)/W; i++) {
	(&umemw(oldc))[i] = ((unsw*)&T)[i];
	((unsw*)&T)[i] = (&umemw(newc))[i];
    }
    context= newc;

    ctlb[CODE]= tlb[T.space[CODE]];
    ctlb[DATA]= tlb[T.space[CODE]];
    pc_base= pc_size= 0;
    sp_base= sp_size= 0;
}

/* Trap and fault codes. */
#define T_ARRAY		0	/* Array bound error */
#define T_RANGE		1	/* Range bound error */
#define T_SET		2	/* Set bound error */
#define T_IOVFL		3	/* Integer overflow */
#define T_FOVFL		4	/* Floating overflow */
#define T_FUNFL		5	/* Floating underflow */
#define T_IDIVZ		6	/* Divide by 0 */
#define T_FDIVZ		7	/* Divide by 0.0 */
#define T_IUND		8	/* Undefined integer */
#define T_FUND		9	/* Undefined float */
#define T_CONV		10	/* Conversion error */
#define T_SUPER		12	/* Operation priviliged to supervisor */
#define T_RESTART	13	/* Complex instruction faulted midway. */
#define T_STACK		16	/* Stack overflow */
#define T_HEAP		17	/* Heap overflow */
#define T_ILLINS	18	/* Illegal instruction */
#define T_ODDZ		19	/* Illegal size argument */
#define T_CASE		20	/* Case error */
#define T_MEMFLT	21	/* Addressing non existent memory */
#define T_BADPTR	22	/* Bad pointer used (alignment fault) */
#define T_BADPC		23	/* Program counter out of range */
#define T_BADLAE	24	/* Bad argument of LAE */
#define T_BADMON	25	/* Bad monitor call */
#define T_BADLIN	26	/* Argument of LIN too high */
#define T_BADGTO	27	/* GTO descriptor error */
#define T_PAGEFLT	28	/* Page fault */
#define T_INTR		29	/* Hardware interrupt */

static char faultnames[][8] = {
    "ARRAY", "RANGE", "SET", "IOVFL", "FOVFL", "FUNFL", "IDIVZ",
    "FDIVZ", "IUND", "FUND", "CONV", "?\??", "SUPER", "RESTART",
    "?\??", "?\??", "STACK", "HEAP", "ILLINS", "ODDZ", "CASE",
    "MEMFLT", "BADPTR", "BADPC", "BADLAE", "BADMON", "BADLIN",
    "BADGTO", "PAGEFLT", "INTR",
};

static void fault(unsigned type, unsigned space, memory addr, unsigned prot)
/* A trap or fault.  Call the trap handler. */
{
    if (trap_context != context) {
	memory sp;
	task_t *t;

	/* Place ourselves at the mercy of the EM code, assume the trap
	 * context is sane, its registers aligned, and its stack within
	 * linear space with enough room for five objects.
	 */
	t= (task_t *) trap_context;

	/* Push fault data and old context address. */
	t->sp -= W+W+P+W+P;
	sp= t->sp + linear[t->space[DATA]].v2p;
	umemp(sp + W+W+P+W) = context - linear[T.space[DATA]].v2p;
	umemw(sp + W+W+P+0) = prot;
	umemp(sp + W+W+0+0) = addr;
	umemw(sp + W+0+0+0) = space;
	umemw(sp + 0+0+0+0) = type;

	/* Perform a context switch to the trap handler. */
	context_switch(trap_context);
    } else {
	/* No trap handler, or a trap within the trap handler. */
	fprintf(logfp,
	    "Trap %u (%s) in address space %d, address 0x"PrM", prot %X\n",
	    type, (type < arraysize(faultnames) ? faultnames[type] : "?\??"),
	    space, addr, prot);
	where();
	exit(1);
    }
}

static void trap(unsigned type)
/* Simple trap, i.e. anything other than a page fault. */
{
    fault(type, CODE, T.pc, 0);
}

static int tlb_miss(tlb_t *tp, unsigned spidx, memory addr, unsigned prot)
/* A TLB miss.  If the process is linearly mapped then the fix is easy.  (The
 * trap handler is normally linearly mapped.)  For a normal process we see if
 * the miss can be repaired from the LRU cache.  Return true if the miss was
 * avoided, otherwise raise a page fault and return false.
 */
{
    unsigned space= T.space[spidx];
    memory apage= addr & ~PAGE_MASK;	/* Virtual page address. */

    /* Is it a true miss, i.e. the page number is not as expected or the page
     * is not present?
     */
    if ((tp->vir & (~PAGE_MASK | pP)) != apage) {
	/* See if an entry in the cache would have given access. */
	tlb_t *stp, tmp;
	unsigned d;

	/* Stale TLB cache bucket. */
	stp= stale_tlb[space][(apage >> (PAGE_BITS+STALE_SKEW)) & STALE_MASK];

	for (d= 0; d < STALE_DEPTH; d++) {
	    if ((stp->vir & (~PAGE_MASK | prot)) == apage) {
		/* Contending entry that matches address and access found! */
		for (;;) {
		    /* Rearrange the LRU list. */
		    tmp= *stp;
		    if (d == 0) break;
		    d--;
		    stp--;
		    stp[1]= stp[0];
		}
		*stp= *tp;	/* Current entry is now most recent. */
		*tp= tmp;	/* Old entry is now active. */
		return 1;
	    }
	    stp++;
	}

	/* Nothing good found.  Move the current entry out into the cache. */
	do {
	    stp--;
	    stp[0]= stp[-1];
	} while (--d > 1);
	stp[-1]= *tp;
	tp->vir= pP;		/* Current entry free to be replaced. */
    }

    /* Linearly mapped? */
    if (apage < linear[space].lim) {
#if !XXX
	fprintf(logfp,
	    "Linear fault, PC = "PrP", %s space %d, addr = "PrM"\n",
	    T.pc, spidx == CODE ? "code" : "data", space, addr);
	fflush(logfp);
	if (ferror(logfp)) {
	    fprintf(stderr, "%s: Can't write to %s: %s\n",
		program, log_file, strerror(errno));
	    exit(1);
	}
#endif
	tp->vir= apage | 0;
	tp->v2p= linear[space].v2p;
	return 1;
    }

    /* Let the trap handler figure it out. */
    fault(T_PAGEFLT, space, addr, prot);
    return 0;
}

/* Check if a TLB entry has the proper virtual address and protection bits.  If
 * not then we have a TLB miss.  (That may possibly be recovered from.)
 */
#define tlb_chk(ptp, spidx, addr, prot)	\
	(*(ptp)= &ctlb[spidx][((addr) >> PAGE_BITS) & TPAGE_MASK], \
	(((*(ptp))->vir & (~PAGE_MASK | (prot))) == ((addr) & ~PAGE_MASK) \
		|| tlb_miss(*(ptp), (spidx), (addr), (prot))))

/* Translate a virtual to a physical address given a TLB entry. */
#define tlb_v2p(tp, addr)	((addr) + (tp)->v2p)

/* Translate a virtual to a physical address in code or data space, knowing
 * that the TLB entry is present and rights are checked ok.
 */
#define vir2phys(spidx, addr)	\
	tlb_v2p(&ctlb[spidx][((addr) >> PAGE_BITS) & TPAGE_MASK], (addr))

/* Check if an address is word aligned, otherwise raise a trap. */
#define aligned(addr, size)	\
	(((addr) & ((size)-1)) == 0 || (trap(T_BADPTR), 0))

/* Check if the PC is still within a known good bit of code. */
#define pc_chk(pc)	(((pc) - pc_base) < pc_size || pc_dblchk(pc))

static int pc_dblchk(memory pc)
/* Check if the page under the PC can be added to explored code. */
{
    tlb_t *tp;

    if (!tlb_chk(&tp, CODE, pc, pP|pX)) return 0;

    pc_vir2phys[(pc >> PAGE_BITS) & C_V2P_MASK]= tp->v2p;

    if ((pc & ~PAGE_MASK) == pc_base + pc_size) {
	/* The PC just moved into the next page. */
	pc_size += PAGE_SIZE;
	if (pc_size > C_V2P_SIZE * PAGE_SIZE) {
	    /* Too many pages to keep track of. */
	    pc_base += PAGE_SIZE;
	    pc_size -= PAGE_SIZE;
	}
    } else {
	/* The new PC is far outside the current interval. */
	pc_base= pc & ~PAGE_MASK;
	pc_size= PAGE_SIZE;
    }
#if !XXX
    fprintf(logfp, PrM" <= PC < "PrM"\n", pc_base, pc_base + pc_size);
    fflush(logfp);
    if (ferror(logfp)) {
	fprintf(stderr, "%s: Can't write to %s: %s\n",
	    program, log_file, strerror(errno));
	exit(1);
    }
#endif
    return 1;
}

/* Translate a pointer into the known good stack area. */
#define pc_v2p(addr)	((addr) + pc_vir2phys[((addr) >> PAGE_BITS) & C_V2P_MASK])

/* Check if the SP is still within a known good bit of stack. */
#define sp_chk(sp)	(((sp) - sp_base) < sp_size || sp_dblchk(sp))

static int sp_dblchk(memory sp)
/* Check if the page under the SP can be added to the known stack cache. */
{
    tlb_t *tp;

    if (!tlb_chk(&tp, DATA, sp, pP|pR|pW)) return 0;

    sp_vir2phys[(sp >> PAGE_BITS) & C_V2P_MASK]= tp->v2p;

    if ((sp & ~PAGE_MASK) == sp_base - PAGE_SIZE) {
	/* SP went down into a new page. */
	sp_base -= PAGE_SIZE;
	sp_size += PAGE_SIZE;
	if (sp_size > C_V2P_SIZE * PAGE_SIZE) {
	    /* To many pages of our little stack vir -> phys cache. */
	    sp_size -= PAGE_SIZE;
	}
    } else
    if ((sp & ~PAGE_MASK) == sp_base + sp_size) {
	/* SP went up into a forgotten page.  (Shouldn't be new.) */
	sp_size += PAGE_SIZE;
	if (sp_size > C_V2P_SIZE * PAGE_SIZE) {
	    /* Again, too many pages to keep track of. */
	    sp_base += PAGE_SIZE;
	    sp_size -= PAGE_SIZE;
	}
    } else {
	/* The new SP is far outside the current interval. */
	sp_base= sp & ~PAGE_MASK;
	sp_size= PAGE_SIZE;
    }
#if !XXX
    fprintf(logfp, PrM" <= SP < "PrM"\n", sp_base, sp_base + sp_size);
    fflush(logfp);
    if (ferror(logfp)) {
	fprintf(stderr, "%s: Can't write to %s: %s\n",
	    program, log_file, strerror(errno));
	exit(1);
    }
#endif
    return 1;
}

/* Translate a pointer into the known good stack area. */
#define sp_v2p(addr)	((addr) + sp_vir2phys[((addr) >> PAGE_BITS) & C_V2P_MASK])

/* Fetch a signed N byte literal from code space as part of an instruction. */
#define sliteral(ppc, size, pword)	\
    (pc_chk(*(ppc) + ((size) - 1)) && \
	(*(pword)= (size) == 1 ? sliteral1(*(ppc)) : \
	    (size) == 2 ? sliteral2(*(ppc)) : sliteral4(*(ppc)), \
	    *(ppc) += (size), 1))

/* Signed 1 byte literal. */
#define sliteral1(pc) ((unsw) imem1(pc_v2p((pc))))

/* Signed 2 byte literal.  Multibyte literals are always big-endian. */
#define sliteral2(pc)	\
    (((unsw) imem1(pc_v2p(pc+0)) << 8) | ((unsw) umem1(pc_v2p(pc+1)) << 0))

/* Signed 4 byte literal. */
#define sliteral4(pc)	\
    (((unsw) imem1(pc_v2p(pc+0)) << 24) | ((unsw) umem1(pc_v2p(pc+1)) << 16) \
    | ((unsw) umem1(pc_v2p(pc+2)) << 8) | ((unsw) umem1(pc_v2p(pc+3)) << 0))

/* Fetch a negative N byte literal from code space. */
#define nliteral(ppc, size, pword)	\
    (pc_chk(*(ppc) + ((size) - 1)) && \
	(*(pword)= (size) == 1 ? nliteral1(*(ppc)) : \
	    (size) == 2 ? nliteral2(*(ppc)) : nliteral4(*(ppc)), \
	    *(ppc) += (size), 1))

/* Negative 1 byte literal. */
#define nliteral1(pc)	(pliteral1(pc) - ((unsw) 1 << 8))

/* Negative 2 byte literal. */
#if W > 2
#define nliteral2(pc)	(pliteral2(pc) - ((unsw) 1 << 16))
#else
#define nliteral2(pc)	pliteral2(pc)
#endif

/* Negative 4 byte literal. */
#define nliteral4(pc)	pliteral4((pc))

/* Fetch a positive N byte literal from code space. */
#define pliteral(ppc, size, pword)	\
    (pc_chk(*(ppc) + ((size) - 1)) && \
	(*(pword)= (size) == 1 ? pliteral1(*(ppc)) : \
	    (size) == 2 ? pliteral2(*(ppc)) : pliteral4(*(ppc)), \
	    *(ppc) += (size), 1))

/* Positive 1 byte literal. */
#define pliteral1(pc) ((unsw) umem1(pc_v2p((pc))))

/* Positive 2 byte literal. */
#define pliteral2(pc)	\
    (((unsw) umem1(pc_v2p(pc+0)) << 8) | ((unsw) umem1(pc_v2p(pc+1)) << 0))

/* Positive 4 byte literal. */
#define pliteral4(pc)	\
    (((unsw) umem1(pc_v2p(pc+0)) << 24) | ((unsw) umem1(pc_v2p(pc+1)) << 16) \
    | ((unsw) umem1(pc_v2p(pc+2)) << 8) | ((unsw) umem1(pc_v2p(pc+3)) << 0))

static int rd1(unsp addr, unsw *pw)
/* Read a byte.  Not as fast as inlined code, but often good enough. */
{
    tlb_t *tp;

    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    *pw= umem1(tlb_v2p(tp, addr));
    return 1;
}

#if W >= 4
static int rd2(unsp addr, unsw *pw)
/* Read a two byte word. */
{
    tlb_t *tp;

    if (!aligned(addr, 2)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    *pw= umem2(tlb_v2p(tp, addr));
    return 1;
}
#endif

static int rdw(unsp addr, unsw *pw)
/* Read a word. */
{
    tlb_t *tp;

    if (!aligned(addr, W)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    *pw= umemw(tlb_v2p(tp, addr));
    return 1;
}
#define rdp(addr, pw)	rdw((addr), (pw))

static int rddw(unsp addr, unsdw *pw)
/* Read a doubleword. */
{
    tlb_t *tp;

    if (!aligned(addr, W)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    ((unsw*)pw)[0]= umemw(tlb_v2p(tp, addr));
    addr += W;
    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    ((unsw*)pw)[1]= umemw(tlb_v2p(tp, addr));
    return 1;
}

/* Read a 4 byte float. */
#if W == 2
static int rdf4(unsp addr, flt4 *pf)
{
    tlb_t *tp;

    if (!aligned(addr, W)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    ((unsw*)pf)[0]= umemw(tlb_v2p(tp, addr));
    addr += W;
    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    ((unsw*)pf)[1]= umemw(tlb_v2p(tp, addr));
    return 1;
}
#elif W >= 4
static int rdf4(unsp addr, flt4 *pf)
{
    tlb_t *tp;

    if (!aligned(addr, 4)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    *pf= fmem4(tlb_v2p(tp, addr));
    return 1;
}
#endif

static int rdf8(unsp addr, flt8 *pf)
/* Read an 8 byte float. */
{
    tlb_t *tp;

    if (!aligned(addr, W)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    ((unsw*)pf)[0]= umemw(tlb_v2p(tp, addr));
#if 1*W < 8
    addr += W;
    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    ((unsw*)pf)[1]= umemw(tlb_v2p(tp, addr));
#endif
#if 2*W < 8
    addr += W;
    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    ((unsw*)pf)[2]= umemw(tlb_v2p(tp, addr));
#endif
#if 3*W < 8
    addr += W;
    if (!tlb_chk(&tp, DATA, addr, pP|pR)) return 0;
    ((unsw*)pf)[3]= umemw(tlb_v2p(tp, addr));
#endif
    return 1;
}

static int wr1(unsp addr, unsw w)
/* Write a byte. */
{
    tlb_t *tp;

    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    umem1(tlb_v2p(tp, addr))= w;
    return 1;
}

#if W >= 4
static int wr2(unsp addr, unsw w)
/* Write a two byte word. */
{
    tlb_t *tp;

    if (!aligned(addr, 2)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    umem2(tlb_v2p(tp, addr))= w;
    return 1;
}
#endif

static int wrw(unsp addr, unsw w)
/* Write a word. */
{
    tlb_t *tp;

    if (!aligned(addr, W)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    umemw(tlb_v2p(tp, addr))= w;
    return 1;
}
#define wrp(addr, w)	wrw((addr), (w))

static int wrdw(unsp addr, unsdw w)
/* Write a doubleword. */
{
    tlb_t *tp;

    if (!aligned(addr, W)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    umemw(tlb_v2p(tp, addr))= ((unsw*)&w)[0];
    addr += W;
    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    umemw(tlb_v2p(tp, addr))= ((unsw*)&w)[1];
    return 1;
}

/* Write a 4 byte float. */
#if W == 2
static int wrf4(unsp addr, flt4 f)
{
    tlb_t *tp;

    if (!aligned(addr, W)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    umemw(tlb_v2p(tp, addr))= ((unsw*)&f)[0];
    addr += W;
    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    umemw(tlb_v2p(tp, addr))= ((unsw*)&f)[1];
    return 1;
}
#elif W >= 4
static int wrf4(unsp addr, flt4 f)
{
    tlb_t *tp;

    if (!aligned(addr, 4)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    fmem4(tlb_v2p(tp, addr))= f;
    return 1;
}
#endif

static int wrf8(unsp addr, flt8 f)
/* Write an 8 byte float. */
{
    tlb_t *tp;

    if (!aligned(addr, W)) return 0;
    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    umemw(tlb_v2p(tp, addr))= ((unsw*)&f)[0];
#if 1*W < 8
    addr += W;
    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    umemw(tlb_v2p(tp, addr))= ((unsw*)&f)[1];
#endif
#if 2*W < 8
    addr += W;
    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    umemw(tlb_v2p(tp, addr))= ((unsw*)&f)[2];
#endif
#if 3*W < 8
    addr += W;
    if (!tlb_chk(&tp, DATA, addr, pP|pW)) return 0;
    umemw(tlb_v2p(tp, addr))= ((unsw*)&f)[3];
#endif
    return 1;
}

/* Null pointers should not be followed. */
#define nullptr(ptr)	((ptr) == 0 && (trap(T_MEMFLT), 1))

static int wordcpy(memory dst, memory src, memory cnt)
/* Copy cnt bytes from src to dst as words.  All is aligned and cnt > 0. */
{
    tlb_t *tp;
    unsw w;

    if (T.flags & F_(T_RESTART)) {
	/* The copy was interrupted by a page fault or something.  Restart. */
	memory n= cnt - * (memory *) T.ret;
	src += n;
	dst += n;
	cnt -= n;
	T.flags &= ~F_(T_RESTART);
    }

    do {
	if (!tlb_chk(&tp, DATA, src, pP|pR)) goto wc_fault;
	w= umemw(tlb_v2p(tp, src));
	if (!tlb_chk(&tp, DATA, dst, pP|pW)) goto wc_fault;
	umemw(tlb_v2p(tp, src))= w;
	src += W;
	dst += W;
    } while ((cnt -= W) > 0);
    return 1;

wc_fault:
    /* A fault occurred while copying.  Save the current count and set the
     * "instruction faulted" flag, so that we don't have to repeat everything
     * again next time.  (A later fault may drive an entry out of the TLB that
     * we need at an earlier moment, so we can't simply redo everything.)
     */
    * (memory *) T.ret= cnt;
    T.flags |= F_(T_RESTART);
    return 0;
    /* XXX - Handle overlap. */
    /* XXX - Need to reduce tlb_chks. */
}

static int bytecpy(memory dst, memory src, memory cnt)
/* Copy cnt bytes from src to dst.  Cnt may be 0. */
{
    tlb_t *tp;
    unsigned b;

    /* Do a word copy if possible. */
    if (cnt == 0) return 1;
    if (((src | dst | cnt) & (W-1)) == 0) return wordcpy(dst, src, cnt);

    if (T.flags & F_(T_RESTART)) {
	memory n= cnt - * (memory *) T.ret;
	src += n;
	dst += n;
	cnt -= n;
	T.flags &= ~F_(T_RESTART);
    }

    do {
	if (!tlb_chk(&tp, DATA, src, pP|pR)) goto bc_fault;
	b= umem1(tlb_v2p(tp, src));
	if (!tlb_chk(&tp, DATA, dst, pP|pW)) goto bc_fault;
	umem1(tlb_v2p(tp, src))= b;
	src++;
	dst++;
    } while (--cnt > 0);
    return 1;

bc_fault:
    * (memory *) T.ret= cnt;
    T.flags |= F_(T_RESTART);
    return 0;
    /* XXX - Handle overlap. */
    /* XXX - Need to reduce tlb_chks. */
}

static intw unsw_mask[W];	/* To zero extend a word to a given size. */
				/* It's important that the type is signed, */
				/* so that it can be used for intw and unsw. */
				/* Most in-between sizes are really illegal. */

static intw intw_min[W];	/* Lower bound on a given sized integer. */
static intw intw_max[W];	/* Upper bound on a given sized integer. */

#if has_int(2*W)		/* Same for and of doubleword type. */
static intdw unsdw_mask[2*W];
static intdw intdw_min[2*W];
static intdw intdw_max[2*W];
#endif

static void limits_init(void)
/* Initialize the arrays of masks and limits. */
{
    int i;

    unsw_mask[1]= 0xFF;
    intw_min[1]= -128;
    intw_max[1]= +127;

    for (i= 2; i <= W; i++) {
	unsw_mask[i]= (unsw_mask[i-1] << 8) | 0xFF;
	intw_min[i]= (intw_min[i-1] << 8) | 0x00;
	intw_max[i]= (intw_max[i-1] << 8) | 0xFF;
    }

#if has_int(2*W)
    unsdw_mask[1]= 0xFF;
    intdw_min[1]= -128;
    intdw_max[1]= +127;

    for (i= 2; i <= W; i++) {
	unsdw_mask[i]= (unsdw_mask[i-1] << 8) | 0xFF;
	intdw_min[i]= (intdw_min[i-1] << 8) | 0x00;
	intdw_max[i]= (intdw_max[i-1] << 8) | 0xFF;
    }
#endif
}

static void monitor(void)
/* Execute a "monitor call", things that EM code wants the interpreter to do. */
{
    unsp pc, sp;
    int op;
    tlb_t *tp;

    pc= T.pc + 2;
    sp= T.sp;

    if (!sp_chk(sp)) return;
    op= imemw(sp_v2p(sp));
    sp += W;

    switch (op) {
    case -1:{		/* New address space. */
	unsw space;
	memory lim, phys;

	if (!sp_chk(sp)) return;
	space= umemw(sp_v2p(sp));
	sp += W;
	if (!sp_chk(sp)) return;
	lim= umemp(sp_v2p(sp));
	sp += P;
	if (!sp_chk(sp)) return;
	phys= umemp(sp_v2p(sp));
	sp += P;

	lim <<= PAGE_BITS;
	phys <<= PAGE_BITS;

	if (space >= TSPACE_MAX) { trap(T_ILLINS); return; }

	/* Silently truncate the limit to be within available memory. */
	if ((lim + phys) >= mem_size) {
	    lim= phys >= mem_size ? 0 : mem_size - phys;
	}

	tlb_expunge(space);
	linear[space].lim= lim;
	linear[space].v2p= mem + phys;
	T.sp= sp;
	T.pc= pc;
	break;}

    case -2:{		/* Load TLB entry. */
	unsw space, prot;
	memory vir, phys;

	if (!sp_chk(sp)) return;
	space= umemw(sp_v2p(sp));
	sp += W;
	if (!sp_chk(sp)) return;
	prot= umemw(sp_v2p(sp));
	sp += W;
	if (!sp_chk(sp)) return;
	vir= umemp(sp_v2p(sp));
	sp += P;
	if (!sp_chk(sp)) return;
	phys= umemp(sp_v2p(sp));
	sp += P;

	vir <<= PAGE_BITS;
	phys <<= PAGE_BITS;

	if (space >= TSPACE_MAX || (prot & ~pMASK) != 0 || phys >= mem_size) {
	    trap(T_ILLINS); return;
	}

	tp= &tlb[space][vir & TPAGE_MASK];
	tp->vir= vir | (~prot & pMASK);
	tp->v2p= mem + phys;
	T.sp= sp;
	T.pc= pc;
	break;}

    case -3:{		/* Environment item. */
	unsw item;
	static unsw all_items[]= {
	    0, 0, TSPACE_MAX, TPAGE_BITS, STALE_SKEW, STALE_DEPTH
	};

	if (!rdw(sp, &item)) return;
	if (item >= arraysize(all_items)) { trap(T_ILLINS); return; }

	all_items[0]= dfd;
	all_items[1]= mem_size >> PAGE_BITS;

	if (!wrw(sp, all_items[item])) return;
	T.sp= sp;
	T.pc= pc;
	break;}

    case -4:{		/* Disk name byte #i. */
	unsw i;
	char *d;

	if (!rdw(sp, &i)) return;

	for (d= disk; i > 0 && *d != 0; d++, i--) {}

	if (!wrw(sp, (unsigned char) *d)) return;
	T.sp= sp;
	T.pc= pc;
	break;}

    case -5:{		/* Environment string #i byte #j. */
	unsw i, j;
	char *d;
	extern char **environ;
	char **epp, *ep;

	if (!rdw(sp, &j)) return;
	sp += W;
	if (!rdw(sp, &i)) return;

	for (epp= environ; i > 0 && *epp != nil; epp++) {}
	for (ep= *epp == nil ? "" : *epp; j > 0 && *ep != 0; ep++, j--) {}

	if (!wrw(sp, (unsigned char) *ep)) return;
	T.sp= sp;
	T.pc= pc;
	break;}

    default:
	trap(T_BADMON);
    }
}

static void run(void)
{
    unsp pc, sp;	/* Moving values of PC and SP, copied to T when OK. */
    unsigned op;	/* Next opcode byte. */
    tlb_t *tp;		/* A TLB entry. */

    for (;;) {		/* Main loop of the interpreter. */
    run:
	pc= T.pc;

	if (!pc_chk(pc)) goto run;
	op= umem1(pc_v2p(pc));
	pc++;

    dispatch:
#if XXX
	if (op != 0x0FE && op != 0x0FF) {
	    fprintf(logfp, "op = 0x%03X\n", op);
	    fflush(logfp);
	    if (ferror(logfp)) {
		fprintf(stderr, "%s: Can't write to %s: %s\n",
		    program, log_file, strerror(errno));
		exit(1);
	    }
	}
#endif
	switch (op) {
	case 0x0FE:	/* ESCAPE 1 */
	    if (!pc_chk(pc)) goto run;
	    op= 0x100 | umem1(pc_v2p(pc));
	    pc++;
	    goto dispatch;

	case 0x0FF:	/* ESCAPE 2 */
	    if (!pc_chk(pc)) goto run;
	    op= 0x200 | umem1(pc_v2p(pc));
	    pc++;
	    goto dispatch;

	case 0x000:	 case 0x001:	 case 0x002:	 case 0x003:	
	case 0x004:	 case 0x005:	 case 0x006:	 case 0x007:	
	case 0x008:	 case 0x009:	 case 0x00A:	 case 0x00B:	
	case 0x00C:	 case 0x00D:	 case 0x00E:	 case 0x00F:	
	case 0x010:	 case 0x011:	 case 0x012:	 case 0x013:	
	case 0x014:	 case 0x015:	 case 0x016:	 case 0x017:	
	case 0x018:	 case 0x019:	 case 0x01A:	 case 0x01B:	
	case 0x01C:	 case 0x01D:	 case 0x01E:	 case 0x01F:	
	case 0x020:	 case 0x021:{
			/* loc.0 - loc.33 : Load constant 0 - 33 */
	    unsw c;

	    c= (op - 0x000);
	    goto LOC;

	case 0x097:	/* loc.l : Load constant c */
	    if (!sliteral(&pc, 2, &c)) goto run;
	    goto LOC;

	case 0x098:	/* loc.-1 : Load constant -1 */
	    c= -1;
	    goto LOC;

	case 0x099:	/* loc.s0 : Load constant c */
	    if (!pliteral(&pc, 1, &c)) goto run;
	    goto LOC;

	case 0x09A:	/* loc.s-1 : Load constant c */
	    if (!pliteral(&pc, 1, &c)) goto run;
	    c -= (unsw) 1 << 8;
	    goto LOC;

#if W >= 4
	case 0x20A:	/* loc.L : Load constant c */
	    if (!sliteral(&pc, 4, &c)) goto run;
	    goto LOC;
#endif
	LOC:
	    sp= T.sp - W;
	    if (!sp_chk(sp)) goto run;
	    umemw(sp_v2p(sp))= c;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x088:{	/* ldc.0 : Load 0 as double constant */
	    unsw c;

	    c= 0;
	    goto LDC;

	case 0x145:	/* ldc.l : Load 16-bit literal as double constant */
	    if (!sliteral(&pc, 2, &c)) goto run;
	    goto LDC;

#if W >= 4
	case 0x200:	/* ldc.L : Load 32-bit literal as double constant */
	    if (!sliteral(&pc, 4, &c)) goto run;
	    goto LDC;
#endif
	LDC:
#if has_int(2*W)
	    if (!wrdw(T.sp - 2*W, (unsdw) * (intw *) &c)) goto run;
#else
# if LITTLE_ENDIAN
	    if (!wrw(T.sp - 2*W, c)) goto run;
	    if (!wrw(T.sp - 1*W, (* (intw *) &c) >> (W*8-1))) goto run;
# endif
# if BIG_ENDIAN
	    if (!wrw(T.sp - 2*W, (* (intw *) &c) >> (W*8-1))) goto run;
	    if (!wrw(T.sp - 1*W, c)) goto run;
# endif
#endif
	    T.sp -= 2*W;
	    T.pc= pc;
	    break;}

	case 0x0AE:{	/* lol.pw : Load word at l-th parameter */
	    unsp l;
	    unsw w;

	    if (!pliteral(&pc, 2, &l)) goto run;
	    l += 2;
	    goto LOL;

	case 0x0AF:	/* lol.nw : Load word at l-th local */
	    if (!nliteral(&pc, 2, &l)) goto run;
	    goto LOL;

	case 0x0B0:	/* lol.0 : Load word at 0th parameter */
	case 0x0B1:	/* lol.1W : Load word at 1st parameter */
	case 0x0B2:	/* lol.2W : Load word at 2nd parameter */
	case 0x0B3:	/* lol.3W : Load word at 3rd parameter */
	    l= (op - 0x0B0) + 2;
	    goto LOL;

	case 0x0B4:	/* lol.-1W : Load word at 1st local */
	case 0x0B5:	/* lol.-2W : Load word at 2nd local */
	case 0x0B6:	/* lol.-3W : Load word at 3rd local */
	case 0x0B7:	/* lol.-4W : Load word at 4th local */
	case 0x0B8:	/* lol.-5W : Load word at 5th local */
	case 0x0B9:	/* lol.-6W : Load word at 6th local */
	case 0x0BA:	/* lol.-7W : Load word at 7th local */
	case 0x0BB:	/* lol.-8W : Load word at 8th local */
	    l= ((unsp) 0x0B4 + 1 - op);
	    goto LOL;

	case 0x0BC:	/* lol.w0 : Load word at l-th parameter */
	    if (!pliteral(&pc, 1, &l)) goto run;
	    l += 2;
	    goto LOL;

	case 0x0BD:	/* lol.w-1 : Load word at l-th local */
	    if (!pliteral(&pc, 1, &l)) goto run;
	    l -= (unsp) 1 << 8;
	    goto LOL;

#if W >= 4
	case 0x20D:	/* lol.Pw : Load word at l-th parameter */
	    if (!pliteral(&pc, 4, &l)) goto run;
	    l += 2;
	    goto LOL;

	case 0x20E:	/* lol.Nw : Load word at l-th local */
	    if (!nliteral(&pc, 4, &l)) goto run;
	    goto LOL;
#endif
	LOL:
	    l= l * W + T.lb;
	    if (!tlb_chk(&tp, DATA, l, pP|pR)) goto run;
	    w= umemw(tlb_v2p(tp, l));

	    sp= T.sp - W;
	    if (!sp_chk(sp)) goto run;
	    umemw(sp_v2p(sp))= w;

	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x09B:{	/* loe.lw : Load external word g */
	    unsp g;
	    unsw w;

	    if (!sliteral(&pc, 2, &g)) goto run;
	    goto LOE;

	case 0x09C:	 case 0x09D:	 case 0x09E:	 case 0x09F:	
	case 0x0A0:	/* loe.w0 - loe.w4 : Load external word g */
	    if (!pliteral(&pc, 1, &g)) goto run;
	    g += (op - 0x09C) << 8;
	    goto LOE;

#if W >= 4
	case 0x20B:	/* loe.Lw : Load external word g */
	    if (!sliteral(&pc, 4, &g)) goto run;
	    goto LOE;
#endif
	LOE:
	    g *= W;
	    if (!tlb_chk(&tp, DATA, g, pP|pR)) goto run;
	    w= umemw(tlb_v2p(tp, g));

	    sp= T.sp - W;
	    if (!sp_chk(sp)) goto run;
	    umemw(sp_v2p(sp))= w;

	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x090:{	/* lil.w-1 : Load word pointed to by l-th local */
	    unsp l;
	    unsw w;

	    if (!pliteral(&pc, 1, &l)) goto run;
	    l -= (unsp) 1 << 8;
	    goto LIL;

	case 0x091:	/* lil.w0 : Load word pointed to by l-th parameter */
	    if (!pliteral(&pc, 1, &l)) goto run;
	    l += 2;
	    goto LIL;

	case 0x092:	/* lil.0 : Load word pointed to by 0th parameter */
	case 0x093:	/* lil.1W : Load word pointed to by 1st parameter */
	    l= (op - 0x092) + 2;
	    goto LIL;

	case 0x14A:	/* lil.pw : Load word pointed to by l-th parameter */
	    if (!pliteral(&pc, 2, &l)) goto run;
	    l += 2;
	    goto LIL;

	case 0x14B:	/* lil.nw : Load word pointed to by l-th local */
	    if (!nliteral(&pc, 2, &l)) goto run;
	    goto LIL;

#if W >= 4
	case 0x208:	/* lil.Pw : Load word pointed to by l-th parameter */
	    if (!pliteral(&pc, 4, &l)) goto run;
	    l += 2;
	    goto LIL;

	case 0x209:	/* lil.Nw : Load word pointed to by l-th local */
	    if (!nliteral(&pc, 4, &l)) goto run;
	    goto LIL;
#endif
	LIL:
	    l= l * W + T.lb;
	    if (!tlb_chk(&tp, DATA, l, pP|pR)) goto run;
	    l= umemp(tlb_v2p(tp, l));

	    if (nullptr(l)) goto run;
	    if (!aligned(l, W)) goto run;

	    if (!tlb_chk(&tp, DATA, l, pP|pR)) goto run;
	    w= umemw(tlb_v2p(tp, l));

	    sp= T.sp - W;
	    if (!sp_chk(sp)) goto run;
	    umemw(sp_v2p(sp))= w;

	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0A1:{	/* lof.l : Load offsetted by f */
	    unsp p, f;
	    unsw *s[1];

	    if (!sliteral(&pc, 2, &f)) goto run;
	    goto LOF;

	case 0x0A2:	/* lof.1W : Load offsetted by 1 word */
	    f= 1 * W;
	    goto LOF;

	case 0x0A3:	/* lof.2W : Load offsetted by 2 words */
	    f= 2 * W;
	    goto LOF;

	case 0x0A4:	/* lof.3W : Load offsetted by 3 words */
	    f= 3 * W;
	    goto LOF;

	case 0x0A5:	/* lof.4W : Load offsetted by 4 words */
	    f= 4 * W;
	    goto LOF;

	case 0x0A6:	/* lof.s0 : Load offsetted by f */
	    if (!pliteral(&pc, 1, &f)) goto run;
	    goto LOF;

#if W >= 4
	case 0x20C:	/* lof.L : Load offsetted by f */
	    if (!sliteral(&pc, 4, &f)) goto run;
	    goto LOF;
#endif
	LOF:
	    if (!tlb_chk(&tp, DATA, T.sp, pP|pR|pW)) goto run;
	    s[0]= &umemw(sp_v2p(T.sp));
	    p= *s[0];

	    if (nullptr(p)) goto run;
	    p += f;
	    if (!aligned(p, W)) goto run;

	    if (!tlb_chk(&tp, DATA, p, pP|pR)) goto run;
	    *s[0]= umemw(tlb_v2p(tp, p));

	    T.pc= pc;
	    break;}

	case 0x080:{	/* lal.p : Load address of parameter */
	    unsp l;

	    if (!pliteral(&pc, 2, &l)) goto run;
	    l += 2*W;
	    goto LAL;

	case 0x081:	/* lal.n : Load address of local */
	    if (!nliteral(&pc, 2, &l)) goto run;
	    goto LAL;

	case 0x082:	/* lal.0 : Load address of parameter 0 */
	    l= 2*W;
	    goto LAL;

	case 0x083:	/* lal.-1 : Load address of local 1 */
	    l= -1 * W;
	    goto LAL;

	case 0x084:	/* lal.w0 : Load address of parameter */
	    if (!pliteral(&pc, 1, &l)) goto run;
	    l= (l + 2) * W;
	    goto LAL;

	case 0x085:	/* lal.w-1 : Load address of local */
	    if (!pliteral(&pc, 1, &l)) goto run;
	    l= (l - ((unsp) 1 << 8)) * W;
	    goto LAL;

	case 0x086:	/* lal.w-2 : Load address of local */
	    if (!pliteral(&pc, 1, &l)) goto run;
	    l= (l - ((unsp) 2 << 8)) * W;
	    goto LAL;

#if W >= 4
	case 0x202:	/* lal.P : Load address of parameter */
	    if (!pliteral(&pc, 4, &l)) goto run;
	    l += 2*W;
	    goto LAL;

	case 0x203:	/* lal.N : Load address of local */
	    if (!nliteral(&pc, 4, &l)) goto run;
	    goto LAL;
#endif
	LAL:
	    sp= T.sp - W;
	    if (!sp_chk(sp)) goto run;
	    umemp(sp_v2p(sp))= T.lb + l;

	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x078:{	/* lae.u : Load address of external */
	    unsp g;

	    if (!pliteral(&pc, 2, &g)) goto run;
	    goto LAE;

	case 0x079:	 case 0x07A:	 case 0x07B:	 case 0x07C:	
	case 0x07D:	 case 0x07E:	
	case 0x07F:	/* lae.w0 - lae.w6 : Load address of external */

	    if (!pliteral(&pc, 1, &g)) goto run;
	    g= (((op - 0x079) << 8) + g) * W;
	    goto LAE;

#if W >= 4
	case 0x201:	/* lae.L : Load address of external */
	    if (!sliteral(&pc, 4, &g)) goto run;
	    goto LAE;
#endif
	LAE:
	    sp= T.sp - W;
	    if (!sp_chk(sp)) goto run;
	    umemw(sp_v2p(sp))= g;

	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0BE:{	/* lxa.1 : Load AB 1 lexical level back */
	    unsigned off;
	    unsp xlb;
	    unsw n;

	    n= 1;
	    off= 2*W;
	    goto LXL;

	case 0x0BF:	/* lxl.1 : Load LB 1 lexical level back */
	    n= 1;
	    off= 0;
	    goto LXL;

	case 0x0C0:	/* lxl.2 : Load LB 2 lexical levels back */
	    n= 2;
	    off= 0;
	    goto LXL;

	case 0x151:	/* lxa.l : Load AB n lexical levels back */
	    if (!sliteral(&pc, 2, &n)) goto run;
	    off= 2*W;
	    goto LXL;

	case 0x152:	/* lxl.l : Load LB n lexical levels back */
	    if (!sliteral(&pc, 2, &n)) goto run;
	    off= 0;
	    goto LXL;

	LXL:
	    xlb= T.lb;

	    if (T.flags & F_(T_RESTART)) {
		n= T.ret[0];
		xlb= T.ret[1];
		T.flags &= ~F_(T_RESTART);
	    }
	    while (n > 0) {
		if (!rdp(xlb + 2*W, &xlb)) {
		    T.ret[0]= n;
		    T.ret[1]= xlb;
		    T.flags |= F_(T_RESTART);
		    goto run;
		}
		n--;
	    }
	    sp= T.sp - P;
	    if (!wrp(sp, xlb + off)) {
		T.ret[0]= n;
		T.ret[1]= xlb;
		T.flags |= F_(T_RESTART);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0A7:{	/* loi.l : Load indirect o bytes */
	    unsp o;
	    unsp p, *s[1];

	    if (!sliteral(&pc, 2, &o)) goto run;
	    sp= T.sp;
	    goto LOI;

	case 0x0A8:	/* loi.1 : Load indirect 1 byte */
	    o= 1;
	    sp= T.sp;
	    goto LOI;

	case 0x0A9:	/* loi.1W : Load indirect 1 word */
	case 0x0AA:	/* loi.2W : Load indirect 2 words */
	case 0x0AB:	/* loi.3W : Load indirect 3 words */
	case 0x0AC:	/* loi.4W : Load indirect 4 words */
	    o= ((op - 0x0A9) + 1) * W;
	    sp= T.sp;
	    goto LOI;

	case 0x0AD:	/* loi.s0 : Load indirect o bytes */
	    if (!pliteral(&pc, 1, &o)) goto run;
	    sp= T.sp;
	    goto LOI;
#if W >= 4
	case 0x237:	/* loi.L : Load indirect o bytes */
	    if (!sliteral(&pc, 4, &o)) goto run;
	    sp= T.sp;
	    goto LOI;
#endif
	case 0x14D:	/* los.l : Load indirect */
	    if (!sliteral(&pc, 2, &o)) goto run;
	    sp= T.sp;
	    goto LOS;

	case 0x14E:	/* los.z : Load indirect */
	    if (!rdw(T.sp, &o)) goto run;
	    sp= T.sp + W;
	    goto LOS;

	LOS:
	    if (o != W) { trap(T_ILLINS); goto run; }

	    if (!rdw(sp, &o)) goto run;
	    sp += W;
	    goto LOI;

	LOI:
	    if (!sp_chk(sp)) goto run;
	    s[0]= &umemp(sp_v2p(sp));
	    p= *s[0];
	    if (nullptr(p)) goto run;

	    switch (o) {
	    case 0:	trap(T_ILLINS); goto run;
	    case 1:
		if (!tlb_chk(&tp, DATA, p, pP|pR)) goto run;
		*s[0]= umem1(tlb_v2p(tp, p));
		break;
#if W >= 4
	    case 2:
		if (!aligned(p, 2)) goto run;
		if (!tlb_chk(&tp, DATA, p, pP|pR)) goto run;
		*s[0]= umem2(tlb_v2p(tp, p));
		break;
#endif
	    case W:
		if (!aligned(p, W)) goto run;
		if (!tlb_chk(&tp, DATA, p, pP|pR)) goto run;
		*s[0]= umemw(tlb_v2p(tp, p));
		break;

	    default:
		if ((o & (W-1)) != 0) { trap(T_ODDZ); goto run; }
		if (!aligned(p, W)) goto run;
		sp -= o - P;
		if (!wordcpy(sp, p, o)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x08B:{	/* ldl.0 : Load double 0th parameter */
	    unsp l;
	    unsdw w;

	    l= 2;
	    goto LDL;

	case 0x08C:	/* ldl.w-1 : Load double l-th local */
	    if (!pliteral(&pc, 1, &l)) goto run;
	    l -= (unsp) 1 << 8;
	    goto LDL;

	case 0x147:	/* ldl.pw : Load double l-th parameter */
	    if (!pliteral(&pc, 2, &l)) goto run;
	    l += 2;
	    goto LDL;

	case 0x148:	/* ldl.nw : Load double l-th local */
	    if (!nliteral(&pc, 2, &l)) goto run;
	    goto LDL;

#if W >= 4
	case 0x206:	/* ldl.Pw : Load double l-th parameter */
	    if (!pliteral(&pc, 4, &l)) goto run;
	    l += 2;
	    goto LDL;

	case 0x207:	/* ldl.Nw : Load double l-th local */
	    if (!nliteral(&pc, 4, &l)) goto run;
	    goto LDL;
#endif
	LDL:
	    if (!rddw(T.lb + l*W, &w)) goto run;
	    if (!wrdw(T.sp - 2*W, w)) goto run;
	    T.sp -= 2*W;
	    T.pc= pc;
	    break;}

	case 0x089:{	/* lde.lw : Load double external */
	    unsp g;
	    unsdw w;

	    if (!sliteral(&pc, 2, &g)) goto run;
	    goto LDE;

	case 0x08A:	/* lde.w0 : Load double external */
	    if (!pliteral(&pc, 1, &g)) goto run;
	    goto LDE;

#if W >= 4
	case 0x204:	/* lde.Lw : Load double external */
	    if (!sliteral(&pc, 4, &g)) goto run;
	    goto LDE;
#endif
	LDE:
	    if (!rddw(g * W, &w)) goto run;
	    if (!wrdw(T.sp, w)) goto run;
	    T.sp -= 2*W;
	    T.pc= pc;
	    break;}

	case 0x146:{	/* ldf.l : Load double offsetted */
	    unsp f, p;
	    unsdw w;

	    if (!sliteral(&pc, 2, &f)) goto run;
	    goto LDF;

#if W >= 4
	case 0x205:	/* ldf.L : Load double offsetted */
	    if (!sliteral(&pc, 4, &f)) goto run;
	    goto LDF;
#endif
	LDF:
	    if (!rdp(T.sp, &p)) goto run;
	    if (nullptr(p)) goto run;
	    if (!rddw(p + f, &w)) goto run;
	    if (!wrdw(T.sp + P - 2*W, w)) goto run;
	    T.sp -= 2*W - P;
	    T.pc= pc;
	    break;}

	case 0x150:{	/* lpi.l : Load procedure identifier */
	    unsp p;

	    if (!sliteral(&pc, 2, &p)) goto run;
	    goto LPI;

#if W >= 4
	case 0x20F:	/* lpi.L : Load procedure identifier */
	    if (!sliteral(&pc, 4, &p)) goto run;
	    goto LPI;
#endif
	LPI:
	    sp= T.sp - W;
	    if (!sp_chk(sp)) goto run;
	    umemp(sp_v2p(sp))= p;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0E0:{	/* stl.pw : Store word at l-th parameter */
	    unsp l;
	    unsw w;

	    if (!pliteral(&pc, 2, &l)) goto run;
	    l += 2;
	    goto STL;

	case 0x0E1:	/* stl.nw : Store word at l-th local */
	    if (!nliteral(&pc, 2, &l)) goto run;
	    goto STL;

	case 0x0E2:	/* stl.0 : Store word at 0th parameter */
	case 0x0E3:	/* stl.1W : Store word at 1st parameter */
	    l= (op - 0x0E2) + 2;
	    goto STL;

	case 0x0E4:	/* stl.-1W : Store word at 1st local */
	case 0x0E5:	/* stl.-2W : Store word at 2nd local */
	case 0x0E6:	/* stl.-3W : Store word at 3rd local */
	case 0x0E7:	/* stl.-4W : Store word at 4th local */
	case 0x0E8:	/* stl.-5W : Store word at 5th local */
	    l= ((unsp) 0x0E4 + 1 - op);
	    goto STL;

	case 0x0E9:	/* stl.w-1 : Store word at l-th local */
	    if (!pliteral(&pc, 1, &l)) goto run;
	    l -= (unsp) 1 << 8;
	    goto STL;

#if W >= 4
	case 0x22C:	/* stl.Pw : Store word at l-th parameter */
	    if (!pliteral(&pc, 4, &l)) goto run;
	    l += 2;
	    goto STL;

	case 0x22D:	/* stl.Nw : Store word at l-th local */
	    if (!nliteral(&pc, 4, &l)) goto run;
	    goto STL;
#endif
	STL:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w= umemw(sp_v2p(sp));
	    sp += W;

	    l= l * W + T.lb;
	    if (!tlb_chk(&tp, DATA, l, pP|pW)) goto run;
	    umemw(tlb_v2p(tp, l))= w;

	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0D2:{	/* ste.lw : Store external word g */
	    unsp g;
	    unsw w;

	    if (!sliteral(&pc, 2, &g)) goto run;
	    goto STE;

	case 0x0D3:	 case 0x0D4:
	case 0x0D5:	/* ste.w0 - ste.w2 : Store external word g */

	    if (!pliteral(&pc, 1, &g)) goto run;
	    g += (op - 0x0D3) << 8;
	    goto STE;

#if W >= 4
	case 0x22A:	/* ste.Lw : Store external word g */
	    if (!sliteral(&pc, 4, &g)) goto run;
	    goto STE;
#endif
	STE:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w= umemw(sp_v2p(sp));
	    sp += W;

	    g *= W;
	    if (!tlb_chk(&tp, DATA, g, pP|pW)) goto run;
	    umemw(tlb_v2p(tp, g))= w;

	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0CF:{	/* sil.w-1 : Store word pointed to by l-th local */
	    unsp l;
	    unsw w;

	    if (!pliteral(&pc, 1, &l)) goto run;
	    l -= (unsp) 1 << 8;
	    goto SIL;

	case 0x0D0:	/* sil.w0 : Store word pointed to by l-th parameter */
	    if (!pliteral(&pc, 1, &l)) goto run;
	    l += 2;
	    goto SIL;

	case 0x17C:	/* sil.pw : Store word pointed to by l-th parameter */
	    if (!pliteral(&pc, 2, &l)) goto run;
	    l += 2;
	    goto SIL;

	case 0x17D:	/* sil.nw : Store word pointed to by l-th local */
	    if (!nliteral(&pc, 2, &l)) goto run;
	    goto SIL;

#if W >= 4
	case 0x228:	/* sil.Pw : Store word pointed to by l-th parameter */
	    if (!pliteral(&pc, 4, &l)) goto run;
	    l += 2;
	    goto SIL;

	case 0x229:	/* sil.Nw : Store word pointed to by l-th local */
	    if (!nliteral(&pc, 4, &l)) goto run;
	    goto SIL;
#endif
	SIL:
	    l= l * W + T.lb;
	    if (!tlb_chk(&tp, DATA, l, pP|pR)) goto run;
	    l= umemp(tlb_v2p(tp, l));

	    if (nullptr(l)) goto run;
	    if (!aligned(l, W)) goto run;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w= umemw(sp_v2p(sp));
	    sp += W;

	    if (!tlb_chk(&tp, DATA, l, pP|pW)) goto run;
	    umemw(tlb_v2p(tp, l))= w;

	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0D6:{	/* stf.l : Store offsetted by f */
	    unsp p, f;
	    unsw w;

	    if (!sliteral(&pc, 2, &f)) goto run;
	    goto STF;

	case 0x0D7:	/* stf.1W : Store offsetted by 1 word */
	    f= 1 * W;
	    goto STF;

	case 0x0D8:	/* stf.2W : Store offsetted by 2 words */
	    f= 2 * W;
	    goto STF;

	case 0x0D9:	/* stf.s0 : Store offsetted by f */
	    if (!pliteral(&pc, 1, &f)) goto run;
	    goto STF;

#if W >= 4
	case 0x22B:	/* stf.L : Store offsetted by f */
	    if (!sliteral(&pc, 4, &f)) goto run;
	    goto STF;
#endif
	STF:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    p= umemp(sp_v2p(sp));
	    sp += P;

	    if (nullptr(p)) goto run;
	    p += f;
	    if (!aligned(p, W)) goto run;

	    if (!sp_chk(sp)) goto run;
	    w= umemw(sp_v2p(sp));
	    sp += W;

	    if (!tlb_chk(&tp, DATA, p, pP|pW)) goto run;
	    umemw(tlb_v2p(tp, f))= w;

	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0DA:{	/* sti.1 : Store indirect 1 byte */
	    unsp o;
	    unsp p;
	    unsw w;

	    o= 1;
	    sp= T.sp;
	    goto STI;

	case 0x0DB:	/* sti.1W : Store indirect 1 word */
	case 0x0DC:	/* sti.2W : Store indirect 2 words */
	case 0x0DD:	/* sti.3W : Store indirect 3 words */
	case 0x0DE:	/* sti.4W : Store indirect 4 words */
	    o= ((op - 0x0DB) + 1) * W;
	    sp= T.sp;
	    goto STI;

	case 0x0DF:	/* sti.s0 : Store indirect o bytes */
	    if (!pliteral(&pc, 1, &o)) goto run;
	    sp= T.sp;
	    goto STI;

	case 0x187:	/* sti.l : Store indirect o bytes */
	    if (!sliteral(&pc, 2, &o)) goto run;
	    sp= T.sp;
	    goto STI;

#if W >= 4
	case 0x238:	/* sti.L : Store indirect o bytes */
	    if (!sliteral(&pc, 4, &o)) goto run;
	    sp= T.sp;
	    goto STI;
#endif
	case 0x188:	/* sts.l : Store indirect */
	    if (!sliteral(&pc, 2, &o)) goto run;
	    sp= T.sp;
	    goto STS;

	case 0x189:	/* sts.z : Store indirect */
	    if (!rdw(T.sp, &o)) goto run;
	    sp= T.sp + W;

	STS:
	    if (o != W) { trap(T_ILLINS); goto run; }

	    if (!rdw(sp, &o)) goto run;
	    sp += W;

	STI:
	    if (!sp_chk(sp)) goto run;
	    p= umemp(sp_v2p(sp));
	    sp += P;
	    if (nullptr(p)) goto run;

	    if (!sp_chk(sp)) goto run;
	    w= umemw(sp_v2p(sp));
	    sp += W;

	    switch (o) {
	    case 0:	trap(T_ILLINS); goto run;
	    case 1:
		if (!tlb_chk(&tp, DATA, p, pP|pW)) goto run;
		umem1(tlb_v2p(tp, p))= w;
		break;
#if W >= 4
	    case 2:
		if (!aligned(p, 2)) goto run;
		if (!tlb_chk(&tp, DATA, p, pP|pW)) goto run;
		umem2(tlb_v2p(tp, p))= w;
		break;
#endif
	    case W:
		if (!aligned(p, W)) goto run;
		if (!tlb_chk(&tp, DATA, p, pP|pW)) goto run;
		umemw(tlb_v2p(tp, p))= w;
		break;

	    default:
		if ((o & (W-1)) != 0) { trap(T_ODDZ); goto run; }
		if (!aligned(p, W)) goto run;
		sp -= W;
		if (!wordcpy(p, sp, o)) goto run;
		sp += o;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0CD:{	/* sdl.w-1 : Store double l-th local */
	    unsp l;
	    unsdw w;

	    if (!pliteral(&pc, 1, &l)) goto run;
	    l -= (unsp) 1 << 8;
	    goto SDL;

	case 0x177:	/* sdl.pw : Store double l-th parameter */
	    if (!pliteral(&pc, 2, &l)) goto run;
	    l += 2;
	    goto SDL;

	case 0x178:	/* sdl.nw : Store double l-th local */
	    if (!nliteral(&pc, 2, &l)) goto run;
	    goto SDL;

#if W >= 4
	case 0x226:	/* sdl.Pw : Store double l-th parameter */
	    if (!pliteral(&pc, 4, &l)) goto run;
	    l += 2;
	    goto SDL;

	case 0x227:	/* sdl.Nw : Store double l-th local */
	    if (!nliteral(&pc, 4, &l)) goto run;
	    goto SDL;
#endif
	SDL:
	    if (!rddw(T.sp, &w)) goto run;
	    if (!wrdw(T.lb + l*W, w)) goto run;
	    T.sp += 2*W;
	    T.pc= pc;
	    break;}

	case 0x175:{	/* sde.u : Store double external */
	    unsp g;
	    unsdw w;

	    if (!pliteral(&pc, 2, &g)) goto run;
	    goto SDE;

#if W >= 4
	case 0x224:	/* sde.L : Store double external */
	    if (!sliteral(&pc, 4, &g)) goto run;
	    goto SDE;
#endif
	SDE:
	    if (!rddw(T.sp, &w)) goto run;
	    if (!wrdw(g, w)) goto run;
	    T.sp += 2*W;
	    T.pc= pc;
	    break;}

	case 0x176:{	/* sdf.l : Store double offsetted */
	    unsp f, p;
	    unsdw w;

	    if (!sliteral(&pc, 2, &f)) goto run;
	    goto SDF;

#if W >= 4
	case 0x225:	/* sdf.L : Store double offsetted */
	    if (!sliteral(&pc, 4, &f)) goto run;
	    goto SDF;
#endif
	SDF:
	    if (!rdp(T.sp, &p)) goto run;
	    if (nullptr(p)) goto run;
	    if (!rddw(T.sp + P, &w)) goto run;
	    if (!wrdw(p + f, w)) goto run;
	    T.sp += P + 2*W;
	    T.pc= pc;
	    break;}

	case 0x024:{	/* adi.1W : Signed word addition */
	    unsw s;

	    sp= T.sp;
	    goto ADI_1W;

#if has_int(2*W)
	case 0x025:	/* adi.2W : Signed doubleword addition */
	    sp= T.sp;
	    goto ADI_2W;
#endif

	case 0x104:	/* adi.l : Signed addition */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto ADI;

	case 0x105:	/* adi.z : Signed addition */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto ADI;

	ADI:
	    if (s == W) {
		unsw r, w0, w1, *s[1];

	    ADI_1W:
		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));
		w0= *s[0];

		r= w0 + w1;
		if ((T.flags & F_(T_IOVFL)) == 0) {
		    if (((~(w0 | w1) & r) | (w0 & w1 & ~r)) >> (W*8-1)) {
			trap(T_IOVFL);
			goto run;
		    }
		}
		*s[0]= r;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0, w1;

	    ADI_2W:
		if (!rddw(sp, &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, &w0)) goto run;

		r= w0 + w1;
		if ((T.flags & F_(T_IOVFL)) == 0) {
		    if (((~(w0 | w1) & r) | (w0 & w1 & ~r)) >> (2*W*8-1)) {
			trap(T_IOVFL);
			goto run;
		    }
		}
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0CB:{	/* sbi.1W : Signed word subtract */
	    unsw s;

	    sp= T.sp;
	    goto SBI_1W;

#if has_int(2*W)
	case 0x0CC:	/* sbi.2W : Signed doubleword subtract */
	    sp= T.sp;
	    goto SBI_2W;
#endif

	case 0x16F:	/* sbi.l : Signed subtract */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto SBI;

	case 0x170:	/* sbi.z : Signed subtract */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto SBI;

	SBI:
	    if (s == W) {
		unsw r, w0, w1, *s[1];

	    SBI_1W:
		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));
		w0= *s[0];

		r= w0 - w1;
		if ((T.flags & F_(T_IOVFL)) == 0) {
		    if (((~w0 & w1 & r) | (w0 & ~(w1 | r))) >> (W*8-1)) {
			trap(T_IOVFL);
			goto run;
		    }
		}
		*s[0]= r;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0, w1;

	    SBI_2W:
		if (!rddw(sp, &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, &w0)) goto run;

		r= w0 - w1;
		if ((T.flags & F_(T_IOVFL)) == 0) {
		    if (((~w0 & w1 & r) | (w0 & ~(w1 | r))) >> (2*W*8-1)) {
			trap(T_IOVFL);
			goto run;
		    }
		}
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0C2:{	/* mli.1W : Signed multiply */
	    unsw s;

	    sp= T.sp;
	    goto MLI_1W;

#if has_int(2*W)
	case 0x0C3:	/* mli.2W : Signed doubleword multiply */
	    sp= T.sp;
	    goto MLI_2W;
#endif

	case 0x155:	/* mli.l : Signed multiply */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto MLI;

	case 0x156:	/* mli.z : Signed multiply */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto MLI;

	MLI:
	    if (s == W) {
		unsw r, w0, w1, *s[1];

	    MLI_1W:
		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));
		w0= *s[0];

		r= w0 * w1;
		if ((T.flags & F_(T_IOVFL)) == 0) {
		    if (w0 > 1 && w1 > 1) {
			unsw ar, aw0, aw1;

			aw0= (w0 >> (W*8-1)) ? -w0 : w0;
			aw1= (w1 >> (W*8-1)) ? -w1 : w1;
			ar= aw0 * aw1;
			if (ar > (((unsw) -1 >> 1) + ((w0 ^ w1) >> (W*8-1)))
						    || ar / aw0 != aw1) {
			    trap(T_IOVFL);
			    goto run;
			}
		    }
		}
		*s[0]= r;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0, w1;

	    MLI_2W:
		if (!rddw(sp, &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, &w0)) goto run;

		r= w0 * w1;
		if ((T.flags & F_(T_IOVFL)) == 0) {
		    if (w0 > 1 && w1 > 1) {
			unsdw ar, aw0, aw1;

			aw0= (w0 >> (2*W*8-1)) ? -w0 : w0;
			aw1= (w1 >> (2*W*8-1)) ? -w1 : w1;
			ar= (aw0 * aw1) & ((unsdw) -1 >> 1);
			if (ar > (((unsdw)-1>>1) + ((w0 ^ w1)>>(2*W*8-1)))
						    || ar / aw0 != aw1) {
			    trap(T_IOVFL);
			    goto run;
			}
		    }
		}
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x06C:{	/* dvi.1W : Signed word divide */
	    unsw s;

	    sp= T.sp;
	    goto DVI_1W;

	case 0x135:	/* dvi.l : Signed divide */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto DVI;

	case 0x136:	/* dvi.z : Signed divide */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto DVI;

	DVI:
	    if (s == W) {
		unsw r, w0, w1, *s[1];

	    DVI_1W:
		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));
		w0= *s[0];

		if (w1 == 0) {
		    r= (unsw) 1 << (W*8-1);
		    if ((T.flags & F_(T_IDIVZ)) == 0) {
			trap(T_IDIVZ);
			goto run;
		    }
		} else {
		    if (w0 == ((unsw) 1 << (W*8-1)) && w1 == (unsw) -1) {
			r= w0;
			if ((T.flags & F_(T_IOVFL)) == 0) {
			    trap(T_IOVFL);
			    goto run;
			}
		    } else {
			*(intw*)&r= *(intw*)&w0 / *(intw*)&w1;
		    }
		}
		*s[0]= r;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0, w1;

		if (!rddw(sp, &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, &w0)) goto run;

		if (w1 == 0) {
		    r= (unsdw) 1 << (2*W*8-1);
		    if ((T.flags & F_(T_IDIVZ)) == 0) {
			trap(T_IDIVZ);
			goto run;
		    }
		} else {
		    if (w0 == ((unsdw) 1 << (2*W*8-1)) && w1 == (unsdw)-1) {
			r= w0;
			if ((T.flags & F_(T_IOVFL)) == 0) {
			    trap(T_IOVFL);
			    goto run;
			}
		    } else {
			*(intdw*)&r= *(intdw*)&w0 / *(intdw*)&w1;
		    }
		}
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0C8:{	/* rmi.1W : Signed word remainder */
	    unsw s;

	    sp= T.sp;
	    goto RMI_1W;

	case 0x162:	/* rmi.l : Signed remainder */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto RMI;

	case 0x163:	/* rmi.z : Signed remainder */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto RMI;

	RMI:
	    if (s == W) {
		unsw r, w0, w1, *s[1];

	    RMI_1W:
		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));
		w0= *s[0];

		if (w1 == 0) {
		    r= 0;
		    if ((T.flags & F_(T_IDIVZ)) == 0) {
			trap(T_IDIVZ);
			goto run;
		    }
		} else {
		    if (w0 == ((unsw) 1 << (W*8-1)) && w1 == (unsw) -1) {
			r= 0;
		    } else {
			*(intw*)&r= *(intw*)&w0 % *(intw*)&w1;
		    }
		}
		*s[0]= r;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0, w1;

		if (!rddw(sp, &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, &w0)) goto run;

		if (w1 == 0) {
		    r= 0;
		    if ((T.flags & F_(T_IDIVZ)) == 0) {
			trap(T_IDIVZ);
			goto run;
		    }
		} else {
		    if (w0 == ((unsdw) 1 << (2*W*8-1)) && w1 == (unsdw)-1) {
			r= 0;
		    } else {
			*(intdw*)&r= *(intdw*)&w0 % *(intdw*)&w1;
		    }
		}
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x15C:{	/* ngi.l : Negate */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto NGI;

	case 0x15D:	/* ngi.z : Negate */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto NGI;

	NGI:
	    if (s == W) {
		unsw r, *s[1];

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));
		r= *s[0];

		if ((T.flags & F_(T_IOVFL)) == 0) {
		    if (r == ((unsw) 1 << (W*8-1))) {
			trap(T_IOVFL);
			goto run;
		    }
		}
		*s[0]= -r;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r;

		if (!rddw(sp, &r)) goto run;

		if ((T.flags & F_(T_IOVFL)) == 0) {
		    if (r == ((unsdw) 1 << (2*W*8-1))) {
			trap(T_IOVFL);
			goto run;
		    }
		}
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0D1:{	/* sli.1W : Shift left signed word */
	    unsw s;

	    sp= T.sp;
	    goto SLI_1W;

	case 0x17F:	/* sli.l : Left shift signed */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto SLI;

	case 0x180:	/* sli.z : Left shift signed */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto SLI;

	SLI:
	    if (s == W) {
		unsw r, w0, w1, *s[1];

	    SLI_1W:
		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));
		w0= *s[0];

		r= w0 << w1;
		if ((T.flags & F_(T_IOVFL)) == 0) {
		    if (((r ^ w0) >> (W*8-1)) || (*(intw*)&r >> w1) != w0) {
			trap(T_IOVFL);
			goto run;
		    }
		}
		*s[0]= r;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0;
		unsw w1;

		if (!rdw(sp + 1*W, &w1)) goto run;
		sp += W;
		if (!rddw(sp, &w0)) goto run;

		r= w0 << w1;
		if ((T.flags & F_(T_IOVFL)) == 0) {
		    if (((r ^ w0) >> (2*W*8-1)) || (*(intdw*)&r >> w1) != w0) {
			trap(T_IOVFL);
			goto run;
		    }
		}
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x183:{	/* sri.l : Right shift signed */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto SRI;

	case 0x184:	/* sri.z : Right shift signed */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto SRI;

	SRI:
	    if (s == W) {
		unsw w0, w1, *s[1];

		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));
		w0= *s[0];

		*s[0]= *(intw*)&w0 >> w1;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0;
		unsw w1;

		if (!rdw(sp + 1*W, &w1)) goto run;
		sp += W;
		if (!rddw(sp, &w0)) goto run;

		r= *(intdw*)&w0 >> w1;
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x108:{	/* adu.l : Unsigned addition */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto ADU;

	case 0x109:	/* adu.z : Unsigned addition */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto ADU;

	ADU:
	    if (s == W) {
		unsw w1;

		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		umemw(sp_v2p(sp)) += w1;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0, w1;

		if (!rddw(sp, &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, &w0)) goto run;

		r= w0 + w1;
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x173:{	/* sbu.l : Unsigned subtract */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto SBU;

	case 0x174:	/* sbu.z : Unsigned subtract */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto SBU;

	SBU:
	    if (s == W) {
		unsw w1;

		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		umemw(sp_v2p(sp)) -= w1;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0, w1;

		if (!rddw(sp, &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, &w0)) goto run;

		r= w0 - w1;
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x157:{	/* mlu.l : Unsigned multiply */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto MLU;

	case 0x158:	/* mlu.z : Unsigned multiply */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto MLU;

	MLU:
	    if (s == W) {
		unsw w1;

		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		umemw(sp_v2p(sp)) *= w1;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0, w1;

		if (!rddw(sp, &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, &w0)) goto run;

		r= w0 * w1;
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x137:{	/* dvu.l : Unsigned divide */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto DVU;

	case 0x138:	/* dvu.z : Unsigned divide */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto DVU;

	DVU:
	    if (s == W) {
		unsw r, w0, w1, *s[1];

		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));
		w0= *s[0];

		if (w1 == 0) {
		    r= (unsw) 1 << (W*8-1);
		    if ((T.flags & F_(T_IDIVZ)) == 0) {
			trap(T_IDIVZ);
			goto run;
		    }
		} else {
		    r= w0 / w1;
		}
		*s[0]= r;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0, w1;

		if (!rddw(sp, &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, &w0)) goto run;

		if (w1 == 0) {
		    r= (unsdw) 1 << (2*W*8-1);
		    if ((T.flags & F_(T_IDIVZ)) == 0) {
			trap(T_IDIVZ);
			goto run;
		    }
		} else {
		    r= w0 / w1;
		}
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x164:{	/* rmu.l : Unsigned remainder */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto RMU;

	case 0x165:	/* rmu.z : Unsigned remainder */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto RMU;

	RMU:
	    if (s == W) {
		unsw r, w0, w1, *s[1];

		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));
		w0= *s[0];

		if (w1 == 0) {
		    r= 0;
		    if ((T.flags & F_(T_IDIVZ)) == 0) {
			trap(T_IDIVZ);
			goto run;
		    }
		} else {
		    r= w0 % w1;
		}
		*s[0]= r;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0, w1;

		if (!rddw(sp, &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, &w0)) goto run;

		if (w1 == 0) {
		    r= 0;
		    if ((T.flags & F_(T_IDIVZ)) == 0) {
			trap(T_IDIVZ);
			goto run;
		    }
		} else {
		    r= w0 % w1;
		}
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x181:{	/* slu.l : Left shift unsigned */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto SLU;

	case 0x182:	/* slu.z : Left shift unsigned */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto SLU;

	SLU:
	    if (s == W) {
		unsw w1;

		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		umemw(sp_v2p(sp)) <<= w1;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0;
		unsw w1;

		if (!rdw(sp + 1*W, &w1)) goto run;
		sp += W;
		if (!rddw(sp, &w0)) goto run;

		r= w0 << w1;
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x185:{	/* sru.l : Right shift unsigned */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto SRU;

	case 0x186:	/* sru.z : Right shift unsigned */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto SRU;

	SRU:
	    if (s == W) {
		unsw w1;

		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		umemw(sp_v2p(sp)) >>= w1;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0;
		unsw w1;

		if (!rdw(sp + 1*W, &w1)) goto run;
		sp += W;
		if (!rddw(sp, &w0)) goto run;

		r= w0 >> w1;
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x023:{	/* adf.s0 : Floating point addition */
	    unsw s;

	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto ADF;

	case 0x102:	/* adf.l : Floating point addition */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto ADF;

	case 0x103:	/* adf.z : Floating point addition */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto ADF;

	ADF:
	    if (s == 4) {
		flt4 r, f0, f1;

		if (!rdf4(sp, &f1)) goto run;
		sp += 4;
		if (!rdf4(sp, &f0)) goto run;

		r= f0 + f1;
		if (!wrf4(sp, r)) goto run;
	    } else
	    if (s == 8) {
		flt8 r, f0, f1;

		if (!rdf8(sp, &f1)) goto run;
		sp += 8;
		if (!rdf8(sp, &f0)) goto run;

		r= f0 + f1;
		if (!wrf8(sp, r)) goto run;
	    } else {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0CA:{	/* sbf.s0 : Floating point subtract */
	    unsw s;

	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto SBF;

	case 0x16D:	/* sbf.l : Floating point subtract */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto SBF;

	case 0x16E:	/* sbf.z : Floating point subtract */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto SBF;

	SBF:
	    if (s == 4) {
		flt4 r, f0, f1;

		if (!rdf4(sp, &f1)) goto run;
		sp += 4;
		if (!rdf4(sp, &f0)) goto run;

		r= f0 - f1;
		if (!wrf4(sp, r)) goto run;
	    } else
	    if (s == 8) {
		flt8 r, f0, f1;

		if (!rdf8(sp, &f1)) goto run;
		sp += 8;
		if (!rdf8(sp, &f0)) goto run;

		r= f0 - f1;
		if (!wrf8(sp, r)) goto run;
	    } else {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0C1:{	/* mlf.s0 : Floating point multiply */
	    unsw s;

	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto MLF;

	case 0x153:	/* mlf.l : Floating point multiply */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto MLF;

	case 0x154:	/* mlf.z : Floating point multiply */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto MLF;

	MLF:
	    if (s == 4) {
		flt4 r, f0, f1;

		if (!rdf4(sp, &f1)) goto run;
		sp += 4;
		if (!rdf4(sp, &f0)) goto run;

		r= f0 * f1;
		if (!wrf4(sp, r)) goto run;
	    } else
	    if (s == 8) {
		flt8 r, f0, f1;

		if (!rdf8(sp, &f1)) goto run;
		sp += 8;
		if (!rdf8(sp, &f0)) goto run;

		r= f0 * f1;
		if (!wrf8(sp, r)) goto run;
	    } else {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x06B:{	/* dvf.s0 : Floating point division */
	    unsw s;

	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto DVF;

	case 0x133:	/* dvf.l : Floating point division */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto DVF;

	case 0x134:	/* dvf.z : Floating point division */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto DVF;

	DVF:
	    if (s == 4) {
		flt4 r, f0, f1;

		if (!rdf4(sp, &f1)) goto run;
		sp += 4;
		if (!rdf4(sp, &f0)) goto run;

		r= f0 / f1;
		if (!wrf4(sp, r)) goto run;
	    } else
	    if (s == 8) {
		flt8 r, f0, f1;

		if (!rdf8(sp, &f1)) goto run;
		sp += 8;
		if (!rdf8(sp, &f0)) goto run;

		r= f0 / f1;
		if (!wrf8(sp, r)) goto run;
	    } else {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x15A:{	/* ngf.l : Floating point negation */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    goto NGF;

	case 0x15B:	/* ngf.z : Floating point negation */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto NGF;

	NGF:
	    if (s == 4) {
		flt4 r;

		if (!rdf4(T.sp, &r)) goto run;

		r= -r;
		if (!wrf4(T.sp, r)) goto run;
	    } else
	    if (s == 8) {
		flt8 r;

		if (!rdf8(T.sp, &r)) goto run;

		r= -r;
		if (!wrf8(T.sp, r)) goto run;
	    } else {
		trap(T_ILLINS);
		goto run;
	    }
	    T.pc= pc;
	    break;}

	case 0x13B:{	/* fif.l : Multiply and split integer and fraction */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto FIF;

	case 0x13C:	/* fif.z : Multiply and split integer and fraction */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto FIF;

	FIF:
	    if (s == 4) {
		flt4 f0, f1;
		double i, f;

		if (!rdf4(sp + 0, &f1)) goto run;
		if (!rdf4(sp + 4, &f0)) goto run;

		f= modf((double) f0 * (double) f1, &i);

		if (!wrf4(sp + 4, (flt4) f)) goto run;
		if (!wrf4(sp + 0, (flt4) i)) goto run;
	    } else
	    if (s == 8) {
		flt8 f0, f1;
		double i, f;

		if (!rdf8(sp + 0, &f1)) goto run;
		if (!rdf8(sp + 8, &f0)) goto run;

		f= modf((double) f0 * (double) f1, &i);

		if (!wrf8(sp + 8, (flt8) f)) goto run;
		if (!wrf8(sp + 0, (flt8) i)) goto run;
	    } else {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x139:{	/* fef.l : Split into exponent and mantissa */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto FEF;

	case 0x13A:	/* fef.z : Split into exponent and mantissa */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto FEF;

	FEF:
	    if (s == 4) {
		flt4 f;
		double m;
		int e;

		if (!rdf4(sp, &f)) goto run;

		m= frexp((double) f, &e);

		if (!wrf4(sp, (flt4) m)) goto run;
		sp -= W;
		if (!wrw(sp, (unsw) e)) goto run;
	    } else
	    if (s == 8) {
		flt8 f;
		double m;
		int e;

		if (!rdf8(sp, &f)) goto run;

		m= frexp((double) f, &e);

		if (!wrf8(sp, (flt8) m)) goto run;
		sp -= W;
		if (!wrw(sp, (unsw) e)) goto run;
	    } else {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x026:{	/* adp.l : Add f to pointer */
	    unsw s;
	    unsp f;

	    if (!sliteral(&pc, 2, &f)) goto run;
	    sp= T.sp;
	    goto ADP;

	case 0x027:	/* adp.1 : Add 1 to pointer */
	case 0x028:	/* adp.2 : Add 2 to pointer */
	    f= (op - 0x027 + 1);
	    sp= T.sp;
	    goto ADP;

	case 0x029:	/* adp.s0 : Add f to pointer */
	    if (!pliteral(&pc, 1, &f)) goto run;
	    sp= T.sp;
	    goto ADP;

	case 0x02A:	/* adp.s-1 : Add f to pointer */
	    if (!pliteral(&pc, 1, &f)) goto run;
	    f -= (unsw) 1 << 8;
	    sp= T.sp;
	    goto ADP;

	case 0x02B:	/* ads.1W : Add offset to pointer */
	    sp= T.sp;
	    goto ADS;

	case 0x106:	/* ads.l : Add offset to pointer */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    if (s != W) { trap(T_ILLINS); goto run; }
	    sp= T.sp;
	    goto ADS;

	case 0x107:	/* ads.z : Add offset to pointer */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    if (s != W) { trap(T_ILLINS); goto run; }
	ADS:
	    if (!sp_chk(sp)) goto run;
	    f= umemp(sp_v2p(sp));
	    sp += P;
	    goto ADP;

#if W >= 4
	case 0x210:	/* adp.L : Add f to pointer */
	    if (!sliteral(&pc, 4, &f)) goto run;
	    sp= T.sp;
	    goto ADP;
#endif
	ADP:
	    if (!sp_chk(sp)) goto run;
	    umemp(sp_v2p(sp)) += f;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x171:{	/* sbs.l : Subtract pointers */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto SBS;

	case 0x172:	/* sbs.z : Subtract pointers */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto SBS;

	SBS:
	    if (s == P) {
		unsp p1;

		sp= T.sp;
		if (!sp_chk(sp)) goto run;
		p1= umemp(sp_v2p(sp));
		sp += P;

		if (!sp_chk(sp)) goto run;
		umemp(sp_v2p(sp)) -= p1;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsp p0, p1;
		unsdw r;

		if (!rdp(sp + 0, &p1)) goto run;
		if (!rdp(sp + P, &p0)) goto run;

		r= (unsdw) p0 - (unsdw) p1;
		sp += 2*P - 2*W;
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x06E:	/* inc.z : Increment word at top of stack */
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    if ((T.flags & F_(T_IOVFL)) != 0) {
		umemw(sp_v2p(sp))++;
	    } else {
		unsw w, *s[1];

		s[0]= &umemw(sp_v2p(sp));
		w= *s[0] + 1;
		if ((w ^ *s[0]) >> (W*8-1)) {
		    trap(T_IOVFL);
		    goto run;
		}
		*s[0]= w;
	    }
	    T.pc= pc;
	    break;

	case 0x071:	/* inl.-1W : Increment 1st local */
	case 0x072:	/* inl.-2W : Increment 2nd local */
	case 0x073:{	/* inl.-3W : Increment 3rd local */
	    unsp l;

	    l= ((unsp) 0x071 + 1 - op);
	    goto INL;

	case 0x074:	/* inl.w-1 : Increment l-th local */
	    if (!pliteral(&pc, 1, &l)) goto run;
	    l -= (unsp) 1 << 8;
	    goto INL;

	case 0x13D:	/* inl.pw : Increment l-th parameter */
	    if (!pliteral(&pc, 2, &l)) goto run;
	    l += 2;
	    goto INL;

	case 0x13E:	/* inl.nw : Increment l-th local */
	    if (!nliteral(&pc, 2, &l)) goto run;
	    goto INL;

#if W >= 4
	case 0x221:	/* inl.Pw : Increment l-th parameter */
	    if (!pliteral(&pc, 4, &l)) goto run;
	    l += 2;
	    goto INL;

	case 0x222:	/* inl.Nw : Increment l-th local */
	    if (!nliteral(&pc, 4, &l)) goto run;
	    goto INL;
#endif
	INL:
	    l= l * W + T.lb;
	    if (!tlb_chk(&tp, DATA, l, pP|pR|pW)) goto run;
	    if ((T.flags & F_(T_IOVFL)) != 0) {
		umemw(tlb_v2p(tp, l))++;
	    } else {
		unsw w, *s[1];

		s[0]= &umemw(tlb_v2p(tp, l));
		w= *s[0] + 1;
		if ((w ^ *s[0]) >> (W*8-1)) {
		    trap(T_IOVFL);
		    goto run;
		}
		*s[0]= w;
	    }
	    T.pc= pc;
	    break;}

	case 0x06F:{	/* ine.lw : Increment externel */
	    unsp g;

	    if (!sliteral(&pc, 2, &g)) goto run;
	    goto INE;

	case 0x070:	/* ine.w0 : Increment externel */
	    if (!pliteral(&pc, 1, &g)) goto run;
	    goto INE;

#if W >= 4
	case 0x220:	/* ine.Lw : Increment externel */
	    if (!sliteral(&pc, 4, &g)) goto run;
	    goto INE;
#endif
	INE:
	    g *= W;
	    if (!tlb_chk(&tp, DATA, g, pP|pR|pW)) goto run;
	    if ((T.flags & F_(T_IOVFL)) != 0) {
		umemw(tlb_v2p(tp, g))++;
	    } else {
		unsw w, *s[1];

		s[0]= &umemw(tlb_v2p(tp, g));
		w= *s[0] + 1;
		if ((w ^ *s[0]) >> (W*8-1)) {
		    trap(T_IOVFL);
		    goto run;
		}
		*s[0]= w;
	    }
	    T.pc= pc;
	    break;}

	case 0x067:	/* dec.z : Decrement word at top of stack */
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    if ((T.flags & F_(T_IOVFL)) != 0) {
		umemw(sp_v2p(sp))--;
	    } else {
		unsw w, *s[1];

		s[0]= &umemw(sp_v2p(sp));
		w= *s[0] - 1;
		if ((w ^ *s[0]) >> (W*8-1)) {
		    trap(T_IOVFL);
		    goto run;
		}
		*s[0]= w;
	    }
	    T.pc= pc;
	    break;

	case 0x069:{	/* del.w-1 : Decrement l-th local */
	    unsp l;

	    if (!pliteral(&pc, 1, &l)) goto run;
	    l -= (unsp) 1 << 8;
	    goto DEL;

	case 0x12E:	/* del.pw : Decrement l-th parameter */
	    if (!pliteral(&pc, 2, &l)) goto run;
	    l += 2;
	    goto DEL;

	case 0x12F:	/* del.nw : Decrement l-th local */
	    if (!nliteral(&pc, 2, &l)) goto run;
	    goto DEL;

#if W >= 4
	case 0x21C:	/* del.Pw : Decrement l-th parameter */
	    if (!pliteral(&pc, 4, &l)) goto run;
	    l += 2;
	    goto DEL;

	case 0x21D:	/* del.Nw : Decrement l-th local */
	    if (!nliteral(&pc, 4, &l)) goto run;
	    goto DEL;
#endif
	DEL:
	    l= l * W + T.lb;
	    if (!tlb_chk(&tp, DATA, l, pP|pR|pW)) goto run;
	    if ((T.flags & F_(T_IOVFL)) != 0) {
		umemw(tlb_v2p(tp, l))--;
	    } else {
		unsw w, *s[1];

		s[0]= &umemw(tlb_v2p(tp, l));
		w= *s[0] - 1;
		if ((w ^ *s[0]) >> (W*8-1)) {
		    trap(T_IOVFL);
		    goto run;
		}
		*s[0]= w;
	    }
	    T.pc= pc;
	    break;}

	case 0x068:{	/* dee.w0 : Decrement external */
	    unsp g;

	    if (!pliteral(&pc, 1, &g)) goto run;
	    goto DEE;

	case 0x12D:	/* dee.lw : Decrement external */
	    if (!sliteral(&pc, 2, &g)) goto run;
	    goto DEE;

#if W >= 4
	case 0x21B:	/* dee.Lw : Decrement external */
	    if (!sliteral(&pc, 4, &g)) goto run;
	    goto DEE;
#endif
	DEE:
	    g *= W;
	    if (!tlb_chk(&tp, DATA, g, pP|pR|pW)) goto run;
	    if ((T.flags & F_(T_IOVFL)) != 0) {
		umemw(tlb_v2p(tp, g))--;
	    } else {
		unsw w, *s[1];

		s[0]= &umemw(tlb_v2p(tp, g));
		w= *s[0] - 1;
		if ((w ^ *s[0]) >> (W*8-1)) {
		    trap(T_IOVFL);
		    goto run;
		}
		*s[0]= w;
	    }
	    T.pc= pc;
	    break;}

	case 0x0FA:	/* zrl.-1W : Zero 1st local */
	case 0x0FB:{	/* zrl.-2W : Zero 2nd local */
	    unsp l;

	    l= ((unsp) 0x0FA + 1 - op);
	    goto ZRL;

	case 0x0FC:	/* zrl.w-1 : Zero l-th local */
	    if (!pliteral(&pc, 1, &l)) goto run;
	    l -= (unsp) 1 << 8;
	    goto ZRL;

	case 0x0FD:	/* zrl.nw : Zero l-th local */
	    if (!nliteral(&pc, 2, &l)) goto run;
	    goto ZRL;

	case 0x199:	/* zrl.pw : Zero l-th parameter */
	    if (!pliteral(&pc, 2, &l)) goto run;
	    l += 2;
	    goto ZRL;

#if W >= 4
	case 0x235:	/* zrl.Pw : Zero l-th parameter */
	    if (!pliteral(&pc, 4, &l)) goto run;
	    l += 2;
	    goto ZRL;

	case 0x236:	/* zrl.Nw : Zero l-th local */
	    if (!nliteral(&pc, 4, &l)) goto run;
	    goto ZRL;
#endif
	ZRL:
	    l= l * W + T.lb;
	    if (!tlb_chk(&tp, DATA, l, pP|pR|pW)) goto run;
	    umemw(tlb_v2p(tp, l))= 0;
	    T.pc= pc;
	    break;}

	case 0x0F8:{	/* zre.lw : Zero external */
	    unsp g;

	    if (!sliteral(&pc, 2, &g)) goto run;
	    goto ZRE;

	case 0x0F9:	/* zre.w0 : Zero external */
	    if (!pliteral(&pc, 1, &g)) goto run;
	    goto ZRE;

#if W >= 4
	case 0x234:	/* zre.Lw : Zero external */
	    if (!sliteral(&pc, 4, &g)) goto run;
	    goto ZRE;
#endif
	ZRE:
	    g *= W;
	    if (!tlb_chk(&tp, DATA, g, pP|pR|pW)) goto run;
	    umemw(tlb_v2p(tp, g))= 0;
	    T.pc= pc;
	    break;}

	case 0x197:{	/* zrf.l : Load a floating zero */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto ZRF;

	case 0x198:	/* zrf.z : Load a floating zero */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto ZRF;

	ZRF:
	    sp -= s;
	    if (s == 4) {
		if (!wrf4(sp, (flt4) 0.0)) goto run;
	    } else
	    if (s == 8) {
		if (!wrf8(sp, (flt8) 0.0)) goto run;
	    } else {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0F1:{	/* zer.s0 : Load w zero bytes */
	    unsw s;

	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto ZER;

	case 0x190:	/* zer.l : Load w zero bytes */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto ZER;

	case 0x191:	/* zer.z : Load w zero bytes */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto ZER;

	ZER:
	    if ((s & (W-1)) != 0) { trap(T_ODDZ); goto run; }
	    while (s > 0) {
		sp -= W;
		if (!sp_chk(sp)) goto run;
		umemw(sp_v2p(sp))= 0;
		s -= W;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x05F:{	/* cii.z : Convert integer to integer */
	    unsw ds, ss;
	    memory m;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    ds= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    ss= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    m= sp_v2p(sp);

	    if (ss < ds) {		/* Widening */
		int n= (W - ss) * 8;
		intw i= (imemw(m) << n) >> n;

		if (ds <= W) {
		    umemw(m)= i & unsw_mask[ds];
		} else
#if has_int(2*W)
		if (ss <= W && ds == 2*W) {
		    sp -= W;
		    if (!wrdw(sp, (intdw) i)) goto run;
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    } else
	    if (ss > ds) {		/* Narrowing */
		if (ss <= W) {
		    if ((T.flags & F_(T_CONV)) == 0) {
			int n= (W - ss) * 8;
			intw i= (imemw(m) << n) >> n;

			n= (W - ds) * 8;
			if ((((i & unsw_mask[ds]) << n) >> n) != i) {
			    trap(T_CONV); goto run;
			}
		    }
		    umemw(m) &= unsw_mask[ds];
		} else
#if has_int(2*W)
		if (ss == 2*W && ds <= W) {
		    intdw i;

		    if (!rddw(sp, (unsdw *) &i)) goto run;

		    if ((T.flags & F_(T_CONV)) == 0) {
			int n= (2*W - ds) * 8;
			if ((((i & unsdw_mask[ds]) << n) >> n) != i) {
			    trap(T_CONV); goto run;
			}
		    }
		    sp += W;
		    if (!wrw(sp, (unsw) i & unsw_mask[ds])) goto run;
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    } else {			/* Same size */
		/* Do nothing. */
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x12B:{	/* cui.z : Convert unsigned to integer */
	    unsw ds, ss;
	    memory m;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    ds= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    ss= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    m= sp_v2p(sp);

	    if (ss < ds) {		/* Widening */
		if (ds <= W) {
		    umemw(m) &= unsw_mask[ss];
		} else
#if has_int(2*W)
		if (ss <= W && ds == 2*W) {
		    sp -= W;
		    if (!wrdw(sp, umemw(m) & unsw_mask[ss])) goto run;
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    } else {			/* Narrowing */
		if (ss <= W) {
		    if ((T.flags & F_(T_CONV)) == 0) {
			unsw u= umemw(m);

			if ((u & unsw_mask[ss]) > intw_max[ds]) {
			    trap(T_CONV); goto run;
			}
		    }
		    umemw(m) &= unsw_mask[ds];
		} else
#if has_int(2*W)
		if (ss == 2*W) {
		    unsdw u;

		    if (!rddw(sp, &u)) goto run;

		    if ((T.flags & F_(T_CONV)) == 0) {
			if ((u & unsdw_mask[ss]) > intdw_max[ds]) {
			    trap(T_CONV); goto run;
			}
		    }
		    if (ds <= W) {
			sp += W;
			if (!wrw(sp, (unsw) u & unsw_mask[ds])) goto run;
		    } else
		    if (ds == 2*W) {
			if (!wrdw(sp, u & unsdw_mask[ds])) goto run;
		    } else {
			trap(T_ILLINS); goto run;
		    }
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x119:{	/* cfi.z : Convert floating to integer */
	    unsw ds, ss;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    ds= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    ss= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;

	    if (ss == 4) {
		flt4 f;

		if (!rdf4(sp, &f)) goto run;
		sp += 4;
		if (ds <= W) {
		    sp -= W;
		    if (!wrw(sp, ((intw) f) & unsw_mask[ds])) goto run;
		} else
#if has_int(2*W)
		if (ds == 2*W) {
		    sp -= 2*W;
		    if (!wrdw(sp, (intdw) f)) goto run;
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    } else
	    if (ss == 8) {
		flt8 f;

		if (!rdf8(sp, &f)) goto run;
		sp += 8;
		if (ds <= W) {
		    sp -= W;
		    if (!wrw(sp, ((intw) f) & unsw_mask[ds])) goto run;
		} else
#if has_int(2*W)
		if (ds == 2*W) {
		    sp -= 2*W;
		    if (!wrdw(sp, (intdw) f)) goto run;
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    } else {
		trap(T_ILLINS); goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x05E:{	/* cif.z : Convert integer to floating */
	    unsw ds, ss;
	    flt4 f4;
	    flt8 f8;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    ds= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    ss= umemw(sp_v2p(sp));
	    sp += W;

	    if (ss <= W) {
		intw i;
		int n= (W - ss) * 8;

		if (!rdw(sp, (unsw *) &i)) goto run;
		sp += W;
		i= (i << n) >> n;
		f4= i;
		f8= i;
	    } else
#if has_int(2*W)
	    if (ss == 2*W) {
		intdw i;

		if (!rddw(sp, (unsdw *) &i)) goto run;
		sp += W;
		f4= i;
		f8= i;
	    } else
#endif
	    {
		trap(T_ILLINS); goto run;
	    }

	    sp -= ds;
	    if (ds == 4) {
		if (!wrf4(sp, f4)) goto run;
	    } else
	    if (ds == 8) {
		if (!wrf8(sp, f8)) goto run;
	    } else {
		trap(T_ILLINS); goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x12A:{	/* cuf.z : Convert unsigned to floating */
	    unsw ds, ss;
	    flt4 f4;
	    flt8 f8;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    ds= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    ss= umemw(sp_v2p(sp));
	    sp += W;

	    if (ss <= W) {
		unsw u;

		if (!rdw(sp, &u)) goto run;
		sp += W;
		u &= unsw_mask[ss];
		f4= u;
		f8= u;
	    } else
#if has_int(2*W)
	    if (ss == 2*W) {
		unsdw u;

		if (!rddw(sp, &u)) goto run;
		sp += W;
		f4= u;
		f8= u;
	    } else
#endif
	    {
		trap(T_ILLINS); goto run;
	    }

	    sp -= ds;
	    if (ds == 4) {
		if (!wrf4(sp, f4)) goto run;
	    } else
	    if (ds == 8) {
		if (!wrf8(sp, f8)) goto run;
	    } else {
		trap(T_ILLINS); goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x05D:{	/* cff.z : Convert floating to floating */
	    unsw ds, ss;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    ds= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    ss= umemw(sp_v2p(sp));
	    sp += W;

	    if (ss == 4 && ds == 8) {
		flt4 f;

		if (!rdf4(sp, &f)) goto run;
		sp= sp + 4 - 8;
		if (!wrf8(sp, (flt8) f)) goto run;
	    } else
	    if (ss == 8 && ds == 4) {
		flt8 f;

		if (!rdf8(sp, &f)) goto run;
		sp= sp + 8 - 4;
		if (!wrf4(sp, (flt4) f)) goto run;
	    } else
	    if (ss != ds) {
		trap(T_ILLINS); goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x11B:{	/* ciu.z : Convert integer to unsigned */
	    unsw ds, ss;
	    memory m;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    ds= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    ss= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    m= sp_v2p(sp);

	    if (ss < ds) {		/* Widening */
		int n= (W - ss) * 8;
		intw i= (imemw(m) << n) >> n;

		if (ds <= W) {
		    umemw(m)= i & unsw_mask[ds];
		} else
#if has_int(2*W)
		if (ss <= W && ds == 2*W) {
		    sp -= W;
		    if (!wrdw(sp, (intdw) i)) goto run;
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    } else
	    if (ss > ds) {		/* Narrowing */
		if (ss <= W) {
		    umemw(m) &= unsw_mask[ds];
		} else
#if has_int(2*W)
		if (ss == 2*W && ds <= W) {
		    unsdw u;

		    if (!rddw(sp, &u)) goto run;
		    sp += W;
		    if (!wrw(sp, (unsw) u & unsw_mask[ds])) goto run;
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    } else {			/* Same size */
		/* Do nothing. */
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x12C:{	/* cuu.z : Convert unsigned to unsigned */
	    unsw ds, ss;
	    memory m;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    ds= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    ss= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    m= sp_v2p(sp);

	    if (ss < ds) {		/* Widening */
		unsw u= umemw(m) & unsw_mask[ss];

		if (ds <= W) {
		    umemw(m)= u;
		} else
#if has_int(2*W)
		if (ss <= W && ds == 2*W) {
		    sp -= W;
		    if (!wrdw(sp, (unsdw) u)) goto run;
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    } else
	    if (ss > ds) {		/* Narrowing */
		if (ss <= W) {
		    umemw(m) &= unsw_mask[ds];
		} else
#if has_int(2*W)
		if (ss == 2*W && ds <= W) {
		    unsdw u;

		    if (!rddw(sp, &u)) goto run;
		    sp += W;
		    if (!wrw(sp, (unsw) u & unsw_mask[ds])) goto run;
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    } else {			/* Same size */
		/* Do nothing. */
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x11A:{	/* cfu.z : Convert floating to unsigned */
	    unsw ds, ss;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    ds= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    ss= umemw(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;

	    if (ss == 4) {
		flt4 f;

		if (!rdf4(sp, &f)) goto run;
		sp += 4;
		if (ds <= W) {
		    sp -= W;
		    if (!wrw(sp, ((unsw) f) & unsw_mask[ds])) goto run;
		} else
#if has_int(2*W)
		if (ds == 2*W) {
		    sp -= 2*W;
		    if (!wrdw(sp, (unsdw) f)) goto run;
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    } else
	    if (ss == 8) {
		flt8 f;

		if (!rdf8(sp, &f)) goto run;
		sp += 8;
		if (ds <= W) {
		    sp -= W;
		    if (!wrw(sp, ((unsw) f) & unsw_mask[ds])) goto run;
		} else
#if has_int(2*W)
		if (ds == 2*W) {
		    sp -= 2*W;
		    if (!wrdw(sp, (unsdw) f)) goto run;
		} else
#endif
		{
		    trap(T_ILLINS); goto run;
		}
	    } else {
		trap(T_ILLINS); goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x02C:{	/* and.1W : Bitwise AND */
	    unsw s, w;
	    unsp sp2;

	    s= W;
	    sp= T.sp;
	    goto AND_1W;

	case 0x10A:	/* and.l : Bitwise AND */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto AND;

	case 0x10B:	/* and.z : Bitwise AND */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto AND;

	AND:
	    if ((s & (W-1)) != 0) { trap(T_ODDZ); goto run; }
	AND_1W:
	    sp2= sp + s;
	    while (s > 0) {
		if (!sp_chk(sp)) goto run;
		w= umemw(sp_v2p(sp));
		sp += W;
		if (!sp_chk(sp2)) goto run;
		umemw(sp_v2p(sp2)) &= w;
		sp2 += W;
		s -= W;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x076:{	/* ior.1W : Bitwise OR */
	    unsw s, w;
	    unsp sp2;

	    s= W;
	    sp= T.sp;
	    goto IOR_1W;

	case 0x077:	/* ior.s0 : Bitwise OR */
	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto IOR;

	case 0x141:	/* ior.l : Bitwise OR */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto IOR;

	case 0x142:	/* ior.z : Bitwise OR */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto IOR;

	IOR:
	    if ((s & (W-1)) != 0) { trap(T_ODDZ); goto run; }
	IOR_1W:
	    sp2= sp + s;
	    while (s > 0) {
		if (!sp_chk(sp)) goto run;
		w= umemw(sp_v2p(sp));
		sp += W;
		if (!sp_chk(sp2)) goto run;
		umemw(sp_v2p(sp2)) |= w;
		sp2 += W;
		s -= W;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x18E:{	/* xor.l : Bitwise XOR */
	    unsw s, w;
	    unsp sp2;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto XOR;

	case 0x18F:	/* xor.z : Bitwise XOR */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto XOR;

	XOR:
	    if ((s & (W-1)) != 0) { trap(T_ODDZ); goto run; }
	    sp2= sp + s;
	    while (s > 0) {
		if (!sp_chk(sp)) goto run;
		w= umemw(sp_v2p(sp));
		sp += W;
		if (!sp_chk(sp2)) goto run;
		umemw(sp_v2p(sp2)) ^= w;
		sp2 += W;
		s -= W;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x124:{	/* com.l : Bitwise complement */
	    unsw s;
	    unsp sp2;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto COM;

	case 0x125:	/* com.z : Bitwise complement */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto COM;

	COM:
	    if ((s & (W-1)) != 0) { trap(T_ODDZ); goto run; }
	    sp2= sp;
	    while (s > 0) {
		if (!sp_chk(sp)) goto run;
		umemw(sp_v2p(sp)) ^= (unsw) -1;
		sp += W;
		s -= W;
	    }
	    T.sp= sp2;
	    T.pc= pc;
	    break;}

	case 0x166:{	/* rol.l : Rotate left */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto ROL;

	case 0x167:	/* rol.z : Rotate left */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto ROL;

	ROL:
	    if (s == W) {
		unsw w1, *s[1];

		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));

		*s[0]= (*s[0] << w1) | (*s[0] >> (W*8 - w1));
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0;
		unsw w1;

		if (!rdw(sp + 1*W, &w1)) goto run;
		sp += W;
		if (!rddw(sp, &w0)) goto run;

		r= (w0 << w1) | (w0 >> (W*8 - w1));
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x168:{	/* ror.l : Rotate right */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto ROR;

	case 0x169:	/* ror.z : Rotate right */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto ROR;

	ROR:
	    if (s == W) {
		unsw w1, *s[1];

		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));

		*s[0]= (*s[0] >> w1) | (*s[0] << (W*8 - w1));
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw r, w0;
		unsw w1;

		if (!rdw(sp + 1*W, &w1)) goto run;
		sp += W;
		if (!rddw(sp, &w0)) goto run;

		r= (w0 >> w1) | (w0 << (W*8 - w1));
		if (!wrdw(sp, r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x075:{	/* inn.s0 : Bit test on w byte set */
	    unsw s, b, t;
	    unsp p;

	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto INN;

	case 0x13F:	/* inn.l : Bit test on w byte set */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto INN;

	case 0x140:	/* inn.z : Bit test on w byte set */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto INN;

	INN:
	    if (!sp_chk(sp)) goto run;
	    b= umemw(sp_v2p(sp));
	    sp += W;
	    if ((s & (W-1)) != 0) { trap(T_ODDZ); goto run; }

	    if ((p= b / 8) >= s) {
		if ((T.flags & F_(T_SET)) == 0) { trap(T_SET); goto run; }
		t= 0;
	    } else {
		p += sp;
		if (!sp_chk(p)) goto run;
		t= (umem1(sp_v2p(p)) >> (b % 8)) & 1;
	    }
	    sp= sp + s - W;
	    if (!sp_chk(sp)) goto run;
	    umemw(sp_v2p(sp))= t;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0CE:{	/* set.s0 : Create singleton w byte set */
	    unsw s, n, b;
	    unsp p;

	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto SET;

	case 0x179:	/* set.l : Create singleton w byte set */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto SET;

	case 0x17A:	/* set.z : Create singleton w byte set */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto SET;

	SET:
	    if (!sp_chk(sp)) goto run;
	    b= umemw(sp_v2p(sp));
	    sp += W;
	    if ((s & (W-1)) != 0) { trap(T_ODDZ); goto run; }
	    n= s;
	    while (n > 0) {
		sp -= W;
		if (!sp_chk(sp)) goto run;
		umemw(sp_v2p(sp))= 0;
		n -= W;
	    }

	    if ((p= b / 8) >= s) {
		if ((T.flags & F_(T_SET)) == 0) { trap(T_SET); goto run; }
	    } else {
		p += sp;
		if (!sp_chk(p)) goto run;
		umem1(sp_v2p(p))= (uns1) 1 << (b % 8);
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x087:{	/* lar.W : Load array element */
	    unsw s, i, t;
	    unsp d, a;

	    sp= T.sp;
	    goto LAR_1W;

	case 0x143:	/* lar.l : Load array element */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto LAR;

	case 0x144:	/* lar.z : Load array element */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto LAR;

	LAR:
	    if (s != W) { trap(T_ILLINS); goto run; }
	LAR_1W:
	    if (!rdp(sp, &d)) goto run;
	    sp += P;
	    if (!rdw(sp, &i)) goto run;
	    sp += W;
	    if (!rdp(sp, &a)) goto run;
	    sp += P;
	    if (nullptr(a)) goto run;

	    if (!rdw(d + 0*W, &t)) goto run;
	    i -= t;
	    if (!rdw(d + 1*W, &t)) goto run;
	    if (i >= t) {
		if ((T.flags & F_(T_ARRAY)) == 0) { trap(T_ARRAY); goto run; }
	    }
	    if (!rdw(d + 2*W, &s)) goto run;

	    a += i * s;

	    switch (s) {
	    case 0:	trap(T_ILLINS); goto run;
	    case 1:
		if (!rd1(a, &t)) goto run;
		sp -= W;
		if (!wrw(sp, t)) goto run;
		break;
#if W >= 4
	    case 2:
		if (!aligned(a, 2)) goto run;
		if (!rd2(a, &t)) goto run;
		sp -= W;
		if (!wrw(sp, t)) goto run;
		break;
#endif
	    case W:
		if (!aligned(a, W)) goto run;
		if (!rdw(a, &t)) goto run;
		sp -= W;
		if (!wrw(sp, t)) goto run;
		break;

	    default:
		if ((s & (W-1)) != 0) { trap(T_ODDZ); goto run; }
		if (!aligned(a, W)) goto run;
		sp -= s;
		if (!wordcpy(sp, a, s)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0C9:{	/* sar.1W : Store array element */
	    unsw s, i, t;
	    unsp d, a;

	    sp= T.sp;
	    goto SAR_1W;

	case 0x16B:	/* sar.l : Store array element */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto SAR;

	case 0x16C:	/* sar.z : Store array element */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto SAR;

	SAR:
	    if (s != W) { trap(T_ILLINS); goto run; }
	SAR_1W:
	    if (!rdp(sp, &d)) goto run;
	    sp += P;
	    if (!rdw(sp, &i)) goto run;
	    sp += W;
	    if (!rdp(sp, &a)) goto run;
	    sp += P;
	    if (nullptr(a)) goto run;

	    if (!rdw(d + 0*W, &t)) goto run;
	    i -= t;
	    if (!rdw(d + 1*W, &t)) goto run;
	    if (i >= t) {
		if ((T.flags & F_(T_ARRAY)) == 0) { trap(T_ARRAY); goto run; }
	    }
	    if (!rdw(d + 2*W, &s)) goto run;

	    a += i * s;

	    switch (s) {
	    case 0:	trap(T_ILLINS); goto run;
	    case 1:
		if (!rdw(sp, &t)) goto run;
		sp += W;
		if (!wr1(a, t)) goto run;
		break;
#if W >= 4
	    case 2:
		if (!rdw(sp, &t)) goto run;
		sp += W;
		if (!aligned(a, 2)) goto run;
		if (!wr2(a, t)) goto run;
		break;
#endif
	    case W:
		if (!rdw(sp, &t)) goto run;
		sp += W;
		if (!aligned(a, W)) goto run;
		if (!wrw(a, t)) goto run;
		break;

	    default:
		if ((s & (W-1)) != 0) { trap(T_ODDZ); goto run; }
		if (!aligned(a, W)) goto run;
		if (!wordcpy(a, sp, s)) goto run;
		sp += s;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x022:{	/* aar.1W : Load address of array element */
	    unsw s, i, t;
	    unsp d, a;

	    sp= T.sp;
	    goto AAR_1W;

	case 0x100:	/* aar.l : Load address of array element */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto AAR;

	case 0x101:	/* aar.z : Load address of array element */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto AAR;

	AAR:
	    if (s != W) { trap(T_ILLINS); goto run; }
	AAR_1W:
	    if (!rdp(sp, &d)) goto run;
	    sp += P;
	    if (!rdw(sp, &i)) goto run;
	    sp += W;
	    if (!rdp(sp, &a)) goto run;
	    sp += P;
	    if (nullptr(a)) goto run;

	    if (!rdw(d + 0*W, &t)) goto run;
	    i -= t;
	    if (!rdw(d + 1*W, &t)) goto run;
	    if (i >= t) {
		if ((T.flags & F_(T_ARRAY)) == 0) { trap(T_ARRAY); goto run; }
	    }
	    if (!rdw(d + 2*W, &s)) goto run;

	    a += i * s;
	    sp -= P;
	    if (!wrp(sp, a)) goto run;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x061:{	/* cmi.1W : Compare integers */
	    unsw s;

	    sp= T.sp;
	    goto CMI_1W;

#if has_int(2*W)
	case 0x062:	/* cmi.2W : Compare integers */
	    sp= T.sp;
	    goto CMI_2W;
#endif

	case 0x11E:	/* cmi.l : Compare integers */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto CMI;

	case 0x11F:	/* cmi.z : Compare integers */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto CMI;

	CMI:
	    if (s == W) {
		intw r, w0, w1, *s[1];

	    CMI_1W:
		if (!sp_chk(sp)) goto run;
		w1= imemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &imemw(sp_v2p(sp));
		w0= *s[0];

		r= w0 == w1 ? 0 : w0 < w1 ? -1 : 1;
		*s[0]= r;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		intdw w0, w1;
		intw r;

	    CMI_2W:
		if (!rddw(sp, (unsdw *) &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, (unsdw *) &w0)) goto run;

		r= w0 == w1 ? 0 : w0 < w1 ? -1 : 1;
		sp= sp + 2*W - W;
		if (!wrw(sp, (unsw) r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x060:{	/* cmf.s0 : Compare floating */
	    unsw s;

	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto CMF;

	case 0x11C:	/* cmf.l : Compare floating */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto CMF;

	case 0x11D:	/* cmf.z : Compare floating */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto CMF;

	CMF:
	    if (s == 4) {
		flt4 f0, f1;
		intw r;

		if (!rdf4(sp, &f1)) goto run;
		sp += 4;
		if (!rdf4(sp, &f0)) goto run;

		r= f0 == f1 ? 0 : f0 < f1 ? -1 : 1;
		sp= sp + 4 - W;
		if (!wrw(sp, (unsw) r)) goto run;
	    } else
	    if (s == 8) {
		flt8 f0, f1;
		intw r;

		if (!rdf8(sp, &f1)) goto run;
		sp += 8;
		if (!rdf8(sp, &f0)) goto run;

		r= f0 == f1 ? 0 : f0 < f1 ? -1 : 1;
		sp= sp + 8 - W;
		if (!wrw(sp, (unsw) r)) goto run;
	    } else {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x122:{	/* cmu.l : Compare unsigned */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto CMU;

	case 0x123:	/* cmu.z : Compare unsigned */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto CMU;

	case 0x063:	/* cmp.z : Compare pointers */
	    sp= T.sp;
	    goto CMP;	/* Since P == W... */

	CMU:
	    if (s == W) {
		unsw w0, w1, *s[1];
		intw r;

	    CMP:
		if (!sp_chk(sp)) goto run;
		w1= umemw(sp_v2p(sp));
		sp += W;

		if (!sp_chk(sp)) goto run;
		s[0]= &umemw(sp_v2p(sp));
		w0= *s[0];

		r= w0 == w1 ? 0 : w0 < w1 ? -1 : 1;
		*(intw*)s[0]= r;
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		unsdw w0, w1;
		intw r;

		if (!rddw(sp, &w1)) goto run;
		sp += 2*W;
		if (!rddw(sp, &w0)) goto run;

		r= w0 == w1 ? 0 : w0 < w1 ? -1 : 1;
		sp= sp + 2*W - W;
		if (!wrw(sp, (unsw) r)) goto run;
	    } else
#endif
	    {
		trap(T_ILLINS);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x064:{	/* cms.s0 : Bitwise compare */
	    unsw s, r, w0, w1;
	    unsp sp0, sp1;

	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto CMS;

	case 0x120:	/* cms.l : Bitwise compare */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto CMS;

	case 0x121:	/* cms.z : Bitwise compare */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto CMS;

	CMS:
	    if ((s & (W-1)) != 0) { trap(T_ODDZ); goto run; }
	    r= 0;
	    sp1= sp;
	    sp0= sp1 + s;
	    sp= sp0 + s;
	    while (s > 0) {
		if (!sp_chk(sp1)) goto run;
		w1= umemw(sp_v2p(sp1));
		sp1 += W;
		if (!sp_chk(sp0)) goto run;
		w0= umemw(sp_v2p(sp0));
		sp0 += W;
		if (w0 != w1) {
		    r= 1;
		    break;
		}
		s -= W;
	    }
	    sp -= W;
	    if (!sp_chk(sp)) goto run;
	    umemw(sp_v2p(sp))= r;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0EC:{	/* tlt.z : True if less */
	    intw *tp;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    tp= &imemw(sp_v2p(sp));
	    *tp= (*tp < 0);
	    T.pc= pc;
	    break;}

	case 0x18C:{	/* tle.z : True if less or equal */
	    intw *tp;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    tp= &imemw(sp_v2p(sp));
	    *tp= (*tp <= 0);
	    T.pc= pc;
	    break;}

	case 0x0EA:{	/* teq.z : True if equal */
	    intw *tp;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    tp= &imemw(sp_v2p(sp));
	    *tp= (*tp == 0);
	    T.pc= pc;
	    break;}

	case 0x0ED:{	/* tne.z : True if not equal */
	    intw *tp;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    tp= &imemw(sp_v2p(sp));
	    *tp= (*tp != 0);
	    T.pc= pc;
	    break;}

	case 0x18B:{	/* tge.z : True if greater or equal */
	    intw *tp;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    tp= &imemw(sp_v2p(sp));
	    *tp= (*tp >= 0);
	    T.pc= pc;
	    break;}

	case 0x0EB:{	/* tgt.z : True if greater */
	    intw *tp;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    tp= &imemw(sp_v2p(sp));
	    *tp= (*tp > 0);
	    T.pc= pc;
	    break;}

	case 0x03B:{	/* bra.l : Branch unconditionally */
	    unsw b;

	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto BRA;

	case 0x03C:	/* bra.s-1 : Branch unconditionally */
	    if (!pliteral(&pc, 1, &b)) goto run;
	    b -= (unsw) 1 << 8;
	    goto BRA;

	case 0x03D:	/* bra.s-2 : Branch unconditionally */
	    if (!pliteral(&pc, 1, &b)) goto run;
	    b -= (unsw) 2 << 8;
	    goto BRA;

	case 0x03E:	/* bra.s0 : Branch unconditionally */
	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto BRA;

	case 0x03F:	/* bra.s1 : Branch unconditionally */
	    if (!pliteral(&pc, 1, &b)) goto run;
	    b += (unsw) 1 << 8;
	    goto BRA;

#if W >= 4
	case 0x219:	/* bra.L : Branch unconditionally */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto BRA;
#endif
	BRA:
	    pc += b;
	    if (!pc_chk(pc)) goto run;
	    T.pc= pc;
	    break;}

	case 0x039:{	/* blt.s0 : Branch if less */
	    unsw b;
	    intw w0, w1;

	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto BLT;

	case 0x115:	/* blt.l : Branch if less */
	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto BLT;

#if W >= 4
	case 0x217:	/* blt.L : Branch if less */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto BLT;
#endif
	BLT:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w1= imemw(sp_v2p(sp));
	    sp += W;

	    if (!sp_chk(sp)) goto run;
	    w0= imemw(sp_v2p(sp));
	    sp += W;

	    if (w0 < w1) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x037:{	/* ble.s0 : Branch if less or equal */
	    unsw b;
	    intw w0, w1;

	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto BLE;

	case 0x111:	/* ble.l : Branch if less or equal */
	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto BLE;

#if W >= 4
	case 0x215:	/* ble.L : Branch if less or equal */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto BLE;
#endif
	BLE:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w1= imemw(sp_v2p(sp));
	    sp += W;

	    if (!sp_chk(sp)) goto run;
	    w0= imemw(sp_v2p(sp));
	    sp += W;

	    if (w0 <= w1) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x033:{	/* beq.l : Branch if equal */
	    unsw b;
	    intw w0, w1;

	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto BEQ;

	case 0x034:	/* beq.s0 : Branch if equal */
	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto BEQ;

#if W >= 4
	case 0x212:	/* beq.L : Branch if equal */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto BEQ;
#endif
	BEQ:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w1= imemw(sp_v2p(sp));
	    sp += W;

	    if (!sp_chk(sp)) goto run;
	    w0= imemw(sp_v2p(sp));
	    sp += W;

	    if (w0 == w1) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x03A:{	/* bne.s0 : Branch if not equal */
	    unsw b;
	    intw w0, w1;

	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto BNE;

	case 0x116:	/* bne.l : Branch if not equal */
	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto BNE;

#if W >= 4
	case 0x218:	/* bne.L : Branch if not equal */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto BNE;
#endif
	BNE:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w1= imemw(sp_v2p(sp));
	    sp += W;

	    if (!sp_chk(sp)) goto run;
	    w0= imemw(sp_v2p(sp));
	    sp += W;

	    if (w0 != w1) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x035:{	/* bge.s0 : Branch if greater or equal */
	    unsw b;
	    intw w0, w1;

	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto BGE;

	case 0x10F:	/* bge.l : Branch if greater or equal */
	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto BGE;

#if W >= 4
	case 0x213:	/* bge.L : Branch if greater or equal */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto BGE;
#endif
	BGE:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w1= imemw(sp_v2p(sp));
	    sp += W;

	    if (!sp_chk(sp)) goto run;
	    w0= imemw(sp_v2p(sp));
	    sp += W;

	    if (w0 >= w1) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x036:{	/* bgt.s0 : Branch if greater */
	    unsw b;
	    intw w0, w1;

	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto BGT;

	case 0x110:	/* bgt.l : Branch if greater */
	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto BGT;

#if W >= 4
	case 0x214:	/* bgt.L : Branch if greater */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto BGT;
#endif
	BGT:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w1= imemw(sp_v2p(sp));
	    sp += W;

	    if (!sp_chk(sp)) goto run;
	    w0= imemw(sp_v2p(sp));
	    sp += W;

	    if (w0 > w1) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0F5:{	/* zlt.s0 : Branch if less than zero */
	    unsw b;
	    intw w;

	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto ZLT;

	case 0x195:	/* zlt.l : Branch if less than zero */
	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto ZLT;

#if W >= 4
	case 0x232:	/* zlt.L : Branch if less than zero */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto ZLT;
#endif
	ZLT:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w= imemw(sp_v2p(sp));
	    sp += W;

	    if (w < 0) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0F4:{	/* zle.s0 : Branch if less or equal to zero */
	    unsw b;
	    intw w;

	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto ZLE;

	case 0x194:	/* zle.l : Branch if less or equal to zero */
	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto ZLE;

#if W >= 4
	case 0x231:	/* zle.L : Branch if less or equal to zero */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto ZLE;
#endif
	ZLE:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w= imemw(sp_v2p(sp));
	    sp += W;

	    if (w <= 0) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0EE:{	/* zeq.l : Branch if equal to zero */
	    unsw b;
	    intw w;

	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto ZEQ;

	case 0x0EF:	/* zeq.s0 : Branch if equal to zero */
	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto ZEQ;

	case 0x0F0:	/* zeq.s1 : Branch if equal to zero */
	    if (!pliteral(&pc, 1, &b)) goto run;
	    b += (unsw) 1 << 8;
	    goto ZEQ;

#if W >= 4
	case 0x22E:	/* zeq.L : Branch if equal to zero */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto ZEQ;
#endif
	ZEQ:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w= imemw(sp_v2p(sp));
	    sp += W;

	    if (w == 0) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0F6:{	/* zne.s0 : Branch if not equal to zero */
	    unsw b;
	    intw w;

	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto ZNE;

	case 0x0F7:	/* zne.s-1 : Branch if not equal to zero */
	    if (!pliteral(&pc, 1, &b)) goto run;
	    b -= (unsw) 1 << 8;
	    goto ZNE;

	case 0x196:	/* zne.l : Branch if not equal to zero */
	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto ZNE;

#if W >= 4
	case 0x233:	/* zne.L : Branch if not equal to zero */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto ZNE;
#endif
	ZNE:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w= imemw(sp_v2p(sp));
	    sp += W;

	    if (w != 0) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0F2:{	/* zge.s0 : Branch if greater or equal to zero */
	    unsw b;
	    intw w;

	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto ZGE;

	case 0x192:	/* zge.l : Branch if greater or equal to zero */
	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto ZGE;

#if W >= 4
	case 0x22F:	/* zge.L : Branch if greater or equal to zero */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto ZGE;
#endif
	ZGE:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w= imemw(sp_v2p(sp));
	    sp += W;

	    if (w >= 0) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0F3:{	/* zgt.s0 : Branch if greater than zero */
	    unsw b;
	    intw w;

	    if (!pliteral(&pc, 1, &b)) goto run;
	    goto ZGT;

	case 0x193:	/* zgt.l : Branch if greater than zero */
	    if (!sliteral(&pc, 2, &b)) goto run;
	    goto ZGT;

#if W >= 4
	case 0x230:	/* zgt.L : Branch if greater than zero */
	    if (!sliteral(&pc, 4, &b)) goto run;
	    goto ZGT;
#endif
	ZGT:
	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    w= imemw(sp_v2p(sp));
	    sp += W;

	    if (w > 0) {
		pc += b;
		if (!pc_chk(pc)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x117:{	/* cai.z : Call procedure */
	    unsp p, lb;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    p= umemp(sp_v2p(sp));
	    sp += P;
	    goto CAL;

	case 0x040:	 case 0x041:	 case 0x042:	 case 0x043:	
	case 0x044:	 case 0x045:	 case 0x046:	 case 0x047:	
	case 0x048:	 case 0x049:	 case 0x04A:	 case 0x04B:	
	case 0x04C:	 case 0x04D:	 case 0x04E:	 case 0x04F:	
	case 0x050:	 case 0x051:	 case 0x052:	 case 0x053:	
	case 0x054:	 case 0x055:	 case 0x056:	 case 0x057:	
	case 0x058:	 case 0x059:	 case 0x05A:	
	case 0x05B:	/* cal.1 - cal.28 : Call procedure p */
	    p= (op - 0x040 + 1);
	    sp= T.sp;
	    goto CAL;

	case 0x05C:	/* cal.s0 : Call procedure p */
	    if (!pliteral(&pc, 1, &p)) goto run;
	    sp= T.sp;
	    goto CAL;

	case 0x118:	/* cal.l : Call procedure p */
	    if (!sliteral(&pc, 2, &p)) goto run;
	    sp= T.sp;
	    goto CAL;

#if W >= 4
	case 0x21A:	/* cal.L : Call procedure p */
	    if (!sliteral(&pc, 4, &p)) goto run;
	    sp= T.sp;
	    goto CAL;
#endif
	CAL:
	    sp -= P;
	    if (!sp_chk(sp)) goto run;
	    umemp(sp_v2p(sp))= pc;

	    sp -= P;
	    if (!sp_chk(sp)) goto run;
	    umemp(sp_v2p(sp))= T.lb;
	    lb= sp;

	    p= T.pd + p * (2*P);
	    if (!tlb_chk(&tp, DATA, p, pP|pR)) goto run;
	    sp -= umemp(tlb_v2p(tp, p));
	    if (!aligned(sp, W)) goto run;

	    p += P;
	    if (!tlb_chk(&tp, DATA, p, pP|pR)) goto run;
	    pc= umemp(tlb_v2p(tp, p));
	    if (pc_chk(pc)) goto run;

	    T.lb= lb;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x08D:{	/* lfr.1W : Load wordsized function result */
	    unsw s;

	    s= W;
	    goto LFR_1W;

#if has_int(2*W)
	case 0x08E:	/* lfr.2W : Load doublewordsized function result */
	    s= 2*W;
	    goto LFR_2W;
#endif

	case 0x08F:	/* lfr.s0 : Load function result of size s */
	    if (!pliteral(&pc, 1, &s)) goto run;
	    goto LFR;

	case 0x149:	/* lfr.l : Load function result of size s */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    goto LFR;

	LFR:
	    if (s == 0) {
		trap(T_ODDZ); goto run;
	    } else
	    if (s <= W) {
	    LFR_1W:
		sp= T.sp - W;
		if (!sp_chk(sp)) goto run;
		umemw(sp_v2p(sp))= T.ret[0] & unsw_mask[s];
	    } else
	    if ((s & (W-1)) != 0) {
		trap(T_ODDZ); goto run;
	    } else
	    if (s <= 4*W) {
		unsw *rp;

	    LFR_2W:
		sp= T.sp;
		rp = (unsw *) ((char *) T.ret + s);
		do {
		    sp -= W;
		    if (!wrw(sp, *--rp)) goto run;
		} while ((s -= W) > 0);
	    } else {
		trap(T_ILLINS); goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0C5:{	/* ret.0 : Return */
	    unsw s;
	    unsp lb;

	    goto RET_0;

	case 0x0C6:	/* ret.1W : Return one word */
	    s= W;
	    goto RET_1W;

	case 0x0C7:	/* ret.s0 : Return result of size s */
	    if (!pliteral(&pc, 1, &s)) goto run;
	    goto RET;

	case 0x161:	/* ret.l : Return result of size s */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    goto RET;

	RET:
	    if ((s-1) <= (W-1)) {
	    RET_1W:
		sp= T.sp;
		if (!sp_chk(sp)) goto run;
		T.ret[0]= umemw(sp_v2p(sp)) & unsw_mask[s];
	    } else
	    if ((s & (W-1)) != 0) {
		trap(T_ODDZ); goto run;
	    } else
	    if (s <= 4*W) {
		unsw *rp = T.ret;

		sp= T.sp;
		while (s > 0) {
		    if (!rdw(sp, &*rp++)) goto run;
		    sp += W;
		    s -= W;
		}
	    } else {
		trap(T_ILLINS); goto run;
	    }
	RET_0:
	    sp= T.lb;
	    if (!sp_chk(sp)) goto run;
	    lb= umemp(sp_v2p(sp));
	    sp += P;
	    if (!aligned(lb, W)) goto run;

	    if (!sp_chk(sp)) goto run;
	    pc= umemp(sp_v2p(sp));
	    if (!pc_chk(pc)) goto run;

	    T.lb= lb;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x02D: case 0x02E: case 0x02F: case 0x030:
	case 0x031:{	/* asp.1W - asp.5W : Adjust SP by 1 to 5 words */
	    unsp f;

	    f= (op - 0x02D) + 1;
	    goto ASP;

	case 0x032:	/* asp.w0 : Adjust the stack pointer by f words */
	    if (!pliteral(&pc, 1, &f)) goto run;
	    goto ASP;

	case 0x10C:	/* asp.lw : Adjust the stack pointer by f words */
	    if (!sliteral(&pc, 2, &f)) goto run;
	    goto ASP;

#if W >= 4
	case 0x211:	/* asp.Lw : Adjust the stack pointer by f words */
	    if (!sliteral(&pc, 4, &f)) goto run;
	    goto ASP;
#endif
	ASP:
	    sp= T.sp + f*W;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x10D:{	/* ass.l : Adjust the stack pointer */
	    unsw s;

	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto ASS;

	case 0x10E:	/* ass.z : Adjust the stack pointer */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto ASS;

	ASS:
	    if (s != W) { trap(T_ILLINS); goto run; }

	    if (!sp_chk(sp)) goto run;
	    s= umemw(sp_v2p(sp));
	    sp += W + s;
	    if (!aligned(sp, W)) goto run;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x038:{	/* blm.s0 : Block move */
	    unsw s;
	    memory dst, src, cnt;

	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto BLM;

	case 0x112:	/* blm.l : Block move */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto BLM;

#if W >= 4
	case 0x216:	/* blm.L : Block move */
	    if (!sliteral(&pc, 4, &s)) goto run;
	    sp= T.sp;
	    goto BLM;
#endif
	case 0x113:	/* bls.l : Block move */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto BLS;

	case 0x114:	/* bls.z : Block move */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto BLS;

	BLS:
	    if (s == P) {
		if (!rdp(sp, &s)) goto run;
		sp += P;
		goto BLS_P;
	    } else
#if M == 2*P
	    if (s == M) {
		if (!rddw(sp, &cnt)) goto run;
		sp += M;
		if (!rddw(sp, &dst)) goto run;
		sp += M;
		if (!rddw(sp, &src)) goto run;
		sp += M;
		goto BLS_M;
	    } else
#endif
	    {
		trap(T_ILLINS); goto run;
	    }

	BLM:
	    sp= T.sp;
	BLS_P:
	    cnt= s;
	    if (!sp_chk(sp)) goto run;
	    dst= umemp(sp_v2p(sp));
	    sp += W;
	    if (!sp_chk(sp)) goto run;
	    src= umemp(sp_v2p(sp));
	    sp += W;
#if M == 2*P
	BLS_M:
#endif
	    if (!bytecpy(dst, src, cnt)) goto run;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x065:{	/* csa.1W : Case jump type A */
	    unsw s, i;
	    unsp d;

	    sp= T.sp;
	    goto CSA_1W;

	case 0x126:	/* csa.l : Case jump type A */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto CSA;

	case 0x127:	/* csa.z : Case jump type A */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto CSA;

	CSA:
	    if (s != W) { trap(T_ILLINS); goto run; }
	CSA_1W:
	    if (!sp_chk(sp)) goto run;
	    d= umemp(sp_v2p(sp));
	    sp += P;
	    if (!sp_chk(sp)) goto run;
	    i= umemw(sp_v2p(sp));
	    sp += W;

	    if (!tlb_chk(&tp, DATA, d, pP|pR)) goto run;
	    pc= umemp(tlb_v2p(tp, d));
	    d += P;
	    if (!tlb_chk(&tp, DATA, d, pP|pR)) goto run;
	    i -= umemw(tlb_v2p(tp, d));
	    d += W;
	    if (!tlb_chk(&tp, DATA, d, pP|pR)) goto run;
	    if (i < umemw(tlb_v2p(tp, d))) {
		d += W + i*P;
		if (!tlb_chk(&tp, DATA, d, pP|pR)) goto run;
		d= umemp(tlb_v2p(tp, d));
		if (d != 0) pc= d;
	    }
	    if (pc == 0) { trap(T_CASE); goto run; }
	    if (!pc_chk(pc)) goto run;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x066:{	/* csb.1W : Case jump type B */
	    unsw s, i, n;
	    unsp d;

	    sp= T.sp;
	    goto CSB_1W;

	case 0x128:	/* csb.l : Case jump type B */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto CSB;

	case 0x129:	/* csb.z : Case jump type B */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto CSB;

	CSB:
	    if (s != W) { trap(T_ILLINS); goto run; }
	CSB_1W:
	    if (!sp_chk(sp)) goto run;
	    d= umemp(sp_v2p(sp));
	    sp += P;
	    if (!sp_chk(sp)) goto run;
	    i= umemw(sp_v2p(sp));
	    sp += W;

	    if (!tlb_chk(&tp, DATA, d, pP|pR)) goto run;
	    pc= umemp(tlb_v2p(tp, d));
	    d += P;
	    if (!tlb_chk(&tp, DATA, d, pP|pR)) goto run;
	    n= umemw(tlb_v2p(tp, d));
	    d += W;

	    while (n > 0) {
		if (!tlb_chk(&tp, DATA, d, pP|pR)) goto run;
		if (i == umemw(tlb_v2p(tp, d))) {
		    d += P;
		    if (!tlb_chk(&tp, DATA, d, pP|pR)) goto run;
		    pc= umemp(tlb_v2p(tp, d));
		    break;
		}
		d += W + P;
		n--;
	    }
	    if (pc == 0) { trap(T_CASE); goto run; }
	    if (!pc_chk(pc)) goto run;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x19A:{	/* dch.z : Follow dynamic chain */
	    unsp l;

	    if (!rdp(T.sp, &l)) goto run;
	    if (!rdp(l, &l)) goto run;
	    if (!wrp(T.sp, l)) goto run;
	    T.pc= pc;
	    break;}

	case 0x06A:{	/* dup.1W : Duplicate 1 word */
	    unsw s;

	    s= W;
	    sp= T.sp;
	    goto DUP_1W;

	case 0x130:	/* dup.l : Duplicate top s bytes */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto DUP;

	case 0x131:	/* dus.l : Duplicate top w bytes */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto DUS;

	case 0x132:	/* dus.z : Duplicate top w bytes */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto DUS;

	DUS:
	    if (s != W) { trap(T_ILLINS); goto run; }

	    if (!rdw(sp, &s)) goto run;
	    sp += W;
	    goto DUP;

	DUP:
	    if (s == 0) {
		trap(T_ODDZ); goto run;
	    } else
	    if (s <= W) {
		unsw w;

	    DUP_1W:
		if (!sp_chk(sp)) goto run;
		w= umemw(sp_v2p(sp));
		sp -= W;
		if (!sp_chk(sp)) goto run;
		umemw(sp_v2p(sp))= w & unsw_mask[s];
	    } else
	    if ((s & (W-1)) == 0) {
		trap(T_ODDZ); goto run;
	    } else {
		sp -= s;
		if (!wordcpy(sp, sp + s, s)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x19B:{	/* exg.s0 : Exchange top w bytes */
	    unsw s, w0, w1;
	    unsp p0, p1;

	    if (!pliteral(&pc, 1, &s)) goto run;
	    sp= T.sp;
	    goto EXG;

	case 0x19C:	/* exg.l : Exchange top w bytes */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto EXG;

	case 0x19D:	/* exg.z : Exchange top w bytes */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto EXG;

	EXG:
	    if (s == 0 || (s & (W-1)) != 0) { trap(T_ODDZ); goto run; } else
	    p0= sp;
	    p1= sp + s;
	    do {
		if (!rdw(p0, &w0)) goto run;
		if (!rdw(p1, &w1)) goto run;
		if (!wrw(p0, w1)) goto run;
		if (!wrw(p1, w0)) goto run;
		p0 += W;
		p1 += W;
	    } while ((s -= W) > 0);
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x06D:{	/* fil.u : File name */
	    unsp f;

	    if (!pliteral(&pc, 2, &f)) goto run;
	    goto FIL;

#if W >= 4
	case 0x21E:	/* fil.L : File name */
	    if (!sliteral(&pc, 4, &f)) goto run;
	    goto FIL;
#endif
	FIL:
	    T.file= f;
	    T.pc= pc;
	    break;}

	case 0x19F:{	/* gto.u : Non-local goto */
	    unsp g, lb;

	    if (!pliteral(&pc, 2, &g)) goto run;
	    goto GTO;

#if W >= 4
	case 0x21F:	/* gto.L : Non-local goto */
	    if (!sliteral(&pc, 4, &g)) goto run;
	    goto GTO;
#endif
	GTO:
	    if (!tlb_chk(&tp, DATA, g, pP|pR)) goto run;
	    pc= umemp(tlb_v2p(tp, g));
	    if (!pc_chk(pc)) goto run;

	    g += P;
	    if (!tlb_chk(&tp, DATA, g, pP|pR)) goto run;
	    sp= umemp(tlb_v2p(tp, g));
	    if (!aligned(sp, W)) goto run;

	    g += P;
	    if (!tlb_chk(&tp, DATA, g, pP|pR)) goto run;
	    lb= umemp(tlb_v2p(tp, g));
	    if (!aligned(lb, W)) goto run;

	    T.lb= lb;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x14C:	/* lim.z : Load ignore mask */
	    sp= T.sp - W;
	    if (!wrw(sp, T.flags & 0x0FFF)) goto run;
	    T.sp= sp;
	    T.pc= pc;
	    break;

	case 0x094:{	/* lin.l : Line number n */
	    unsw n;

	    if (!sliteral(&pc, 2, &n)) goto run;
	    goto LIN;

	case 0x095:	/* lin.s0 : Line number n */
	    if (!pliteral(&pc, 1, &n)) goto run;
	    goto LIN;

#if W >= 4
	case 0x223:	/* lin.L : Line number n */
	    if (!sliteral(&pc, 4, &n)) goto run;
	    goto LIN;
#endif
	LIN:
	    T.line= n;
	    T.pc= pc;
	    break;}

	case 0x096:	/* lni.z : Line number increment */
	    T.line++;
	    T.pc= pc;
	    break;

	case 0x14F:{	/* lor.s0 : Load register */
	    unsw r;

	    if (!pliteral(&pc, 1, &r)) goto run;
	    if (r >= 16) { trap(T_ILLINS); goto run; }
	    if (((1 << r) & 0xE004) && !(T.flags & F_(T_SUPER))) {
		trap(T_SUPER); goto run;
	    }
	    sp= T.sp - W;
	    if (!wrw(sp, ((unsw *) &T)[r])) goto run;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x19E:{	/* lpb.z : Convert LB to AB */
	    unsp l;

	    if (!rdp(T.sp, &l)) goto run;
	    if (!wrp(T.sp, l + 2*W)) goto run;
	    T.pc= pc;
	    break;}

	case 0x159:	/* mon.z : Monitor call */
	    if (!(T.flags & F_(T_SUPER))) { trap(T_SUPER); goto run; }
	    monitor();
	    break;

	case 0x15E:{	/* nop.z : No operation */
	    static i= 0, n= 1;

	    if (++i == n) {
		fprintf(logfp, "Your modifier lights glow dimly for a moment."
			    "  Nothing happens.\n");
		where();
		n <<= 1;
	    }
	    T.pc= pc;
	    break;}

	case 0x0C4:{	/* rck.1W : Range check */
	    unsw s;
	    unsp d;

	    s= W;
	    sp= T.sp;
	    goto RCK;

	case 0x15F:	/* rck.l : Range check */
	    if (!sliteral(&pc, 2, &s)) goto run;
	    sp= T.sp;
	    goto RCK;

	case 0x160:	/* rck.z : Range check */
	    if (!rdw(T.sp, &s)) goto run;
	    sp= T.sp + W;
	    goto RCK;

	RCK:
	    if (!rdp(sp, &d)) goto run;
	    sp += P;
	    if (s == W) {
		intw w, l, h;

		if (!rdw(sp, (unsw *) &w)) goto run;
		if (!rdw(d, (unsw *) &l)) goto run;
		d += W;
		if (!rdw(d, (unsw *) &h)) goto run;
		if (w < l || w > h) { trap(T_RANGE); goto run; }
	    } else
#if has_int(2*W)
	    if (s == 2*W) {
		intdw w, l, h;

		if (!rddw(sp, (unsdw *) &w)) goto run;
		if (!rddw(d, (unsdw *) &l)) goto run;
		d += 2*W;
		if (!rddw(d, (unsdw *) &h)) goto run;
		if (w < l || w > h) { trap(T_RANGE); goto run; }
	    } else
#endif
	    {
		trap(T_ILLINS); goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x16A:{	/* rtt.z : Return from trap */
	    unsp p;
	    memory newc;
	    task_t *t;

	    sp= T.sp;
	    if (!sp_chk(sp)) goto run;
	    p= umemp(sp_v2p(sp));
	    sp += P;

	    if (!aligned(p, W)) goto run;
	    if (!tlb_chk(&tp, DATA, p, pP|pR|pW)) goto run;
	    newc= tlb_v2p(tp, p);
	    t= (task_t *) newc;
	    p += sizeof(T)-1;
	    if (!tlb_chk(&tp, DATA, p, pP|pR|pW)) goto run;
	    if (newc + (sizeof(T)-1) != tlb_v2p(tp, p)
		|| (t->lb & (W-1)) || (t->sp & (W-1))
		|| (t->hp & (W-1)) || (t->pd & (W-1))
	    ) {
		trap(T_BADPTR);
		goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    context_switch(newc);
	    break;}

	case 0x17B:{	/* sig.z : Set trap handler */
	    unsp p;
	    memory tc;
	    task_t *t;

	    if (!rdp(T.sp, &p)) goto run;
	    if ((T.flags & F_(T_SUPER)) == 0) { trap(T_SUPER); goto run; }

	    /* Check thoroughly, we won't check it again. */
	    if (!aligned(p, W)) goto run;
	    if (!tlb_chk(&tp, DATA, p, pP|pR|pW)) goto run;
	    tc= tlb_v2p(tp, p);
	    t= (task_t *) tc;
	    p += sizeof(T)-1;
	    if (!tlb_chk(&tp, DATA, p, pP|pR|pW)) goto run;
	    if (tc + (sizeof(T)-1) != tlb_v2p(tp, p)
		|| (t->lb & (W-1)) || (t->sp & (W-1))
		|| (t->hp & (W-1)) || (t->pd & (W-1))
	    ) {
		trap(T_BADPTR);
		goto run;
	    }
	    trap_context= tc;
	    T.sp += W;
	    T.pc= pc;
	    break;}

	case 0x17E:{	/* sim.z : Store ignore mask */
	    unsw m;

	    if (!rdw(T.sp, &m)) goto run;
	    T.flags= (T.flags & ~0x0FFF) | (m & 0x0FFF);
	    T.sp += W;
	    T.pc= pc;
	    break;}

	case 0x18A:{	/* str.s0 : Store register */
	    unsw r, w;

	    if (!pliteral(&pc, 1, &r)) goto run;
	    if (r >= 16) { trap(T_ILLINS); goto run; }
	    if (((1 << r) & 0xE004) && !(T.flags & F_(T_SUPER))) {
		trap(T_SUPER); goto run;
	    }
	    sp= T.sp;
	    if (!rdw(sp, &w)) goto run;
	    sp += W;
	    if (((1 << r) & 0x0103)) {
		/* LB, SP and PD are word pointers. */
		if (!aligned(w, W)) goto run;
	    }
	    T.sp= sp;
	    T.pc= pc;
	    ((unsw *) &T)[r]= w;
	    if (r >= 14) context_switch(context);
	    break;}

	case 0x18D:{	/* trp.z : Trap */
	    unsw t;

	    sp= T.sp;
	    if (!rdw(sp, &t)) goto run;
	    sp += W;
	    if (t == T_PAGEFLT) { trap(T_ILLINS); goto run; }
	    T.sp= sp;
	    T.pc= pc;	/* Setting PC after TRP allows RTT to work right. */
	    trap(t);
	    break;}

	default:
	    trap(T_ILLINS);
	    goto run;
	}
    }
}

static void machine_init(void)
/* Initialize the interpreter to bootup state. */
{
    T.lb= 0;			/* Local base ends at 0. */
    T.sp= mem_size;		/* Stack at the far end (may be 0). */
    T.hp= 0;			/* Useless heap pointer. */
    T.pc= 0;			/* First instruction at address 0. */

    T.ret[0]= T.ret[1]= T.ret[2]= T.ret[3]= T.pd= T.file= T.line= 0;

				/* Ignored traps and flags. */
    T.flags= F_(T_IOVFL) | F_(T_FOVFL) | F_(T_FUNFL) | F_(T_IUND)
	| F_(T_FUND) | F_(T_CONV) | F_(T_SUPER);

    T.space[CODE]= T.space[DATA]= 0;	/* Code space 0, common I&D. */

    linear[0].lim= mem_size;	/* All memory is linear. */
    linear[0].v2p= mem;		/* With vir == phys. */

    tlb_expunge(0);		/* Unmap address space 0. */

    context= (memory) &T;	/* Current register set location unknown. */
    trap_context= (memory) &T;	/* Current trap handler unknown. */
    context_switch(context);
}

static void usage(void)
{
    fprintf(stderr, "Usage: %s [-m megabytes] [-l logfile] boot-disk ...\n",
	program);
    exit(1);
}

int main(int argc, char **argv)
{
    int i;
    ssize_t r;
    unsigned megs;
    char *m;

    program= argv[0];

    /* Process options and arguments. */
    megs= MEGS_DEFAULT;
    log_file= nil;
    i= 1;
    while (i < argc && argv[i][0] == '-') {
	char *opt= argv[i++] + 1;
	unsigned long m;
	char *end;

	if (opt[0] == '-' && opt[1] == 0) break;	/* -- */

	while (*opt != 0) switch (*opt++) {
	case 'm':
	    if (*opt == 0) {
		if (i == argc) usage();
		opt= argv[i++];
	    }
	    m= strtoul(opt, &end, 0x10);
	    if (end == opt || *end != 0) usage();
	    if (m < 1 || m > ((memory) -1 >> 20)) {
		fprintf(stderr, "%s: Memory size %s is undoable\n",
		    program, opt);
		exit(1);
	    }
	    megs= m;
	    opt= "";
	    break;
	case 'l':
	    if (*opt == 0) {
		if (i == argc) usage();
		opt= argv[i++];
	    }
	    log_file= opt;
	    opt= "";
	    break;
	default:
	    usage();
	}
    }
    if ((argc - i) != 1) usage();
    disk= argv[i];

    /* Obtain memory. */
    mem_size= (memory) megs << 20;
    if ((m= malloc(mem_size + PAGE_SIZE)) == nil) {
	fprintf(stderr, "%s: Can't obtain %u megabytes of memory\n",
	    program, megs);
	exit(1);
    }

    /* It never hurts to align our bit of memory to the page size. */
    mem= ((memory) m + (PAGE_SIZE - 1)) & ~PAGE_MASK;
    memset((void *) mem, 0, mem_size);

    /* Open the log file. */
    if (log_file == nil) {
	log_file= "stdout";
	logfp= stdout;
    } else
    if ((logfp= fopen(log_file, "w")) == nil) {
	fprintf(stderr, "%s: %s: %s\n", program, log_file, strerror(errno));
	exit(1);
    }

    /* Initialize some static tables. */
    limits_init();

    /* Initialize the machine to start running at address 0. */
    machine_init();

    /* Open the "disk". */
    if ((dfd= open(disk, O_RDWR)) == -1) {
	fprintf(stderr, "%s: Can't open %s: %s\n",
	    program, disk, strerror(errno));
	exit(1);
    }

    /* Read the first sector of the disk into memory. */
    r= read(dfd, &umem1(mem), 512);
    if (r < 512) {
	fprintf(stderr, "%s: Can't read sector 0 of %s: %s\n",
	    program, disk, r == -1 ? strerror(errno) : "Short read");
	exit(1);
    }

    /* Signature OK? */
    if (umem2(mem + 510) != 0xAA55) {
	fprintf(stderr, "%s: Bootstrap signature 0x%04X != 0xAA55\n",
	    program, umem2(mem + 510));
	exit(1);
    }

    /* Let er rip. */
    run();
    return 0;
}


 ******    *****   ******
 **   **  **   **  **   **         unRAR utility
 ******   *******  ******          ~~~~~~~~~~~~~
 **   **  **   **  **   **         FREE portable version
 **   **  **   **  **   **         ~~~~~~~~~~~~~~~~~~~~~

    The unRAR utility is a freeware program, distributed with source
    code and developed for extracting, testing and viewing the
    contents of archives created with the RAR archiver, version 1.50
    and above.  For the usage and distribution license please read the
    file LICENSE.TXT.

    The unRAR utility is a minor part of the RAR archiver and contains
    RAR uncompression algorithm.

    You should uncomment one of initial lines in OS.H to define
    the Operating System you are using (generic WIN32 and UNIX types
    are currently supported). For systems with Intel style byte order,
    it is recommended to uncomment the line '#define LITTLE_ENDIAN'
    to increase decryption speed.

    Compile it using the 32-bit flat model.

    To build UNRAR executable you need to compile UNRAR.C module only.

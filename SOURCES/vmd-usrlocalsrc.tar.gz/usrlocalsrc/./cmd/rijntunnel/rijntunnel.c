/*	rijntunnel 3.1 - Create a Rijndael encrypted IP tunnel
 *							Author: Kees J. Bot
 *								1 Nov 2000
 */
#define nil ((void*)0)
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <time.h>
#include <signal.h>
#include <configfile.h>
#include <sys/asynchio.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <crypto/rijndael.h>
#include <crypto/md5.h>

#if __minix
#include <net/hton.h>
#include <net/netlib.h>
#include <net/gen/in.h>
#include <net/gen/netdb.h>
#include <net/gen/socket.h>
#include <net/gen/inet.h>
#include <net/gen/psip_hdr.h>
#include <net/gen/psip_io.h>
#include <net/gen/ip_hdr.h>
#include <net/gen/ip_io.h>
#include <net/gen/udp.h>
#include <net/gen/udp_hdr.h>
#include <net/gen/udp_io.h>
#include <net/gen/tcp.h>
#include <net/gen/tcp_hdr.h>
#include <net/gen/icmp.h>
#include <net/gen/icmp_hdr.h>
typedef ipaddr_t psip_nexthop_t;
#define MINIX 1
#endif /* Minix */

#if __FreeBSD__
#include <inttypes.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#define _IP_VHL 1
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>

typedef uint8_t u8_t;
typedef uint16_t u16_t;
typedef uint32_t u32_t;

typedef u32_t ipaddr_t;
typedef u16_t udpport_t;

static char *my_inet_ntoa(ipaddr_t ip) {
    return inet_ntoa(* (struct in_addr *) &ip);
}
static int my_inet_aton(const char *cp, ipaddr_t *pip) {
    return inet_aton(cp, (struct in_addr *) pip);
}
#undef inet_ntoa
#define inet_ntoa my_inet_ntoa
#undef inet_aton
#define inet_aton my_inet_aton

typedef struct sockaddr_in psip_nexthop_t;

typedef struct sockaddr_in udp_io_hdr_t;

#undef HTONS
#undef HTONL
#if BYTE_ORDER == LITTLE_ENDIAN
#define HTONS(x) (((((u16_t)(x))>>8)&0xFF)|((((u16_t)(x))&0xFF)<<8))
#define HTONL(x) ((((u32_t)(x)>>24)&0xFFL)|(((u32_t)(x)>>8)&0xFF00L)| \
		 (((u32_t)(x)<<8)&0xFF0000L)|(((u32_t)(x)<<24)&0xFF000000L))
#else
#define HTONS(x) ((u16_t)(x))
#define HTONL(x) ((u32_t)(x))
#endif

typedef struct ip ip_hdr_t;
#define ih_vers_ihl		ip_vhl
#define ih_src			ip_src.s_addr
#define ih_dst			ip_dst.s_addr
#define ih_flags_fragoff	ip_off
#define ih_proto		ip_p
#define IH_FRAGOFF_MASK		IP_OFFMASK

typedef struct tcphdr tcp_hdr_t;
#define th_srcport		th_sport
#define th_dstport		th_dport
#define THF_SYN			TH_SYN
#define THF_ACK			TH_ACK

typedef struct udphdr udp_hdr_t;
#define uh_src_port		uh_sport
#define uh_dst_port		uh_dport

typedef struct icmp icmp_hdr_t;
#define ih_type			icmp_type
#define ih_code			icmp_code
#define ICMP_MIN_HDR_SIZE	ICMP_MINLEN

#define BSD 1
#define FREEBSD 1
#endif /* FreeBSD */

#define TICK		 30		/* My pseudo clock ticks this often. */
#define SLOWALIVE	(10*60)		/* Normal keepalive interval. */
#define FASTALIVE	 (2*60)		/* If no peep out of master. */
#define EXPIRE		(30*60)		/* Endpoint expiry interval. */
#define NEVER		LONG_MAX	/* Don't do this ever. */
#define DEFAULT_CONFIG	"/etc/rijntunnel.conf";
static char RANDOM[] =	"/dev/random";

#define IPBUFLEN	1500		/* Max IP packet size. */
#define UDPBUFLEN	4096		/* Tunneled packet maximum. */

#define IPHDRLEN	(int)sizeof(ip_hdr_t)
#define UDPHDRLEN	(int)sizeof(udp_io_hdr_t)
#define PSIPHDRLEN	(int)sizeof(ipaddr_t)

#define BROADCAST	HTONL(0xFFFFFFFFUL)
#define isbroadcast(ip)	\
	(((ip ^ HTONL(0xE0000000UL)) & HTONL(0xE0000000UL)) == 0)

#define B(a)		((u8_t *) (a))	/* Look at something as a byte array. */

static char *program;		/* Name of this program. */
static unsigned debug;		/* Debug level. */
static time_t now;		/* The current time. */
static time_t slowalive;	/* When to send a keepalive message? */
static time_t fastalive;
static time_t info;		/* When did I receive info from master. */
static unsigned nr_alives;	/* Number of unanswered info requests. */
#define NR_DEAD		3	/* Link is dead if nr_alives == NR_DEAD. */

/* Source of a packet, UDP tunneled, PSIP network, or in-tunnel (thin air). */
typedef enum { UDP, PSIP, AIR } net_t;

/* Filter sets on tunneled packets or packets from the local network. */
static config_t *filter_set[2];

/* Lists of stuff used in filter rules. */
typedef struct define {
	struct define	*next;
	int		busy;
	config_t	*define;
} define_t;
static define_t *define_list;

/* Crypto data: Key and sending initialization vector. */
typedef struct crypto {
	rd_keyinstance	keyinst;	/* Rijndael "key instance". */
	u8_t		sIV[16];	/* Sending initialization vector. */
} crypto_t;

/* Description of one endpoint in the tunnel. */
typedef struct peer {
	struct peer	*next;
	ipaddr_t	tip;		/* Address of peer within tunnel. */
	ipaddr_t	cip;		/* Current open address of peer. */
	udpport_t	port;		/* Port used for tunneled traffic. */
	time_t		expire;		/* When does 'cip' expire? */
	time_t		intro;		/* Time this client was introduced. */
	u8_t		key[16];	/* Session key for this peer. */
	crypto_t	crypto;		/* Crypto data (key and IV.) */
	u8_t		rIV[16];	/* Receiving IV while in sync. */
	unsigned	sync_ct;	/* Out of sync with receiver if > 0. */
} peer_t;

#define P_NR_SYNC	4		/* Send this many full IVs to sync. */

static crypto_t passkey;		/* The tunnel master key. */
static peer_t *peer_table;		/* Table of known tunnel endpoints. */
static peer_t *master;			/* Tunnel master's endpoint. */

static ipaddr_t my_tip;			/* My tunnel endpoint IP address. */
static peer_t *myself;			/* My endpoint's description. */

static void *allocate(void *mem, size_t len)
/* Allocate or reallocate a memory block of 'len' bytes. */
{
    if ((mem= realloc(mem, len)) == nil) {
	fprintf(stderr, "%s: Can't allocate %lu bytes memory: %s\n",
	    program, (unsigned long) len, strerror(errno));
	exit(1);
    }
    return mem;
}

#define between(a, c, z)	((unsigned) (c) - (a) <= (unsigned) (z) - (a))

static void makerandom(void *data, size_t len)
/* Pull some randomness out of the random device. */
{
    int rfd;
    ssize_t n, r;

    if ((rfd= open(RANDOM, O_RDONLY)) < 0) {
	fprintf(stderr, "%s: %s: %s\n", program, RANDOM, strerror(errno));
	exit(1);
    }
    for (n= 0; n < len; n += r) {
	r= read(rfd, B(data) + n, len - n);
	if (r <= 0) {
	    fprintf(stderr, "%s: %s: %s\n", program, RANDOM,
		r < 0 ? strerror(errno) : "Unexpected EOF");
	    exit(1);
	}
    }
    close(rfd);
}

static peer_t *new_peer(void)
/* Add a new tunnel endpoint to the peer table. */
{
    peer_t *pr, **apr;

    for (apr= &peer_table; *apr != nil; apr= &(*apr)->next) {}

    *apr= pr= allocate(nil, sizeof(*pr));
    pr->next= nil;
    pr->tip= 0;
    pr->cip= 0;
    pr->port= 0;
    pr->expire= 0;
    pr->intro= now;
    makerandom(pr->key, sizeof(pr->key));
    rijndael_makekey(&pr->crypto.keyinst, sizeof(pr->key), pr->key);
    memcpy(pr->crypto.sIV, passkey.sIV, sizeof(pr->crypto.sIV));
    pr->sync_ct= P_NR_SYNC;
    return pr;
}

static void parse_config(char *configfile)
/* Parse the tunnel configuration file. */
{
    config_t *cfg;
    net_t net;

    now= time(nil);

    /* Choose a random sending IV for the master key. */
    makerandom(passkey.sIV, sizeof(passkey.sIV));

    /* Read the configuration file to determine the tunnel master and stuff. */
    cfg= config_read(configfile, 0, nil);

    while (cfg != nil) {
	config_t *cmd= cfg->list;
	cfg= cfg->next;

	if (strcmp(cmd->word, "master") == 0) {
	    /* Address, port and key of the tunnel master. */
	    struct hostent *he;
	    char *colon, *end;
	    unsigned long p;
	    const char *key;

	    if (config_length(cmd) != 4
		|| !config_isatom(cmd->next)
		|| !config_isatom(cmd->next->next)
		|| !config_isatom(cmd->next->next->next)
	    ) {
		fprintf(stderr,
		"\"%s\", line %u: Usage: master tunnel-name open-name\n",
		    cmd->file, cmd->line);
		exit(1);
	    }

	    if (master != nil) {
		fprintf(stderr,
		"\"%s\", line %u: The tunnel master has already been defined\n",
		    cmd->file, cmd->line);
	    }

	    /* Create a peer entry for the tunnel master. */
	    master= new_peer();

	    /* Look up the IP address of the master's endpoint. */
	    if ((he= gethostbyname(cmd->next->word)) == nil
		|| he->h_addrtype != AF_INET
		|| he->h_length != sizeof(ipaddr_t)
	    ) {
		fprintf(stderr, "\"%s\", line %u: %s: Lookup failed\n",
		    cmd->next->file, cmd->next->line, cmd->next->word);
		exit(1);
	    }
	    memcpy(&master->tip, he->h_addr, sizeof(master->tip));

	    /* Look up the outside IP address and compute port. */
	    if ((colon= strchr(cmd->next->next->word, ':')) == nil) {
		fprintf(stderr,
		    "\"%s\", line %u: %s should be hostname:port\n",
		    cmd->next->next->file, cmd->next->next->line,
		    cmd->next->next->word);
		exit(1);
	    }
	    *colon++ = 0;

	    if ((he= gethostbyname(cmd->next->next->word)) == nil
		|| he->h_addrtype != AF_INET
		|| he->h_length != sizeof(ipaddr_t)
	    ) {
		fprintf(stderr, "\"%s\", line %u: %s: Lookup failed\n",
		    cmd->next->next->file, cmd->next->next->line,
		    cmd->next->next->word);
		exit(1);
	    }
	    memcpy(&master->cip, he->h_addr, sizeof(master->cip));

	    p= strtoul(colon, &end, 0);
	    if (end == colon || *end != 0 || p <= 0 || p > 0xFFFFU) {
		fprintf(stderr,
		    "\"%s\", line %u: %s: Bad port number\n",
		    cmd->next->next->file, cmd->next->next->line,
		    cmd->next->next->word);
		exit(1);
	    }
	    master->port= ntohs(p);

	    *--colon= ':';

	    /* Initialize the master key. */
	    key= cmd->next->next->next->word;
	    if (rijndael_makekey(&passkey.keyinst, RD_KEY_HEX, key) < 0) {
		fprintf(stderr, "\"%s\", line %u: Not a proper Rijndael key\n",
		    cmd->next->file, cmd->next->line);
		exit(1);
	    }

	    if (debug >= 1) {
		printf("master %s ", inet_ntoa(master->tip));
		printf("%s:%u [key]\n",
		    inet_ntoa(master->cip), ntohs(master->port));
	    }
	} else
	if (strcmp(cmd->word, "filter") == 0) {
	    if (config_length(cmd) != 3
		|| !config_isatom(cmd->next)
		|| !(strcmp(cmd->next->word, "tunnel") == 0
		    || strcmp(cmd->next->word, "network") == 0)
		|| !config_issub(cmd->next->next)
	    ) {
		fprintf(stderr,
		"\"%s\", line %u: Usage: filter [tunnel|network] { ... }\n",
		    cmd->file, cmd->line);
		exit(1);
	    } else {
		/* A tunnel or network filter set. */
		net= cmd->next->word[0] == 't' ? UDP : PSIP;
		if (filter_set[net] != nil) {
		    fprintf(stderr,
	    "\"%s\", line %u: %s filters already defined at \"%s\", line %u\n",
			cmd->file, cmd->line, cmd->next->word,
			filter_set[net]->file, filter_set[net]->line);
		    exit(1);
		}
		filter_set[net] = cmd;
	    }
	} else
	if (strcmp(cmd->word, "define") == 0) {
	    if (config_length(cmd) < 3 || !config_isatom(cmd->next)) {
		fprintf(stderr,
		    "\"%s\", line %u: Usage: define keyword stuff ...\n",
		    cmd->file, cmd->line);
		exit(1);
	    } else {
		/* A definition of stuff used in filter rules. */
		define_t *d;

		for (d= define_list; d != nil; d= d->next) {
		    if (strcmp(cmd->next->word, d->define->word) == 0) {
			fprintf(stderr,
		"\"%s\", line %u: %s is already defined at \"%s\", line %u\n",
			    cmd->next->file, cmd->next->line, cmd->next->word,
			    d->define->file, d->define->line);
			exit(1);
		    }
		}
		d= allocate(nil, sizeof(*d));
		d->next= define_list;
		define_list= d;
		d->busy= 0;
		d->define= cmd->next;
	    }
	} else {
	    fprintf(stderr, "\"%s\", line %u: Unknown keyword, '%s'\n",
		cmd->file, cmd->line, cmd->word);
	    exit(1);
	}
    }

    if (master == nil) {
	fprintf(stderr, "\"%s\": No tunnel master has been specified\n",
	    configfile);
	exit(1);
    }

    if (master->tip == my_tip) {
	/* I seem to be this tunnel's master, the only reliable endpoint in
	 * the tunnel.  So I get to manage peers and stuff.
	 */
	master->expire= NEVER;
	myself= master;
    } else {
	/* I'm just a lowly endpoint.  Create an empty entry for myself. */
	myself= new_peer();
	myself->tip= my_tip;
    }

    /* Filters pointers must be adjusted to the actual filter rules. */
    for (net= UDP; net <= PSIP; net++) {
	if (filter_set[net] != nil) {
	    filter_set[net]= filter_set[net]->next->next->list;
	}
    }
}

static peer_t *find_peer(ipaddr_t ip, udpport_t port)
/* Find a peer given its current IP address and port if port != 0, or find
 * a peer given its tunnel IP address if port == 0.
 */
{
    static struct {
	ipaddr_t	ip;
	udpport_t	port;
	peer_t		*peer;
    } pcache[256], *pc;

    pc= &pcache[B(&ip)[3]];

    /* Is it in the cache now? */
    if (pc->ip != ip || pc->port != port) {
	peer_t *pr;

	/* Walk through the list of peers. */
	for (pr= peer_table; pr != nil; pr= pr->next) {
	    if ((pr->tip == ip && port == 0)
		|| (pr->cip == ip && pr->port == port)
	    ) {
		pc->ip= ip;
		pc->port= port;
		pc->peer= pr;
		goto found;
	    }
	}
	return nil;
    }
found:
    return pc->peer;
}

/* Command/flags byte at the end of a packet on the open net. */
#define OCMD_MASK	0x07	/* Mask for the command field. */
#define OCMD_IP		0x00	/* Tunneled IP packet or in-tunnel command. */
#define OCMD_RESYNC	0x01	/* Need to reestablish sync. */
#define OCMD_RENEW	0x02	/* Need to renew information. */
#define OCMD_IV0	0x80	/* Only IV[0] is sent (we're in sync). */
#define OCMD_MASTER	0x40	/* Using the master key. */
#define OCMD_BCAST	0x20	/* Packet is broadcast within the tunnel net. */

/* Commands within the tunnel. */
#define TCMD_ALIVE	0x00	/* I'm alive! (Tells current IP and port). */
#define TCMD_INFO	0x01	/* Tunnel endpoint information. */

#define CKSUM_LEN	16

static void cksum(const u8_t *data, size_t len, u8_t *sum)
/* Compute an MD5 checksum of a data area. */
{
    struct MD5Context md5c;

    MD5Init(&md5c);
    MD5Update(&md5c, data, len);
    MD5Final(sum, &md5c);
}

static void warpIV(u8_t *IV, unsigned low)
/* Increment or decrement an IV at the minimum distance needed to make the low
 * 8 bits equal to 'low'.  Being fond of little endian we choose to do that.
 */
{
    unsigned b;
    int i;

    goto up;	/* (In a perfect world we only increment by one.) */
    do {
	if (b < 0x80) {
	    /* Up is closer. */
	up: if (++IV[0] == 0x00) {
		for (i= 1; i < 16 && ++IV[i] == 0x00; i++) {}
	    }
	} else {
	    /* Down is closer. */
	    if (--IV[0] == 0xFF) {
		for (i= 1; i < 16 && --IV[i] == 0xFF; i++) {}
	    }
	}
    } while ((b= ((low - IV[0])) & 0xFF) != 0);
}

static ssize_t encode(unsigned cmd, u8_t *data, size_t len, peer_t *peer)
/* Encode data to be sent to the given peer.  Return the new size after adding
 * a checksum and stuff, or -1 on error.
 */
{
    crypto_t *crypto;
    u8_t iv[16];

    /* First add a checksum. */
    cksum(data, len, data + len);
    len += CKSUM_LEN;

    /* Encrypt the data with the proper crypto.  If the first byte is zero
     * then it is an in-tunnel command (improper IP packet), so we use the
     * tunnel master key.  Otherwise the recipients session key.
     */
    if (data[0] == 0) cmd |= OCMD_MASTER;
    crypto= (cmd & OCMD_MASTER) ? &passkey : &peer->crypto;
    memcpy(iv, crypto->sIV, 16);
    if (rijndael_cbc_encrypt(&crypto->keyinst, data, data, len, &iv) < 0) {
	return -1;
    }

    if (cmd & OCMD_MASTER) {
	/* An in-tunnel message, always the full IV. */
	memcpy(data+len, crypto->sIV, 16);
	len += 16;
    } else
    if (peer->sync_ct > 0) {
	/* We're out of sync with the receiver, so include the full IV. */
	if (peer->expire <= now) return -1;
	memcpy(data+len, crypto->sIV, 16);
	len += 16;
	peer->sync_ct--;		/* We're getting in sync. */
    } else {
	/* We're in sync with the receiver, so send only the low 8 IV bits. */
	if (peer->expire <= now) return -1;
	data[len++] = crypto->sIV[0];
	cmd |= OCMD_IV0;
    }

    /* Add the command byte. */
    data[len++]= cmd;

    /* Increment the IV, never use it twice with the same key. */
    warpIV(crypto->sIV, crypto->sIV[0] + 1);

    return len;
}

static ssize_t decode(unsigned cmd, u8_t *data, size_t len, peer_t *peer)
/* Decode data received from a given peer (may be a null pointer for an as
 * yet unknown peer).  Return the new size after removing the checksum and
 * stuff, or -1 on error.
 */
{
    u8_t iv[16], riv[16], sum[CKSUM_LEN];
    crypto_t *crypto;

    /* Master key or my own key? */
    crypto= (cmd & OCMD_MASTER) ? &passkey : &myself->crypto;

    if (cmd & OCMD_IV0) {
	/* Only the low few IV bits have been sent. */
	if (peer == nil) return -1;
	memcpy(riv, peer->rIV, 16);
	if (len < 1) return -1;
	len--;
	warpIV(riv, data[len]);
    } else {
	/* A full IV has been sent, master key or sync lost. */
	if (len < 16) return -1;
	len -= 16;
	memcpy(riv, data + len, 16);
    }

    /* Expecting at least an IP header and a checksum. */
    if (len < 20+CKSUM_LEN) return -1;

    /* Decrypt the packet. */
    memcpy(iv, riv, 16);
    if (rijndael_cbc_decrypt(&crypto->keyinst, data, data, len, &iv) < 0) {
	return -1;
    }

    /* Compute the checksum and compare. */
    len -= CKSUM_LEN;
    cksum(data, len, sum);
    if (memcmp(data + len, sum, CKSUM_LEN) != 0) return -1;

    /* Looks OK to me, update the receiving IV and return. */
    if (peer != nil && crypto != &passkey) memcpy(peer->rIV, riv, 16);

    return len;
}

/* Buffers for packets. */
typedef struct buf {
	struct buf	*next;		/* Next on the free list. */
	net_t		net;		/* Source of this packet. */
	ipaddr_t	nexthop;	/* Where to forward it to. */
	udp_io_hdr_t	*udp;		/* UDP prefix from UDP tunnel. */
	psip_nexthop_t	*psip;		/* PSIP prefix from PSIP net. */
	ip_hdr_t	*ip;		/* IP header of packet. */
	u8_t		*data;		/* User data in payload. */
	u8_t		*end;		/* End of useful data. */
	u8_t		buf[UDPBUFLEN];	/* Payload. */
} buf_t;

buf_t *freebuf;		/* Currently unused buffers. */

static void get_buf(buf_t **bp)
/* Allocate and return a buffer pointer iff *bp == nil. */
{
    if (*bp != nil) {
	/* Already has one. */
    } else
    if (freebuf != nil) {
	/* There is a free buffer. */
	*bp= freebuf;
	freebuf= freebuf->next;
    } else {
	/* Get one from the heap. */
	buf_t *new= allocate(nil, sizeof(*new));
	new->udp= (udp_io_hdr_t *) new->buf;
	new->ip= (ip_hdr_t *) (new->udp + 1);
	new->psip= (psip_nexthop_t *) new->ip - 1;
	new->data= (u8_t *) (new->ip + 1);
	*bp= new;
    }
}

static void put_buf(buf_t **bp)
/* Return a buffer to the free list. */
{
    if (*bp != nil) {
	(*bp)->next= freebuf;
	freebuf= *bp;
	*bp= nil;
    }
}

static void give_buf(buf_t **dbp, buf_t **sbp)
/* Hand over a buffer to another variable. */
{
    if (*dbp != nil) put_buf(dbp);
    *dbp= *sbp;
    *sbp= nil;
}

static int cidr_aton(const char *cidr, ipaddr_t *addr, ipaddr_t *mask)
/* Translate something like 172.16.0.0/12 to an address/mask pair. */
{
    char *slash, *check;
    ipaddr_t a;
    int ok;
    unsigned long len;

    if ((slash= strchr(cidr, '/')) != nil) *slash++= 0;

    ok= inet_aton(cidr, &a);

    if (slash == nil) {
	len= 32;
    } else {
	len= strtoul(slash, &check, 10);
	if (check == slash || *check != 0 || len > 32) ok= 0;
	*--slash= '/';
    }

    if (!ok) return 0;
    *addr= a;
    *mask= htonl(len == 0 ? 0 : (0xFFFFFFFFUL << (32-len)) & 0xFFFFFFFFUL);
    return 1;
}

typedef enum { ADDR, PORT, TYPECODE } whatspec_t;

static int onspec(whatspec_t what, unsigned long ap, config_t *spec)
/* Check if an IP address or port is matched by a list of addr/port specs. */
{
    define_t *d= nil;
    int ok= 0;

    if (config_isatom(spec)) {
	/* A defined word, maybe? */
	for (d= define_list; d != nil; d= d->next) {
	    if (strcmp(spec->word, d->define->word) == 0) {
		if (d->busy) {
		    fprintf(stderr,
		"\"%s\", line %u: %s includes itself in recursive expansion\n",
			spec->file, spec->line, spec->word);
		    exit(1);
		}
		d->busy= 1;
		spec= d->define->next;
		break;
	    }
	}
	if (d == nil) {
	    switch (what) {
	    case ADDR: {
		/* Must be a CIDR spec, try to match it. */
		ipaddr_t ip, mask;

		if (!cidr_aton(spec->word, &ip, &mask)) {
		    fprintf(stderr,
		    "\"%s\", line %u: %s is not a CIDR spec or an IP address\n",
			spec->file, spec->line, spec->word);
		    exit(1);
		}
		return ((((ipaddr_t) ap ^ ip) & mask) == 0); }
	    case PORT:
		/* Must be a port number, test it. */
		if (!(spec->flags & CFG_DULONG)) {
		    fprintf(stderr,
			"\"%s\", line %u: %s is not a port number\n",
			spec->file, spec->line, spec->word);
		    exit(1);
		}
		return (ntohs((u16_t) ap) == strtoul(spec->word, nil, 10));
	    case TYPECODE:
		/* Must be a type or code number, test it. */
		if (!(spec->flags & CFG_DULONG)) {
		    fprintf(stderr,
			"\"%s\", line %u: %s is not a type/code number\n",
			spec->file, spec->line, spec->word);
		    exit(1);
		}
		return (ap == strtoul(spec->word, nil, 10));
	    default:
		abort();
	    }
	}
    } else {
	/* A list of stuff, try each element. */
	spec= spec->list;
    }

    while (spec != nil) {
	if (onspec(what, ap, spec)) ok= 1;
	spec= spec->next;
    }

    if (d != nil) d->busy= 0;
    return ok;
}

typedef enum { FORWARD, DROP, NEXT } filter_t;

static filter_t filter_rules(ipaddr_t src_addr, ipaddr_t dst_addr,
    const u16_t par[2], unsigned proto, config_t *rules)
/* Apply filter rules as found in the configuration file.  (Used by the
 * filter() function below to update its filter cache, so this doesn't have
 * to be fast.)
 */
{
    filter_t this= NEXT, that[2];

    while (rules != nil) {
	int i, action, gotnext;
	config_t *rule;

	rule= rules->list;
	rules= rules->next;

	action= 0;
	while (rule != nil && rule->next != nil && rule->next->next != nil) {
	    if (!config_isatom(rule)) goto badrule;

	    if (strcmp(rule->word, "icmp") == 0) {
		if (proto != IPPROTO_ICMP) action= 1;
		rule= rule->next;
	    } else
	    if (strcmp(rule->word, "tcp") == 0) {
		if (proto != IPPROTO_TCP) action= 1;
		rule= rule->next;
	    } else
	    if (strcmp(rule->word, "udp") == 0) {
		if (proto != IPPROTO_UDP) action= 1;
		rule= rule->next;
	    } else
	    if (strcmp(rule->word, "src") == 0) {
		if (!config_isatom(rule->next)) goto badrule;
		if (strcmp(rule->next->word, "port") == 0) {
		    if (!onspec(PORT, par[0], rule->next->next)) action= 1;
		    rule= rule->next->next->next;
		} else {
		    if (!onspec(ADDR, src_addr, rule->next)) action= 1;
		    rule= rule->next->next;
		}
	    } else
	    if (strcmp(rule->word, "dst") == 0) {
		if (!config_isatom(rule->next)) goto badrule;
		if (strcmp(rule->next->word, "port") == 0) {
		    if (!onspec(PORT, par[1], rule->next->next)) action= 1;
		    rule= rule->next->next->next;
		} else {
		    if (!onspec(ADDR, dst_addr, rule->next)) action= 1;
		    rule= rule->next->next;
		}
	    } else
	    if (strcmp(rule->word, "type") == 0) {
		if (!config_isatom(rule->next)) goto badrule;
		if (!onspec(TYPECODE, par[0], rule->next)) action= 1;
		rule= rule->next->next;
	    } else
	    if (strcmp(rule->word, "code") == 0) {
		if (!config_isatom(rule->next)) goto badrule;
		if (!onspec(TYPECODE, par[1], rule->next)) action= 1;
		rule= rule->next->next;
	    } else {
	    badrule:
		fprintf(stderr,
		    "\"%s\", line %u: Bad filter rule, see manual\n",
		    rule->file, rule->line);
		exit(1);
	    }
	}

	gotnext= 0;
	for (i= 0; rule != nil; rule= rule->next, i++) {
	    if (config_isatom(rule) && strcmp(rule->word, "forward") == 0) {
		that[i]= FORWARD;
	    } else
	    if (config_isatom(rule) && strcmp(rule->word, "drop") == 0) {
		that[i]= DROP;
	    } else
	    if (config_isatom(rule) && strcmp(rule->word, "next") == 0) {
		that[i]= NEXT;
		gotnext= 1;
	    } else
	    if (config_issub(rule)) {
		that[i]= filter_rules(src_addr, dst_addr, par,
					proto, rule->list);
		gotnext= 1;	/* can't tell */
	    } else {
		fprintf(stderr,
		    "\"%s\", line %u: Bad filter action, see manual\n",
		    rule->file, rule->line);
		exit(1);
	    }
	}

	if (rules != nil && !gotnext) {
		fprintf(stderr,
		    "\"%s\", line %u: This rule can't be reached\n",
		    rules->list->file, rules->list->line);
		exit(1);
	}

	if (this == NEXT) this= that[action];
    }
    return this;
}

static filter_t filter(buf_t *bp)
/* Apply a set of filter rules to a packet to see if we like it. */
{
    static struct {
	ipaddr_t	src_addr;	/* Source and destination addresses. */
	ipaddr_t	dst_addr;
	u16_t		par[2];		/* Protocol parameters (ports/types). */
	unsigned	proto;		/* Protocol number. */
    } fcache[2][256], *fc;
    ip_hdr_t *ip;
    u16_t par[2];
    unsigned hpar;

    /* Don't bother if not filtering. */
    if (filter_set[bp->net] == nil) return FORWARD;

    /* The IPv4 header must not use options. */
    ip= bp->ip;
    if (ip->ih_vers_ihl != 0x45) {
	if (ip->ih_vers_ihl == 0) return FORWARD;	/* In-tunnel command. */
	fprintf(stderr, "Packet with version/length %02X from %s to ",
	    ip->ih_vers_ihl, inet_ntoa(ip->ih_src));
	fprintf(stderr, "%s dropped\n", inet_ntoa(ip->ih_dst));
    }

    /* Only look at fragment 0. */
    if ((ip->ih_flags_fragoff & HTONS(IH_FRAGOFF_MASK)) != 0) return FORWARD;

    /* Look at the packet by protocol to determine protocol parameters. */
    if (ip->ih_proto == IPPROTO_TCP) {
	tcp_hdr_t *tcp= (tcp_hdr_t *) bp->data;

	/* TCP header complete? */
	if (bp->end < B(tcp + 1)) {
	    fprintf(stderr, "Too short TCP packet from %s to ",
		inet_ntoa(ip->ih_src));
	    fprintf(stderr, "%s dropped\n", inet_ntoa(ip->ih_dst));
	    return DROP;
	}

	/* Only look at SYN packets trying to setup a connection. */
	if ((tcp->th_flags & (THF_SYN|THF_ACK)) != THF_SYN) return FORWARD;

	par[0]= tcp->th_srcport;	/* TCP port numbers. */
	par[1]= tcp->th_dstport;
	hpar= B(&par[0])[1] ^ B(&par[1])[1];
    } else
    if (ip->ih_proto == IPPROTO_UDP) {
	udp_hdr_t *udp= (udp_hdr_t *) bp->data;

	/* UDP header complete? */
	if (bp->end < B(udp + 1)) {
	    fprintf(stderr, "Too short UDP packet from %s to ",
		inet_ntoa(ip->ih_src));
	    fprintf(stderr, "%s dropped\n", inet_ntoa(ip->ih_dst));
	    return DROP;
	}

	par[0]= udp->uh_src_port;	/* UDP port numbers. */
	par[1]= udp->uh_dst_port;
					/* Port number hash key. */
	hpar= B(&par[0])[1] ^ B(&par[1])[1];
    } else
    if (ip->ih_proto == IPPROTO_ICMP) {
	icmp_hdr_t *icmp= (icmp_hdr_t *) bp->data;

	/* ICMP header complete? */
	if (bp->end < B(icmp) + ICMP_MIN_HDR_SIZE) {
	    fprintf(stderr, "Too short ICMP packet from %s to ",
		inet_ntoa(ip->ih_src));
	    fprintf(stderr, "%s dropped\n", inet_ntoa(ip->ih_dst));
	    return DROP;
	}

	par[0]= icmp->ih_type;		/* ICMP type and code. */
	par[1]= icmp->ih_code;
	hpar= par[0] ^ par[1];
    } else {
	/* Some other protocol. */
	par[0]= par[1]= 0;		/* No parameters. */
	hpar= 0;
    }

    /* Determine the cache entry for this kind of packet. */
    fc= &fcache[bp->net][B(&ip->ih_src)[3] ^ B(&ip->ih_dst)[3]
						^ hpar ^ ip->ih_proto];

    if (fc->src_addr == ip->ih_src && fc->dst_addr == ip->ih_dst
	&& fc->par[0] == par[0] && fc->par[1] == par[1]
	&& fc->proto == ip->ih_proto
    ) {
	/* The cache tells that a packet like this has been found ok before. */
	return FORWARD;
    }

    /* Apply a filter ruleset to the packet attributes. */
    switch (filter_rules(ip->ih_src, ip->ih_dst,
	par, ip->ih_proto, filter_set[bp->net])
    ) {
    case NEXT:
	fprintf(stderr,
	"\"%s\", line %u: Filter does not say \"forward\" or \"drop\"\n",
	    filter_set[bp->net]->file, filter_set[bp->net]->line);
	exit(1);
    case FORWARD:
	/* It may be forwarded.  Cache this knowledge to speed things up. */
	fc->src_addr= ip->ih_src;
	fc->dst_addr= ip->ih_dst;
	fc->par[0]= par[0];
	fc->par[1]= par[1];
	fc->proto= ip->ih_proto;
	if (debug >= 2) {
	    if (ip->ih_proto == IPPROTO_TCP || ip->ih_proto == IPPROTO_UDP) {
		printf("%s packet from %s:%u to ",
		    ip->ih_proto == IPPROTO_TCP ? "TCP" : "UDP",
		    inet_ntoa(ip->ih_src), ntohs(par[0]));
		printf("%s:%u allowed\n",
		    inet_ntoa(ip->ih_dst), ntohs(par[1]));
	    } else
	    if (ip->ih_proto == IPPROTO_ICMP) {
		printf("ICMP packet type %u code %u from %s to ",
		    par[0], par[1], inet_ntoa(ip->ih_src));
		printf("%s allowed\n",
		    inet_ntoa(ip->ih_dst));
	    } else {
		printf("Packet proto %u from %s to ",
		    ip->ih_proto, inet_ntoa(ip->ih_src));
		printf("%s allowed\n",
		    inet_ntoa(ip->ih_dst));
	    }
	}
	return FORWARD;
    case DROP:
	/* Otherwise forget it. */
	if (ip->ih_proto == IPPROTO_TCP || ip->ih_proto == IPPROTO_UDP) {
	    fprintf(stderr, "%s packet from %s:%u to ",
		ip->ih_proto == IPPROTO_TCP ? "TCP" : "UDP",
		inet_ntoa(ip->ih_src), ntohs(par[0]));
	    fprintf(stderr, "%s:%u dropped\n",
		inet_ntoa(ip->ih_dst), ntohs(par[1]));
	} else
	if (ip->ih_proto == IPPROTO_ICMP) {
	    fprintf(stderr, "ICMP packet type %u code %u from %s to ",
		par[0], par[1], inet_ntoa(ip->ih_src));
	    fprintf(stderr, "%s dropped\n",
		inet_ntoa(ip->ih_dst));
	} else {
	    fprintf(stderr, "Packet proto %u from %s to ",
		ip->ih_proto, inet_ntoa(ip->ih_src));
	    fprintf(stderr, "%s dropped\n",
		inet_ntoa(ip->ih_dst));
	}
	return DROP;
    default:
	abort();
    }
}

static void onsig(int sig)
{
    switch (sig) {
    case SIGUSR1:	debug++;	break;
    case SIGUSR2:	debug= 0;	break;
    }
}

static void onalarm(int sig)
/* Our pseudo clock interrupts asyn_wait() and updates 'now'. */
{
    now= time(nil);
    alarm(TICK);
}

static void usage(void)
{
    fprintf(stderr,
	"Usage: %s [-d[level]] [-f config] tunnel-net open-net\n"
	"	tunnel-net: Interface name of the pseudo-ip tunnel endpoint\n"
	"	open-net: Interface name of the Internet transport network\n",
	program);
    exit(1);
}

#if MINIX
static int ifname2n(const char *name)
/* Translate an interface name, ip0, ip1, etc, to a number. */
{
    const char *np;
    char *end;
    unsigned long n;

    np= name;
    if (*np++ != 'i' || *np++ != 'p') usage();
    n= strtoul(np, &end, 10);
    if (end == np || *end != 0) usage();
    if (n >= 1000) {
	fprintf(stderr, "%s: Network number of \"%s\" is a bit large\n",
	    program, name);
	exit(1);
    }
    return n;
}
#endif

int main(int argc, char **argv)
{
    int ps_fd[2], udp_fd[2], ip_fd;
    asynchio_t asyn;
    int i;
    char *configfile;
    buf_t *udp_buf, *ps_buf, *buf;
    ssize_t r;
    struct sigaction sa;
#if MINIX
    static char ps_device[]= "/dev/psipNNN";
    static char udp_device[]= "/dev/udpNNN";
    static char ip_device[]= "/dev/ipNNN";
#define set_net(device, net) (sprintf((device)+(sizeof(device)-4), "%u", (net)))
    unsigned ps_net, udp_net;
    nwio_ipconf_t ipconf;
    nwio_psipopt_t psipopt;
    nwio_udpopt_t udpopt;
#endif
#if BSD
    char *ps_device, *udp_device, *ip_device;
    char *ps_net, *udp_net;
#endif

    program= argv[0];
    setvbuf(stderr, nil, _IOLBF, 0);

    configfile= DEFAULT_CONFIG;
    debug= 0;
    i= 1;
    while (i < argc && argv[i][0] == '-') {
	char *opt= argv[i++]+1;

	if (opt[0] == '-' && opt[1] == 0) break;	/* -- */

	while (*opt != 0) switch (*opt++) {
	case 'f':
	    if (*opt == 0) {
		if (i == argc) usage();
		opt= argv[i++];
	    }
	    configfile= opt;
	    opt= "";
	    break;
	case 'd':
	    debug= 1;
	    if (between('0', *opt, '9')) debug= strtoul(opt, &opt, 10);
	    break;
	default:
	    usage();
	}
    }
    if ((argc - i) != 2) usage();
#if MINIX
    ps_net= ifname2n(argv[i+0]);
    udp_net= ifname2n(argv[i+1]);
#endif
#if BSD
    ps_net= argv[i+0];
    udp_net= argv[i+1];
#endif

    sa.sa_handler= onsig;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags= 0;
    sigaction(SIGUSR1, &sa, nil);
    sigaction(SIGUSR2, &sa, nil);

    sa.sa_handler= onalarm;
    sigaction(SIGALRM, &sa, nil);

#if MINIX
    /* Set the network numbers of the networks involved. */
    set_net(ps_device, ps_net);
    set_net(udp_device, udp_net);
    set_net(ip_device, ps_net);

    /* Figure out what the IP address of my own pseudo-IP network is. */
    if ((ip_fd= open(ip_device, O_RDWR)) < 0) {
	fprintf(stderr, "%s: Can't open %s: %s\n",
	    program, ip_device, strerror(errno));
	exit(1);
    }
    if (ioctl(ip_fd, NWIOGIPCONF, &ipconf) < 0) {
	fprintf(stderr, "%s: Can't obtain the IP address of %s: %s\n",
	    program, ip_device, strerror(errno));
	exit(1);
    }
    my_tip= ipconf.nwic_ipaddr;
    close(ip_fd);
#endif
#if BSD
#endif
    if (debug >= 1) {
	printf("My tunnel endpoint address is %s\n", inet_ntoa(my_tip));
    }

    /* Read and interpret the configuration file. */
    parse_config(configfile);

#if MINIX
    if ((ps_fd[0]= open(ps_device, O_RDWR)) < 0) {
	fprintf(stderr, "%s: Can't open %s: %s\n",
	    program, ps_device, strerror(errno));
	exit(1);
    }

    psipopt.nwpo_flags= NWPO_EN_NEXTHOP;

    if (ioctl(ps_fd[0], NWIOSPSIPOPT, &psipopt) < 0) {
	fprintf(stderr, "%s: %s: %s\n", program, ps_device, strerror(errno));
	exit(1);
    }

    if ((udp_fd[0]= open(udp_device, O_RDWR)) < 0) {
	fprintf(stderr, "%s: Can't open %s: %s\n",
	    program, udp_device, strerror(errno));
	exit(1);
    }

    udpopt.nwuo_flags= NWUO_EXCL | NWUO_EN_LOC | NWUO_DI_BROAD | NWUO_RP_ANY
			| NWUO_RA_ANY | NWUO_RWDATALL | NWUO_DI_IPOPT
			| (myself == master ? NWUO_LP_SET : NWUO_LP_SEL);
    udpopt.nwuo_locport= master->port;

    if (ioctl(udp_fd[0], NWIOSUDPOPT, &udpopt) == -1
	|| ioctl(udp_fd[0], NWIOGUDPOPT, &udpopt) == -1
    ) {
	fprintf(stderr, "%s: %s: %s\n", program, udp_device, strerror(errno));
	exit(1);
    }

    if (myself == master) {
	if (udpopt.nwuo_locaddr != master->cip) {
	    fprintf(stderr, "%s: My address on %s is %s, expected ",
		program, udp_device, inet_ntoa(udpopt.nwuo_locaddr));
	    fprintf(stderr, "%s\n", inet_ntoa(master->cip));
	    exit(1);
	}
    } else {
	myself->cip= udpopt.nwuo_locaddr;
	myself->port= udpopt.nwuo_locport;
    }

    if (debug >= 1) {
	printf("My current open address is %s:%u\n",
	    inet_ntoa(udpopt.nwuo_locaddr), ntohs(udpopt.nwuo_locport));
    }
#endif

    if ((ps_fd[1]= dup(ps_fd[0])) < 0 || (udp_fd[1]= dup(udp_fd[0])) < 0) {
	fprintf(stderr, "%s: Unable to dup() file descriptors: %s\n",
	    program, strerror(errno));
	exit(1);
    }

    onalarm(SIGALRM);	/* Start the pseudo clock. */

    udp_buf= ps_buf= buf= nil;
    asyn_init(&asyn);

    for (;;) {
	if (buf == nil) {
	    /* Reading UDP tunneled packets from the open network. */
	    get_buf(&udp_buf);
	    r= asyn_read(&asyn, udp_fd[0], udp_buf->udp, UDPBUFLEN);

	    if (r >= UDPHDRLEN) {
		peer_t *pr;
		unsigned cmd;

		udp_buf->end= B(udp_buf->udp) + r;
		cmd= *--udp_buf->end;

		/* Who sent it? */
		pr= find_peer(udp_buf->udp->uih_src_addr,
				udp_buf->udp->uih_src_port);

		/* What is it? */
		switch (cmd & OCMD_MASK) {
		case OCMD_IP:
		    /* An encrypted tunneled packet. */
		    r= udp_buf->end - B(udp_buf->ip);
		    r= decode(cmd, B(udp_buf->ip), r, pr);

		    if (r < 0) goto garbage;

		    /* Decoded fine. */
		    udp_buf->end= B(udp_buf->ip) + r;
		    udp_buf->net= UDP;
		    udp_buf->nexthop= (cmd & OCMD_BCAST) ? BROADCAST : my_tip;

		    /* Use the packet if the filters don't object. */
		    if (filter(udp_buf) == FORWARD) give_buf(&buf, &udp_buf);

		    /* He knows me, but do I know him? */
		    if (pr == nil) slowalive= now;

		    /* I can take it easy if the master still knows me. */
		    if (pr == master) fastalive= now + FASTALIVE;
		    break;

		case OCMD_RESYNC:
		case OCMD_RENEW:
		    /* The other side is unhappy with what I sent it. */

		    if (debug >= 1) {
			printf("Got a re%s request from %s:%u\n",
			    cmd == OCMD_RESYNC ? "sync" : "new",
			    inet_ntoa(udp_buf->udp->uih_src_addr),
			    ntohs(udp_buf->udp->uih_src_port));
		    }

		    /* Use full IV with this one for a while. */
		    if (pr != nil) pr->sync_ct= P_NR_SYNC;

		    /* Don't postpone contact with the master. */
		    if (slowalive > fastalive) slowalive= fastalive;

		    /* If the master sends a renew then go get info now. */
		    if (pr == master && cmd == OCMD_RENEW) slowalive= now;
		    break;

		default:
		garbage:
		    /* Oops, we got garbage.  Tell source to resync or renew. */
		    cmd= pr != nil ? OCMD_RESYNC : OCMD_RENEW;

		    if (debug >= 1) {
			printf(
			    "Got garbage, telling %s:%u to re%s\n",
			    inet_ntoa(udp_buf->udp->uih_src_addr),
			    ntohs(udp_buf->udp->uih_src_port),
			    cmd == OCMD_RESYNC ? "sync" : "new");
		    }
		    udp_buf->udp->uih_dst_addr= udp_buf->udp->uih_src_addr;
		    udp_buf->udp->uih_dst_port= udp_buf->udp->uih_src_port;
		    udp_buf->udp->uih_ip_opt_len= 0;
		    udp_buf->udp->uih_data_len= 1;
		    udp_buf->end= udp_buf->buf + UDPHDRLEN + 1;
		    udp_buf->buf[UDPHDRLEN]= cmd;
		    r= udp_buf->end - udp_buf->buf;
		    if (write(udp_fd[1], udp_buf->udp, r) < 0) {
			fprintf(stderr, "%s(%d): %s: %s\n",
			    program, __LINE__, udp_device, strerror(errno));
			sleep(10);
		    }

		    /* Don't postpone contact with the master. */
		    if (slowalive > fastalive) slowalive= fastalive;
		    break;
		}
	    } else
	    if (r != -1 || errno != ASYN_INPROGRESS) {
		fprintf(stderr, "%s(%d): %s: Input error: %s\n",
		    program, __LINE__, udp_device,
		    r == -1 ? strerror(errno) : "Short read");
		sleep(10);
	    }
	}

	if (buf == nil) {
	    /* Reading packets from the PSIP device that I should tunnel. */
	    get_buf(&ps_buf);
	    r= asyn_read(&asyn, ps_fd[0], ps_buf->psip, PSIPHDRLEN + IPBUFLEN);

	    if (r >= PSIPHDRLEN + IPHDRLEN) {
		ps_buf->end= B(ps_buf->psip) + r;
		ps_buf->net= PSIP;
		ps_buf->nexthop= *ps_buf->psip;

		/* Use the packet if the filters don't object. */
		if (filter(ps_buf) == FORWARD) give_buf(&buf, &ps_buf);
	    } else
	    if (r != -1 || errno != ASYN_INPROGRESS) {
		fprintf(stderr, "%s(%d): %s: Input error: %s\n",
		    program, __LINE__, ps_device,
		    r == -1 ? strerror(errno) : "Short read");
		sleep(10);
	    }
	}

	if (buf == nil && (slowalive <= now || fastalive <= now)) {
	    if (myself == master) {
		/* I'm the master, I don't have to tell me that I'm alive. */
		slowalive= fastalive= NEVER;
	    } else {
		/* Time to send a keepalive packet. */
		u32_t n4;

		if (ioctl(udp_fd[1], NWIOGUDPOPT, &udpopt) == -1) {
		    fprintf(stderr, "%s(%d): %s: %s\n", program, __LINE__,
			udp_device, strerror(errno));
		    exit(1);
		}
		if (udpopt.nwuo_locaddr != myself->cip) {
		    /* My address went and changed on me! */
		    if (debug >= 1) {
			printf("My current open address changed to %s:%u\n",
			    inet_ntoa(udpopt.nwuo_locaddr),
			    ntohs(udpopt.nwuo_locport));
		    }
		    myself->cip= udpopt.nwuo_locaddr;
		}
		slowalive= fastalive= now + FASTALIVE;

		get_buf(&buf);
		buf->net= AIR;	/* (Pulled out of thin air) */
		buf->nexthop= master->tip;

		/* Setting most of the IP header to zeros invalidates it as a
		 * packet any TCP/IP stack could have produced.  We test for
		 * a zero first byte to recognize them as tunnel commands.
		 */
		memset(buf->ip, 0, sizeof(*buf->ip));
		buf->ip->ih_src= my_tip;
		buf->ip->ih_dst= master->tip;
		buf->data[0]= TCMD_ALIVE;
		n4= htonl(info);	/* Include time of last info. */
		memcpy(buf->data+1, &n4, 4);
		buf->end= buf->data + 1 + 4;
		if (++nr_alives == NR_DEAD) {
		    fprintf(stderr, "%s lost contact with ",
			inet_ntoa(my_tip));
		    fprintf(stderr, "%s on %lu\n",
			inet_ntoa(master->tip),
			(unsigned long) (now - (NR_DEAD-1) * FASTALIVE));
		}
	    }
	}

	if (buf != nil) {
	    /* A new packet has come in, what do we do with it? */
	    peer_t *pr;

	    if (debug >= 3) {
		switch (buf->net) {
		case UDP:
		    printf("%s:%u: ",
			inet_ntoa(buf->udp->uih_src_addr),
			ntohs(buf->udp->uih_src_port));
		    break;
		case PSIP:
		    printf("%s: ", inet_ntoa(my_tip));
		    break;
		case AIR:
		    printf("[tunnel]: ");
		    break;
		}
		printf("%s -> ", inet_ntoa(buf->ip->ih_src));
		printf("%s (%d), forward to ",
		    inet_ntoa(buf->ip->ih_dst), (int) (buf->end - B(buf->ip)));
		printf("%s\n", inet_ntoa(buf->nexthop));
	    }

	    if (buf->net == UDP && buf->ip->ih_vers_ihl == 0) {
		/* First byte is zero: A tunnel command for me. */
		peer_t *tpr;
		u16_t n2;
		u32_t n4;
		time_t lastinfo;
		u8_t *bp;

		if (debug >= 3) {
		    printf("\tIn-tunnel command %02X\n", buf->data[0]);
		}

		switch (buf->data[0]) {
		case TCMD_ALIVE: {
		    int changed;

		    /* The sender wants us to know its alive. */
		    if (myself != master) goto strange;

		    /* In our table? */
		    if ((tpr= find_peer(buf->ip->ih_src, 0)) == nil) {
			/* No, create a new entry. */
			tpr= new_peer();
			tpr->tip= buf->ip->ih_src;
		    }

		    /* Newly introduced or reintroduced? */
		    if (tpr->expire <= now) tpr->intro= now;

		    /* Record the sender's current open address. */
		    changed= (buf->udp->uih_src_addr != tpr->cip);
		    tpr->cip= buf->udp->uih_src_addr;
		    tpr->port= buf->udp->uih_src_port;
		    tpr->expire= now + EXPIRE;

		    /* When did the sender receive info? */
		    memcpy(&n4, buf->data+1, 4);
		    lastinfo= ntohl(n4);

		    if (changed || debug >= 1) {
			printf("%s is alive at ", inet_ntoa(tpr->tip));
			printf("%s:%u since %lu\n",
			    inet_ntoa(tpr->cip), ntohs(tpr->port),
			    (unsigned long) lastinfo);
		    }

		    /* Create an info packet naming all endpoints. */
		    buf->net= AIR;
		    buf->nexthop= tpr->tip;
		    memset(buf->ip, 0, sizeof(*buf->ip));
		    buf->ip->ih_src= my_tip;
		    buf->ip->ih_dst= tpr->tip;
		    buf->data[0]= TCMD_INFO;
		    n4= htonl(now);
		    memcpy(buf->data+1, &n4, 4);
		    bp= buf->data + 1 + 4;
		    for (pr= peer_table; pr != nil; pr= pr->next) {
			if (pr->expire <= now) continue;

			memcpy(bp, &pr->tip, 4);
			bp += 4;
			memcpy(bp, &pr->cip, 4);
			bp += 4;
			memcpy(bp, &pr->port, 2);
			bp += 2;

			n2= htons(pr->expire == NEVER ?
					0xFFFFU : pr->expire - now);
			memcpy(bp, &n2, 2);
			bp += 2;

			if (lastinfo > pr->intro) {
			    *bp++ = 0;
			} else {
			    *bp++ = sizeof(pr->key);
			    memcpy(bp, pr->key, sizeof(pr->key));
			    bp += sizeof(pr->key);
			}
		    }
		    buf->end= bp;
		    break; }

		case TCMD_INFO:
		    /* We get information about the tunnel endpoints. */
		    if (myself == master) goto strange;

		    if (nr_alives >= NR_DEAD) {
			fprintf(stderr, "%s regained contact ",
			    inet_ntoa(my_tip));
			fprintf(stderr, "with %s on %lu\n",
			    inet_ntoa(master->tip),
			    (unsigned long) now);
		    }
		    nr_alives= 0;

		    /* The master's timestamp is? */
		    memcpy(&n4, buf->data+1, 4);
		    info= ntohl(n4);

		    bp= buf->data + 1 + 4;
		    while (bp < buf->end) {
			memcpy(&n4, bp, 4);
			bp += 4;

			/* Do we know this endpoint? */
			if ((tpr= find_peer(n4, 0)) == nil) {
			    /* No, create a new entry. */
			    tpr= new_peer();
			    tpr->tip= n4;
			}

			/* Address and port of the endpoint.  Be careful not
			 * to replace my own, because the master may see quite
			 * different addresses thanks to the wonder that is
			 * Network Address Translation.
			 */
			if (tpr != myself) memcpy(&tpr->cip, bp, 4);
			bp += 4;
			if (tpr != myself) memcpy(&tpr->port, bp, 2);
			bp += 2;

			memcpy(&n2, bp, 2);
			bp += 2;
			n2= ntohs(n2);
			tpr->expire= n2 == 0xFFFFU ? NEVER : now + n2;

			if (*bp++ != 0) {
			    memcpy(tpr->key, bp, sizeof(tpr->key));
			    bp += sizeof(tpr->key);
			    rijndael_makekey(&tpr->crypto.keyinst,
				sizeof(tpr->key), tpr->key);
			    memcpy(tpr->crypto.sIV, passkey.sIV,
				sizeof(tpr->crypto.sIV));
			    tpr->sync_ct= P_NR_SYNC;
			}
			if (debug >= 1) {
			    printf("%s is found at ", inet_ntoa(tpr->tip));
			    printf("%s:%u until ",
				inet_ntoa(tpr->cip), ntohs(tpr->port));
			    printf(tpr->expire == NEVER ? "forever\n" : "%lu\n",
				(unsigned long) tpr->expire);
			}
		    }
		    put_buf(&buf);
		    slowalive= now + SLOWALIVE;
		    break;

		default:
		strange:
		    fprintf(stderr, "Strange tunnel command %02X from %s\n",
			buf->data[0], inet_ntoa(buf->ip->ih_src));
		    put_buf(&buf);
		}
	    } else
	    if (buf->net == UDP) {
		/* Deliver to the networks behind me. */

		*buf->psip= buf->nexthop;
		r= write(ps_fd[1], buf->psip, buf->end - B(buf->psip));
		if (r < 0) {
		    fprintf(stderr, "%s(%d): %s: %s\n",
			program, __LINE__, ps_device, strerror(errno));
		    sleep(10);
		} else
		if (debug >= 3) {
		    printf("\tDelivered at %s\n", inet_ntoa(my_tip));
		}
		put_buf(&buf);
	    } else
	    if (isbroadcast(buf->nexthop)) {
		/* A broadcast packet must be sent to all peers I know. */
		buf_t *tmp_buf= nil;

		get_buf(&tmp_buf);
		for (pr= peer_table; pr != nil; pr= pr->next) {
		    if (pr == myself) continue;		/* All but myself. */

		    r= buf->end - B(buf->ip);
		    memcpy(tmp_buf->ip, buf->ip, r);
		    r= encode(OCMD_IP | OCMD_BCAST, B(tmp_buf->ip), r, pr);
		    if (r < 0) continue;

		    tmp_buf->end= B(tmp_buf->ip) + r;
		    tmp_buf->udp->uih_src_addr= myself->cip;
		    tmp_buf->udp->uih_src_port= myself->port;
		    tmp_buf->udp->uih_dst_addr= pr->cip;
		    tmp_buf->udp->uih_dst_port= pr->port;
		    tmp_buf->udp->uih_ip_opt_len= 0;
		    tmp_buf->udp->uih_data_len= r;
		    r= write(udp_fd[1], tmp_buf->udp,
					tmp_buf->end - B(tmp_buf->udp));
		    if (r < 0) {
			fprintf(stderr, "%s(%d): %s: %s\n",
			    program, __LINE__, udp_device, strerror(errno));
			sleep(10);
		    } else
		    if (debug >= 3) {
			printf("\tSent to %s:%u\n",
			    inet_ntoa(pr->cip), ntohs(pr->port));
		    }
		}
		put_buf(&tmp_buf);
		put_buf(&buf);
	    } else
	    if ((pr= find_peer(buf->nexthop, 0)) != nil) {
		/* The packet is for a particular endpoint.  Send it yonder. */

		r= buf->end - B(buf->ip);
		r= encode(OCMD_IP, B(buf->ip), r, pr);
		if (r < 0) goto discard;

		buf->end= B(buf->ip) + r;
		buf->udp->uih_src_addr= myself->cip;
		buf->udp->uih_src_port= myself->port;
		buf->udp->uih_dst_addr= pr->cip;
		buf->udp->uih_dst_port= pr->port;
		buf->udp->uih_ip_opt_len= 0;
		buf->udp->uih_data_len= r;
		r= write(udp_fd[1], buf->udp, buf->end - B(buf->udp));
		if (r < 0) {
		    fprintf(stderr, "%s(%d): %s: %s\n",
			program, __LINE__, udp_device, strerror(errno));
		    sleep(10);
		} else {
		    if (debug >= 3) {
			printf("\tSent to %s:%u\n",
			    inet_ntoa(pr->cip), ntohs(pr->port));
		    }
		}
		put_buf(&buf);
	    } else {
	    discard:
		/* No-one to send it to.  Discard. */
		if (debug >= 3) printf("\tDiscarded\n");
		put_buf(&buf);
	    }
	}

	if (debug >= 1) {
	    static char *lastbrk;
	    extern char end;

	    if (sbrk(0) != lastbrk) {
		lastbrk= sbrk(0);
		printf("Memory use = %lu\n", (unsigned long) (lastbrk - &end));
	    }
	    fflush(stdout);
	}

	if (buf == nil) {
	    /* Wait for I/O. */
	    if (asyn_wait(&asyn, 0, nil) < 0) {
		if (errno != EINTR) {
		    fprintf(stderr, "%s: fwait(): %s\n",
			program, strerror(errno));
		    exit(1);
		}
	    }
	}
    }
    return 0;
}

/*
 * $PchId: rijntunnel.c,v 1.7 2002/10/15 09:36:42 philip Exp $
 */

/*
 * This code implements the MD5 message-digest algorithm.
 * The algorithm is due to Ron Rivest.  This code was
 * written by Colin Plumb in 1993, no copyright is claimed.
 * This code is in the public domain; do with it what you wish.
 *
 * Equivalent code is available from RSA Data Security, Inc.
 * This code has been tested against that, and is equivalent,
 * except that you don't need to include two pages of legalese
 * with every copy.
 *
 * To compute the message digest of a chunk of bytes, declare an
 * MD5Context structure, pass it to MD5Init, call MD5Update as
 * needed on buffers full of bytes, and then call MD5Final, which
 * will fill a supplied 16-byte array with the digest.
 */
#ifndef _CRYPTO__MD5_H
#define _CRYPTO__MD5_H

#include <inttypes.h>

typedef struct MD5Context {
	uint32_t buf[4];
	uint32_t bits[2];
	unsigned char in[64];
} MD5_CTX;

void MD5Init(struct MD5Context *_ctx);
void MD5Update(struct MD5Context *_ctx, void const *_buf, uint32_t _len);
void MD5Final(void *_digest, struct MD5Context *_ctx);

#endif /* _CRYPTO__MD5_H */

/*
 * $PchId: md5.h,v 1.2 2001/01/08 21:43:29 philip Exp $
 */

/*	gentypes - Generate word types of given sizes.	Author: Kees J. Bot
 *								3 Nov 2000
 */

#define nil ((void*)0)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Table of unsigned types and their sizes. */
static struct type {
	char	*name;
	int	size;
} inttype[] = {
  {	"unsigned char",	sizeof(char)	},
  {	"unsigned short",	sizeof(short)	},
  {	"unsigned",		sizeof(int)	},
  {	"unsigned long",	sizeof(long)	},
};

static char *wordof(int size)
{
    /* Return the name of a type of a certain size. */
    int i;

    for (i= 0; i < sizeof(inttype)/sizeof(inttype[0]); i++) {
	if (inttype[i].size == size) return inttype[i].name;
    }
    fprintf(stderr, "gentypes: There is no type that is %d bytes large\n",
	size);
    exit(1);
}

int main(void)
{
    /* One requirement for the machine. */
    if ((unsigned char) -1 != 0xFF) {
	fprintf(stderr, "Bytes must be exactly 8 bits\n");
	exit(1);
    }

    /* Emit definitions for the word types. */
    printf("typedef %s byte;\n", wordof(1));
    printf("typedef %s word8;\n", wordof(1));
    printf("typedef %s word16;\n", wordof(2));
    printf("typedef %s word32;\n", wordof(4));

#ifndef STRICT_ALIGN
    /* Strict alignment is required on all but the 386 (if not Minix). */
#if __i386 && !__minix
    printf("#define STRICT_ALIGN 0\n");
#else
    printf("#define STRICT_ALIGN 1\n");
#endif
#endif
    return 0;
}

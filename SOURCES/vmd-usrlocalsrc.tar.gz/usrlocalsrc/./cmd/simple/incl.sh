#!/bin/sh

set -z		# Failed wildcard expansion gives zero files.

f="$1"

if [ -f /usr/include/"$f" ]
then
	set -- /usr/include/"$f" /usr/include/*/"$f"
else
	set -- /usr/include/*/"$f"
fi

case $# in
0)	echo "incl: $f: no such include file" >&2
	exit 1
esac

exec ${PAGER-more} "$@"

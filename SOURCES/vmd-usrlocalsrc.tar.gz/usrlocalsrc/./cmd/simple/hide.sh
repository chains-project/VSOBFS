#!/bin/sh
#
# hide 1.1 - Put a file in a hidden directory.
#

flag="$1"

case $#:$flag in
*:-p)	mode=4000	shift ;;
*:-k)	mode=4001	shift ;;
*:-m)	mode=4002	shift ;;
*:-h)	mode=4003	shift ;;
*:-n)	mode=4004	shift ;;
*:-r)	mode=4005	shift ;;
*:-v)	mode=4006	shift ;;
*:-s)	mode=4007	shift ;;
*:-b)	mode=4010	shift ;;
0:*|*:-*)		flag=	;;
*:*)	mode=4000	flag=-p ;;
esac

case $#:$flag in
*:|0:*)		echo >&2 "Usage:
hide -p file ...	# Hide by achitecture (i86/i386/m68000)
hide -k file ...	# Hide by kernel (i86/i386/m68000)
hide -m file ...	# Hide by machine (i86/i286/i486/m68000/m68030)
hide -h file ...	# Hide by hostname
hide -n file ...	# Hide by nodename
hide -r file ...	# Hide by release
hide -v file ...	# Hide by version
hide -s file ...	# Hide by system name"
hide -b file ...	# Hide by bus architecture (ibm/mac/sun)"
	exit 1
esac

for f
do
	if [ -f "$f.$$" ]; then echo "File "$f.$$" exists?" >&2; exit 1; fi

	if mv "$f" "$f.$$" && mkdir "$f" && chmod $mode "$f" && mv "$f.$$" "$f"
	then
		echo "$f hidden for all but '`arch $flag`'"
	else
		if [ -f "$f.$$" ]; then
			if [ -d "$f@" ]; then rmdir "$f@"; fi
			mv "$f.$$" "$f"
		fi
		exit 1
	fi
done

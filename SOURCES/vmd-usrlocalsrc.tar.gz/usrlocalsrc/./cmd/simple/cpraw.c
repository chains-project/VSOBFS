/*	cpraw 1.2 - Copy/rescue data using raw devices.
 *							Author: Kees J. Bot
 *								11 Jan 1993
 */
#define nil 0
#define _POSIX_SOURCE	1
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/stat.h>
#include <minix/u64.h>

#define DEFAULT_BUFSIZE	(128*1024)

#define SECTOR_SIZE	512

typedef enum direction { READ, WRITE } dir_t;
static char *direction[]= { "read", "write" };

static ssize_t bufio(int fd, char *file, dir_t dir,
					u64_t *pos, char *buf, ssize_t n)
/* Read or write n bytes from/to position *pos to/from buf[]. */
{
    ssize_t r, got= 0, try= n, want= n;
    int know_pos= 1;

    for (;;) {
	if (!know_pos && fcntl(fd, F_SEEK, *pos) < 0) {
	    fprintf(stderr, "cpraw: %s: %s seek failed: %s\n",
		file, direction[dir], strerror(errno));
	    exit(1);
	}
	know_pos= 1;

	if (got == n) break;	/* All transferred. */

	/* Try to read or write. */
	if (dir == READ) {
	    r= read(fd, buf, try);
	} else {
	    r= write(fd, buf, try);
	}

	if (r <= 0) {
	    if (r == 0) {
		/* EOF */
		if (dir == WRITE) {
		    fprintf(stderr, "cpraw: %s: EOF on write\n", file);
		}
		break;
	    }

	    if (errno != EIO) {
		fprintf(stderr, "cpraw: %s: %s failed: %s\n",
		    file, direction[dir], strerror(errno));
		exit(1);
	    }

	    if (try <= SECTOR_SIZE) {
		/* Single sector I/O failed, skip sector. */
		fprintf(stderr, "cpraw: %s: bad %s sector: %4lu (%luK)\n",
		    file, direction[dir],
		    div64u(*pos, SECTOR_SIZE),
		    div64u(*pos, 1024));

		if (dir == READ) memset(buf, 0, try);

		r= try;
	    } else {
		r= 0;
	    }

	    know_pos= 0;	/* Need to seek. */
	}
	*pos= add64u(*pos, r);
	buf+= r;
	got+= r;
	want-= r;
	try= want < SECTOR_SIZE ? want : SECTOR_SIZE;
    }
    return got;
}

static int spec_open(const char *file, int flags)
/* Open a file unless it is a block special, for which we try to create and
 * open a char special.
 */
{
    struct stat st;
    char *tmp;
    int fd;

    if (geteuid() != 0 || stat(file, &st) < 0 || !S_ISBLK(st.st_mode)) {
	/* Normal open. */

	if ((fd= open(file, flags, 0666)) < 0) {
	    fprintf(stderr, "cpraw: %s: %s\n", file, strerror(errno));
	    exit(1);
	}
	return fd;
    }

    /* It's a block special, try to make an alike char special. */
    tmp= tmpnam(nil);

    if (mknod(tmp, S_IFCHR | 0600, st.st_rdev) < 0) {
	fprintf(stderr, "cpraw: making a char special: %s\n",
	    strerror(errno));
	exit(1);
    }

    if ((fd= open(tmp, flags)) < 0) {
	fprintf(stderr, "cpraw: opening a char special: %s\n",
	    strerror(errno));
	(void) unlink(tmp);
	exit(1);
    }
    (void) unlink(tmp);

    return fd;
}

static unsigned long strtosize(char *str)
{
    unsigned long s, m;
    char *end;

    s= strtoul(str, &end, 10);
    if (end == str) {
	fprintf(stderr, "cpraw: '%s' is not a number\n", str);
	exit(1);
    }
    m= 1;
    switch (*end) {
    case 'g':	case 'G':	m *= 1024;
    case 'm':	case 'M':	m *= 1024;
    case 'k':	case 'K':	m *=    2;
    case 'b':	case 'B':	m *=  512;
	end++;
	break;
    }
    if (*end != 0) {
	fprintf(stderr, "cpraw: '%s' should not be followed by '%s'\n",
	    str, end);
	exit(1);
    }
    if ((s * m) / m != s) {
	fprintf(stderr, "cpraw: '%s' is too large\n", str);
	exit(1);
    }
    return s * m;
}

static void usage(void)
{
    fprintf(stderr,
	"Usage: cpraw [-s bufsize[kmg]] [-t throughput[kmg]] infile outfile\n"
	"       Either file may be \"-\"\n"
    );
    exit(1);
}

int main(int argc, char **argv)
{
    int i;
    ssize_t n;
    int ifd, ofd;
    off_t tpos;
    u64_t ipos, opos;
    char *infile, *outfile;
    char *buf;
    size_t buf_size;
    unsigned long thruput;
    u64_t total;
    time_t t0;
    struct timeval tv;

    buf_size= DEFAULT_BUFSIZE;
    thruput= 0;

    i= 1;
    while (i < argc && argv[i][0] == '-') {
	char *opt= argv[i++]+1;
	unsigned long s;

	if (opt[0] == '-' && opt[1] == 0) break;
	while (*opt != 0) switch (*opt++) {
	case 's':
	    if (*opt == 0) {
		if (i == argc) usage();
		opt= argv[i++];
	    }
	    s= strtosize(opt);
	    if ((buf_size= s) != s || buf_size == 0) {
		fprintf(stderr, "cpraw: Can't handle size '%s'\n", opt);
		exit(1);
	    }
	    opt= "";
	    break;
	case 't':
	    if (*opt == 0) {
		if (i == argc) usage();
		opt= argv[i++];
	    }
	    thruput= strtosize(opt);
	    if (thruput == 0) {
		fprintf(stderr, "cpraw: Can't handle throughput '%s'\n", opt);
		exit(1);
	    }
	    opt= "";
	    break;
	default:
	    usage();
	}
    }

    if ((argc - i) != 2) usage();
    infile= argv[i++];
    outfile= argv[i++];

    if ((buf= malloc(buf_size)) == nil) {
	fprintf(stderr, "cpraw: Can't obtain %lu bytes of memory\n",
	    (unsigned long) buf_size);
	exit(1);
    }

    if (geteuid() != 0) {
	fprintf(stderr, "(You need to be root to work at the sector level)\n");
    }

    ifd= strcmp(infile, "-") == 0 ? 0 : spec_open(infile, O_RDONLY);
    ofd= strcmp(outfile, "-") == 0 ? 1 :
			spec_open(outfile, O_WRONLY | O_CREAT | O_TRUNC);

    if ((tpos= lseek(ifd, 0L, SEEK_CUR)) < 0) tpos= 0;
    ipos= cvul64(tpos);

    if ((tpos= lseek(ofd, 0L, SEEK_CUR)) < 0) tpos= 0;
    opos= cvul64(tpos);

    t0= time(nil);	/* Start time. */
    total= cvu64(0);	/* Total transferred. */

    while ((n= bufio(ifd, infile, READ, &ipos, buf, buf_size)) > 0) {
	(void) bufio(ofd, outfile, WRITE, &opos, buf, n);

	if (thruput != 0) {
	    total= add64ul(total, n);

	    /* Expected to reach total after (total / thruput) seconds. */
	    tv.tv_sec= div64u(total, thruput);
	    tv.tv_usec= div64u(mul64u(rem64u(total,thruput),1000000),thruput);

	    tv.tv_sec += t0;
	    u_sleep(&tv);
	}
    }
    exit(0);
}

#!/usr/bin/perl -w
#
#	showdbm 1.0 - Show the contents of a DBM database
#							Author: Kees J. Bot
#								3 Mar 2003

sub usage
{
    die "Usage: $0 dbm-database ...\n";
}

sub q
{
    foreach (@_) {
	s/[\000-\037]/sprintf("\\%03o", ord($&))/eg;
    }
    wantarray ? @_ : $_[0];
}

while (@ARGV > 0 && $ARGV[0] =~ /^-/) {
    local($opt) = shift(@ARGV);

    last if $opt eq '--';
    next if $opt eq '-';
    &usage;
}

&usage unless @ARGV > 0;

foreach $dbm (@ARGV) {
    -f "$dbm.pag" || die "$0: $dbm: $!\n";

    dbmopen(%dbm, $dbm, 0644) || die "$0: $dbm: $!\n";

    while (($key, $val) = each(%dbm)) {
	print '"', &q($key), '" -> "', &q($val), "\"\n";
    }

    dbmclose(%dbm);
}
exit(0);

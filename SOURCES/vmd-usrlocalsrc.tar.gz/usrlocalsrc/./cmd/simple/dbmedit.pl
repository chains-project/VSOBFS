#!/usr/bin/perl -w
#
#	dbmedit 1.0 - Edit an entry in a DBM database
#							Author: Kees J. Bot
#								25 Mov 2004

sub usage
{
    die "Usage: $0 dbm-database entry\n";
}

while (@ARGV > 0 && $ARGV[0] =~ /^-/) {
    local($opt) = shift(@ARGV);

    last if $opt eq '--';
    next if $opt eq '-';
    &usage;
}

&usage unless @ARGV == 2;

($dbm, $key) = @ARGV;

if (-f "$dbm.pag") {
    dbmopen(%dbm, $dbm, 0644) || die "$0: $dbm: $!\n";
    $value = $dbm{$key};
    dbmclose(%dbm);
}
$value = '' unless defined($value);
$oldvalue = $value;

$tmpfile = sprintf("/tmp/dbmedit.%d.$$", time());

open(EDIT, ">$tmpfile") || die "$0: $tmpfile: $!\n";
print EDIT $value;
close(EDIT);

system("\${EDITOR-vi} '$tmpfile'");

open(EDIT, "<$tmpfile") || die "$0: $tmpfile: $!\n";
$value = '';
while (<EDIT>) { $value .= $_; }
close(EDIT);
unlink($tmpfile);

unless ($value eq $oldvalue) {
    dbmopen(%dbm, $dbm, 0644) || die "$0: $dbm: $!\n";
    $dbm{$key} = $value;
    dbmclose(%dbm);
}
exit(0);

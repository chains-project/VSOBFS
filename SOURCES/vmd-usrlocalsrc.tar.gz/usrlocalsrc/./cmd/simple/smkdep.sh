#!/bin/sh

for i
do
	obj="$(expr "$i" : '\(.*\.\)[^.]*')o"

	case "$obj" in
	???????*)	echo -n "$obj:	"
		;;
	*)		echo -n "$obj:		"
	esac

	echo $(
		sed -e '/^#include[ 	]*"/!d
			s/[^"]*"//
			s/".*//'  "$i" | \
		sort
	)
done

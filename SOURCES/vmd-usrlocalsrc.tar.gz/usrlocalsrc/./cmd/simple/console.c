/*	console 1.0 - Minix console multiplexing	Author: Kees J. Bot
 *								18 Feb 1996
 */
#define nil 0
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <string.h>
#include <errno.h>

#define arraysize(a)	(sizeof(a) / sizeof((a)[0]))
#define arraylimit(a)	((a) + arraysize(a))

static struct termios term_attr_save, term_attr_raw;
static int term_attr_israw;
static void term_restore(void);

static void report(const char *label)
{
	fprintf(stderr, "console: %s: %s%s\n", label, strerror(errno),
						term_israw ? "\r" : "");
}

static void fatal(const char *label)
{
	int err= errno;
	if (term_attr_israw) term_restore();
	errno= err;
	report(label);
	exit(1);
}

static void term_save(void)
/* Save the current terminal attributes and compute the RAW parameters. */
{
	if (tcgetattr(0, &term_attr_save) < 0) fatal("input is not a terminal");
	term_attr_raw= term_attr_save;
	term_attr_raw.c_iflag&= ~(ICRNL|IGNCR|INLCR|IXON|IXOFF);
	term_attr_raw.c_oflag&= ~(OPOST);
	term_attr_raw.c_lflag&= ~(ECHO|ECHONL|ICANON|ISIG);
	term_attr_raw.c_cc[VMIN]= 0;
}

static void term_raw(int time)
/* Set the terminal to raw mode with a 'time' decisecond input timeout. */
{
	term_attr_raw.c_cc[VTIME]= time;
	(void) tcsetattr(0, TCSANOW, &term_attr_raw);
	term_attr_israw= 1;
}

static void term_restore(void)
/* Restore the terminal attributes. */
{
	(void) tcsetattr(0, TCSANOW, &term_attr_save);
	term_attr_israw= 0;
}

typedef struct tty {
	int	pty_fd;
	char	tty_name[sizeof("/dev/ttyp0")];
	pid_t	pid;
} tty_t;

#define tty_active(ttp)	((ttp)->pty_fd != -1)
#define tty_free(ttp)	((void) ((ttp)->pty_fd= -1))

static tty_t tty_list[10];
static int tty_current;
static int tty_count;

static void tty_tell(void) {}

static void tty_setup(void)
{
	tty_t **ttpp, *ttp;
	static char pty_name[]= "/dev/ptyp0";
	int p, i;

	if (tty_count == 0) {
		for (ttp= tty_list; ttp < arraylimit(tty_list); ttp++) {
			tty_free(ttp);
		}
	}

	for (p= 'p'; p < 'p'+8; p++) {
		for (i= 0; i < 0x10; i++) {
			pty_name[8]= p;
			pty_name[9]= i < 0xa ? '0' + i : 'a' + i - 10;
			ttp->pty_fd= open(pty_name, O_RDWR);
			if (ttp->pty_fd != -1) goto got_pty;
		}
	}
	tty_tell("Out of ptys");
	free(ttp);
	return;
got_pty:
	strcpy(ttp->tty_name, pty_name);
	ttp->tty_name[5]= 't';

	if (
}

static void console_in()
/* Read one user input character. */
{
	unsigned char c;

	switch (read(0, &c, 1)) {
	case -1:
		fatal("input error");
	case 0:
		break;
	case 1:
		pty_out(current, c);
	}
}

int main(void)
{
	tty_t *ttp, *next;

	term_save();
	term_raw(1);
	tty_setup();

	while (tty_count > 0) {
		console_in();
		for (ttp= tty_list; ttp != nil; ttp= next) {
			next= ttp->next;
			pty_in(i);
		}
	}
	term_restore();
	exit(0);
}

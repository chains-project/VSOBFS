#!/bin/sh
#
#	going 1.0 - keep the disk going			Author: Kees J. Bot
#								27 Jun 1996
# A dump script to keep the disk from spinning down.  I should
# invent an ioctl to set parameters like the idle timeout.  A "putenv"
# ioctl might be fun.

while :;
do
	echo >/usr/tmp/.going
	rm /usr/tmp/.going
	sleep 240
done

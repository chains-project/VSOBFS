#!/usr/bin/perl
#
#	unpartition 1.0 - show how disks are partitioned
#							Author: Kees J. Bot
#								24 Feb 1997

sub little
# Transform a list of bytes into a little endian number.
{
	local($num, $n) = (0, 0);

	while (@_) {
		$num |= shift << $n;
		$n += 8;
	}
	$num;
}

sub readpart
# Read the partition table of a device and decode it.
{
	local($device) = shift;
	local($boot, $code, $table, @sig, @code, $fix, @part);

	open(DEV, $device) || return ();

	read(DEV, $boot, 512) == 512 || return ();

	($code, $table, @sig) = unpack('a446 a64 CC', $boot);

	return () unless &little(@sig[0..1]) == 0xAA55;

	@code = unpack('CCCCC', $code);

	$fix = '0';
	$fix = sprintf("%d", $code[2])
		if $code[0] == 0xEB
		&& $code[1] == 0x01
		&& $code[2] < 40
		&& $code[3] == 0x31;
	$fix = sprintf("%d%c", $code[2], $code[3] - 1 + ord('a'))
		if $code[0] == 0xEB
		&& $code[1] == 0x02
		&& $code[2] < 40
		&& 1 <= $code[3] && $code[3] <= 4
		&& $code[4] == 0x31;

	@part = ($fix);
	until ($table eq '') {
		@entry = unpack('C16', $table);
		$table = substr($table, 16);
		@part = (@part, $entry[0], $entry[4],
				&little(@entry[8..11]),
				&little(@entry[12..15]));
	}
	@part;
}

sub makepart
# Print commands that remake a partition table.
{
	local($device, $offset, $fix, @part) = @_;

	if ($fix eq '0') {
		print "installboot -m $device /usr/mdec/masterboot\n";
	}
	elsif (length($fix) == 1) {
		print "installboot -m $fix $device /usr/mdec/masterboot\n";
	}
	elsif (length($fix) == 2) {
		print "installboot -m $fix $device /usr/mdec/extboot\n";
	} else {
		die;
	}
	print "partition -m $device";
	while (@part) {
		if ($part[1] == 0) {
			print ' 0:0';
		} else {
			print ' ', $part[2] - $offset if $offset != $part[2];
			print ' ', sprintf('%02x', $part[1]), ':', $part[3];
			print '*' if $part[0] != 0;
			$offset = $part[2] + $part[3];
		}
		@part = @part[4..$#part];
	}
	print "\nrepartition $device\n";
}

sub fstab
# Gather interesting devices from /etc/fstab.
{
	local(%disks, $n);

	open(FSTAB, '/etc/fstab') || die "$0: /etc/fstab: $!\n";
	%disks = ();
	while (<FSTAB>) {
		s/^#.*//;
		s/\s+#.*//;
		split;
		next unless $_[0] =~ m#^/dev/(sd|hd|dosd)(\d+)([a-d]?)$#;

		$n = $2 - $2 % 5;
		$disks{"/dev/$1$n"} = 1;
	}
	close(FSTAB);
	sort(keys(%disks));
}

# Make a list of devices and partition info.
@allpart = ();
foreach $disk (&fstab) {
	(@part = &readpart($disk)) || next;
	@allpart = (@allpart, $disk, 0, @part);
	for ($i = 0; $i < 4; $i++) {
		next unless $part[1 + 4*$i + 1] == 0x81;
		($primary = $disk) =~ s/(\d+)$/$1 + 1 + $i/e;;
		(@subpart = &readpart($primary)) || next;
		@allpart = (@allpart, $primary, $part[1 + 4*$i + 2], @subpart);
	}
}

# Show how the disk partitions could be recreated.
while (@allpart) {
	&makepart(@allpart[0..18]);
	@allpart = @allpart[19..$#allpart];
}

#!/bin/sh
#
#	80/132 - switch to 80 or 132 column mode	Author: Kees J. Bot
#								11 Apr 1996

case "$0:$#" in
*/80:0)
	echo -e '\033[?3l\c'
	;;
*/132:0)
	echo -e '\033[?3h\c'
	;;
*)	echo "Usage: 80/132" >&2
	exit 1
esac

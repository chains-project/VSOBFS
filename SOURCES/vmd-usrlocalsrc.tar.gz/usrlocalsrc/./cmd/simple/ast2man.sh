#!/bin/sh
#
# ast2man - Transform Andy's manual pages to man(7)	Author: Kees J. Bot
#
# Transformation:
#	.TH <name_of_page> 1
#	.SH NAME
#	<Arguments of .CD>
#	.SH SYNOPSIS
#	<Arguments of .SX>
#	<New definitions of .FL and .SX>
#	.SH OPTIONS
#	.FL ...
#	.SH EXAMPLES
#	.SX ...		(.SY to .SX)
#	.SH DESCRIPTION
#	<The rest of the page>
#
# Some macros and strings are substituted by:
#	\(en			\-		(Oops, don't tell Andy.)
#	\s \f					(NAME section only.)
#	~			<space>
#	\*(OQ  \*(CQ  \*(SQ	\&'
#	\*(M0			MINIX
#	\*(M1			\s-1MINIX\s+1
#	\*(M2			\s-2MINIX\s+2
#	\*(M9			\s-1MINIX\s+1
#	\*(m0			minix
#	\*(Mx			\s-1MINIX\s0
#	\*(Mp			\s-1MINIX-PC\s0
#	\*(Ms			\s-1MINIX-ST\s0
#	.MX			\s-2MINIX\s+2
#	.Cx			.B "<tab>"
#	.DI			.B
#	.HS			.PP
#	.SY			\&
#	.Ux			\s-2UNIX\s+2
#	.UX			\s-2UNIX\s+2
#	.UU			.SS

case $# in
1)	;;
*)	echo "Usage: ast2man manual_page" >&2
esac

# Make a manual page.
echo ".TH `basename $1` 1
.SH NAME" | tr '[a-z]' '[A-Z]'

# Transform the command macro.
sed -e '
	/^\.CD /!d
	s/\\(en/\\-/g
	s/~/ /g
	s/\\\*([OCS]Q/\\\&'\''/g
	s/\\\*(M2/MINIX/g
	s/^\.CD "*//
	s/"* *$//
	s/\\s0//g
	s/\\s[-+][0-9]//g
	s/\\f[RBIP]//g
' $1

# The syntax.
echo ".SH SYNOPSIS"
sed -e '
	/^\.SX /!d
	s/\\(en/\\-/g
	s/~/ /g
	s/\\\*([OCS]Q/\\\&'\''/g
	s/\\\*(M2/\\s-2MINIX\\s+2/g
	s/^\.SX "*/\\fB/
	s/"* *$/\\fR/
	a\
.br
' $1

# Define macros for flags and examples.
echo '.de FL
.TP
\\fB\\$1\\fR
\\$2
..
.de EX
.TP 20
\\fB\\$1\\fR
# \\$2
..'

# The flags.
echo ".SH OPTIONS"
sed -e '
	/^\.FL /!d
	s/\\(en/\\-/g
	s/~/ /g
	s/\\\*([OCS]Q/\\\&'\''/g
	s/\\\*(M2/\\s-2MINIX\\s+2/g
	s/^\.FL "\\fR(none)" *$/(none)/
' $1

# The examples.
echo ".SH EXAMPLES"
sed -e '
	/^\.E[XY] /!d
	s/\\(en/\\-/g
	s/~/ /g
	s/\\\*([OCS]Q/\\\&'\''/g
	s/\\\*(M2/\\s-2MINIX\\s+2/g
	s/^\.EY /.EX /
' $1

# Extract the body.
echo ".SH DESCRIPTION"
sed -e '
	/^\.CD /d
	/^\.SX /d
	/^\.FL /d
	/^\.EX /d
	/^\.EY /d
	s/\\(en/\\-/g
	s/\\\*([OCS]Q/\\\&'\''/g
	s/\\\*(M0/MINIX/g
	s/\\\*(M[19]/\\s-1MINIX\\s+1/g
	s/\\\*(M2/\\s-2MINIX\\s+2/g
	s/\\\*(Mx/\\s-1MINIX\\s0/g
	s/\\\*(Mp/\\s-1MINIX-PC\\s0/g
	s/\\\*(Ms/\\s-1MINIX-ST\\s0/g
	s/^\.MX */\\s-2MINIX\\s+2/
	s/^\.Cx /.B "	"/
	s/^\.DI /.B /
	s/^\.HS/.PP/
	s/^\.SY /\\\&/
	s/^\.U[xX] */\\s-2UNIX\\s+2/
	s/^\.UU/.SS/
	/^$/d
	/^\.SP/d
' $1

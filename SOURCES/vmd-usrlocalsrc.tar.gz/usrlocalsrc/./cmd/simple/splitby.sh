#!/bin/sh
#
# Split an input stream in equal sized packages.

case $# in
2)
	size="$1"
	name="$2"
	;;
*)
	echo "splitby <size-in-k> <name>" >&2
	exit 1
esac

i=1
while :; do
	case $i in
	?)	ii=0$i
		;;
	*)	ii=$i
	esac
	dd bs="$size"k count=1 of="$name.$ii" || exit

	test -s "$name.$ii" || break	# The last is of zero length.

	i=`expr $i + 1`
done

rm "$name.$ii"	# Remove the zero length one.

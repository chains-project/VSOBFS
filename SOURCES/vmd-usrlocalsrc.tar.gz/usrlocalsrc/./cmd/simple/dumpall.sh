#!/bin/sh
#
#	dumpall 1.1 - Make a backup of the darask	Author: Kees J. Bot
#								7 Oct 1995

dumpdir=/usr/local/adm/dumpdir
ntape=/dev/nrst4
tape=/dev/rst4

if [ `pwd` != / ]
then
	echo "dumpall: Please run this from the root directory" 2>&1
	exit 1
fi

if [ $0 != /tmp/dumpall ]
then
	cp $0 /tmp/dumpall || exit
	exec sh -$- /tmp/dumpall "$@" || exit
else
	rm /tmp/dumpall || exit
fi

usage()
{
	echo >&2 "\
Usage: dumpall -f	# Full
       dumpall -i	# Incremental"
	exit 1
}

full=
incr=
while getopts 'fi' opt
do
	case $opt in
	f)	full=yes
		;;
	i)	incr=yes
		;;
	?)	echo "Usage: dumpall -f		# Full" >&2
		echo "       dumpall -i		# Incremental" >&2
		exit 1
	esac
done

test "$full" = "$incr" && usage

shift `expr $OPTIND - 1`
test $# = 0 || usage

for fs in /usr /save /misc[1234]
do
	umount $fs || exit
	mount -o ro $fs || exit
done

dump()
{
	echo "Dumping /$1..."
	if [ "$full" ]; then state=/dev/null; else state=$dumpdir/$1.state; fi
	remsync -d /$1 $state | compress | vol -1 $ntape || exit

	if [ "$2" ]
	then
		# Rewind.
		< $tape
	fi

	if [ "$full" ]
	then
		echo "New /$1 state..."
		remsync -s /$1 /tmp/$1.state || exit
	fi

	if [ "$2" ]
	then
		# Offline (may eject tape).
		mt -f $ntape offline || exit
	fi
}

echo -n "Insert tape 1 for /usr "; read ret
dump usr ${full:+last}

if [ "$full" ]
then
	echo -n "Insert tape 2 for /save, /misc[13] "; read ret
fi
dump save
dump misc1
dump misc3 last
#dump misc3 ${full:+last}
#
#if [ "$full" ]
#then
#	echo -n "Insert tape 3 for /misc2 "; read ret
#fi
#dump misc2 last

for fs in /usr /save /misc[123]
do
	mount -o remount,rw $fs || exit
done

# catlog is usually gone.
intr -d catlog&

if [ "$full" ]
then
	echo "State files to /usr/local/adm/dumpdir/"
	mv /tmp/*.state /usr/local/adm/dumpdir || exit
fi

echo Done.

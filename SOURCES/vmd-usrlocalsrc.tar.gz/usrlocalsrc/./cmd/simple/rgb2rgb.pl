#!/usr/bin/perl
#
#	rgb2rgb 1.0 - translate RGB values all over	Author: Kees J. Bot
#								30 Oct 1997

$_=$0;s#/*$##;s#^.*/##;$0=$_;

$rgbtxt = '/usr/X11/lib/X11/rgb.txt';

$x = '[\da-fA-F]';					# Hex digit.
$f = '([-+]?(\d+|\d*\.\d+|\d+\.\d*)([eE][-+]?\d+)?)';	# Float number.

# Read the X11 rgb file (colour names).
open(RGBTXT, $rgbtxt) || die "$0: Can't open X11 colour database $rgbtxt: $!\n";
%rgb2col = ();
%col2rgb = ();
while (<RGBTXT>) {
    chop;
    @_ = split(' ', $_, 4);
    if (@_ == 4) {
	$rgb = "$_[0],$_[1],$_[2]";
	$col = $_[3];
	if (!defined($rgb2col{$rgb})) {
	    $rgb2col{$rgb} = $col;
	} else {
	    $rgb2col{$rgb} .= ', ' . $col;
	}
	$col2rgb{"\L$col"} = $rgb;
    }
}
close(RGBTXT);

sub hex
# Hex to number, scaled to 0..255 range.
{
    local(@_) = @_;
    foreach (@_) { $_ = oct("0x$_") / oct("0x" . ('F' x length($_))); }
    @_;
}

sub show
# Show a colour indicator and an explanatary text.
{
    printf("    %-30s - %s\n", @_);
}

$err = 0;

foreach (@ARGV) {
    if (/^\s*#($x)($x)($x)\s*$/o) {
	print "Warning: #\U$1$2$3\E equals #\U${1}0${2}0${3}0\E under X11",
		", but #\U$1$1$2$2$3$3\E in HTML (avoid this form)\n";
	last;
    }
}

foreach (@ARGV) {
    s/^\s*//;
    s/\s*$//;

    if (/^(\d+)(\s*,\s*|\s+)(\d+)(\s*,\s*|\s+)(\d+)$/) {
	@rgbi = ($1 / 255, $3 / 255, $5 / 255);
    }
    elsif (/^#($x)($x)($x)$/o) {
	@rgbi = &hex("$1$1", "$2$2", "$3$3");
    }
    elsif (/^#($x$x)($x$x)($x$x)$/o) {
	@rgbi = &hex($1, $2, $3);
    }
    elsif (/^#($x$x$x)($x$x$x)($x$x$x)$/o) {
	@rgbi = &hex($1, $2, $3);
    }
    elsif (/^#($x$x$x$x)($x$x$x$x)($x$x$x$x)$/o) {
	@rgbi = &hex($1, $2, $3);
    }
    elsif (m#^rgb:($x+)/($x+)/($x+)$#o) {
	@rgbi = &hex($1, $2, $3);
    }
    elsif (m#^rgbi:$f/$f/$f$#o) {
	m#^rgbi:(.*)/(.*)/(.*)$#o;
	@rgbi = ($1, $2, $3);
    }
    elsif (/^rgb\s*\((\s*(\d+|$f%)\s*,\s*(\d+|$f%)\s*,\s*(\d+|$f%)\s*)\)$/) {
	@rgbi = split(',', $1);
	foreach (@rgbi) {
	    s/^\s*//;
	    s/\s*$//;
	    $_ = $_ / (/%$/ ? 100 : 255);
	}
    }
    elsif (defined($col2rgb{"\L$_"})) {
	@rgbi = split(',', $col2rgb{"\L$_"});
	foreach (@rgbi) { $_ = $_ / 255; }
    } else {
	print STDERR "$0: can't recognize '$_' as a colour name or RGB value\n";
	$err++;
	next;
    }
    foreach (@rgbi) {
	$_ = 0 if $_ < 0;
	$_ = 1 if $_ > 1;
    }
    @rgb = @rgbi;
    foreach (@rgb) { $_ = int($_ * 255 + 0.5); }
    $rgb = join(',', @rgb);
    $col = $rgb2col{$rgb};

    print "\n\"$_\" translates to:\n";
    &show(sprintf("#%02X%02X%02X", @rgb), "HTML / old style X11");
    &show("$col", "X11 colour name" . ($col =~ /,/ ? "s" : ""))
	if defined($col);
    &show(sprintf("%3d %3d %3d", @rgb), "Decimal RGB values as in X11 rgb.txt");
    &show(sprintf("rgb:%02X/%02X/%02X", @rgb), "X11 absolute");
    &show(sprintf("rgbi:%.4f/%.4f/%.4f", @rgbi),
					"X11 intensity (ignoring gamma)");
    &show(sprintf("rgb(%d, %d, %d)", @rgb), "CSS1 integer");
    &show(sprintf("rgb(%.1f%%, %.1f%%, %.1f%%)",
	$rgbi[0]*100, $rgbi[1]*100, $rgbi[2]*100), "CSS1 float");
}
exit($err == 0 ? 0 : 1);

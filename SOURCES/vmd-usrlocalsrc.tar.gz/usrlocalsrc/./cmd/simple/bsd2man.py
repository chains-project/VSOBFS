#!/usr/local/bin/python
#
#	bsd2man 1.0 - transform new BSD manual pages to old man(7) format
#							Author: Kees J. Bot
#								22 Sep 1994

import sys, string

# An exception for assert().
AssertionFailed= 'Assertion failed'

def assert(test):
	# Make sure that the state of the world is as expected.
	if not test: raise AssertionFailed

ParseProblem = 'Parsing problem'	# Exception for unknown construct.

transformations= {}	# Transformation functions for given [nt]roff codes.

def tr_Dd(line):
	# .Dd date		<- Input [nt]roff code.
	# .\" .Dd date		<- What goes out (a comment in this case.)
	spew(['.\\"'] + line)
	del line[:]

transformations['.Dd']= tr_Dd
transformations['.Os']= tr_Dd
transformations['.Bl']= tr_Dd
transformations['.El']= tr_Dd

def tr_Dt(line):
	# .Dt command section
	# .TH command section
	spew(['.TH'] + line[1:])
	del line[:]

transformations['.Dt']= tr_Dt

def tr_Nm(line):
	# .Nm [name] ...
	# \fBname\fR ...
	global _in_synopsis
	if _in_synopsis: spew(['.br'])
	spew(['\\fB' + remember(line[:2]) + '\\fR'])
	del line[:2]

transformations['.Nm']= tr_Nm

def tr_Nd(line):
	# .Nm [name]; .Nd string
	# name - string
	void= choke()
	spew([remember(['.Nm']), '\\-'] + line[1:])
	del line[:]

transformations['.Nd']= tr_Nd

_in_synopsys= 0		# Inside a synopsis section .Nm needs a .br???

def tr_Sh(line):
	# .Sh NAME
	# .SH NAME
	global _in_synopsis
	_in_synopsis= (line[1] == 'SYNOPSIS' or line[1] == 'SYNOPSYS')
	undo()
	spew(['.SH'] + line[1:])
	del line[:]

transformations['.Sh']= tr_Sh

def tr_Op(line):
	# .Op Xx ...
	# [ .Xx ... ]
	del line[0]
	while line:
		line[0]= '.' + line[0]
		transform(line)
		spew(['[' + choke()[0] + ']'])

transformations['.Op']= tr_Op
transformations['.Bq']= tr_Op

def tr_Fl(line):
	# .Fl flags
	# .B \-flags
	spew(['\\fB\\-' + remember(line[:2]) + '\\fR'])
	del line[:2]

transformations['.Fl']= tr_Fl

def tr_Li(line):
	# .Li arg
	# .B arg
	spew(['\\fB' + remember(line[:2]) + '\\fR'])
	del line[:2]

transformations['.Li']= tr_Li
transformations['.Pa']= tr_Li
transformations['.Fa']= tr_Li
transformations['.Er']= tr_Li
transformations['.Va']= tr_Li

def tr_Ar(line):
	# .Ar arg
	# .I arg
	spew(['\\fI' + remember(line[:2]) + '\\fR'])
	del line[:2]

transformations['.Ar']= tr_Ar

def tr_It(line):
	# .It Xx ...
	# .TP; .Xx ...
	spew(['.TP'])
	del line[0]
	while line:
		line[0]= '.' + line[0]
		transform(line)

transformations['.It']= tr_It

_undo= {}
def undo(key= None):
	# Add commands to undo indents, etc.
	if key:
		keys= [key]
	else:
		keys= _undo.keys()
	for key in keys:
		if _undo.has_key(key):
			for ctrl in _undo[key]:
				spew(ctrl)
			del _undo[key]

def undo_later(key, ctrl):
	# Remember to do this command later.
	if not _undo.has_key(key): _undo[key]= []
	_undo[key].insert(0, ctrl)

def tr_Pp(line):
	# .Pp
	# .PP
	undo()
	spew(['.PP'])
	del line[:]

transformations['.Pp']= tr_Pp

def tr_Xr(line):
	# .Xr title section [punct]
	# .BR title (section) [punct]
	spew(['.BR'] + line[1:2] + ['(' + line[2] + ')' + concat(line[3:])])
	del line[:]

transformations['.Xr']= tr_Xr

def tr_Ql(line):
	# .Ql punct
	# punct
	spew(['\\&' + line[1]])
	del line[:2]

transformations['.Ql']= tr_Ql
transformations['.Dv']= tr_Ql

def tr_Em(line):
	# .Em words ...
	# .B words ...; .br
	spew(['\\fB' + concat(line[1:]) + '\\fR'])
	spew(['.br'])
	del line[:]

transformations['.Em']= tr_Em

_At_translate= {
	'v6':		'Version 6',
	'V':		'System V',
}

def tr_At(line):
	# .At keyword
	# \fBwhat system\fR
	spew(['\\fB' + _At_translate[line[1]] + '\\fR'])
	del line[:2]

transformations['.At']= tr_At

_St_translate= {
	'-ansiC':	'the ANSI C standard',
}

def tr_St(line):
	# .St keyword
	# \fBwhat standard\fR
	spew([_St_translate[line[1]]])
	del line[:2]

transformations['.St']= tr_St

def tr_Dl(line):
	# .Dl text ...
	# .RS; .nf; \&text ...; .fi; .RE
	spew(['.RS'])
	spew(['.nf'])
	spew(['.if', 't', '.ft', 'C'])
	spew(['\\&' + concat(line[1:])])
	spew(['.if', 't', '.ft', 'R'])
	spew(['.fi'])
	spew(['.RE'])
	del line[:]

transformations['.Dl']= tr_Dl

def tr_Bd(line):
	# .Bd -literal -offset xxx
	# .nf; .RS
	del line[0]
	while line:
		if line[0] == '-literal':
			spew(['.nf'])
			spew(['.if', 't', '.ft', 'C'])
			undo_later('Bd', ['.if', 't', '.ft', 'R'])
			undo_later('Bd', ['.fi'])
			del line[:1]
		elif line[0] == '-offset':
			spew(['.RS'])
			undo_later('Bd', ['.RE'])
			del line[:2]
		else:
			raise ParseProblem, ('.Bd control', line)

transformations['.Bd']= tr_Bd

def tr_Ed(line):
	undo('Bd')
	del line[0]

transformations['.Ed']= tr_Ed

def tr_Tn(line):
	# .Tn acronym
	# \s-2acronym\s+2
	spew(['\\s-2' + line[1] + '\\s+2'])
	del line[:2]

transformations['.Tn']= tr_Tn

def tr_Bx(line):
	# .Bx version
	# \s-2BSD\s+2 version
	spew(['\\s-2BSD\\s+2'] + line[1:2])
	del line[:2]

transformations['.Bx']= tr_Bx

def tr_Fd(line):
	# .Fd text ...
	# .nf; \fBtext ...\fR; .fi
	spew(['.nf'])
	spew(['\\fB' + concat(line[1:]) + '\\fR'])
	spew(['.fi'])
	del line[:]

transformations['.Fd']= tr_Fd

def tr_Ft(line):
	# .Ft type
	# .sp; .nf; .B type
	spew(['.sp'])
	spew(['.nf'])
	spew(['\\fB' + concat(line[1:]) + '\\fR'])
	undo_later('Ft', ['.fi'])
	del line[:]

transformations['.Ft']= tr_Ft

def tr_Fn(line):
	# .Fn function "type param" "type param" ...
	# \fBfunction\fR(type param, type param)
	fun= '\\fB' + line[1] + '\\fR('
	del line[:2]
	while line:
		if line[0][0] in '!);:,.?]}': break
		fun= fun + line[0]
		del line[0]
		if line: fun= fun + ', '
	spew([concat([fun + ')'] + line)])
	undo('Ft')
	del line[:]

transformations['.Fn']= tr_Fn

# End of transformations.

_memory= {}

def remember(flagop):
	# Remember an optional argument for the next time.
	if len(flagop) > 1:
		_memory[flagop[0]]= flagop[1]
	try:
		return _memory[flagop[0]]
	except KeyError:
		return 'wotsit'

def concat(line):
	# Concatenate a line of words.  Separate by spaces unless it's
	# Punctuation.
	if not line: return ''
	conc=line[0]
	while len(line) > 1:
		del line[0]
		if line[0][0] not in '!);:,.?]}': conc= conc + ' '
		conc= conc + line[0]
	return conc

def emphasize(font, line):
	# Concatenate words with the first word in a given font.  "font" is
	# .B or .I.
	return concat(['\\f' + font[1] + line[0] + '\\fR'] + line[1:])

_spewn= []	# One line remembered.

def spew(line):
	# Emit a transformed line of words.  Allow one chance to back up.
	global _spewn
	if _spewn:
		if _spewn[0][0] == '.':
			# Some .troff command.
			for s in _spewn:
				if haswhitespace(s):
					print '"%s"' % s,
				else:
					print s,
			print
		else:
			print concat(_spewn)
	_spewn= line

def haswhitespace(word):
	for c in word:
		if c in string.whitespace: return 1
	return 0

def flush():
	# Flush a backup line
	spew([])

def choke():
	global _spewn
	spewn, _spewn= _spewn, []
	return spewn

def parseline(line):
	# Parse a line containing [nt]roff commands.  Return false if it
	# isn't a command.
	if not line or line[0] != '.': return []
	words= []
	i= 0
	while 1:
		while i < len(line) and line[i] in string.whitespace: i= i+1
		if i == len(line): break
		word= ''
		quote= 0
		while i < len(line) and \
				(quote or line[i] not in string.whitespace):
			if line[i] == '"':
				quote= not quote
			else:
				if line[i] == '\\':
					word= word + '\\'
					i= i+1
					if i == len(line): break
				word= word + line[i]
			i= i+1
		words.append(word)
	return words

def transform(list):
	# Transform a list by calling functions that nibble pieces off.
	if transformations.has_key(list[0]):
		transformations[list[0]](list)
	else:
		spew(choke() + list)
		del list[:]

def bsd2man(file= "-"):
	# Transform a new style BSD manual page to trusty old man(7) format.
	if file == "-":
		file= sys.stdin
	else:
		file= open(file)

	print '.\\" Translated from new BSD style to old man(7).'
	print '.\\" DO NOT EDIT!'

	while 1:
		line= file.readline()
		if not line: break
		if line[-1:] == '\n': line= line[:-1]
		parsedline= parseline(line)
		if parsedline and transformations.has_key(parsedline[0]):
			transform(parsedline)
			if parsedline: spew(choke() + parsedline)
		else:
			flush()
			print line
	flush()
	if file is not sys.stdin: file.close()

def main():
	for file in sys.argv[1:] or ["-"]:
		bsd2man(file)

if __name__ == '__main__': main()

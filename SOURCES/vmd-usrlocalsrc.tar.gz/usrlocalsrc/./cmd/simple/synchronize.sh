#!/bin/sh
#
#	synchronize 8.4 - sync one of the VU PC's to the master backup.
#
#							Author: Kees J. Bot
#								26 Jan 1994

backup_path=/net/minix_backup/2001a

PATH=/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin
PATH=$PATH:/root/usr/bin:/root/usr/local/bin:/root/usr/sbin:/root/usr/local/sbin
export PATH

. /etc/profile		# Often run from the login prompt; need TZ.

remote=minixsync
locX=/usr/local/XF86

[]()
{
	# Index into a list, i.e. f='x y z'; $([] 1 $f) = y
	shift $1
	shift
	echo "$1"
}

@()
{
	# Dereference, i.e. y=z; x=y; $(@ $x) = z
	eval "echo \$$1"
}

bool2yesno()
{
	# Turn a boolean variable into 'yes' or 'no'.
	if [ "$(@ $1)" ]; then echo yes; else echo no; fi
}

case $# in
0)	;;
1)	remote="$1"
	;;
*)	echo "Usage: synchronize [remote-host]" >&2
	exit 1
esac

backup="mnximg@$remote:$backup_path"

if [ ! "$sync_warp" ]
then
	# See if the remote host is there.
	rcp -p "$backup/Minix-vmd/usr/local/sbin/synchronize" \
			/tmp/synchronize || {
		echo "synchronize: mnximg@$remote is not at home" >&2
		exit 1
	}

	# Always run the remote sync script.
	export sync_warp=true
	exec sh /tmp/synchronize $remote
fi

# Set time and date, both UNIX time and the hardware clock.
if [ -t 0 ]
then
	# Interactive.
	rdate $remote
	readclock -w
else
	# Executed from a cron job, be careful.
	old_time=`date +%s`
	sleep 300
	rdate $remote >/dev/null
	readclock -w
	new_time=`date +%s`
	if [ $new_time -lt $old_time -o $new_time -gt \( $old_time + 7200 \) ]
	then
		# Time warp, get out.
		exit 1
	fi
fi

# Variables.
host=`hostname`
dpeth0=`sysenv DPETH0`
if [ -f /etc/.config ]
then
	. /etc/.config
else
	keep_NT=true
	has_minix=true
	xconfig=mg400-85
	synch=true
fi

# If root is /dev/ram or /dev/fd? then we don't have to be careful.
read root rest </etc/mtab
rough=
case $root in
/dev/ram|/dev/fd?)	rough=true
esac

interactive=
test -t 0 && interactive=true

if [ "$interactive" ]
then
	echo "Current options:"
	echo "	Keep NT around in the first partition? $(bool2yesno keep_NT)"
	echo "	Install plain Minix also? $(bool2yesno has_minix)"
	echo "	X configuration is '$xconfig'"
	echo "	Synchronize automatically each night? $(bool2yesno synch)"
	echo

	echo "Please enter new values for options.  Type CTRL-D if nothing more"
	echo "needs to be changed.  Hit DEL and start over on a mistake."
	echo
fi

if [ "$interactive" -a "$rough" ]
then
	echo -n "Keep NT? [$(bool2yesno keep_NT)] ";
	read answer || interactive=
fi

if [ "$interactive" -a "$rough" ]
then
	case "$answer" in
	[yY]|[yY]es|sure)	keep_NT=true
		;;
	[nN]|[nN]o)		keep_NT=
		;;
	?*)	echo "Strange answer, '$answer'"; exit 1
	esac
fi

if [ "$interactive" -a "$rough" ]
then
	echo -n "Also install plain Minix? [$(bool2yesno has_minix)] ";
	read answer || interactive=
fi

if [ "$interactive" -a "$rough" ]
then
	case "$answer" in
	[yY]|[yY]es|sure)	has_minix=true
		;;
	[nN]|[nN]o)		has_minix=
		;;
	?*)	echo "Strange answer, '$answer'"; exit 1
	esac
fi

if [ "$interactive" ]
then
	if [ -d $locX ]
	then
		echo "Available X configuration files:"
		ls $locX/lib/X11 | sed '/XF86Config/!d;s/XF86Config-/	/'
	fi
	echo -n "X configuration? [$xconfig] ";
	read answer || interactive=
fi

if [ "$interactive" ]
then
	case "$answer" in
	?*)	xconfig="$answer"
	esac
fi

if [ "$interactive" ]
then
	echo -n "Synchronize automatically each night? [$(bool2yesno synch)] ";
	read answer || interactive=
fi

if [ "$interactive" ]
then
	case "$answer" in
	[yY]|[yY]es|sure)	synch=true
		;;
	[nN]|[nN]o)		synch=
		;;
	?*)	echo "Strange answer, '$answer'"; exit 1
	esac
fi

# Slight pause before doing damage.
echo;echo 'Synchronizing ...'
sleep 5

if [ "$keep_NT" ]
then
	part0='07:exist 81:800001*'
	minixvmd=c0d0p1
	minix=c0d0p2
	minix_test=c0d0p3
	bootvmd=hd2
	bootstd=hd3
else
	part0='81:800000*'
	minixvmd=c0d0p0
	minix=c0d0p1
	minix_test=c0d0p2
	bootvmd=hd1
	bootstd=hd2
fi

if [ "$has_minix" ]
then
	part0="$part0 81:200001 81:292481"
fi

if [ "$rough" ]
then
	echo
	echo "Setting up partition tables."

	# Whole disk
	installboot -m /dev/c0d0 /usr/mdec/masterboot >/dev/null
	partition /dev/c0d0 $part0 >/dev/null || exit
	repartition /dev/c0d0

	# Minix-vmd
	umount -q /root/var 2>/dev/null
	umount -q /root/opt 2>/dev/null
	umount -q /root/home 2>/dev/null
	umount -q /dev/${minixvmd}s2 2>/dev/null
	umount -q /dev/${minixvmd}s1 2>/dev/null
	umount -q /dev/${minixvmd}s0 2>/dev/null
	umount -q /mnt/usr 2>/dev/null
	umount -q /mnt 2>/dev/null

	installboot -m /dev/$minixvmd /usr/mdec/masterboot >/dev/null
	partition /dev/$minixvmd 81:2880* 81:32768 81:0+ >/dev/null || exit
	repartition /dev/$minixvmd
fi

# Minix
if [ "$has_minix" ]
then
	umount -q /dev/${minix}s2 2>/dev/null
	umount -q /dev/${minix}s0 2>/dev/null

	if [ "$rough" ]
	then
		installboot -m /dev/$minix /usr/mdec/masterboot >/dev/null
		partition /dev/$minix 81:2880* 0:0 81:0+ >/dev/null || exit
		repartition /dev/$minix
		installboot -m /dev/$minix_test /usr/mdec/masterboot >/dev/null
		partition /dev/$minix_test 81:2880 81:2880 81:143360 81:143360 \
					>/dev/null || exit
		repartition /dev/$minix_test
	fi
fi

echo
echo "Minix-vmd /, /tmp, /usr."

if [ "$rough" ]
then
	# Make filesystems.
	mkfs -t 2f /dev/${minixvmd}s0 </dev/null || exit
	mkfs -t 2f /dev/${minixvmd}s1 8192 </dev/null || exit
	mkfs -t 2f /dev/${minixvmd}s2 </dev/null || exit
	mount /dev/${minixvmd}s0 /root || exit
	mkdir -p -m 555 /root/usr || exit
	mount /dev/${minixvmd}s2 /root/usr || exit
	mkdir -p /root/usr/.lo || exit
	for fs in var opt home
	do
		mkdir -p /root/usr/.lo/$fs || exit
		rm -f /root/$fs
		mkdir -p -m 555 /root/$fs || exit
		mount -t lo /root/usr/.lo/$fs /root/$fs || exit
	done
	root=/root
else
	root=/
fi

if [ ! "$rough" ]
then
	# Keep the stuff in /etc, /var/adm and /var/run around.
	tar cf /tmp/.sync$$ /etc/mtab /etc/utmp /var/adm /var/run
	exec 9</tmp/.sync$$
	rm /tmp/.sync$$
fi

# Sync it.
rm -rf $root/tmp $root/var/tmp		# Delete any junk
synctree -f $backup/Minix-vmd $root

if [ ! "$rough" ]
then
	# Restore /etc, /var/adm and /var/run.
	tar xf - <&9
	exec 9<&-
fi

# Create a proper /etc/fstab.
cat >$root/etc/fstab <<EOF
# fstab - File System Table
#
# Device	Dir	Type	Options		Freq	Pass	Time
/dev/${minixvmd}s0	/	2f	rw		7	1	0
/dev/${minixvmd}s1	/tmp	2f	rw,swap		0	2	0
/dev/${minixvmd}s2	/usr	2f	rw		7	3	0
/usr/.lo/var	/var	lo	rw		0	0	0
/usr/.lo/opt	/opt	lo	rw		0	0	0
/usr/.lo/home	/home	lo	rw		0	0	0

/dev/fd0	/fd0	dev	rw,noauto,user	0	0	0
/dev/fd1	/fd1	dev	rw,noauto,user	0	0	0
EOF

# X configuration
rm -f $root/etc/XF86Config
cp -p $root$locX/lib/X11/XF86Config-$xconfig $root/etc/XF86Config

# Store the settings.
cat >$root/etc/.config <<EOF
keep_NT=$keep_NT
has_minix=$has_minix
xconfig=$xconfig
synch=$synch
EOF

# Install bootstrap and boot parameters.
dd if=/dev/zero of=/dev/${minixvmd}s0 bs=1k count=1 2>/dev/null || exit
installboot -d /dev/${minixvmd}s0 /usr/mdec/bootblock boot || exit
edparams /dev/${minixvmd}s0 "
	rootdev=bootdev
	main() {date;trap 10000 vmd;menu}
	date() {echo;echo Synchronized on `date '+%e %b %Y %H:%M'`}
	vmd(=,Minix-vmd (Computer Networks)) {boot}
	${has_minix:+"std(m,Minix (Operating Systems)) boot $minix"}
	${keep_NT:+"win(w,Windows NT) boot c0d0p0"}
	DPETH0=$dpeth0
	servers=inet
	save
	" || exit

if [ "$synch" ]
then
	# Synchronize automatically each night.
	echo >>$root/usr/lib/crontab \
		'?  2  *  *  *	/usr/local/sbin/synchronize'
fi

if [ "$rough" ]
then
	# Initialize the swap partition.  (Not needed much these days.)
	mkfs -t +swap /dev/${minixvmd}s1 || exit
fi

# Minix.
if [ "$has_minix" ]
then
	echo
	echo "Minix /, /usr."

	# Check each filesystem and if necessary remake them.
	if [ "$rough" ]
	then
		fsck=false
	else
		fsck=fsck
	fi

	$fsck -y /dev/${minix}s0 ||
		mkfs -t 2 -i 512 /dev/${minix}s0 </dev/null || exit
	$fsck -y /dev/${minix}s2 ||
		mkfs -t 2 /dev/${minix}s2 </dev/null || exit

	# Mount and sync.
	mount /dev/${minix}s0 /mnt || exit
	mkdir -p -m 555 /mnt/usr || exit
	mount /dev/${minix}s2 /mnt/usr || exit
	synctree -f $backup/Minix /mnt

	# Create a proper /etc/fstab.
	cat >/mnt/etc/fstab <<EOF
# Poor man's File System Table.

root=/dev/${bootstd}a
usr=/dev/${bootstd}c
EOF
	# List of DNS servers.
	dhcpd -q | sed '/DNSserver/!d;s/.* = /nameserver /' \
		>/mnt/etc/resolv.conf

	cp -p /mnt/usr/mdec/bootblock /tmp
	umount /mnt/usr
	umount /mnt

	# Install bootstrap and boot parameters.
	dd if=/dev/zero of=/dev/${minix}s0 bs=1k count=1 2>/dev/null || exit
	installboot -d /dev/${minix}s0 /tmp/bootblock boot || exit
	rm /tmp/bootblock
	edparams /dev/${minix}s0 "
		rootdev=bootdev
		ramimagedev=bootdev
		extsize=15360
		main() {date;trap 900000 vmd;menu}
		date() {echo;echo Synchronized on `date '+%e %b %Y %H:%M'`}
		minix(=,Minix) {image=minix/2.0.0;boot}
		test(t,Test new kernel) {unset image;boot}
		vmd(v,Minix-vmd) {boot $bootvmd}
		DPETH0=$dpeth0
		save
		" || exit

	# Test partitions exist yet? (XXX - Remove this eventually)
	if [ ! "$keep_NT" ]
	then
		partition /dev/c0d0 $part0 || exit
		repartition /dev/c0d0
		partition /dev/$minix_test 81:2880 81:2880 81:143360 81:143360 \
					|| exit
		repartition /dev/$minix_test
	fi >/dev/null

	# Wipe the test partitions.
	for s in 0 1 2 3
	do
		test -b /dev/${minix_test}s$s || continue
		mkfs -t 2 /dev/${minix_test}s$s </dev/null || exit
	done
fi

if [ "$rough" ]
then
	echo "Done."
	shutdown -R
elif [ ! -t 0 ]
then
	# Probably running from cron at night.  Reboot if new kernel.
	test "`find /minix -mtime -1`" && reboot
else
	# How do people reboot?  With the RESET button, of course!
	for i in 1 2 3 4 5 6 7 8 9 0; do sync; done

	echo "Done.  Please reboot now."
fi

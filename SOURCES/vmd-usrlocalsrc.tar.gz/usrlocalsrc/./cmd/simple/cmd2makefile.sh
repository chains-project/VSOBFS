#!/bin/sh
#
#	cmd2makefile 1.3 - Output a Makefile for a set of commands.
#							Author: Kees J. Bot

install=/tmp/c2mI.$$
rules=/tmp/c2mR.$$
maninstall=/tmp/c2mMI.$$
manrules=/tmp/c2mMR.$$

trap "rm -f $install $rules $maninstall $manrules; exit 1" 1 2 15

case `pwd` in
/usr/local/*)	defbin=/usr/local/bin
		sbin=/usr/local/sbin
		man=/usr/local/man
	;;
*)		defbin=/usr/bin
		sbin=/usr/sbin
		man=/usr/man
esac

# Open install & rules temp files.
exec 8>$install 9>$rules 6>$maninstall 7>$manrules

for i
do
	case $i in
	*.c)
		base="`basename "$i" .c`"
		if [ -f "$sbin/$base" ]
		then
			bin="$sbin/$base"
		else
			bin="$defbin/$base"
		fi

		echo "	$bin \\" >&8
		echo "
$bin:	$i
	\$(CCLD) -stack 4kw -o \$@ \$?" >&9
		;;
	*.[0-9]*)
		section="`expr "$i" : '.*\\.\(.*\)$`"
		echo "	\$(MAN)/man$section/$i \\" >&6
		echo "\$(MAN)/man$section/$i:	$i	install -lc \$? \$@" >&7
		;;
	*.*)
		base="`expr "$i" : '\(.*\)\\..*$`"
		if [ -f "$sbin/$base" ]
		then
			bin="$sbin/$base"
		else
			bin="$defbin/$base"
		fi

		echo "	$bin \\" >&8
		echo "
$bin:	$i
	install -lc \$? \$@" >&9
	esac
done

# Close install & rules temp files.
exec 8>&- 9>&- 6>&- 7>&-

echo "# Makefile for `pwd | sed 's:^/usr/src/::'`."
echo "
CFLAGS	= -D_MINIX \$(OPT)
CCLD	= \$(CC) -fnone \$(CFLAGS)
MAKE	= exec make -\$(MAKEFLAGS)
MAN	= $man

install:	bin man

bin:	\\"

cat $install
echo	'
man:	\'
sort $maninstall
echo '
clean:
	rm -f a.out core'
cat $rules
sort $manrules | tr '\1' '\12'

rm $install $rules $maninstall $manrules

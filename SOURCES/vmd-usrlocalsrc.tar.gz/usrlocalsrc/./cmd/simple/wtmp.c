/*	wtmp 1.4 - Show logins and logouts.		Author: Kees J. Bot
 */
#define nil 0
#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <utmp.h>
#include <time.h>
#include <limits.h>

#if defined(BSD) || defined(HOSTNAME_MAX)
#define REMOTE
#endif

extern struct utmp dummy;
#define NLEN	(int)sizeof(dummy.ut_name)
#define LLEN	(int)sizeof(dummy.ut_line)
#ifdef REMOTE
#define HLEN	(int)sizeof(dummy.ut_host)
#endif
#ifdef HOSTNAME_MAX
#define LHLEN	(int)sizeof(dummy.ut_localhost)
#endif

#ifndef WTMP
char WTMP[]=	"/usr/adm/wtmp";
#endif

struct wtree {
	struct wtree *left, *right;
	struct utmp w;
} wtop=nil;

struct wtree **search();
void insert(), delete(), printwtree();
time_t date();

char *name;

#ifdef HOSTNAME_MAX
void showhostname(pwtmp) struct utmp *pwtmp;
{
	printf("%-10.*s ", LHLEN, pwtmp->ut_localhost);
}
#else
#define showhostname(pwtmp)
#endif

main(argc, argv) char **argv;
{
	FILE *wi;
	char *wtmpf= WTMP;
	struct utmp wtmp;
	struct wtree *pw;
	time_t mintime= 0, maxtime= (time_t) -1 < 0 ? 0x7FFFFFFF : 0xFFFFFFFF;
	time_t lasttime= 0;
	int hold= 0;

	if ((name= strrchr(argv[0], '/')) == nil) name= argv[0]; else name++;

	if (argc > 1 && '0' <= argv[1][0] && argv[1][0] <= '9') {
		if (strcmp(argv[1], "0") != 0) mintime= date(argv[1]);
		argc--;
		argv++;
	}
	if (argc > 1 && '0' <= argv[1][0] && argv[1][0] <= '9') {
		maxtime= strcmp(argv[1], "0") == 0 ? mintime : date(argv[1]);
		argc--;
		argv++;
	}
	if (argc > 2) {
		fprintf(stderr, "Usage: %s [min-time [max-time]] [wtmp-file]\n",
			name);
		exit(1);
	} else
	if (argc == 2)
		wtmpf= argv[1];
	else
	if (!isatty(0)) {
		wtmpf= nil;
		wi= stdin;
	}

	if (wtmpf != nil && (wi= fopen(wtmpf, "r")) == nil) {
		fprintf(stderr, "%s: can't open %s\n", name, wtmpf);
		exit(1);
	}

	while(fread(&wtmp, sizeof wtmp, 1, wi) > 0 && wtmp.ut_time < maxtime) {
		switch (wtmp.ut_line[0]) {
		default:
			if (wtmp.ut_name[0] != 0) {	/* Login */
				insert(&wtop, &wtmp);
				if (mintime <= wtmp.ut_time) {
					showhostname(&wtmp);
					printf("In:  %-*.*s  %-*.*s  %.16s",
						NLEN, NLEN, wtmp.ut_name,
						LLEN, LLEN, wtmp.ut_line,
						ctime(&wtmp.ut_time)
					);
#ifdef REMOTE
					if (wtmp.ut_host[0] != 0) {
						printf("  (%.*s)",
							HLEN, wtmp.ut_host);
					}
#endif
				}
			} else {			/* Logout */
#ifdef MINIX
				if (mintime <= wtmp.ut_time
					&& wtmp.ut_type != DEAD_PROCESS
				) {
					hold= 1;
					break;
				}
#endif
				pw= *search(&wtop, &wtmp);
				if (mintime <= wtmp.ut_time) {
					showhostname(&wtmp);
					printf("Out: %-*.*s  %-*.*s  %.16s",
						NLEN, NLEN, pw == nil ? "??"
							: pw->w.ut_name,
						LLEN, LLEN, wtmp.ut_line,
						ctime(&wtmp.ut_time)
					);
#ifdef REMOTE
					if (pw != nil && pw->w.ut_host[0] != 0)
					{
						printf("  (%.*s)",
							HLEN, pw->w.ut_host);
					}
#endif
				}
				if (pw != nil) pw->w.ut_name[0]= 0;
			}
			break;
		case '~':	/* Reboot */
			if (mintime <= wtmp.ut_time) {
				showhostname(&wtmp);
				printf("%s %.24s",
					wtmp.ut_name[0] == 's' ?
						"Shutdown:" : "Reboot:  ",
					ctime(&wtmp.ut_time));
			}
			delete(&wtmp);
			break;
		case '|':
			if (mintime <= wtmp.ut_time) {
				showhostname(&wtmp);
				printf("Old date: %.24s",
					ctime(&wtmp.ut_time));
			}
			break;
		case '{': case '}':
			if (mintime <= wtmp.ut_time) {
				showhostname(&wtmp);
				printf("New date: %.24s",
					ctime(&wtmp.ut_time));
			}
			break;
		}
		if (mintime <= wtmp.ut_time) {
			if (hold) hold=0; else putchar('\n');
			lasttime= wtmp.ut_time;
		}
	}
	printf("Logged in since %.24s:\n", ctime(&lasttime));
	printwtree(wtop);
	exit(0);
}

struct wtree **search(ppw, pwtmp)
	struct wtree **ppw;
	struct utmp *pwtmp;
{
	struct wtree *pw;
	int cmp;

	while ((pw= *ppw) != nil && (
#ifdef HOSTNAME_MAX
	    (cmp= strncmp(pwtmp->ut_localhost, pw->w.ut_localhost, LHLEN)) != 0
		||
#endif
	    (cmp= strncmp(pwtmp->ut_line, pw->w.ut_line, LLEN)) != 0
	))
		ppw= cmp < 0 ? &pw->left : &pw->right;

	return ppw;
}

void insert(ppw, pwtmp)
	struct wtree **ppw;
	struct utmp *pwtmp;
{
	struct wtree *pw;

	ppw= search(ppw, pwtmp);

	if ((pw= *ppw) == nil) {
		pw= (struct wtree *) malloc(sizeof *pw);
		*ppw= pw;
		pw->left= nil;
		pw->right= nil;
	}
	pw->w= *pwtmp;
}

static void rec_delete();

void delete(pwtmp) struct utmp *pwtmp;
{
	struct wtree *pw= &wtop;
#ifdef HOSTNAME_MAX
	int cmp;

	while (pw != nil &&
	    (cmp= strncmp(pwtmp->ut_localhost, pw->w.ut_localhost, LHLEN)) != 0
	)
		pw= cmp < 0 ? pw->left : pw->right;
#endif
	rec_delete(pw);
}

static void rec_delete(pw) struct wtree *pw;
{
	if (pw != nil) {
		rec_delete(pw->left);
		rec_delete(pw->right);
		pw->w.ut_name[0]= 0;
	}
}

void printwtree(pw) struct wtree *pw;
{
	if (pw != nil) {
		printwtree(pw->left);
		if (pw->w.ut_name[0] != 0) {
#ifdef HOSTNAME_MAX
			printf("%10.*s!", LHLEN, pw->w.ut_localhost);
#endif
			printf("%-*.*s  %-*.*s  %.16s",
				NLEN, NLEN, pw->w.ut_name,
				LLEN, LLEN, pw->w.ut_line,
				ctime(&pw->w.ut_time)
			);
#ifdef REMOTE
			if (pw->w.ut_host[0] != 0)
				printf("  (%.*s)", HLEN, pw->w.ut_host);
#endif
			putchar('\n');
		}
		printwtree(pw->right);
	}
}

int digits(s) char *s;
{
	if (*s == '.') s++;
	return (s[0] - '0') * 10 + (s[1] - '0');
}

time_t date(ascdat) char *ascdat;
/* date [YYMMDDHHMM[[.]SS]] : convert date to number of seconds since epoch */
{
	struct tm tm;

	tm.tm_year= digits(ascdat + 0);
	tm.tm_mon=  digits(ascdat + 2) - 1;
	tm.tm_mday= digits(ascdat + 4);
	tm.tm_hour= digits(ascdat + 6);
	tm.tm_min=  digits(ascdat + 8);
	tm.tm_sec=  ascdat[10] != 0 ? digits(ascdat + 10) : 0;
	tm.tm_isdst= -1;

	return mktime(&tm);
}
/* Kees J. Bot 14-11-85. */

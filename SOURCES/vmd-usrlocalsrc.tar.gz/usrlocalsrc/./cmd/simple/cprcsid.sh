#!/bin/sh
#
#	cprcsid 1.0 - update one of those wretched RCS ids
#							Author: Kees J. Bot
#								16 Mar 1996

case $# in
2)	src="$1" dst="$2"
	;;
*)	echo "Usage: cprcsid source-file dest-file" >&2
	exit 1
esac

id="`grep '\$PchId:' "$1"`" || exit

ed - "$2" <<EOF
/\\\$PchHeader:/c
$id
.
/\\\$PchId:/c
$id
.
w
q
EOF

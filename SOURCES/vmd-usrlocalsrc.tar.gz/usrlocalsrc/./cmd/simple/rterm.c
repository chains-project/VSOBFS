/*	rterm 1.3 - Shared remote terminal.		Author: Kees J. Bot
 *								4 Jul 1997
 */
#define nil 0
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <termios.h>
#include <pwd.h>
#include <signal.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/asynchio.h>
#include <sys/ioctl.h>

#if !__minix_vmd && !__SVR4
#error It looks like you have some work to do
#endif

#if __minix_vmd
/* Minix specific include files and kludges. */
#include <net/netlib.h>
#include <net/hton.h>
#include <net/gen/in.h>
#include <net/gen/netdb.h>
#include <net/gen/tcp.h>
#include <net/gen/tcp_io.h>
#endif /* __minix_vmd */

#if __SVR4
/* Solaris / BSD socket specific include files. */
#include <sys/stropts.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#endif /* __SVR4 */

#define	EXCL_TIME	   10	/* It's mine for this many seconds. */
#define TTYLEN		32768	/* TTY output buffer length. */
#define BUFLEN		 1024	/* Length of other buffers. */
#define DLE		 0xFF	/* Data link escape. */
#define BEEP		 0x00	/* Ring terminal alarm! */
#define GETWINZ		 0x01	/* Please report your window size. */
#define REPWINZ		 0x02	/* Here is my window size. */
#define NAME		 0x03	/* Here is my login name. */

#define arraylenght(a)		(sizeof(a) / sizeof((a)[0]))
#define arraylimit(a)		((a) + arraylenght(a))

static uid_t uid;		/* Identity of the caller. */
static gid_t gid;
static unsigned char name[8];

static int tty_changed;
static struct termios oldterm, newterm;
static struct winsize winsize;

static void quit(int status)
{
    if (tty_changed) {
	(void) tcsetattr(0, TCSAFLUSH, &oldterm);
#if __SVR4
	/* O_NONBLOCK had better be cleared, it's a file flag, not an fd flag.
	 */
	fcntl(0, F_SETFL, fcntl(0, F_GETFL) & ~O_NONBLOCK);
	fcntl(1, F_SETFL, fcntl(1, F_GETFL) & ~O_NONBLOCK);
#endif
    }
    exit(status);
}

static void report(const char *label)
{
    fprintf(stderr, "rterm: %s: %s\n", label, strerror(errno));
}

static void fatal(const char *label)
{
    report(label);
    quit(1);
}

#if __minix_vmd
/* Minix specific support code. */

#define TTY_GID		4	/* The group ID of ttys. */
static char *tcp_device;
static char pty_device[]= "/dev/ptyXX";
static char tty_device[]= "/dev/ttyXX";
static char hexdigits[0x10]= "0123456789ABCDEF";
#define hex(i)	(hexdigits[i]+0)

static int grab_pty(void)
/* Look for a free pty. */
{
    int pfd;
    int p, n;

    pfd= -1;
    for (p= 'p'; pfd < 0 && p <= 'z'; p++) {
	for (n= 0x0; pfd < 0 && n <= 0xF; n++) {
	    pty_device[8]= p;
	    pty_device[9]= hex(n);
	    tty_device[8]= p;
	    tty_device[9]= hex(n);

	    pfd= open(pty_device, O_RDWR);
	}
    }

    if (pfd < 0) {
	fprintf(stderr, "rterm: Out of ptys\n");
	quit(1);
    }

    chown(tty_device, uid, TTY_GID);
    chmod(tty_device, 0600);
    /* Use mode 0620?  Update /etc/utmp? */

    return pfd;
}

static int net_open(char *port)
/* Open a TCP listening port that remote clients can connect to. */
{
    int fd;
    nwio_tcpconf_t tcpconf;
    nwio_tcpopt_t tcpopt;

    if ((fd= open(tcp_device, O_RDWR)) < 0) fatal(tcp_device);

    tcpconf.nwtc_flags= NWTC_SHARED | NWTC_LP_SET | NWTC_UNSET_RA
			| NWTC_UNSET_RP;
    tcpconf.nwtc_locport= htons(atoi(port));
    if (ioctl(fd, NWIOSTCPCONF, &tcpconf) < 0) fatal(tcp_device);

    tcpopt.nwto_flags= NWTO_DEL_RST;
    if (ioctl(fd, NWIOSTCPOPT, &tcpopt) < 0) fatal(tcp_device);

    return fd;
}

static int asyn_accept(asynchio_t *asyn, int fd, char *port)
/* Asynchronously listen for and accept a new tcp connection.  Return the
 * connected channel under a new file descriptor number and reopen a listening
 * connection under the old fd.  (I.e. effect like BSD accept(2).
 */
{
    static nwio_tcpcl_t tcpcl;
    int afd, nfd;
    char *tcp_device;
    static char toomany[]= "Too many connections\r\n";

    tcpcl.nwtcl_flags= 0;
    if (asyn_ioctl(asyn, fd, NWIOTCPLISTEN, &tcpcl) == -1) return -1;

    asyn_synch(asyn, fd);

    if ((afd= dup(fd)) < 0) {
	if (errno != EMFILE) fatal(tcp_device);
	write(fd, toomany, sizeof(toomany)-1);
    }
    close(fd);
    nfd= net_open(port);
    if (nfd != fd) {
	dup2(nfd, fd);
	close(nfd);
    }
    return afd;
}

static int net_connect(char *host, char *port)
/* Connect to a remote host at a given port. */
{
    struct hostent *he;
    int fd;
    nwio_tcpconf_t tcpconf;
    nwio_tcpcl_t tcpcl;
    int lport;

    if ((he= gethostbyname(host)) == nil) {
	fprintf(stderr, "rterm: %s: Unknown host\n", host);
	quit(1);
    }

    if ((fd= open(tcp_device, O_RDWR)) < 0) fatal(tcp_device);

    /* Bind to a privileged port, the remote side likes that. */
    for (lport= 1023; lport >= 512; lport--) {
	tcpconf.nwtc_flags= NWTC_EXCL | NWTC_LP_SET | NWTC_SET_RA | NWTC_SET_RP;
	memcpy(&tcpconf.nwtc_remaddr, he->h_addr, he->h_length);
	tcpconf.nwtc_locport= htons(lport);
	tcpconf.nwtc_remport= htons(atoi(port));
	if (ioctl(fd, NWIOSTCPCONF, &tcpconf) == 0) break;
	if (errno != EADDRINUSE) fatal(tcp_device);
    }

    tcpcl.nwtcl_flags= 0;
    if (ioctl(fd, NWIOTCPCONN, &tcpcl) < 0) {
	fprintf(stderr, "rterm: Can't connect to %s:%s: %s\n",
		host, port, strerror(errno));
	quit(1);
    }
    return fd;
}

static int net_check(unsigned char *rname, int fd)
/* Make an rsh(1) like check to see if the remote user is allowed in. */
{
    nwio_tcpconf_t tcpconf;
    char ruser[8+1];
    char luser[8+1];

    if (ioctl(fd, NWIOGTCPCONF, &tcpconf) < 0) return 0;
    if (ntohs(tcpconf.nwtc_remport) >= 1024) return 0;
    memcpy(ruser, rname, 8);
    ruser[8]= 0;
    memcpy(luser, name, 8);
    luser[8]= 0;
    if (iruserok(tcpconf.nwtc_remaddr, 0, ruser, luser) != 0) return 0;
    return 1;
}
#endif /* __minix_vmd */

#if __SVR4
/* Solaris specific support code. */

static char pty_device[]= "/dev/ptmx";
static char tty_device[sizeof("/dev/pts/NNN") + 3 * sizeof(int)];

static int grab_pty(void)
/* Look for a free pty. */
{
    int pfd;
    char *tty_name;

    /* Try to open a free pty device and ask the name of the associated tty. */
    if ((pfd= open(pty_device, O_RDWR)) < 0
					|| (tty_name= ptsname(pfd)) == nil) {
	fprintf(stderr, "rterm: Out of ptys\n");
	quit(1);
    }
    strncpy(tty_device, tty_name, sizeof(tty_device));

    if (grantpt(pfd) < 0) {
	fprintf(stderr, "rterm: Failed to get ownership of %s: %s\n",
	    tty_device, strerror(errno));
	quit(1);
    }
    chown(tty_device, uid, -1);
    chmod(tty_device, 0600);
    /* Use mode 0620?  Update /etc/utmp? */

    if (unlockpt(pfd) < 0) {
	fprintf(stderr, "rterm: Failed to unlock %s: %s\n",
	    tty_device, strerror(errno));
	quit(1);
    }
    return pfd;
}

static int net_open(char *port)
/* Open a TCP listening port that remote clients can connect to. */
{
    int fd;
    struct sockaddr_in addr;
    static int on= 1;
    struct protoent *proto;

    if ((fd= socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) fatal("socket()");

    (void) setsockopt(fd, SOL_SOCKET, SO_REUSEADDR | SO_KEEPALIVE,
						(char *) &on, sizeof(on));

    memset(&addr, 0, sizeof(addr));
    addr.sin_family= AF_INET;
    addr.sin_addr.s_addr= htonl(INADDR_ANY);
    addr.sin_port= htons(atoi(port));

    if (bind(fd, (struct sockaddr *) &addr, sizeof(addr)) < 0) fatal("bind()");

    if (listen(fd, 5) < 0) fatal("listen()");

    return fd;
}

static int asyn_accept(asynchio_t *asyn, int fd, char *port)
/* Asynchronously listen for a new client connection. */
{
    int r;

    if (asyn_special(asyn, fd, SEL_READ) < 0) return -1;
    r= r == 0 ? accept(fd, nil, nil) : -1;
    return asyn_result(asyn, fd, SEL_READ, r);
}

static int net_connect(char *host, char *port)
/* Connect to a remote host at a given port. */
{
    struct hostent *he;
    int fd;
    struct sockaddr_in addr;
    int lport;
    static int on= 1;

    if ((he= gethostbyname(host)) == nil) {
	fprintf(stderr, "rterm: %s: Unknown host\n", host);
	quit(1);
    }

    if ((fd= socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) fatal("socket()");

    /* Bind to a privileged port, the remote side likes that. */
    for (lport= 1023; lport >= 512; lport--) {
	memset(&addr, 0, sizeof(addr));
	addr.sin_family= AF_INET;
	addr.sin_addr.s_addr= htonl(INADDR_ANY);
	addr.sin_port= htons(lport);

	if (bind(fd, (struct sockaddr *) &addr, sizeof(addr)) == 0) break;
	if (errno != EADDRINUSE) fatal("Can't bind to privileged port");
    }

    memset(&addr, 0, sizeof(addr));
    addr.sin_family= AF_INET;
    memcpy(&addr.sin_addr.s_addr, he->h_addr, he->h_length);
    addr.sin_port= htons(atoi(port));
    if (connect(fd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
	fprintf(stderr, "rterm: Can't connect to %s:%s: %s\n",
		host, port, strerror(errno));
	quit(1);
    }
    (void) setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, (char *) &on, sizeof(on));
    return fd;
}

static int net_check(unsigned char *rname, int fd)
/* Make an rsh(1) like check to see if the remote user is allowed in. */
{
    struct sockaddr_in addr;
    int addrlen;
    struct hostent *he;
    char ruser[8+1];
    char luser[8+1];

    addrlen= sizeof(addr);
    if (getpeername(fd, (struct sockaddr *) &addr, &addrlen) < 0) return 0;
    if (addr.sin_family != AF_INET) return 0;
    if (ntohs(addr.sin_port) >= 1024) return 0;

    he= gethostbyaddr((void *) &addr.sin_addr, sizeof(addr.sin_addr), AF_INET);
    if (he == nil) return 0;

    memcpy(ruser, rname, 8);
    ruser[8]= 0;
    memcpy(luser, name, 8);
    luser[8]= 0;
    if (ruserok(he->h_name, uid == 0, ruser, luser) != 0) return 0;
    return 1;
}
#endif /* __SVR4 */

typedef enum state {
	AUTH,		/* Must authenticate itself. */
	DENIED,		/* Will be denied access when output drains. */
	ONLINE		/* Fully online. */
} state_t;

typedef struct client {
	struct client	*next;
	int		fd;		/* Descriptor to connected client. */
	state_t		state;		/* Connection state. */
	unsigned char	outbuf[BUFLEN];	/* Output buffer. */
	unsigned	outcount;	/* Number of bytes trying to send. */
	unsigned char	*outp;		/* Position in tty output buffer. */
	unsigned	outleft;	/* Number of bytes left to send. */
	unsigned char	inbuf[BUFLEN];	/* Input keypresses. */
	unsigned	incount;	/* Number of unprocessed input bytes. */
} client_t;

static void server(char *port, char **argv)
/* Grab a pty, execute a command, and let others look on. */
{
    int pfd, net, err[2], exs[2];
    struct { int what, errno; } whaterr;
    client_t *clist, *cp, *owner;
    unsigned char outbuf[TTYLEN];
    unsigned char *outp;
    unsigned outcount, outroom, outseen;
    unsigned char inbuf[BUFLEN];
    unsigned incount;
    ssize_t r;
    asynchio_t asyn;
    time_t keytime;
    static char noperm[]= "Permission denied\r\n";
    int status;
    int afd;

    pfd= grab_pty();
    net= net_open(port);

    if (pipe(err) < 0 || pipe(exs) < 0) fatal("Can't create a pipe");

    fcntl(err[1], F_SETFD, fcntl(err[1], F_GETFD) | FD_CLOEXEC);

#if 1
    /* Fork to slink off into the background. */
    switch (fork()) {
    case -1:	fatal("Can't fork");
    case 0:	/* child! */	break;
    default:
	/* Wait for our exit status. */
	close(pfd);
	close(net);
	close(err[1]);
	close(exs[1]);
	if (read(exs[0], &status, sizeof(status)) != sizeof(status)) status= 1;
	_exit(status);
    }
#endif
    close(exs[0]);
    status= 0;

    /* Fork again to start the command. */
    switch (fork()) {
    case -1:	fatal("Can't fork");
    case 0:
	/* Execute the command connected to the tty end. */
	setgid(gid);
	setuid(uid);
	close(pfd);
	close(net);
	close(err[0]);
	close(exs[1]);
	signal(SIGHUP, SIG_DFL);
	signal(SIGINT, SIG_DFL);
	signal(SIGQUIT, SIG_DFL);
	signal(SIGTERM, SIG_DFL);
#ifdef SIGTTIN
	signal(SIGTTIN, SIG_DFL);
	signal(SIGTTOU, SIG_DFL);
#endif
	signal(SIGPIPE, SIG_DFL);
	close(0);
	close(1);
	close(2);
	setsid();
	if (open(tty_device, O_RDWR) < 0
#if __SVR4
	    || ioctl(0, I_PUSH, "ptem") < 0
	    || ioctl(0, I_PUSH, "ldterm") < 0
	    || ioctl(0, I_PUSH, "ttcompat") < 0
#endif
	) {
	    whaterr.what= 0;
	    whaterr.errno= errno;
	    write(err[1], &whaterr, sizeof(whaterr));
	    _exit(1);
	}
	dup(0);
	dup(0);
	execvp(argv[0], argv);
	whaterr.what= 1;
	whaterr.errno= errno;
	write(err[1], &whaterr, sizeof(whaterr));
	_exit(1);
    }

    /* If executing the command fails then an error description will come down
     * the error pipe, otherwise it will be "closed on exec".  Tell our parent
     * what its exit status should be.
     */
    close(err[1]);
    if (read(err[0], &whaterr, sizeof(whaterr)) != 0) {
	errno= whaterr.errno;
	switch (whaterr.what) {
	case 0:		report(tty_device);	break;
	case 1:		report(argv[0]);	break;
	}
	status= 1;
    }
    close(err[0]);
#if 1
    (void) write(exs[1], &status, sizeof(status));
#endif
    close(exs[1]);
    if (status != 0) exit(status);

#if 1
    /* Detach from the terminal. */
    setsid();
    close(0);
    open("/dev/null", O_RDWR);
    close(1);
#if __minix_vmd
    open("/dev/log", O_RDWR);
#else
    open("/dev/console", O_RDWR|O_NOCTTY);
#endif
    dup2(1, 2);
#endif

    /* Don't die on pipe errors (lost connections.) */
    signal(SIGPIPE, SIG_IGN);

    clist= nil;		/* No clients yet. */
    owner= nil;		/* Noone owning the tty momentarily yet. */
    keytime= 0;		/* No recent keypresses. */
    outp= outbuf;	/* TTY output buffer. */
    outcount= 0;	/* Empty as yet. */
    outseen= 0;		/* Nothing for new clients. */
    incount= 0;		/* No input from remote onlookers yet. */
    asyn_init(&asyn);	/* Asynch administration. */

    for (;;) {
	/* Handle these asynchronous events:
	 *	1.  New clients.
	 *	2.  TTY output from PTY.
	 *	3.  TTY input to PTY.
	 *	4.  Command/output to a client.
	 *	5.  Input from client.
	 */

	/* A new client calling in? */
	if ((afd= asyn_accept(&asyn, net, port)) < 0) {
	    if (errno != ASYN_INPROGRESS) {
		report("Can't accept connection");
		sleep(1);
	    }
	} else {
	    for (cp= clist; cp != nil; cp= cp->next) {
		if (cp->fd == -1) break;
	    }
	    if (cp == nil) {
		cp= malloc(sizeof(*cp));
		if (cp == nil) fatal("Memory problem");
		cp->next= clist;
		clist= cp;
	    }
	    cp->fd= afd;
	    cp->state= AUTH;	/* Who are you? */
	    cp->outcount= 0;
	    cp->outp= outbuf;
	    cp->outleft= 0;
	    cp->incount= 0;
	}

	/* How much output buffer room is there? */
	outroom= arraylimit(outbuf) - outp;
	for (cp= clist; cp != nil; cp= cp->next) {
	    if (cp->fd == -1) continue;
	    if (outroom > TTYLEN - cp->outleft) outroom= TTYLEN - cp->outleft;
	}

	/* Read TTY output. */
	if (outroom > 0) {
	    if ((r= asyn_read(&asyn, pfd, outp, outroom)) < 0) {
		if (errno != ASYN_INPROGRESS) fatal(pty_device);
	    } else
	    if (r == 0) {
		/* EOF on pty, command must have exited. */
		break;
	    } else {
		outcount+= r;
		if ((outseen+= r) > TTYLEN) outseen= TTYLEN;
		if ((outp+= r) >= arraylimit(outbuf)) outp= outbuf;
		for (cp= clist; cp != nil; cp= cp->next) {
		    if (cp->fd == -1) continue;
		    if (cp->state == ONLINE) cp->outleft+= r;
		}
	    }
	}

	/* Write TTY input. */
	if (incount > 0) {
	    if ((r= asyn_write(&asyn, pfd, inbuf, incount)) < 0) {
		if (errno != ASYN_INPROGRESS) fatal(pty_device);
	    } else {
		if ((incount-= r) > 0) memmove(inbuf, inbuf + 2, incount);
	    }
	}

	/* For each client... */
	for (cp= clist; cp != nil; cp= cp->next) {
	    if (cp->fd == -1) continue;

	    /* Get remote keypresses. */
	    if (cp->incount == 0) {
		if ((r= asyn_read(&asyn, cp->fd, cp->inbuf, BUFLEN)) < 0) {
		    if (errno != ASYN_INPROGRESS) {
			asyn_synch(&asyn, cp->fd);
			close(cp->fd);
			cp->fd= -1;
			continue;
		    }
		} else
		if (r == 0) {
		    /* Remote client checked out. */
		    asyn_synch(&asyn, cp->fd);
		    close(cp->fd);
		    cp->fd= -1;
		    continue;
		} else {
		    cp->incount= r;
		}
	    }

	    /* Copy client input to the TTY input buffer. */
	    if (incount == 0 && cp->incount > 0 && cp->inbuf[0] != DLE
							&& cp->outcount == 0) {
		unsigned char *dle;
		unsigned n= cp->incount;
		time_t now= time(nil);

		/* Any commands further down? */
		if ((dle= memchr(cp->inbuf, DLE, n)) != nil) {
		    /* Only copy bytes up to the DLE. */
		    n= dle - cp->inbuf;
		}

		/* Is this client the current owner? */
		if (now < keytime + EXCL_TIME && owner != cp) {
		    /* Someone tries to interfere! */
		    cp->outbuf[0]= DLE;
		    cp->outbuf[1]= BEEP;
		    cp->outcount= 2;
		} else {
		    if (cp->state == ONLINE) {
			/* Copy client input to the TTY input buffer. */
			memcpy(inbuf, cp->inbuf, n);
			incount= n;
			keytime= now;
			owner= cp;
		    }
		}
		if ((cp->incount-= n) > 0) {
		    memmove(cp->inbuf, cp->inbuf + n, cp->incount);
		}
	    }

	    /* Handle client commands. */
	    if (incount == 0 && cp->incount > 0 && cp->inbuf[0] == DLE
							&& cp->outcount == 0) {
		unsigned cmdsize= 2;

		/* Command size. */
		if (cp->incount >= 2) {
		    switch (cp->inbuf[1]) {
		    case REPWINZ:
			cmdsize+= sizeof(struct winsize);
			break;
		    case NAME:
			cmdsize+= 8;
		    }
		}

		if (cp->incount < cmdsize) {
		    if ((r= asyn_read(&asyn, cp->fd, cp->inbuf + cp->incount,
						BUFLEN - cp->incount)) < 0) {
			if (errno != ASYN_INPROGRESS) {
			    asyn_synch(&asyn, cp->fd);
			    close(cp->fd);
			    cp->fd= -1;
			    continue;
			}
		    } else {
			if (r == 0) {			/* EOF? */
			    /* Remote client checked out. */
			    asyn_synch(&asyn, cp->fd);
			    close(cp->fd);
			    cp->fd= -1;
			    continue;
			}
			cp->incount+= r;
		    }
		} else {
		    /* Do the command. */
		    switch (cp->inbuf[1]) {
		    case DLE:	/* DLE DLE -> DLE */
			inbuf[0]= DLE;
			incount= 1;
			break;
		    case NAME:
			asyn_synch(&asyn, cp->fd);
			if (!net_check(cp->inbuf+2, cp->fd)) {
			    cp->state= DENIED;
			    memcpy(cp->outbuf, noperm, sizeof(noperm)-1);
			    cp->outcount= sizeof(noperm)-1;
			} else {
			    cp->state= ONLINE;
			    cp->outp= outbuf + (TTYLEN + (outp-outbuf)
							- outseen) % TTYLEN;
			    cp->outleft= outseen;
			}
			break;
		    default:	/* Unexpected command! */
			asyn_synch(&asyn, cp->fd);
			close(cp->fd);
			cp->fd= -1;	/* Tell 'em to get lost. */
			continue;
		    }

		    /* Discard command if done. */
		    if (cmdsize > 0 && (cp->incount-= cmdsize) > 0) {
			memmove(cp->inbuf, cp->inbuf + cmdsize, cp->incount);
		    }
		}
	    }

	    /* Any new output to send to the remote end? */
	    if (cp->outcount == 0) {
		while (cp->outleft > 0 && cp->outcount < BUFLEN) {
		    if (*cp->outp == DLE) {
			/* DLE -> DLE DLE */
			if (cp->outcount == BUFLEN-1) break;
			cp->outbuf[cp->outcount++] = DLE;
		    }
		    cp->outbuf[cp->outcount++] = *cp->outp++;
		    if (cp->outp == arraylimit(outbuf)) cp->outp= outbuf;
		    cp->outleft--;
		}
	    }

	    /* Send output to remote client. */
	    if (cp->outcount > 0) {
		if ((r= asyn_write(&asyn, cp->fd, cp->outbuf,
							cp->outcount)) < 0) {
		    if (errno != ASYN_INPROGRESS) {
			asyn_synch(&asyn, cp->fd);
			close(cp->fd);
			cp->fd= -1;
			continue;
		    }
		} else {
		    if ((cp->outcount-= r) > 0) {
			memmove(cp->outbuf, cp->outbuf + r, cp->outcount);
		    } else {
			if (cp->state == DENIED) {
			    /* Alas you failed the access check, goodbye. */
			    asyn_synch(&asyn, cp->fd);
			    close(cp->fd);
			    cp->fd= -1;
			    continue;
			}
		    }
		}
	    }
	}

	/* Wait for something to happen. */
	if (asyn_wait(&asyn, 0, nil) < 0) {
	    if (errno != EINTR) fatal("asyn_wait()");
	}
    }
}

static void trap(int sig)
{
    if (tty_changed) {
	(void) tcsetattr(0, TCSAFLUSH, &oldterm);
#if __SVR4
	/* O_NONBLOCK had better be cleared, it's a file flag, not an fd flag.
	 */
	fcntl(0, F_SETFL, fcntl(0, F_GETFL) & ~O_NONBLOCK);
	fcntl(1, F_SETFL, fcntl(1, F_GETFL) & ~O_NONBLOCK);
#endif
    }
    signal(sig, SIG_DFL);
    raise(sig);
    exit(1);
}

static void client(char *host, char *port)
{
    int net;
    asynchio_t asyn;
    unsigned char outbuf[BUFLEN];
    unsigned outcount;
    unsigned char inbuf[BUFLEN];
    unsigned incount;
    ssize_t r;

    /* Connect to an rterm server. */
    net= net_connect(host, port);

    /* No need for root privs from this point on. */
    setgid(gid);
    setuid(uid);

    if (tcgetattr(0, &oldterm) < 0) fatal("Can't obtain terminal attributes");

    if (signal(SIGHUP, SIG_IGN) != SIG_IGN) signal(SIGHUP, trap);
    if (signal(SIGINT, SIG_IGN) != SIG_IGN) signal(SIGINT, trap);
    if (signal(SIGTERM, SIG_IGN) != SIG_IGN) signal(SIGTERM, trap);

    /* Change the terminal to an 8-bit clean connection. */
    newterm= oldterm;
    newterm.c_iflag &= ~(ICRNL|IGNCR|INLCR|IXON|IXOFF);
    newterm.c_oflag &= ~(OPOST);
    newterm.c_lflag &= ~(ECHO|ECHONL|ICANON|ISIG);
    newterm.c_cc[VMIN]= 1;
    newterm.c_cc[VTIME]= 0;
    tty_changed= 1;
    if (tcsetattr(0, TCSANOW, &newterm) < 0)
	fatal("Can't change terminal attributes");

    inbuf[0]= DLE;	/* Initial "keyboard" input is my name. */
    inbuf[1]= NAME;
    memcpy(inbuf+2, name, 8);
    incount= 10;
    outcount= 0;	/* Nothing to show the user yet. */
    asyn_init(&asyn);	/* Asynch administration. */

    for (;;) {
	/* Handle these asynchronous events:
	 *	1.  Remote server to outbuf.
	 *	2.  Outbuf to user.
	 *	3.  User input to inbuf.
	 *	4.  Inbuf to remote server.
	 *	5.  Commands from the server.
	 */

	/* Any output from the remote server? */
	if (outcount == 0) {
	    if ((r= asyn_read(&asyn, net, outbuf, BUFLEN)) < 0) {
		if (errno != ASYN_INPROGRESS) fatal("Input from remote server");
	    } else {
		if (r == 0) {			/* EOF! */
		    fprintf(stderr, "rterm: Connection closed\r\n");
		    break;
		}
		outcount= r;
	    }
	}

	/* Show output to the user. */
	if (outcount > 0 && outbuf[0] != DLE) {
	    unsigned char *dle;
	    unsigned n= outcount;

	    /* Any commands further down? */
	    if ((dle= memchr(outbuf, DLE, n)) != nil) {
		/* Only show bytes up to the DLE. */
		n= dle - outbuf;
	    }

	    if ((r= asyn_write(&asyn, 1, outbuf, n)) < 0) {
		if (errno != ASYN_INPROGRESS) fatal("TTY output");
	    } else {
		if ((outcount-= r) > 0) memmove(outbuf, outbuf + r, outcount);
	    }
	}

	/* Handle commands. */
	if (outcount > 0 && outbuf[0] == DLE && incount == 0) {
	    unsigned cmdsize= 2;

	    /* Command size. */
	    if (outcount >= 2) {
		switch (outbuf[1]) {
		case REPWINZ:
		    cmdsize+= sizeof(struct winsize);
		    break;
		}
	    }

	    if (outcount < cmdsize) {
		if ((r= asyn_read(&asyn, net, outbuf + outcount,
						BUFLEN - outcount)) < 0) {
		    if (errno != ASYN_INPROGRESS) {
			fatal("Input from remote server");
		    }
		} else {
		    if (r == 0) {			/* EOF? */
			fprintf(stderr, "rterm: Connection closed\r\n");
			break;
		    }
		    outcount+= r;
		}
	    } else {
		/* Do the command. */
		switch (outbuf[1]) {
		case BEEP:	/* Beep command, no arguments. */
		    (void) write(2, "\a", 1);
		    break;
		case GETWINZ:	/* Please report window size. */
		    (void) ioctl(2, TIOCGWINSZ, &winsize);
		    outbuf[0]= DLE;
		    outbuf[1]= REPWINZ;
		    memcpy(outbuf+2, &winsize, sizeof(winsize));
		    outcount= 2 + sizeof(winsize);
		    break;
		case DLE:	/* DLE DLE -> DLE */
		    if ((r= asyn_write(&asyn, 1, outbuf+1, 1)) < 0) {
			if (errno != ASYN_INPROGRESS) fatal("TTY output");
			/* Not done yet. */
			cmdsize= 0;
		    }
		    break;
		default:	/* Unexpected command! */
		    abort();
		    break;
		}

		/* Discard command if done. */
		if (cmdsize > 0 && (outcount-= cmdsize) > 0) {
		    memmove(outbuf, outbuf + cmdsize, outcount);
		}
	    }
	}

	/* User input? */
	if (incount == 0) {
	    if ((r= asyn_read(&asyn, 0, inbuf, 1)) < 0) {
		if (errno != ASYN_INPROGRESS) fatal("TTY input");
	    } else {
		if (r == 0) break;	/* EOF? */
		incount= 1;
		if (inbuf[0] == DLE) {	/* DLE -> DLE DLE */
		    inbuf[1]= DLE;
		    incount= 2;
		}
	    }
	}

	/* Send user input to the remote server. */
	if (incount > 0) {
	    if ((r= asyn_write(&asyn, net, inbuf, incount)) < 0) {
		if (errno != ASYN_INPROGRESS) fatal("Output to remote server");
	    } else {
		if ((incount-= r) > 0) memmove(inbuf, inbuf + r, incount);
	    }
	}

	/* Wait for something to happen. */
	if (asyn_wait(&asyn, 0, nil) < 0) {
	    if (errno != EINTR) fatal("asyn_wait()");
	}
    }
    quit(0);
}

static void usage(void)
{
    fprintf(stderr, "Usage: rterm -e port command [arg ...]\n"
	    "       rterm [host] port\n");
    exit(1);
}

int main(int argc, char **argv)
{
    int i;
    int eflag= 0;
    struct passwd *pwd;
    struct utsname uts;

    uid= getuid();
    gid= getgid();
    setuid(0);
#if __minix_vmd
    if ((tcp_device= getenv("TCP_DEVICE")) == nil) tcp_device= TCP_DEVICE;
#endif

    /* The remote end will want to know the caller's name. */
    if ((pwd= getpwuid(uid)) == nil) {
	fprintf(stderr, "rterm: You do not seem to exist!?\n");
	exit(1);
    }
    strncpy((char *) name, pwd->pw_name, 8);

    i= 1;
    while (i < argc && argv[i][0] == '-') {
	char *opt= argv[i++] + 1;

	if (opt[0] == '-' && opt[1] == 0) break;	/* -- */

	while (*opt != 0) switch (*opt++) {
	case 'e':	eflag= 1;	break;
	default:	usage();
	}
    }

    if (eflag && (argc - i) >= 2) {
	/* Run a program then serve remote onlookers. */
	server(argv[i], argv+i+1);
    } else
    if (!eflag && (argc - i) == 1) {
	/* Connect to a local rterm. */
	if (uname(&uts) < 0) fatal("uname()");
	client(uts.nodename, argv[i]);
    } else
    if (!eflag && (argc - i) == 2) {
	/* Connect to a remote rterm. */
	client(argv[i], argv[i+1]);
    } else {
	usage();
    }
    return 0;
}

#!/bin/sh
#
#	whatis2windex 1.0 - change a whatis(5) to a windex(5) database.
#							Author: Kees J. Bot

case $# in
[01])	;;
*)	echo "Usage: whatis2windex [whatis-file]" >&2
	exit 1
esac

ifs="$IFS"

sed -e 's/\([^(]*\)(\([^)]*\)) *- *\(.*\)/\1\\\2\\\3/' "$@" | \
while read whatis
do
	IFS='\'
	set -$- $whatis
	list="$1"; section="$2"; explanation="$3"
	IFS=', '
	set -$- $list
	page="$1"
	IFS="$ifs"

	for key
	do
		case $key in
		?*)	echo "$key	$page ($section)	- $explanation"
		esac
	done
done | sort

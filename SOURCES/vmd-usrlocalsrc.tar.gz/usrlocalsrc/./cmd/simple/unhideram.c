/*	unhideram 1.3 - Remove everything on the RAM disk that is hidden
 *			for this architecture.		Author: Kees J. Bot
 */
#define nil 0
#define _MINIX 1
#define _POSIX_SOURCE 1
#include "sys/types.h"
#include "sys/utsname.h"
#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"
#include "errno.h"
#include "string.h"
#include "dirent.h"
#include "limits.h"
#define _TRANSPARENT 1
#include "sys/stat.h"

#define DEV_RAM	((dev_t) 0x100)

void report(const char *label)
{
	const char *errstr= strerror(errno);

	write(2, "unhideram: ", 11);
	write(2, label, strlen(label));
	write(2, errstr, strlen(errstr));
	write(2, "\n", 1);
}

void fatal(const char *label)
{
	report(label);
	exit(1);
}

char TMPH[] = "/\377\377\377";		/* Hidden file in transit. */

/* Names for different types of hiding: */
struct utsname utsname;
char *hidden[_UTS_MAX] = {
	utsname.arch,
	utsname.kernel,
	utsname.machine,
	utsname.hostname,
	utsname.nodename,
	utsname.release,
	utsname.version,
	utsname.sysname,
};

/* Path name construction, addpath adds a component, delpath removes it. */

char path[PATH_MAX+1], *pp= path;	/* Path name constructed in path. */
char *del[PATH_MAX/2+1], **dpp= del;	/* Record 'how to go back' in del. */

int addpath(const char *name)
/* Add a component to path. (name may also be a full path at the first call) */
{
	int n= strlen(name);

	if (pp - path + 1 + n > PATH_MAX) return 0;

	*dpp++ = pp;	/* Record point to go back to for delpath. */

	if (pp > path && pp[-1] != '/') *pp++ = '/';

	memcpy(pp, name, n+1);
	pp+= n;

	return 1;
}

#define delpath()	(*(pp= *--dpp) = 0)	/* Remove component. */

int rm_r(void)
{
	DIR *dp;
	struct dirent *ent;
	struct stat st;
	int r= 1;

	if ((dp= opendir(path)) == nil) return 0;

	while ((ent= readdir(dp)) != nil) {
		if (strcmp(ent->d_name, ".") == 0) continue;
		if (strcmp(ent->d_name, "..") == 0) continue;

		if (!addpath(ent->d_name)) { r= 0; continue; }

		if (stat(path, &st) < 0)
			r= 0;
		else
		if (S_ISDIR(st.st_mode)) {
			if (!rm_r()) r= 0;
		} else {
			if (unlink(path) < 0) r= 0;
		}
		delpath();
	}
	closedir(dp);

	return r && rmdir(path) >= 0;
}

void unhide(void)
{
	struct stat st;

	if (stat(path, &st) < 0 || st.st_dev != DEV_RAM || !S_ISDIR(st.st_mode))
		return;

	if (S_ISHIDDEN(st.st_mode)) {
		/* This thing needs unhiding. */
		const char *name= hidden[st.st_mode & S_HTYPE];
		int removed;

		if ((st.st_mode & S_HTYPE) >= _UTS_MAX) return;  /* Bad... */

		name= hidden[st.st_mode & S_HTYPE];

		if (!addpath(name)) return;
		if (rename(path, TMPH) < 0 && errno != ENOENT) {
			report(path);
			delpath();
			return;
		}
		delpath();

		removed= rm_r();	/* Remove all other arch's files. */

		if (!removed) (void) addpath(name);
		if (rename(TMPH, path) < 0 && errno != ENOENT) {
			report(path);
			if (!removed) delpath();
			return;
		}
		unhide();	/* Unhide the file further. */
		if (!removed) delpath();
	} else {
		/* Ordinary directory. */
		DIR *dp;
		struct dirent *ent;

		if ((dp= opendir(path)) == nil) return;

		while ((ent= readdir(dp)) != nil) {
			if (strcmp(ent->d_name, ".") == 0) continue;
			if (strcmp(ent->d_name, "..") == 0) continue;

			if (addpath(ent->d_name)) {
				unhide();
				delpath();
			}
		}
		closedir(dp);
	}
}

main(void)
{
	int h;

	/* Get the uname(3) info. */
	if (uname(&utsname) < 0) fatal("gethostname()");

	(void) addpath("/.@");
	unhide();
	exit(0);
}
/* Kees J. Bot  27-4-91. */

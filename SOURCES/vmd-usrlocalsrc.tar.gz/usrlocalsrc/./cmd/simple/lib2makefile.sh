#!/bin/sh
#
# lib2makefile 1.2 - From a set of sources to a library makefile
#							Author: Kees J. Bot

cat <<EOF
# Makefile for `pwd | sed 's:^/usr/src/::'`.

CC	= false
ARCH	= eniac
CFLAGS	= -O9
CC1	= \$(CC) -m\$(ARCH) \$(CFLAGS) -c
MAKE	= exec make -\$(MAKEFLAGS) CC=\$(CC) ARCH=\$(ARCH)

LIBRARY	= /usr/lib/\$(CC)/\$(ARCH)/libc.a
MAN	= /usr/man

all:	\$(LIBRARY) man

OBJECTS	= \\
EOF

for i
do
	case "$i" in *.[0-9]*) continue;; esac

	base="`expr "$i" : '\\(.*\\)\\.[^.][^.]*'`" || {
		echo "lib2makefile: $i???" >&2
		exit 1
	}
	echo "	\$(LIBRARY)($base.o) \\"
done

cat <<\EOF

$(LIBRARY):	$(OBJECTS)
	$(CC) -c.a -o $@ *.o
	rm *.o
EOF

for i
do
	case "$i" in *.[0-9]*) continue;; esac

	base="`expr "$i" : '\\(.*\\)\\.[^.][^.]*'`"
	echo "
\$(LIBRARY)($base.o):	$i
	\$(CC1) $i"
done

cat <<\EOF

man:	\
EOF

for i
do
	case "$i" in *.[0-9]*) ;; *) continue;; esac

	section="`expr "$i" : '.*\\.\\([^.][^.]*\\)'`"
	echo "	\$(MAN)/man$section/$i \\"
done | sort

for i
do
	case "$i" in *.[0-9]*) ;; *) continue;; esac

	section="`expr "$i" : '.*\\.\\([^.][^.]*\\)'`"
	echo "\$(MAN)/man$section/$i:	$i	install -lc \$? \$@"
done | sort | tr '\1' '\12'

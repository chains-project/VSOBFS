/*	bincheck 1.0 - Check out contents of hidden bin dirs.
 *#C	>$:1
 *#C	$CC -o $:1 $1
 */
#define nil 0
#include <stdio.h>
#include <sys/types.h>
#include <stddef.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <a.out.h>
#if __minix_vmd
#include <sys/utsname.h>
#define S_ARCH	_UTS_ARCH
#endif

#define arraysize(a)	(sizeof(a) / sizeof((a)[0]))

void report(const char *mess)
{
	int e= errno;
	fprintf(stderr, "bincheck: ");
	fflush(stderr);
	errno= e;
	perror(mess);
}

void fatal(const char *mess)
{
	report(mess);
	exit(1);
}

void enomem(void)
{
	fprintf(stderr, "bincheck: Out of memory\n");
	exit(1);
}

unsigned hash(const char *s)
/* Simple string hash function. */
{
	unsigned h= 0;

	while (*s != 0) h= (h * 0x1111) + *s++;

	return h;
}

struct file {
	struct file *next;
	char *name;
} *flist[500];

void insertname(const char *name)
/* Put name in a hash bucket in reverse sorted order.  Reversed, because
 * if names have any order in directories, then it is sorted by name, which
 * inserts faster this way.
 */
{
	struct file **af, *f;
	int cmp= -1;

	af= &flist[hash(name) % arraysize(flist)];

	while (*af != nil && (cmp= strcmp(name, (*af)->name)) < 0)
		af= &(*af)->next;

	if (cmp == 0) return;		/* name already listed. */

	if ((f= (struct file *) malloc(sizeof(*f))) == nil
	    || (f->name= (char *) malloc((strlen(name) + 1) * sizeof(char)))
									== nil
	) enomem();

	strcpy(f->name, name);
	f->next= *af;
	*af= f;
}

struct file *collectnames(void)
/* Merge the hash list in one forward sorted list.  The sorting is only
 * done to please the eye.  At exit the hash list is ready for re-use.
 */
{
	int i, j;

	/* Merge the hashbuckets pairwise, until you have just one. */
	j= arraysize(flist) - 1;

	do {
		i= 0;
		while (i < j) {
			struct file **afi= &flist[i];
			struct file   *fj=  flist[j];

			while (fj != nil) {
				if (*afi == nil
					|| strcmp((*afi)->name, fj->name) < 0
				) {
					struct file *t= fj;
					fj= fj->next;
					t->next= *afi;
					*afi= t;
				}
				afi= &(*afi)->next;
			}
			i++;
			flist[j--]= nil;
		}
	} while (j > 0);

	{	/* Don't forget to reverse. */
	struct file *n= nil;
	struct file *f= flist[0];
	flist[0]= nil;

	while (f != nil) {
		struct file *t= f;
		f= f->next;
		t->next= n;
		n= t;
	}
	return n;
}}

void listdir(const char *dir)
/* Call insertname for all the names in a directory. */
{
	DIR *d;
	struct dirent *e;

	if ((d= opendir(dir)) == nil) fatal(dir);

	while ((e= readdir(d)) != nil) {
		if (strcmp(e->d_name, ".") != 0 && strcmp(e->d_name, "..") != 0)
			insertname(e->d_name);
	}
	(void) closedir(d);
}

enum filetype { NOENT, NONFILE, BINARY, SCRIPT };

enum filetype filetype(const char *name, struct stat *stp)
{
	struct exec hdr;
	int f, n;

	if (stat(name, stp) < 0) {
		if (errno == ENOENT) return NOENT;
		fatal(name);
	}
	if (!S_ISREG(stp->st_mode)) return NONFILE;

	if ((f= open(name, O_RDONLY)) < 0
		|| (n= read(f, (char *) &hdr, (int) sizeof(hdr))) < 0
	) fatal(name);

	close(f);

	return n < sizeof(hdr) || BADMAG(hdr) ? SCRIPT : BINARY;
}

int yes(void)
{
	int y, c;

	fflush(stdout);

	while ((c= getchar()) == ' ' || c == '\t') {}

	y= c == 'y';

	while (c != EOF && c != '\n') c= getchar();

	if (c == EOF) {
		fprintf(stderr, "bincheck: Unexpected EOF\n");
		exit(1);
	}
	return y;
}

/*	void path_init(struct pathname *);
 *	void path_add(struct pathname *, size_t *didx, const char *name);
 *	void path_delete(struct pathname *, size_t didx);
 *	const char *path_name(const struct pathname *);
 *	size_t path_length(const struct pathname *);
 *	void path_drop(struct pathname *);
 *
 *	Needs stddef.h, string.h, and an enomem() function.
 *	(And a C++ compiler for an approach with more class.)
 */

struct pathname {
	char		*path;	/* The actual pathname. */
	size_t	idx;	/* Index for the terminating null byte. */
	size_t	lim;	/* Actual length of the path array. */
};

const char UNCOVER[] = "@";	/* To uncover hidden directories. */

void path_init(struct pathname *pp)
{
	if ((pp->path= (char *) malloc(pp->lim= 16)) == NULL) enomem();
	pp->path[pp->idx= 0]= 0;
}

void path_add(struct pathname *pp, size_t *didx, const char *name)
{
	size_t lim;
	char *p;

	*didx = pp->idx;   /* Record point to go back to for path_delete. */

	lim= pp->idx + strlen(name) + 2;

	if (lim > pp->lim) {
		pp->lim= lim += lim/2;	/* add an extra 50% growing space. */

		if ((pp->path= (char *) realloc((void *) pp->path,
							lim)) == NULL) enomem();
	}

	p= pp->path + pp->idx;
	if (p > pp->path && name != UNCOVER) *p++ = '/';

	while (*name != 0) {
		if (*name != '/' || p == pp->path || p[-1] != '/')
			*p++ = *name;
		name++;
	}
	*p = 0;
	pp->idx= p - pp->path;
}

void path_delete(struct pathname *pp, size_t didx)
{
	pp->path[pp->idx= didx]= 0;
}

const char *path_name(const struct pathname *pp)
{
	return pp->path;
}

size_t path_length(const struct pathname *pp)
{
	return pp->idx;
}

void path_drop(struct pathname *pp)
{
	free((void *) pp->path);
}

#define path_name(pp)		((const char *) (pp)->path)
#define path_length(pp)		((pp)->idx)
#define path_drop(pp)		free((void *) (pp)->path)

void main(int argc, char **argv)
{
	struct stat st;
	struct pathname bindir;
	struct file *archlist, *binlist, *al, *bl;
	size_t didx, dummy;

	if (argc != 2) {
		fprintf(stderr, "Usage: bincheck bindir\n");
		exit(1);
	}

	path_init(&bindir);
	path_add(&bindir, &dummy, argv[1]);
	if (argv[1][0] != 0 && argv[1][strlen(argv[1]) - 1] != '@')
		path_add(&bindir, &dummy, UNCOVER);

	if (stat(path_name(&bindir), &st) < 0) fatal(path_name(&bindir));

	if (!S_ISDIR(st.st_mode) || (st.st_mode & S_HTYPE) != S_ARCH) {
		fprintf(stderr,
		    "bincheck: %s is not a by architecture hidden directory\n",
			path_name(&bindir)
		);
		exit(1);
	}
	listdir(path_name(&bindir));
	archlist= collectnames();

	for (al= archlist; al != nil; al= al->next) {
		path_add(&bindir, &didx, al->name);
		listdir(path_name(&bindir));
		path_delete(&bindir, didx);
	}
	binlist= collectnames();

	for (bl= binlist; bl != nil; bl= bl->next) {
		const char *newest= nil;
		time_t newtime;
		dev_t dev;
		ino_t ino;
		struct pathname script;

		for (al= archlist; al != nil; al= al->next) {
			path_add(&bindir, &didx, al->name);
			path_add(&bindir, &dummy, bl->name);

			if (filetype(path_name(&bindir), &st) == SCRIPT
				&& (newest == nil || st.st_mtime > newtime)
			) {
				newest= al->name;
				newtime= st.st_mtime;
				dev= st.st_dev;
				ino= st.st_ino;
			}
			path_delete(&bindir, didx);
		}
		if (newest == nil) continue;

		path_init(&script);
		path_add(&script, &dummy, path_name(&bindir));
		path_add(&script, &dummy, newest);
		path_add(&script, &dummy, bl->name);

		for (al= archlist; al != nil; al= al->next) {
			int veto= 0;

			if (al->name == newest) continue;

			path_add(&bindir, &didx, al->name);
			path_add(&bindir, &dummy, bl->name);

			switch (filetype(path_name(&bindir), &st)) {
			case NOENT:
				printf("Install %s? ", path_name(&bindir));
				break;
			case NONFILE:
				printf("%s is not a file\n",
					path_name(&bindir));
				veto= 1;
				break;
			case BINARY:
				printf("Replace binary %s with script %s? ",
					path_name(&bindir), path_name(&script)
				);
				break;
			case SCRIPT:
				if (st.st_dev == dev && st.st_ino == ino)
					veto= 1;
				else
				printf(
				    "Replace script %s with newer script %s? ",
					path_name(&bindir), path_name(&script)
				);
			}
			if (!veto && yes() && (
				(unlink(path_name(&bindir)) < 0
					&& errno != ENOENT
				) ||
				link(path_name(&script), path_name(&bindir)) < 0
			)) fatal(path_name(&bindir));

			path_delete(&bindir, didx);
		}
		path_drop(&script);
	}
	exit(0);
}
/* Kees J. Bot 8-12-91. */

#!/bin/sh
#
#	p 1.1 - favourite editor and pager		Author: Kees J. Bot
#								13 Jul 1996

case $0 in
*e)	prog=${EDITOR-vi}
	;;
*e4)	exec vi +'set sw=4' "$@"
	;;
*e8)	exec vi +'set sw=8' "$@"
	;;
*p)	prog=${PAGER-more}
	;;
*)	echo "$0? Don't know what to do!" >&2; exit 1
esac

exec $prog "$@"

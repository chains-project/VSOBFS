/*	htmlpp - HTML preprocessor.			Author: Kees J. Bot
 *								24 Oct 1997
 */
static char version[]= "2.5";

#define nil	0
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <limits.h>
#include <assert.h>
#include <errno.h>

/* Do we have Posix extensions? */
#define POSIX	(defined(_POSIX_SOURCE) || _POSIX_C_SOURCE >= 1)

#if POSIX
#include <sys/types.h>
#include <pwd.h>
#endif

#define MAX_OBJECTS	50000		/* Max # objects allocated. */

#ifndef ROOT
static char ROOT[]= "/usr/local/www";	/* Document root. */
#endif
#ifndef HSUB
static char HSUB[]= "www";		/* User home page subdirectory. */
#endif

static char DEPFILE[]= "HTMLPP_DEPEND";	/* Dependency file name env var. */

#define arraysize(a)	  (sizeof(a) / sizeof((a)[0]))
#define arraylimit(a)	  ((a) + arraysize(a))
#define between(a, c, z)  ((unsigned) ((c)-(a)) <= (unsigned) ((z)-(a)))

static char *program;		/* Call name. */

static int suppress;			/* -s: Suppress initial banner. */

static void report(const char *label)
{
    if (label == nil || *label == 0) {
	fprintf(stderr, "%s: %s\n", program, strerror(errno));
    } else {
	fprintf(stderr, "%s: %s: %s\n", program, label, strerror(errno));
    }
}

static void fatal(const char *label)
{
    report(label);
    exit(1);
}

/* Need a ctype that is HTML(PP) oriented, and not botched up by locales. */
static unsigned char ctype_[UCHAR_MAX+1];

#define	C_CTRL		0x01
#define	C_SPACE		0x02
#define	C_DIGIT		0x04
#define	C_XDIGIT	0x08
#define	C_LETTER	0x10
#define	C_DOLLAR	0x20
#define	C_DOT		0x40
#define	C_DASH		0x80

#define ctype(c)	((int) ctype_[(unsigned char)(c)])
#define	istest(c,t)	((ctype(c) & (t)) != 0)
#define	iscntrl(c)	istest((c), C_CTRL)
#define	isspace(c)	istest((c), C_SPACE)
#define	isdigit(c)	istest((c), C_DIGIT)
#define	isxdigit(c)	istest((c), C_DIGIT | C_XDIGIT)
#define	isupper(c)	between('A', (c), 'Z')
#define	islower(c)	between('a', (c), 'z')
#define	isalpha(c)	istest((c), C_LETTER)
#define	isalnum(c)	istest((c), C_LETTER | C_DIGIT)
#define	isattr1(c)	istest((c), C_LETTER | C_DOT)
#define	isattr(c)	istest((c), C_LETTER | C_DIGIT | C_DOT | C_DASH)
#define	toupper(c)	((c) & ~0x20)
#define	tolower(c)	((c) |  0x20)

static void init_ctype(void)
{
    int c;

    for (c= '\000'; c <= '\037'; c++) ctype_[c] |= C_CTRL;
    ctype_[0177] |= C_CTRL;

    for (c= '\t'; c <= '\r'; c++) ctype_[c] |= C_SPACE;
    ctype_[' '] |= C_SPACE;

    for (c= '0'; c <= '9'; c++) ctype_[c] |= C_DIGIT;
    for (c= 'A'; c <= 'F'; c++) ctype_[c] |= C_XDIGIT;
    for (c= 'a'; c <= 'f'; c++) ctype_[c] |= C_XDIGIT;
    for (c= 'A'; c <= 'Z'; c++) ctype_[c] |= C_LETTER;
    for (c= 'a'; c <= 'z'; c++) ctype_[c] |= C_LETTER;

    ctype_['$'] |= C_DOLLAR;
    ctype_['.'] |= C_DOT;
    ctype_['-'] |= C_DASH;
}

/* Memory allocation with reference counters, destructors, failure and leak
 * check.
 */

typedef struct m_header {	/* Header in front of each allocated thing. */
	union {
	    size_t refc;		/* Reference count */
	    void *dying;		/* List of objects not entirely gone */
	} h;
	void	*(*destruct)(void *);	/* Object destructor */
	union {
	    long l;
	    double d;
	    void *p;
	    void (*f)(void);
	} d;				/* Alignment of d should suit any. */
} m_head_t;

/* From memory to header and vv. */
#define m_hsize()	offsetof(struct m_header, d)
#define m_head(p)	((struct m_header *)((char *) (p) - m_hsize()))
#define m_data(p)	((void *)((char *) (p) + m_hsize()))

static size_t m_objcount= 0;

static void *new(size_t size, void *(*destruct)(void *))
/* Allocate memory, give it 1 reference and set the destructor function. */
{
    void *mem;

    mem= malloc(m_hsize() + size);
    if (mem == nil) fatal(nil);
    if (++m_objcount >= MAX_OBJECTS) {
	fprintf(stderr, "%s: Maximum memory use of %u objects reached\n",
	    program, MAX_OBJECTS);
	exit(1);
    }
    mem= m_data(mem);
    m_head(mem)->h.refc= 1;
    m_head(mem)->destruct= destruct;
    return mem;
}

static void *inc(void *mem)
/* Let one more pointer share an object. */
{
    if (mem != nil) m_head(mem)->h.refc++;
    return mem;
}

static void *dec(void *mem, void *next)
/* Drop one reference to an object and destroy it if it was the last.  With
 * 'next' one can specify a pointer within the object that is to be followed,
 * i.e. p= dec(p, p->next).  Simple dereference uses next = nil.  To undo
 * the references held within the object the destructor is called to find
 * pointers within the object that are still pointing somewhere.  All these
 * shenanigans are just to avoid recursion into possibly deep lists.
 */
{
    void *junk;
    void *dying= nil;

    if (next != nil) m_head(next)->h.refc++;

    for (;;) {
	if (mem != nil && --m_head(mem)->h.refc == 0) {
	    if (m_head(mem)->destruct == nil) {
		junk= nil;
	    } else {
		junk= (*m_head(mem)->destruct)(mem);
	    }
	    if (junk == nil) {
		free(m_head(mem));
		m_objcount--;
	    } else {
		m_head(mem)->h.dying= dying;
		dying= mem;
	    }
	    mem= junk;
	} else {
	    for (;;) {
		if (dying == nil) return next;

		mem= (*m_head(dying)->destruct)(dying);
		if (mem != nil) break;
		dying= m_head(junk= dying)->h.dying;
		free(m_head(junk));
		m_objcount--;
	    }
	}
    }
}

static char *copystr(const char *s)
{
    char *c;
    c= new((strlen(s)+1) * sizeof(*c), nil);
    strcpy(c, s);
    return c;
}

static char *refer(char *base, char *ref)
/* Refer from one file to another file by <#include src="ref">. */
{
    char *file;
    size_t len;
    char *p;
    int c;

    file= nil;

    if (ref[0] == '/') {
	if (ref[1] == '~') {
	    for (p= ref+2; *p != 0 && *p != '/'; p++) {}

	    if (p > ref+2) {				/* /~name... */
#if POSIX
		struct passwd *pw;
		c= *p;
		*p= 0;
		pw= getpwnam(ref+2);
		*p= c;
		if (pw != nil) {
		    len= strlen(pw->pw_dir) + 1 + sizeof(HSUB) + strlen(p);
		    file= new(len * sizeof(file[0]), nil);
		    strcpy(file, pw->pw_dir);
		    strcat(file, "/");
		    strcat(file, HSUB);
		    strcat(file, p);
		}
#endif
	    } else {					/* /~... */
		if ((p= getenv("HOME")) != nil) {
		    len= strlen(p) + 1 + sizeof(HSUB) + strlen(ref+2);
		    file= new(len * sizeof(file[0]), nil);
		    strcpy(file, p);
		    strcat(file, "/");
		    strcat(file, HSUB);
		    strcat(file, ref+2);
		}
	    }
	} else {					/* /... */
	    len= sizeof(ROOT) + strlen(ref);
	    file= new(len * sizeof(file[0]), nil);
	    strcpy(file, ROOT);
	    strcat(file, ref);
	}
    } else {						/* ... */
	if ((p= strrchr(base, '/')) != nil) p++; else p= base;
	c= *p;
	*p= 0;
	len= strlen(base) + strlen(ref) + 1;
	file= new(len * sizeof(file[0]), nil);
	strcpy(file, base);
	strcat(file, ref);
	*p= c;
    }
    return file == nil ? copystr(ref) : file;
}

static char *percent(char *file)
/* Return a copy of 'file' with '%xx' escapes expanded. */
{
    size_t len;
    char *exp, *pe, *pf;
    char hex[3];

    len= 0;
    pf= file;
    while (*pf != 0) {
	if (pf[0] == '%' && isxdigit(pf[1]) && isxdigit(pf[2])) {
	    pf += 3;
	} else {
	    pf += 1;
	}
	len++;
    }
    exp= new((len + 1) * sizeof(exp[0]), nil);

    pf= file;
    pe= exp;
    for (;;) {
	if (pf[0] == '%' && isxdigit(pf[1]) && isxdigit(pf[2])) {
	    hex[0]= pf[1]; hex[1]= pf[2]; hex[2]= 0;
	    *pe++= strtoul(hex, nil, 0x10);
	    pf += 3;
	} else {
	    if ((*pe++ = *pf++) == 0) break;
	}
    }
    return exp;
}

static char *dirname(char *page)
/* Compute the path leading to a page.  This is simply everything up to and
 * including the last slash.
 */
{
    char *path, *slash;
    size_t len;

    if ((slash= strrchr(page, '/')) == nil) slash= page; else slash++;
    len= slash - page;

    path= new((len + 1) * sizeof(path[0]), nil);
    memcpy(path, page, len);
    path[len]= 0;

    return path;
}

static char *relative(char *path, char *base)
/* Compute a relative path from 'base' to 'path', i.e. we want the minimum
 * relative path to bring us to 'path' from 'base'.
 */
{
    size_t i, s, n;
    char *r;

    /* If path starts with http: or something then return it without looking
     * further.
     */
    for (i= 0; isalpha(path[i]); i++) {}
    if (i > 0 && path[i] == ':') return inc(path);

    /* If the paths are not both absolute or both relative then return path.
     * This is ok in the absolute/relative case, but probably wrong in the
     * relative/absolute case.
     */
    if ((path[0] == '/') != (base[0] == '/')) return inc(path);

    /* Determine point after last path prefix in common. */
    i= s= 0;
    while (path[i] == base[i] && path[i] != 0) {
	if (path[i] == '/') s= i+1;
	i++;
    }

    /* Count leftover directories in base path. */
    n= 0;
    i= s;
    while (base[i] != 0) {
	if (base[i] == '/') n++;
	i++;
    }

    /* So 'n' times up by "../" followed by the rest of 'path'. */
    r= new(((3 * n) + strlen(path + s) + 1) * sizeof(r[0]), nil);
    i= 0;
    while (n > 0) {
	strcpy(r + i, "../");
	i += 3;
	n--;
    }
    strcpy(r + i, path + s);
    return r;
}

/* Hashing is done on the first letter only, in 1<<n (n<=5) slots to ignore
 * case.
 */
#define NR_HASH		16
#define hash(p)		((p)[0] & (NR_HASH-1))

/* HTML data structures. */

typedef enum type {		/* Value type (expr/attr) or operator (expr). */
	/* Type of string value. */
	FALSE,				/* Null string seen as "false" */
	TRUE,				/* Null string seen as "true" */
	STRING,				/* Any other string */
	SQSTR,				/* String, please use single quotes */
	DQSTR,				/* String, please use double quotes */

	/* Some operators, rest as '+', '*', etc. */
	AND,				/* && (boolean and) */
	OR,				/* || */
	NEQ,				/* != */
	LEQ,				/* <= */
	GEQ,				/* >= */
	LSH,				/* << */
	RSH,				/* >> */
	ELLIPSES			/* $... */
} type_t;

typedef struct expr {		/* Generic expression. */
	struct expr *next;		/* Next on a string */
	char	op;			/* Operator or value type */
	struct expr *left;		/* Left operand */
	struct expr *right;		/* Right operand */
	char	*text;			/* Text operand: attr name or string */
} expr_t;

typedef struct attr {		/* Attribute setting. */
	struct attr *next;		/* Next on a list */
	char	type;			/* Value type */
	char	flags;			/* Flags */
	char	*name;			/* Attribute name */
	size_t	level;			/* Attribute's level */
	char	*value;			/* Attribute's value */
} attr_t;

#define A_DEFAULT	0x01	/* Set to a default value (per #define). */
#define A_ARG		0x02	/* Argument to a macro call. */

/* What is this bit of HTML? */
#define H_SUB	0x01		/* Has $ signs, may need to do substitutions */
#define H_TAG	0x02		/* Is some kind of tag */
#define H_MTAG	0x04		/* Tag is a macro tag */
#define H_CLOSE	0x08		/* Tag is a close tag */
#define H_WEIRD	0x10		/* <!...> and <?...> are pretty weird */

/* Type of builtin macro. */
typedef enum builtin {
    NOTBLTIN,
    DEFINE, IF, ELIF, ELSE, ERROR, WARNING, EXPORT,
    INCLUDE, UNDEF, NOOP, CONTAINER,
    NR_BLTINS
} builtin_t;

struct macro;

typedef struct html {		/* One bit of text or a tag. */
	struct html *next;		/* A list forming a file or macro */
	char	flags;			/* H_SUB, H_TAG, ... */
	char	bltin;			/* NOTBLTIN, DEFINE, IF, ... */
	struct macro *file;		/* File and line where it is found */
	unsigned long line;
	char	*text;			/* Text or tag as text */
	expr_t	*name;			/* Tag name */
	expr_t	*expr;			/* Strings and attribute settings */
} html_t;

#define M_CONTAINER	0x01	/* Macro is a container element. */
#define M_EXPORT	0x02	/* Macro is exported (doesn't require '#'). */

typedef struct macro {		/* Macros and files. */
	struct macro *next;		/* Next on a list */
	char	*name;
	char	bltin;			/* NOTBLTIN, DEFINE, IF, ... */
	char	flags;			/* M_CONTAINER, M_EXPORT ... */
	html_t	*body;			/* Macro body, <#define> onwards */
} macro_t;

#define ismacro(m)	((m)->body != nil)	/* Macros have a body. */
#define isfile(m)	((m)->body == nil)	/* Files do not. */

typedef struct attrstack {	/* Stack of attribute levels. */
	struct attrstack *out;		/* To outer attribute levels */
	html_t	*tag;			/* Tag that opened this level */
	macro_t	*macro;			/* Macro/file being executed in it */
	html_t	*body;			/* HTML tags from this macro */
	size_t	dot_level;		/* $.level */
	char	dot_out;		/* $.out */
	char	dot_export;		/* $.export */
				/* Extra variables needed in 'closes': */
	char	skip;			/* Skip code until closed? */
	char	take;			/* Take this #if branch / been taken? */
	html_t	**gather;		/* Hook to gather #define code */
				/* Attributes defined at this level: */
	attr_t	*attr[NR_HASH];
} attrstack_t;

#define DOT_LEVEL	((size_t) -1)	/* "At the current level, please." */

typedef struct filestack {	/* Stack of included files to process. */
	struct filestack *incl;		/* File this one is included from */
	macro_t	*file;			/* File to process */
	FILE	*fp;			/* Open file pointer */
	unsigned long line;		/* Current line */
	size_t	len, buflen;		/* Current input and total lenghts */
	unsigned char *buf, *bp;	/* Input buffer and current offset */
	char	parse_subst;		/* Parse substitutions in text? */
} filestack_t;

/* Macro hash buckets, and builtin macros. */
static macro_t *macros[NR_HASH], *builtin_macros[NR_BLTINS];

/* Builtin macro names. */
static char *builtin_names[] = {
    nil,
    "define", "if", "elif", "else", "error",
    "warning", "export", "include", "undef", "", "/#"
};

/* Attributes stack containing all active levels, from 'global' (level 0), to
 * 'local' (the current level), and a reverse stack for saved attributes for
 * container macros that are between the open and close tag.
 */
static attrstack_t *global, *local, *closes;

/* Stack of open files pushed on it by <#include>. */
static filestack_t *files;

/* Output file name and file pointer (stderr within <#error>). */
static char *outfile;
static FILE *out;

/* Dependency output file name and file pointer. */
static char *depfile;
static FILE *depfp;

/* "false"/"true" endnodes are often used.  Likewise two strings. */
static attr_t *false, *true;
static char *nullstr;

/* Several types of object destructors and allocators: */

static void *des_expr(void *mem)
{
    expr_t *e= mem;
    void *t;

    if (e->next != nil) { t= e->next; e->next= nil; return t; }
    if (e->left != nil) { t= e->left; e->left= nil; return t; }
    if (e->right != nil) { t= e->right; e->right= nil; return t; }
    if (e->text != nil) { t= e->text; e->text= nil; return t; }
    return nil;
}

static void *des_attr(void *mem)
{
    attr_t *a= mem;
    void *t;

    if (a->next != nil) { t= a->next; a->next= nil; return t; }
    if (a->name != nil) { t= a->name; a->name= nil; return t; }
    if (a->value != nil) { t= a->value; a->value= nil; return t; }
    return nil;
}

static void *des_html(void *mem)
{
    html_t *h= mem;
    void *t;

    if (h->next != nil) { t= h->next; h->next= nil; return t; }
    if (h->file != nil) { t= h->file; h->file= nil; return t; }
    if (h->text != nil) { t= h->text; h->text= nil; return t; }
    if (h->name != nil) { t= h->name; h->name= nil; return t; }
    if (h->expr != nil) { t= h->expr; h->expr= nil; return t; }
    return nil;
}

static void *des_macro(void *mem)
{
    macro_t *m= mem;
    void *t;

    if (m->next != nil) { t= m->next; m->next= nil; return t; }
    if (m->name != nil) { t= m->name; m->name= nil; return t; }
    if (m->body != nil) { t= m->body; m->body= nil; return t; }
    return nil;
}

static void *des_attrstack(void *mem)
{
    attrstack_t *as= mem;
    void *t;
    int i;

    if (as->out != nil) { t= as->out; as->out= nil; return t; }
    if (as->tag != nil) { t= as->tag; as->tag= nil; return t; }
    if (as->macro != nil) { t= as->macro; as->macro= nil; return t; }
    if (as->body != nil) { t= as->body; as->body= nil; return t; }
    for (i= 0; i < arraysize(as->attr); i++) {
	if (as->attr[i] != nil) { t= as->attr[i]; as->attr[i]= nil; return t; }
    }
    return nil;
}

static void *des_filestack(void *mem)
{
    filestack_t *fs= mem;
    void *t;

    if (fs->incl != nil) { t= fs->incl; fs->incl= nil; return t; }
    if (fs->file != nil) { t= fs->file; fs->file= nil; return t; }
    if (fs->buf != nil) { t= fs->buf; fs->buf= nil; return t; }
    return nil;
}

static expr_t *alloc_expr(void)
{
    expr_t *e;

    e= new(sizeof(*e), des_expr);
    e->next= nil;
    e->op= FALSE;
    e->left= nil;
    e->right= nil;
    e->text= nil;
    return e;
}

static attr_t *alloc_attr(void)
{
    attr_t *a;

    a= new(sizeof(*a), des_attr);
    a->next= nil;
    a->type= FALSE;
    a->flags= 0;
    a->name= nil;
    a->level= 0;
    a->value= nil;
    return a;
}

static macro_t *alloc_macro(void)
{
    macro_t *m;

    m= new(sizeof(*m), des_macro);
    m->next= nil;
    m->name= nil;
    m->bltin= NOTBLTIN;
    m->flags= 0;
    m->body= nil;
    return m;
}

static html_t *alloc_html(void)
{
    html_t *h;

    h= new(sizeof(*h), des_html);
    h->next= nil;
    h->flags= 0;
    h->bltin= NOTBLTIN;
    h->file= nil;
    h->line= 0;
    h->text= nil;
    h->name= nil;
    h->expr= nil;
    return h;
}

static attrstack_t *alloc_attrstack(void)
{
    attrstack_t *as;
    int i;

    as= new(sizeof(*as), des_attrstack);
    as->out= nil;
    as->tag= nil;
    as->macro= nil;
    as->body= nil;
    as->dot_level= 0;
    as->dot_out= 0;
    as->dot_export= 0;
    as->skip= 0;
    as->take= 0;
    as->gather= nil;
    for (i= 0; i < arraysize(as->attr); i++) as->attr[i]= nil;
    return as;
}

static filestack_t *alloc_filestack(void)
{
    filestack_t *fs;

    fs= new(sizeof(*fs), des_filestack);
    fs->incl= nil;
    fs->file= nil;
    fs->fp= nil;
    fs->line= 1;
    fs->len= 0;
    fs->buflen= 1024;
    fs->buf= new(fs->buflen * sizeof(fs->buf[0]), nil);
    fs->bp= fs->buf;
    fs->parse_subst= 0;
    return fs;
}

/* Error and warning count. */
static unsigned long nr_errors= 0, nr_warnings= 0;

static void error(html_t *tag, const char *fmt, ...)
{
    va_list ap;

    if (tag->file == nil) {
	fprintf(stderr, "%s: ", program);
    } else {
	fprintf(stderr, "\"%s\", line %lu: ", tag->file->name, tag->line);
    }
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    fflush(stderr);
    nr_errors++;
}

static void warn(html_t *tag, const char *fmt, ...)
{
    va_list ap;

    if (tag->file == nil) {
	fprintf(stderr, "%s: Warning: ", program);
    } else {
	fprintf(stderr, "\"%s\", line %lu: Warning: ",
	    tag->file->name, tag->line);
    }
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    fflush(stderr);
    nr_warnings++;
}

static char *n2a(long n)
/* Turn a number into a decimal string. */
{
    char a[CHAR_BIT * sizeof(n) / 3 + 3];

    sprintf(a, "%ld", n);
    return copystr(a);
}

static int numeric(long *n, char *a)
/* Check if 'a' is a number and compute its value. */
{
    char *end;

    if (isspace(a[0])) return 0;	/* *Don't* skip leading space. */
    if (a[0] == '-') {
	*n= strtol(a, &end, 0);
    } else {
	*n= strtoul(a, &end, 0);
    }
    return *end == 0;
}

static int namecmp(const char *n1, const char *n2)
/* Case insensitive comparison of attribute/macro names, a la strcmp(). */
{
    int c1, c2;

    do {
	c1 = (unsigned char) *n1++;
	c2 = (unsigned char) *n2++;
	if (islower(c1)) c1= toupper(c1);
	if (islower(c2)) c2= toupper(c2);
	if (c1 != c2) break;
    } while (c1 != 0);
    return c1 - c2;
}

static macro_t **findmacro(char *name)
/* Return the address of a pointer where macro 'name' is located or to the
 * last null pointer where it could be added.
 */
{
    macro_t **pm;

    pm= &macros[hash(name)];
    while ((*pm) != nil && namecmp((*pm)->name, name) != 0) pm= &(*pm)->next;
    return pm;
}

static attr_t *getattr(html_t *h, char *name, size_t level)
/* Find an attribute 'name' from 'level' outward.  Return the undefined value
 * ("false") if you can't find it.  The caller only cares about the value.
 */
{
    attrstack_t *as;
    attr_t *a;

    if (level == 0) {
	as= global;
    } else {
	as= local;
	while (level != as->dot_level) as= as->out;
    }
    if (name[0] == '.') {
	if (namecmp(name, ".level") == 0) {
	    a= alloc_attr();
	    a->type= STRING;
	    a->value= n2a(as->dot_level);
	} else
	if (namecmp(name, ".out") == 0) {
	    a= as->dot_out ? inc(true) : inc(false);
	} else
	if (namecmp(name, ".export") == 0) {
	    a= as->dot_export ? inc(true) : inc(false);
	} else {
	    error(h, "There is no builtin variable $%s", name);
	    a= inc(false);
	}
	return a;
    }
    do {
	a= as->attr[hash(name)];
	while (a != nil) {
	    if (namecmp(a->name, name) == 0) return inc(a);
	    a= a->next;
	}
    } while ((as= as->out) != nil);
    return inc(false);
}

static void setattrs(html_t *h, attr_t *al, int flags)
/* Set attributes from 'al' by putting/replacing them in the attribute table. */
{
    attrstack_t *as;
    attr_t *a, **pa;

    while (al != nil) {
	a= al;
	al= al->next;
	a->next= nil;

	if (a->name == nil) {	/* Skip unnamed strings. */
	    (void) dec(a, nil);
	    continue;
	}

	if (a->level == DOT_LEVEL) a->level= local->dot_level;

	if (a->level == 0) {
	    as= global;
	} else {
	    as= local;
	    while (a->level != as->dot_level) as= as->out;
	}

	if (a->name[0] == '.') {
	    if (namecmp(a->name, ".level") == 0) {
		error(h, "$.local is read-only");
	    } else
	    if (namecmp(a->name, ".out") == 0) {
		as->dot_out= (a->type != FALSE);
	    } else
	    if (namecmp(a->name, ".export") == 0) {
		as->dot_export= (a->type != FALSE);
	    } else {
		error(h, "There is no builtin variable $%s", a->name);
	    }
	    (void) dec(a, nil);
	    continue;
	}

	/* Replace old value if present. */
	for (pa= &as->attr[hash(a->name)]; *pa != nil; pa= &(*pa)->next) {
	    if (namecmp((*pa)->name, a->name) == 0) {
		/* Got the old value, remove it and chain in the new cell. */
		a->flags |= (*pa)->flags;
		a->next= dec(*pa, (*pa)->next);
		break;
	    }
	}
	/* Add the new attribute. */
	*pa= a;
	a->flags |= flags;
    }
}

static size_t str2level(html_t *h, char *level)
/* Compute a level number from a string.  From 'global' inwards if >= 0, from
 * 'local' outwards if < 0.
 */
{
    long n;

    if (!numeric(&n, level)) {
	error(h, "attribute level '%s' is not a number",level);
	return 0;
    }
    if (n < 0) n += local->dot_level;
    if ((unsigned long) n > local->dot_level) {
	error(h, "attribute level %s is out of range", level);
	return 0;
    }
    return n;
}

static int peek(size_t idx)
/* Peek 'idx' bytes into the current input file, reading and buffering what
 * we need to get there.
 */
{
    filestack_t *fs= files;
    size_t endlen;
    int c;
    unsigned char *newbuf;

    if (idx >= fs->len) {
	if (feof(fs->fp)) return EOF;

	/* Enough space up to the end of the buffer? */
	endlen= fs->buflen - (fs->bp - fs->buf);
	if (idx >= endlen) {
	    memmove(fs->buf, fs->bp, fs->len * sizeof(fs->buf[0]));

	    if (idx >= fs->buflen) {
		/* Doubling the lookahead buffer once should do it. */
		fs->buflen <<= 1;
		assert(idx < fs->buflen);
		newbuf= new(fs->buflen * sizeof(fs->buf[0]), nil);
		memcpy(newbuf, fs->buf, fs->len * sizeof(fs->buf[0]));
		(void) dec(fs->buf, nil);
		fs->buf= newbuf;
	    }
	    fs->bp= fs->buf;
	    endlen= fs->buflen;
	}

	/* Fill 'er up. */
	do {
	    if ((c= getc(fs->fp)) == EOF) {
		if (ferror(fs->fp)) fatal(fs->file->name);
		if (idx >= fs->len) return EOF;
		break;
	    }
	    if (c != 0) fs->bp[fs->len++]= c;
	} while (fs->len < endlen);
    }
    return fs->bp[idx];
}

/* Fast macro wrapper for peek(). */
#define peek(idx)	((idx) < files->len ? files->bp[idx] : (peek)(idx))

static char *collect(size_t idx0, size_t idx1)
/* Collect characters from the "peeked into" input file starting at 'idx0'
 * and ending just before 'idx1'.
 */
{
    filestack_t *fs= files;
    char *coll, *cp;
    unsigned char *bp;
    size_t len;

    assert(idx0 <= idx1);
    assert(idx1 <= fs->len);

    len= idx1 - idx0;
    coll= new((len+1) * sizeof(coll[0]), nil);

    cp= coll;
    bp= fs->bp + idx0;
    while (len > 0) {
	*cp++ = *bp++;
	len--;
    }
    *cp= 0;
    return coll;
}

static void seen(size_t idx)
/* Characters up to, but excluding 'idx' have been seen. */
{
    filestack_t *fs= files;
    size_t i;

    assert(idx <= fs->len);

    for (i= 0; i < idx; i++) {
	if (fs->bp[i] == '\n') fs->line++;
    }
    fs->bp+= idx;
    fs->len-= idx;
}

static void skipspacecomment(html_t *h, size_t *pidx)
/* Skip whitespace and comments. */
{
    int c;
    int tag= 0;

    for (;;) {
	c= peek(*pidx);
	if (isspace(c)) {
	    *pidx += 1;
	} else
	if (c == '-' && peek(*pidx + 1) == '-' && peek(*pidx + 2) != '>') {
	    /* Comment. */
	    *pidx += 1;
	    while ((c= peek(*pidx)) != EOF) {
		*pidx += 1;
		if (c == '-' && peek(*pidx) == '-') {
		    *pidx += 1;
		    break;
		}
		if (c == '<') tag |= 1;
		if (c == '>') tag |= 2;
	    }
	} else {
	    break;
	}
    }
    if (tag == 3) warn(h, "Comment may contain markup");
}

/* Skip only whitespace. */
#define skipspace(pidx)	while (isspace(peek(*(pidx)))) *(pidx) += 1

static int skip_php(size_t *pidx)
/* Skip a PHP expression delimited by <? and ?>.  The start marker must have
 * been recognized already.  Return true iff the end marker is found, and only
 * change *pidx if so.
 */
{
    size_t idx= *pidx;
    int c;

    while ((c= peek(idx)) != EOF) {
	idx++;
	if (c == '?' && peek(idx) == '>') {
	    *pidx= idx+1;
	    return 1;
	}
    }
    return 0;
}

static int operator(size_t *pidx)
/* Recognize multicharacter operators. */
{
    static struct ops {
	char	s[3];
	char	n;
    } ops[] = {
	{ "&&", AND },
	{ "||", OR  },
	{ "==", '=' },
	{ "!=", NEQ },
	{ "<=", LEQ },
	{ ">=", GEQ },
	{ "<<", LSH },
	{ ">>", RSH },
	{ "--", ' ' },		/* (So that '--' isn't two '-' operators) */
    };
    struct ops *opp;
    int i;

    skipspace(pidx);

    for (opp = ops; opp < arraylimit(ops); opp++) {
	i= 0;
	while (peek(*pidx + i) == opp->s[i]) {
	    i++;
	    if (opp->s[i] == 0) {
		*pidx += i;
		return opp->n;
	    }
	}
    }
    /* Assume a one character operator. */
    i= peek(*pidx);
    *pidx += 1;
    return i;
}

#define UNLIM	((size_t) -1)	/* Unlimited expr() limit. */

static expr_t *expr(size_t *pidx, size_t limit);
static expr_t *unit(size_t *pidx);

static expr_t *sub(size_t *pidx)
/*	sub ::= $$ | $< | $>
 *	      | $ [a-z.] [a-z0-9]* ([ expr ])?
 *	      | ${ [a-z.] [a-z0-9.-]* ([ expr ])? }
 *	      | ${ sub }
 *	      | $( expr )
 */
{
    expr_t *e;
    int c;
    size_t idx0;

    if (peek(*pidx) != '$') return nil;
    *pidx += 1;
    c= peek(*pidx);
    e= nil;

    if (c == '$' || c == '<' || c == '>') {	/* $$ $< $> */
	e= alloc_expr();
	e->op= DQSTR;
	e->text= collect(*pidx, *pidx + 1);
	*pidx += 1;
    } else
    if (isattr1(c)) {		/* $ [a-z.] [a-z0-9]* ( : unit )? */
	e= alloc_expr();
	e->op= '$';
	idx0= *pidx;
	do *pidx += 1; while (isalnum(peek(*pidx)));
	e->text= collect(idx0, *pidx);
	if (peek(*pidx) == ':') {
	    *pidx += 1;
	    if ((e->left= unit(pidx)) == nil) e= dec(e, nil);
	}
    } else
    if (c == '{') {		/* $ { aname ( : expr )? } | $ { sub } */
	*pidx += 1;
	skipspace(pidx);
	c= peek(*pidx);

	if (isattr1(c)) {	/* $ { aname ( : expr )? } */
	    e= alloc_expr();
	    e->op= '$';
	    idx0= *pidx;
	    do *pidx += 1; while (isattr(peek(*pidx)));
	    e->text= collect(idx0, *pidx);
	    skipspace(pidx);
	    if (peek(*pidx) == ':') {
		*pidx += 1;
		if ((e->left= expr(pidx, UNLIM)) == nil) e= dec(e, nil);
	    }
	} else
	if (c == '$') {		/* $ { sub } */
	    e= alloc_expr();
	    e->op= '{';
	    if ((e->right= sub(pidx)) == nil) e= dec(e, nil);
	}

	skipspace(pidx);
	if (e != nil && peek(*pidx) == '}') {
	    *pidx += 1;
	} else {
	    e= dec(e, nil);
	}
    } else
    if (c == '(') {			/* $( expr ) */
	*pidx += 1;
	e= expr(pidx, UNLIM);
	skipspace(pidx);
	if (e != nil && peek(*pidx) == ')') {
	    *pidx += 1;
	} else {
	    e= dec(e, nil);
	}
    }
    return e;
}

static expr_t *string(size_t *pidx)
/*	string ::= ( [a-z0-9.-] | sub )+
 *		 | ' ( [^'>] | sub )* '
 *		 | " ( [^">] | sub )* "
 */
{
    int c, q;
    size_t idx0;
    expr_t *str, **pe, *e;

    skipspace(pidx);

    str= nil;
    pe= &str;

    q= peek(*pidx);
    if (q == '"' || q == '\'') {
	*pidx += 1;
	idx0= *pidx;
	while ((c= peek(*pidx)) != EOF && c != q && c != '>') {
	    if (c == '<') {
		if (peek(*pidx+1) != '?') break;

		/* PHP code inside the string? */
		if (!skip_php(pidx)) break;
	    } else
	    if (c == '$') {
		if (*pidx > idx0) {
		    e= alloc_expr();
		    pe= &(*pe= e)->next;
		    e->op= q == '"' ? DQSTR : SQSTR;
		    e->text= collect(idx0, *pidx);
		}
		if ((e= sub(pidx)) == nil) return dec(str, nil);
		*pe= e;
		do pe= &(*pe)->next; while (*pe != nil);
		idx0= *pidx;
	    } else {
		*pidx += 1;
	    }
	}
	if (c != q) return dec(str, nil);
	/* Add leftover even if null to make sure there is at least one
	 * DQSTR/SQSTR so that the result will be forced to also have quotes.
	 */
	e= alloc_expr();
	pe= &(*pe= e)->next;
	e->op= q == '"' ? DQSTR : SQSTR;
	e->text= collect(idx0, *pidx);
	*pidx += 1;
    } else
    if (isattr(q) || q == '$') {
	idx0= *pidx;
	while (isattr(c= peek(*pidx)) || c == '$') {
	    if (c == '$') {
		if (*pidx > idx0) {
		    e= alloc_expr();
		    pe= &(*pe= e)->next;
		    e->op= STRING;
		    e->text= collect(idx0, *pidx);
		}
		if ((e= sub(pidx)) == nil) return dec(str, nil);
		*pe= e;
		do pe= &(*pe)->next; while (*pe != nil);
		idx0= *pidx;
	    } else {
		*pidx += 1;
	    }
	}
	if (*pidx > idx0) {
	    e= alloc_expr();
	    pe= &(*pe= e)->next;
	    e->op= STRING;
	    e->text= collect(idx0, *pidx);
	}
    }
    return str;
}

static expr_t *unit(size_t *pidx)
/*	unit ::= (!  | ~ | + | - | #) unit
 *	       | string
 *	       | ( expr )
 */
{
    expr_t *e;
    size_t idx1;
    int op;

    idx1= *pidx;
    op= operator(&idx1);
    if (op == '!' || op == '~' || op == '+' || op == '-'
						|| op == '#' || op == '@') {
	*pidx= idx1;
	e= alloc_expr();
	e->op= op;
	if ((e->right= unit(pidx)) == nil) e= dec(e, nil);
    } else
    if (op == '(') {
	*pidx= idx1;
	if ((e= expr(pidx, UNLIM)) != nil) {
	    skipspace(pidx);
	    if (peek(*pidx) == ')') {
		*pidx += 1;
	    } else {
		e= dec(e, nil);
	    }
	}
    } else {
	e= string(pidx);
    }
    return e;
}

static expr_t *factor(size_t *pidx)
/*	factor ::= unit
 *		 | factor (& | | | ^ | / | % | * | @) unit
 *		 | unit (<< | >>) unit
 */
{
    expr_t *e, *t;
    size_t idx1;
    int op;

    if ((e= unit(pidx)) == nil) return nil;

    if (idx1= *pidx, op= operator(&idx1), op == LSH || op == RSH) {
	*pidx= idx1;
	t= alloc_expr();
	t->op= op;
	t->left= e;
	if ((t->right = unit(pidx)) == nil) return dec(t, nil);
	return t;
    }

    while (idx1= *pidx, op= operator(&idx1),
	op == '&' || op == '|' || op == '^' ||
	op == '/' || op == '%' || op == '*' ||
	op == '@'
    ) {
	*pidx= idx1;
	t= alloc_expr();
	t->op= op;
	t->left= e;
	if ((t->right = unit(pidx)) == nil) return dec(t, nil);
	e= t;
    }
    return e;
}

static expr_t *term(size_t *pidx)
/*	term ::= factor | term (+ | -) factor
 */
{
    expr_t *e, *t;
    size_t idx1;
    int op;

    if ((e= factor(pidx)) == nil) return nil;

    while (idx1= *pidx, op= operator(&idx1), op == '+' || op == '-') {
	*pidx= idx1;
	t= alloc_expr();
	t->op= op;
	t->left= e;
	if ((t->right = factor(pidx)) == nil) return dec(t, nil);
	e= t;
    }
    return e;
}

static expr_t *test(size_t *pidx, size_t limit)
/*	test ::= term | term (= | == | != | < | <= | >= | >) term
 *
 * This is the trouble point and the reason for 'limit'.  Do we, or don't we
 * treat > or >= as an operator or is the > the end of the tag?  'Limit' will
 * guide us.
 */
{
    expr_t *e, *t;
    size_t idx1;
    int op;

    if ((e= term(pidx)) == nil) return nil;

    if (idx1 = *pidx, op= operator(&idx1),
	op == '=' || op == NEQ || op == '<' ||
	op == LEQ || op == GEQ || op == '>'
    ) {
	if (idx1 > limit) return e;	/* Don't step beyond this '>'? */
	*pidx= idx1;
	t= alloc_expr();
	t->op= op;
	t->left= e;
	t->right = term(pidx);
	if (t->right == nil) return dec(t, nil);
	e= t;
    }
    return e;
}

static expr_t *bool(size_t *pidx, size_t limit)
/*	bool ::= test | bool (&& | ||) test
 */
{
    expr_t *e, *t;
    size_t idx1;
    int op;

    if ((e= test(pidx, limit)) == nil) return nil;

    while (idx1= *pidx, op= operator(&idx1), op == AND || op == OR) {
	*pidx= idx1;
	t= alloc_expr();
	t->op= op;
	t->left= e;
	if ((t->right = test(pidx, limit)) == nil) return dec(t, nil);
	e= t;
    }
    return e;
}

static expr_t *expr(size_t *pidx, size_t limit)
/*	expr ::= bool | bool ? expr : expr
 */
{
    expr_t *e, *t;
    size_t idx1;

    if ((e= bool(pidx, limit)) == nil) return nil;

    if (idx1= *pidx, operator(&idx1) == '?') {
	*pidx= idx1;
	t= alloc_expr();
	t->op= '?';
	t->left= e;
	t->right= alloc_expr();
	t->right->op= ':';
	if ((t->right->left = expr(pidx, limit)) == nil) return dec(t, nil);
	if (idx1= *pidx, operator(&idx1) != ':') return dec(t, nil);
	*pidx= idx1;
	if ((t->right->right = expr(pidx, limit)) == nil) return dec(t, nil);
	e= t;
    }
    return e;
}

static int parsetag(html_t *h, size_t *pidx)
/* Peek(*pidx) == '<', so parse a tag. */
{
    int c;
    expr_t *e, **pe;
    size_t idx0;

    h->flags |= H_TAG;
    pe= &h->expr;

    *pidx += 1;
    c= peek(*pidx);
    if (c == '/') {			/* </ */
	h->flags |= H_CLOSE;
	*pidx += 1;
	c= peek(*pidx);
    }

    if (c == '#') {			/* <# or </# */
	h->flags |= H_MTAG;
	files->parse_subst= 1;		/* OK to recognize '$' in text now. */
	*pidx += 1;
	c= peek(*pidx);
	if (c == '/' && peek(*pidx+1) == '#') {
	    /* <#/# the "container element" tag. */
	    h->bltin= CONTAINER;
	    *pidx += 2;
	} else
	if ((ctype(c) & (C_LETTER | C_DOT | C_DOLLAR)) != 0) {
	    /* Macro name, possibly with substitutions. */
	    if ((h->name= string(pidx)) == nil) return 0;
	    if ((e= h->name)->op == STRING && e->next == nil) {
		macro_t *m;
		if ((m= *findmacro(e->text)) != nil) h->bltin= m->bltin;
	    }
	} else
	if (c != '!') {
	    /* No macro name, just a no-op to set attributes. */
	    h->bltin= NOOP;
	} else {
	    /* Bad character after <# or </# */
	    return 0;
	}
    } else
    if (c == '!') {			/* <! */
	/* A mesh of spaces, comments, words and strings.  Do separately. */
	h->flags |= H_WEIRD;
	*pidx += 1;
	for (;;) {
	    skipspacecomment(h, pidx);
	    if (peek(*pidx) == '>') break;
	    if ((e= string(pidx)) == nil) return 0;
	    e= dec(e, nil);
	}
	*pidx += 1;
	return 1;
    } else
    if (c == '?') {			/* <? */
	/* A PHP start marker.  Gobble it up to the ?> end marker. */
	h->flags |= H_WEIRD;
	return skip_php(pidx);
    } else				/* Ordinary tag */
    if ((ctype(c) & (C_LETTER | C_DOLLAR)) != 0) {
	/* Tag name, possibly with substitutions. */
	if ((h->name= string(pidx)) == nil) return 0;
	if ((e= h->name)->op == STRING && e->next == nil) {
	    macro_t *m;
	    if (local->dot_export
		&& (m= *findmacro(e->text)) != nil && (m->flags & M_EXPORT)
	    ) {
		/* An exported macro tag, not just an ordinary tag! */
		h->flags |= H_MTAG;
		h->bltin= m->bltin;
	    }
	}
    } else {
	/* Bad character after < or </ */
	return 0;
    }

    if ((h->bltin == IF || h->bltin == ELIF) && !(h->flags & H_CLOSE)) {
	/* <#if expr> or <#elif expr>.
	 * Thanks to > being both an operator (> or >=) and the end of a tag
	 * we don't know where the test expression ends precisely.  So we try
	 * something, and if we don't like it we limit how far expr() may parse
	 * and retry repeatedly until the expression ends on a >.
	 */
	size_t limit;

	skipspacecomment(h, pidx);
	limit= UNLIM;
	idx0= *pidx;
	for (;;) {
	    if ((*pe= expr(pidx, limit)) != nil) {
		skipspacecomment(h, pidx);
		if (peek(*pidx) == '>') break;
		*pe= dec(*pe, nil);
	    }
	    if (limit > *pidx) limit= *pidx;
	    do {
		if (--limit <= idx0) return 0;
	    } while (peek(limit) != '>');
	    *pidx= idx0;
	}
    } else {
	/* Normal (macro) tag; gather whitespace and attribute settings. */
	idx0= *pidx;
	for (;;) {
	    skipspacecomment(h, pidx);

	    if (*pidx > idx0 && !(h->flags & H_MTAG)) {
		/* Remember whitespace for an ordinary tag. */
		e= alloc_expr();
		pe= &(*pe= e)->next;
		e->op= STRING;
		e->text= collect(idx0, *pidx);
	    }

	    c= peek(*pidx);
	    if (c == '>') break;

	    /* Create an 'attr=value' expression. */
	    e= alloc_expr();
	    pe= &(*pe= e)->next;
	    e->op= '=';

	    if (c == '$') {
		/* $attr -- Pass a (boolean) attribute. */
		e->op= '$';
		*pidx += 1;
	    } else
	    if (c == '!' && (h->flags & H_MTAG)) {
		/* !attr -- Undefine an attribute */
		e->op= '!';
		*pidx += 1;
		skipspace(pidx);
	    }

	    /* Attribute name. */
	    if (!isattr1(peek(*pidx))) return 0;
	    idx0= *pidx;
	    do *pidx += 1; while (isattr(peek(*pidx)));
	    e->text= collect(idx0, *pidx);
	    idx0= *pidx;

	    /* $... to pass nondefault arguments? */
	    if (strcmp(e->text, "...") == 0) e->op= ELLIPSES;

	    /* Attribute level if on a NOOP. */
	    skipspace(pidx);
	    if (h->bltin == NOOP && peek(*pidx) == ':') {
		*pidx += 1;
		if ((e->left= unit(pidx)) == nil) return 0;
		idx0= *pidx;
		skipspace(pidx);
	    }

	    /* Attribute value. */
	    if (e->op == '=') {
		if (peek(*pidx) == '=') {
		    /* attr = value */
		    *pidx += 1;
		    skipspace(pidx);
		    if ((e->right= string(pidx)) == nil) return 0;
		    idx0= *pidx;
		} else {
		    /* attr -- Boolean "true". */
		    e->right= alloc_expr();
		    e->right->op= TRUE;
		    e->right->text= inc(nullstr);
		}
	    } else
	    if (e->op == '$') {
		/* $attr -- Pass attr as itself, i.e. attr=$attr. */
		e->op= '=';
		e->right= alloc_expr();
		e->right->op= '$';
		e->right->text= inc(e->text);
		e->right->left= inc(e->left);
	    } else
	    if (e->op == '!') {
		/* !attr -- Undefine attribute, boolean "false". */
		e->op= '=';
		e->right= alloc_expr();
		e->right->op= FALSE;
		e->right->text= inc(nullstr);
	    }
	}
    }

    h->flags |= H_SUB;
    if (!(h->flags & H_MTAG)) {
	/* Check if a non-macro tag has only simple settings. */
	for (e= h->expr; e != nil; e= e->next) {
	    if (e->op == '=' && e->right != nil
			&& (e->right->op > DQSTR || e->right->next != nil)) {
		/* This is not a simple string value! */
		break;
	    }
	    if (e->op == ELLIPSES) break;	/* $... */
	}
	if (e == nil && h->name->op == STRING && h->name->next == nil) {
	    /* Just an ordinary tag; we only need its name and full text. */
	    h->expr= dec(h->expr, nil);
	    h->flags &= ~H_SUB;
	}
    }

    /* The closing '>' has been seen. */
    *pidx += 1;

    return 1;
}

static html_t *parsehtml(void)
/* Read HTML, either not more than one line of text, or one complete tag. */
{
    filestack_t *fs;
    html_t *h;
    size_t idx;
    int c;

    fs= files;
    if (peek(0) == EOF) return nil;

    h= alloc_html();
    h->file= inc(fs->file);
    h->line= fs->line;

    idx= 0;
    while ((c= peek(idx)) != EOF && c != '<' && !(c == '$' && fs->parse_subst))
    {
	if (++idx >= 8192) break;	/* Add text, but not too much. */
    }

    if (idx > 0) {		/* Some text can be gathered. */
	h->text= collect(0, idx);
	seen(idx);
    } else
    if (c == '$') {		/* Substitution within text. */
	if ((h->expr= sub(&idx)) != nil) {
	    h->flags |= H_SUB;
	} else {
	    warn(h, "bad $ substitution, maybe use $$?");
	}
	h->text= collect(0, idx);
	seen(idx);
    } else
    if (c == '<') {		/* An HTML or macro tag. */
	int t;
	size_t tlen;
	char *follow;

	t= parsetag(h, &idx);
	h->text= collect(0, idx);
	tlen= idx;
	seen(idx);
	if (!t) {
	    /* Failed to parse a tag; complain. */
	    for (idx= 0; idx < 10; idx++) {
		if ((c= peek(idx)) == EOF || iscntrl(c)) break;
	    }
	    follow= collect(0, idx);
	    if (tlen > 64+5) {
		(fs->parse_subst ? error : warn)(h,
		    "syntax error past ***: %.32s ... %s *** %s",
			h->text, h->text + tlen - 32, follow);
	    } else {
		(fs->parse_subst ? error : warn)(h,
		    "syntax error past ***: %s *** %s", h->text, follow);
	    }
	    (void) dec(follow, nil);
	    h->flags= 0;
	}
    }
    return h;
}

static attr_t *eval(html_t *h, expr_t *e)
/* Evaluate an expression to a string, with care to keep "truth" values. */
{
    attr_t *t, *a, *l, *r;
    long n, m;
    int cmp, level;

    t= nil;

    assert(e != nil);
    do {
	switch (e->op) {
	case FALSE:
	case TRUE:
	case STRING:
	case SQSTR:
	case DQSTR:
	    a= alloc_attr();
	    a->type= e->op;
	    a->value= inc(e->text);
	    break;

	case AND:
	    a= eval(h, e->left);
	    if (a->type != FALSE) {
		(void) dec(a, nil);
		a= eval(h, e->right);
	    }
	    break;

	case OR:
	    a= eval(h, e->left);
	    if (a->type == FALSE) {
		(void) dec(a, nil);
		a= eval(h, e->right);
	    }
	    break;

	case NEQ:
	case LEQ:
	case GEQ:
	case '=':
	case '<':
	case '>':
	    l= eval(h, e->left);
	    r= eval(h, e->right);
	    if (numeric(&n, l->value) && numeric(&m, r->value)) {
		cmp= n == m ? 0 : n < m ? -1 : 1;
	    } else {
		cmp= namecmp(l->value, r->value);
	    }
	    (void) dec(l, nil);
	    (void) dec(r, nil);
	    switch (e->op) {
	    case NEQ:	cmp= cmp != 0;	break;
	    case LEQ:	cmp= cmp <= 0;	break;
	    case GEQ:	cmp= cmp >= 0;	break;
	    case '=':	cmp= cmp == 0;	break;
	    case '<':	cmp= cmp <  0;	break;
	    case '>':	cmp= cmp >  0;	break;
	    }
	    a= inc(cmp ? true : false);
	    break;

	case '?':
	    assert(e->right != nil && e->right->op == ':');
	    l= eval(h, e->left);
	    a= eval(h, l->type != FALSE ? e->right->left : e->right->right);
	    (void) dec(l, nil);
	    break;

	case LSH:
	case RSH:
	case '+':
	case '-':
	case '&':
	case '|':
	case '^':
	case '~':
	case '/':
	case '%':
	case '*':
	    if (e->left == nil) {	/* Unary operator. */
		n= 0;
	    } else {
		l= eval(h, e->left);
		if (!numeric(&n, l->value)) {
		    error(h, "can't do arithmetic on '%s'", l->value);
		    n= 0;
		}
		(void) dec(l, nil);
	    }
	    r= eval(h, e->right);
	    if (!numeric(&m, r->value)) {
		error(h, "can't do arithmetic on '%s'", r->value);
		m= 0;
	    }
	    (void) dec(r, nil);
	    switch (e->op) {
	    case LSH:	n <<= m;		break;
	    case RSH:	n >>= m;		break;
	    case '+':	n +=  m;		break;
	    case '-':	n -=  m;		break;
	    case '&':	n &=  m;		break;
	    case '|':	n |=  m;		break;
	    case '^':	n ^=  m;		break;
	    case '~':	n=   ~m;		break;
	    case '/':	n= m == 0 ? 0 : n / m;	break;
	    case '%':	n= m == 0 ? 0 : n % m;	break;
	    case '*':	n *=  m;		break;
	    }
	    a= alloc_attr();
	    a->type= STRING;
	    a->value= n2a(n);
	    break;

	case '!':
	    r= eval(h, e->right);
	    a= inc(r->type == FALSE ? true : false);
	    (void) dec(r, nil);
	    break;

	case '#':
	    r= eval(h, e->right);
	    a= inc(*findmacro(r->value) != nil ? true : false);
	    (void) dec(r, nil);
	    break;

	case '@':
	    if (e->left == nil) {	/* Compute path leading to page. */
		r= eval(h, e->right);
		a= alloc_attr();
		a->type= r->type < STRING ? STRING : r->type;
		a->value= dirname(r->value);
		(void) dec(r, nil);
	    } else {			/* Compute path from base to page. */
		l= eval(h, e->left);
		r= eval(h, e->right);
		a= alloc_attr();
		a->type= l->type < STRING ? STRING : l->type;
		a->value= relative(l->value, r->value);
		(void) dec(l, nil);
		(void) dec(r, nil);
	    }
	    break;

	case '$':
	    if (e->left == nil) {
		level= local->dot_level;
	    } else {
		l= eval(h, e->left);
		level= str2level(h, l->value);
		(void) dec(l, nil);
	    }
	    a= getattr(h, e->text, level);
	    break;

	case '{':
	    r= eval(h, e->right);
	    a= getattr(h, r->value, local->dot_level);
	    (void) dec(r, nil);
	    break;

	default:
	    fprintf(stderr, e->op < ' ' ? "eval(%d)\n" : "eval('%c')\n", e->op);
	    abort();
	}

	if (t == nil) {
	    /* First element of a string. */
	    t= a;
	} else {
	    /* Next element, concatenate and recompute type. */
	    r= alloc_attr();
	    r->value= new((strlen(t->value) + strlen(a->value) + 1)
						* sizeof(r->value[0]), nil);
	    strcpy(r->value, t->value);
	    strcat(r->value, a->value);
	    r->type= STRING;
	    if (t->type > r->type) r->type= t->type;
	    if (a->type > r->type) r->type= a->type;
	    if (a->name == nil && a->type >= SQSTR) r->type= a->type;
	    (void) dec(t, nil);
	    (void) dec(a, nil);
	    t= r;
	}
    } while ((e= e->next) != nil);
    return t;
}

static attr_t *evaltag(html_t *h, expr_t *e)
/* Evaluate a expression list at tag level to a list of strings and attribute
 * settings.
 */
{
    attr_t *tag, **pa, *a, *s, **ah, *al;
    char *space;

    tag= nil;
    pa= &tag;

    /* A tag has a list of names, strings, assignments, ... */
    while (e != nil) {
	switch (e->op) {
	case STRING:
	    a= alloc_attr();
	    pa= &(*pa= a)->next;
	    a->type= STRING;
	    a->value= inc(e->text);
	    break;

	case '=':
	    a= alloc_attr();
	    pa= &(*pa= a)->next;
	    a->name= inc(e->text);
	    if (e->left == nil) {
		a->level= DOT_LEVEL;
	    } else {
		s= eval(h, e->left);
		a->level= str2level(h, s->value);
		s= dec(s, nil);
	    }
	    s= eval(h, e->right);
	    a->type= s->type;
	    a->value= dec(s, s->value);
	    break;

	case ELLIPSES:
	    space= nil;
	    for (ah= local->attr; ah < arraylimit(local->attr); ah++) {
		for (al= *ah; al != nil; al= al->next) {
		    if ((al->flags & (A_DEFAULT | A_ARG)) == A_ARG) {
			if (space == nil) {
			    space= copystr(" ");
			} else {
			    a= alloc_attr();
			    pa= &(*pa= a)->next;
			    a->value= inc(space);
			}
			a= alloc_attr();
			pa= &(*pa= a)->next;
			a->name= inc(al->name);
			a->level= DOT_LEVEL;
			a->type= al->type;
			a->value= inc(al->value);
		    }
		}
	    }
	    dec(space, nil);
	    break;

	default:
	    fprintf(stderr, e->op < ' ' ? "evaltag(%d)\n" : "evaltag('%c')\n",
		e->op);
	    abort();
	}
	e= e->next;
    }
    return tag;
}

static void output(char *s)
/* Output a string. */
{
    char *t;

    if (!local->dot_out) return;

    for (t= s; *t != 0; t++) if (putc(*t, out) == EOF) fatal(outfile);
}

static void outputq(int type, char *s)
/* Output a string, quoted as 'type' specifies, or as it has to be due to
 * characters outside those allowed for a non-quoted HTML attribute value.
 */
{
    char *t;
    int q;

    if (!local->dot_out) return;

    if (type < SQSTR) {
	if (*s == 0) {
	    q= '"';
	} else {
	    q= 0;
	    t= s;
	    do {
		if (!isattr(*t)) {
		    q |= 1;
		    if (*t == '\'') q |= 2;
		    if (*t == '"') q |= 4;
		}
	    } while (*++t != 0);
	    if (q != 0) q= q == 5 ? '\'' : '"';
	}
    } else {
	q= type == SQSTR ? '\'' : '"';
    }

    if (q != 0) if (putc(q, out) == EOF) fatal(outfile);
    for (t= s; *t != 0; t++) {
	if (iscntrl(*t)) fprintf(out, "&#%d;", *t);
	else
	if (*t == q) fprintf(out, q == '"' ? "&quot;" : "&#39;");
	else
	if (*t == '<') fprintf(out, "&lt;");
	else
	if (*t == '>') fprintf(out, "&gt;");
	else {
	    putc(*t, out);
	}
	if (ferror(out)) fatal(outfile);
    }
    if (q != 0) if (putc(q, out) == EOF) fatal(outfile);
}

static void noclosetag(html_t *h)
{
    error(h, "<#%s> has no close tag", builtin_names[h->bltin]);
}

static void exechtml(void);

static void exec_notbltin(html_t *h)
/* Execute a user defined macro. */
{
    attr_t *d, *a;
    attrstack_t *as;
    macro_t *m;

    a= eval(h, h->name);
    m= *findmacro(a->value);
    if (m == nil) {
	if (!closes->skip) error(h, "Macro \"%s\" is not defined", a->value);
	a= dec(a, nil);
	return;
    }
    a= dec(a, nil);

    if (!(h->flags & H_CLOSE)) {
	/* <#macro>: Call a macro. */

	if (closes->skip) {
	    /* Oops, this tag must be skipped.  Create enclosure? */
	    if (m->flags & M_CONTAINER) {
		as= alloc_attrstack();
		as->out= closes;
		closes= as;
		as->tag= inc(h);
		as->macro= inc(m);
		as->skip= 1;
		as->dot_level= as->out->dot_level + 1;
		as->dot_out= as->out->dot_out;
		as->dot_export= as->out->dot_export;
	    }
	    return;
	}

	/* Default settings from #define and new attributes. */
	d= evaltag(m->body, m->body->expr->next);
	a= evaltag(h, h->expr);

	/* New attribute level. */
	as= alloc_attrstack();
	as->out= local;
	local= as;
	as->tag= inc(h);
	as->macro= inc(m);
	as->body= inc(m->body->next);
	as->dot_level= as->out->dot_level + 1;
	as->dot_out= as->out->dot_out;
	as->dot_export= as->out->dot_export;

	/* Set new attributes at the new level. */
	setattrs(m->body, d, A_DEFAULT);
	setattrs(h, a, A_ARG);
    } else {
	/* </#macro>: Reopen the old attribute level. */
	if (closes->skip && !(m->flags & M_CONTAINER)) return;

	if (closes->macro != m) {
	    error(h, (m->flags & M_CONTAINER) ? "</#%s> without a <#%s>"
		: "<#%s> is not a container macro, so no </#%s> expected",
		m->name, m->name);
	    return;
	}

	/* Any new attributes? */
	a= evaltag(h, h->expr);

	/* Restore attribute level. */
	as= closes; closes= as->out;
	as->out= local; local= as;

	/* Change attributes. */
	setattrs(h, a, 0);
    }
}

static void exec_define(html_t *h)
/* <#define macro attr ...>: Define a macro. */
{
    macro_t *m, **pm;
    expr_t *e;
    attrstack_t *as;

    if (!(h->flags & H_CLOSE)) {
	/* <#define ...> */

	m= alloc_macro();

	/* Check if the first expression is present and just a word that has
	 * been transformed into 'attr=TRUE' by the parser.
	 */
	e= h->expr;
	if (!closes->skip) {
	    /* Untaken #if branch or something. */
	}
	if (e != nil && e->op == '=' && e->left == nil && e->right->op == TRUE)
	{
	    m->name= inc(e->text);
	} else {
	    error(h, "First attribute is not a macro name");
	    m->name= inc(nullstr);
	}

	/* Create an enclosure. */
	as= alloc_attrstack();
	as->out= closes;
	closes= as;
	as->macro= m;
	as->tag= inc(h);
	as->gather= closes->out->skip ? as->out->gather : &m->body;
	as->dot_level= local->dot_level + 1;
	as->skip= 1;

    } else {
	/* </#define> */

	if (closes->tag->bltin != DEFINE) {
	    error(h, "</#define> without a <#define>");
	    return;
	}
	m= closes->macro;
	if (!closes->out->skip) {
	    if (m->name != nullstr) {
		/* Enter macro in the macro table. */
		if (*(pm= findmacro(m->name)) != nil) {
		    error(m->body,
			"Macro %s is already defined in \"%s\", line %lu",
			m->name,
			(*pm)->body->file->name,
			(unsigned long) (*pm)->body->line);
		} else {
		    *pm = inc(m);
		}
	    }
	} else {
	    closes->out->gather= closes->gather;
	}
	closes= dec(closes, closes->out);
    }
}

static void exec_if(html_t *h)
/* <#if expr>: Conditionally include html. */
{
    attrstack_t *as;
    attr_t *a;

    if (!(h->flags & H_CLOSE)) {
	/* <#if ...>: Create an enclosure for the state of the #if branches. */
	as= alloc_attrstack();
	as->out= closes;
	closes= as;
	as->macro= inc(builtin_macros[IF]);
	as->tag= inc(h);
	as->gather= as->out->gather;
	as->dot_level= local->dot_level + 1;
	as->skip= as->out->skip;
	as->take= as->out->skip;

	/* Are we going to take this branch? */
	if (!as->take) {
	    a= eval(h, h->expr);
	    if (a->type != FALSE) {
		as->take= 1;
	    } else {
		as->skip= 1;
	    }
	    (void) dec(a, nil);
	}
    } else {
	/* </#if>: Close the if. */

	if (closes->tag->bltin != IF) {
	    error(h, "</#if> without an <#if>");
	    return;
	}
	closes->out->gather= closes->gather;
	closes= dec(closes, closes->out);
    }
}

static void exec_elif(html_t *h)
/* <elif test>: Possibly execute an alternate #if branch. */
{
    attr_t *a;

    if (h->flags & H_CLOSE) { noclosetag(h); return; }

    if (closes->tag->bltin != IF) {
	error(h, "<#elif> without an <#if>");
	return;
    }

    closes->skip= closes->take;
    if (!closes->take) {
	a= eval(h, h->expr);
	if (a->type != FALSE) {
	    closes->take= 1;
	} else {
	    closes->skip= 1;
	}
	(void) dec(a, nil);
    }
}

static void exec_else(html_t *h)
/* <else>: Possibly execute a last alternate #if branch. */
{
    if (h->flags & H_CLOSE) { noclosetag(h); return; }

    if (closes->tag->bltin != IF) {
	error(h, "<#else> without an <#if>");
	return;
    }

    closes->skip= closes->take;
    closes->take= 1;
}

static void exec_error(html_t *h)
/* <#error>: Emit contents to standard error and exit. */
/* <#warning>: Likewise, but don't exit. */
{
    attrstack_t *as;
    static FILE *save_out;

    if (!(h->flags & H_CLOSE)) {
	/* <#error>: Create an enclosure, change out, set $.out. */
	if (save_out != nil) {
	    error(h, "#%s doesn't nest", builtin_names[h->bltin]);
	    return;
	}
	as= alloc_attrstack();
	as->out= closes;
	closes= as;
	as->macro= inc(builtin_macros[h->bltin]);
	as->tag= inc(h);
	as->gather= as->out->gather;
	as->dot_level= local->dot_level + 1;
	as->dot_out= local->dot_out;		/* safekeeping */
	as->skip= as->out->skip;
	save_out= out;
	out= stderr;

	if (!as->skip) {
	    fprintf(out, "\"%s\", line %lu: #%s: ",
		h->file->name, h->line, builtin_names[h->bltin]);
	    local->dot_out= 1;
	}
    } else {
	/* </#warning>: Close the warning by undoing the output change. */
	/* </#error>: Close the error by exiting. */

	if (closes->tag->bltin != h->bltin) {
	    error(h, "</#%s> without an <#%s>",
		builtin_names[h->bltin], builtin_names[h->bltin]);
	    return;
	}
	local->dot_out= closes->dot_out;
	closes->out->gather= closes->gather;
	closes= dec(closes, closes->out);
	if (!closes->skip) {
	    fputc('\n', out);
	    if (h->bltin == ERROR) exit(1);
	}
	out= save_out;
	save_out= nil;
    }
}

static void exec_export(html_t *h)
/* <#export name ...>: Allow macros to be called without '#'. */
{
    expr_t *e;
    macro_t *m;

    if (h->flags & H_CLOSE) { noclosetag(h); return; }

    if (closes->skip) return;

    for (e= h->expr; e != nil; e= e->next) {
	if (e != nil && e->op == '=' && e->left == nil && e->right->op == TRUE)
	{
	    if ((m= *findmacro(e->text)) != nil) {
		m->flags |= M_EXPORT;
	    } else {
		error(h, "Macro '%s' is not defined", e->text);
	    }
	} else {
	    error(h, "Attribute is not a macro name");
	}
    }
}

static void exec_include(html_t *h)
/* <#include ...>: Include another file within this one. */
{
    attr_t *a;
    attrstack_t *as, *cl;
    macro_t *f;
    filestack_t *fs;
    size_t find_depth;
    int outer_dot_out;
    int i;
    char *file;
    enum filetype { STDIN, FILE, PIPE } filetype;
    enum iattrs { SRC, FIND, ENCL, EXTR, INCL, NR_IATTRS };
    attr_t *ia[NR_IATTRS];
    static char *iattr_names[]= {
	"src", "find", "enclose", "extract", "inclusive"
    };

    if (h->flags & H_CLOSE) { noclosetag(h); return; }

    if (closes->skip) return;

    a= evaltag(h, h->expr);

    /* Open a new attribute level, possibly the first. */
    as= alloc_attrstack();
    as->out= local;
    local= as;
    as->tag= inc(h);
    as->macro= inc(builtin_macros[INCLUDE]);
    if (global == nil) {
	global= inc(as);
	as->dot_level= 0;
	as->dot_out= outer_dot_out= 1;
	as->dot_export= 1;		/* .export set only for first file. */
    } else {
	as->dot_level= as->out->dot_level + 1;
	as->dot_out= outer_dot_out= as->out->dot_out;
	as->dot_export= 0;

	/* Attributes are by default unset. */
	for (i= 0; i < NR_IATTRS; i++) {
	    ia[0]= alloc_attr();
	    ia[0]->name= copystr(iattr_names[i]);
	    ia[0]->level= as->dot_level;
	    setattrs(h, ia[0], A_DEFAULT);
	}
    }

    /* Set tag attributes and try to find the filename ("src"), etc. */
    setattrs(h, a, A_ARG);

    for (i= 0; i < NR_IATTRS; i++) {
	ia[i]= getattr(h, iattr_names[i], as->dot_level);
    }

    if (ia[SRC]->type == FALSE) {
	error(h, "Attribute 'src' not set for %s", h->text);
	exit(1);
    }

    find_depth= 0;
    if (ia[EXTR]->type != FALSE) as->dot_out= 0;

    f= alloc_macro();
    fs= alloc_filestack();
    fs->incl= files;
    files= fs;
    fs->file= f;

    file= ia[SRC]->value;

    if (file[0] == '-' && file[1] == 0) {
	/* Read standard input. */
	f->name= inc(file);
	filetype= STDIN;
	fs->fp= stdin;
    } else
    if (file[0] != 0 && file[strlen(file)-1] == '|') {
	/* Filename ends in '|', so its a command to get output from. */
	f->name= fs->incl == nil ? inc(file) : percent(file);
	filetype= PIPE;
#if POSIX
	file= &f->name[strlen(f->name)-1];
	*file= 0;
	fs->fp= popen(f->name, "r");
	*file= '|';
#else
	fs->fp= nil;
	errno= ENOENT;
#endif
    } else {
	/* Normal file name, refer from current file unless first include. */
	filetype= FILE;
	if (fs->incl == nil) {
	    f->name= inc(file);
	} else {
	    file= percent(file);
	    f->name= refer(files->incl->file->name, file);
	    (void) dec(file, nil);
	}
	if (depfp != nil) {
	    if (fprintf(depfp, "%s:%s\n", outfile, f->name) == EOF) {
		fatal(depfile);
	    }
	}
	fs->fp= fopen(f->name, "r");
    }

    if (fs->fp == nil) {
	error(h, "Can't open %s: %s", f->name, strerror(errno));
	exit(1);
    }

    /* Create an enclosure. */
    cl= alloc_attrstack();
    cl->out= closes;
    closes= cl;
    cl->macro= inc(f);
    cl->tag= inc(h);
    cl->dot_level= local->dot_level + 1;

    for (;;) {
	html_t *hf, *hm;

	if ((hf= parsehtml()) == nil) break;

	/* Find a container element, like <body> ... </body>? */
	if (ia[FIND]->type != FALSE
	    && closes == cl
	    && (hf->flags & (H_TAG | H_MTAG | H_WEIRD)) == H_TAG
	    && hf->name->op == STRING
	    && hf->name->next == nil
	    && namecmp(ia[FIND]->value, hf->name->text) == 0
	) {
	    hm= nil;
	    if (ia[ENCL]->type != FALSE) {
		/* Enclose by a container macro. */
		hm= alloc_html();
		hm->flags= H_TAG | H_MTAG | (hf->flags & H_CLOSE);
		hm->name= alloc_expr();
		hm->name->op= STRING;
		hm->name->text= inc(ia[ENCL]->value);
		hm->file= inc(hf->file);
		hm->line= hf->line;
		hm->text= new((strlen(ia[ENCL]->value) + 4)
					* sizeof(hm->text[0]), nil);
		sprintf(hm->text, "<%s%s>",
			(hf->flags & H_CLOSE) ? "/" : "", ia[ENCL]->value);
	    }

	    if (!(hf->flags & H_CLOSE)) {
		/* <#enclose><body> */
		if (ia[EXTR]->type != FALSE && find_depth == 0) {
		    as->dot_out= outer_dot_out;
		}
		if (ia[ENCL]->type != FALSE) {
		    local->body= hm;
		    exechtml();
		}
		if (ia[EXTR]->type != FALSE && find_depth == 0) {
		    if (ia[INCL]->type == FALSE) as->dot_out= 0;
		}
		local->body= hf;
		exechtml();
		if (ia[EXTR]->type != FALSE && find_depth == 0) {
		    as->dot_out= outer_dot_out;
		}
		find_depth++;
	    } else {
		/* </body></#enclose> */
		if (find_depth == 0) {
		    error(hf,
		    "</%s> without <%s>, this makes extraction too difficult",
			ia[FIND]->value, ia[FIND]->value);
		    exit(1);
		}
		find_depth--;
		if (ia[EXTR]->type != FALSE && find_depth == 0) {
		    as->dot_out= 0;
		    if (ia[INCL]->type != FALSE) as->dot_out= outer_dot_out;
		}
		local->body= hf;
		exechtml();
		if (ia[EXTR]->type != FALSE && find_depth == 0) {
		    as->dot_out= outer_dot_out;
		}
		if (ia[ENCL]->type != FALSE) {
		    cl->skip= 0;
		    local->body= hm;
		    exechtml();
		}
		if (ia[EXTR]->type != FALSE && find_depth == 0) {
		    as->dot_out= 0;
		}
	    }

	} else {

	    /* Include without tricks. */
	    local->body= hf;
	    exechtml();
	}
    }

    for (i= 0; i < NR_IATTRS; i++) (void) dec(ia[i], nil);

    /* Complain about unclosed macro elements. */
    while (closes != cl) {
	error(closes->tag, "No </#%s> for %s",
	    closes->tag->bltin == DEFINE ? "define" : closes->macro->name,
	    closes->tag->text);
	closes= dec(closes, closes->out);
    }

    /* Discard enclosure, attribute level and file. */
    closes= dec(closes, closes->out);
    local= dec(local, local->out);
    if (filetype == STDIN) {
	clearerr(stdin);
    } else
#if POSIX
    if (filetype == PIPE) {
	if (pclose(fs->fp) != nil) exit(1);
    } else
#endif
    {
	(void) fclose(fs->fp);
    }
    files= dec(fs, fs->incl);
}

static void exec_undef(html_t *h)
/* <#undef name ...>: Remove all macro definitions named. */
{
    expr_t *e;
    macro_t **pm;

    if (h->flags & H_CLOSE) { noclosetag(h); return; }

    if (closes->skip) return;

    for (e= h->expr; e != nil; e= e->next) {
	if (e != nil && e->op == '=' && e->left == nil && e->right->op == TRUE)
	{
	    if (*(pm= findmacro(e->text)) != nil) {
		*pm= dec(*pm, (*pm)->next);
	    }
	} else {
	    error(h, "Attribute is not a macro name");
	}
    }
}

static void exec_noop(html_t *h)
/* <# ...>: Do nothing other then evaluating the attribute settings within
 * the current attribute level.
 */
{
    if (h->flags & H_CLOSE) { noclosetag(h); return; }

    if (closes->skip) return;

    setattrs(h, evaltag(h, h->expr), 0);
}

static void exec_container(html_t *h)
/* <#/#>: Do the text contents of a container macro by turning an attribute
 * level into an enclosure to be placed back on the attribute stack when the
 * macro end tag is executed.
 */
{
    attrstack_t *as;
    attr_t *a;

    if (h->flags & H_CLOSE) { noclosetag(h); return; }

    if (closes->skip) return;

    if (local->macro->bltin != NOTBLTIN) {
	error(h, "<#/#> can only be used in a macro body");
	return;
    }

    /* Is the attribute "skip" present on this tag? */
    a= evaltag(h, h->expr);
    while (a != nil) {
	if (namecmp(a->name, "skip") == 0) local->skip= (a->type != FALSE);
	a= dec(a, nil);
    }

    /* Turn the macro's attribute level into an enclosure. */
    as= local; local= as->out;
    as->out= closes; closes= as;
    as->macro->flags |= M_CONTAINER;
}

static void exechtml(void)
/* Execute the HTML body of the current level and higher levels until the
 * current level runs out.  "Execution" usually means sending things straight
 * to stdout, until a macro makes things difficult.  'Skip' is set if we are
 * in an #if branch that is not executed, i.e. if we are just following syntax.
 */
{
    static void (*execmacro[])(html_t *h) = {
	exec_notbltin, exec_define, exec_if, exec_elif, exec_else, exec_error,
	exec_error, exec_export, exec_include, exec_undef, exec_noop,
	exec_container
    };
    size_t baselevel= local->dot_level;
    html_t *h;

    for (;;) {
	while (local->body == nil) {
	    /* Pop attribute levels until we're back at our starting level.
	     * Also check if all close tags have been seen.
	     */
	    if (local->dot_level == baselevel) return;
	    while (closes->dot_level > local->dot_level) {
		error(closes->tag, "No </#%s> for %s",
		    closes->macro->name, closes->tag->text);
		closes= dec(closes, closes->out);
	    }
	    local= dec(local, local->out);
	}

	/* Take one tag and execute it. */
	h= inc(local->body);
	local->body= dec(h, h->next);

	switch (h->flags & (H_MTAG | H_TAG | H_SUB)) {
	case 0:
	    /* Ordinary text. */
	    if (!closes->skip) output(h->text);
	    break;

	case H_SUB:
	    /* A substitution within text. */
	    if (!closes->skip) {
		attr_t *a= eval(h, h->expr);
		output(a->value);
		(void) dec(a, nil);
	    }
	    break;

	case H_TAG:
	    /* A tag without substitutions. */
	    if (!closes->skip) output(h->text);
	    break;

	case H_TAG | H_SUB:
	    /* A tag with substitutions. */
	    if (!closes->skip) {
		attr_t *a;

		output((h->flags & H_CLOSE) ? "</" : "<");
		a= eval(h, h->name);
		output(a->value);
		(void) dec(a, nil);

		a= evaltag(h, h->expr);
		while (a != nil) {
		    if (a->name == nil) {
			output(a->value);
		    } else
		    if (a->type == FALSE) {
			/* nothing */
		    } else
		    if (a->type == TRUE) {
			output(a->name);
		    } else {
			output(a->name);
			output("=");
			outputq(a->type, a->value);
		    }
		    a= dec(a, a->next);
		}
		output(">");
	    }
	    break;

	case H_MTAG:
	case H_MTAG | H_SUB:
	case H_MTAG | H_TAG:
	case H_MTAG | H_TAG | H_SUB:
	    /* A macro. */

	    (*execmacro[h->bltin])(h);
	    break;
	}
	if (closes->gather != nil) {
	    /* A #define is gathering code for a macro, so copy 'h'. */
	    html_t *g= alloc_html();
	    closes->gather= &(*closes->gather= g)->next;
	    g->flags= h->flags;
	    g->bltin= h->bltin;
	    g->file= inc(h->file);
	    g->line= h->line;
	    g->text= inc(h->text);
	    g->name= inc(h->name);
	    g->expr= inc(h->expr);
	}
	(void) dec(h, nil);
    }
}

static void usage(void)
{
    fprintf(stderr,
	"Usage: %s [-o outfile] file [attr[=value] ...]\n", program);
    exit(1);
}

int main(int argc, char **argv)
{
    int i;
    html_t *h;
    expr_t **pe, *e;

    if ((program= strrchr(argv[0], '/')) == nil) {
	program= argv[0];
    } else {
	program++;
    }

    init_ctype();

    nullstr= copystr("");
    false= alloc_attr();
    false->type= FALSE;
    false->value= inc(nullstr);
    true= alloc_attr();
    true->type= TRUE;
    true->value= inc(nullstr);

    /* Create macro cells for builtin macros. */
    for (i= DEFINE; i <= CONTAINER; i++) {
	builtin_macros[i]= alloc_macro();
	builtin_macros[i]->name= copystr(builtin_names[i]);
	builtin_macros[i]->bltin= i;
	*findmacro(builtin_names[i])= inc(builtin_macros[i]);
    }
    builtin_macros[INCLUDE]->flags |= M_EXPORT;

    /* A dummy "close" to set the initial context. */
    closes= alloc_attrstack();

    /* Options. */
    i= 1;
    while (i < argc && argv[i][0] == '-' && argv[i][1] != 0) {
	char *opt= argv[i++] + 1;

	if (opt[0] == '-' && opt[1] == 0) break;	/* -- */

	while (*opt != 0) switch (*opt++) {
	case 'o':					/* -o outfile */
	    if (*opt == 0) {
		if (i == argc) usage();
		outfile= argv[i++];
	    } else {
		outfile= opt;
		opt= "";
	    }
	    break;
	case 's':					/* -s (obsolete) */
	    suppress= 1;
	    break;
	default:					/* -? */
	    usage();
	}
    }

    /* Open the output file. */
    if (outfile != nil) {
	if ((out= fopen(outfile, "w")) == nil) fatal(outfile);
	if ((depfile= getenv(DEPFILE)) != nil) {
	    if ((depfp= fopen(depfile, "a")) == nil) fatal(depfile);
	}
    } else {
	outfile= "standard output";
	out= stdout;
    }

    /* There must be an input file argument. */
    if (i >= argc) usage();

    /* Kludge up an <#include src=file attr=value ...> tag. */
    h= alloc_html();
    h->flags= H_TAG | H_MTAG;
    h->bltin= INCLUDE;
    pe= &h->expr;

    while (i < argc) {
	char *p= argv[i];
	size_t n;

	e= alloc_expr();
	pe= &(*pe= e)->next;
	e->op= '=';

	if (e == h->expr) {		/* File argument. */
	    e->text= copystr("src");
	} else {			/* Attribute. */
	    if (!isattr1(*p)) usage();
	    do p++; while (isattr(*p));
	    n= p - argv[i];
	    if (*p != 0 && *p++ != '=') usage();
	    e->text= new((n + 1) * sizeof(e->text[0]), nil);
	    memcpy(e->text, argv[i], n * sizeof(e->text[0]));
	    e->text[n]= 0;
	}

	e->right= alloc_expr();
	if (*p != 0) {			/* Set attribute to value. */
	    e->right->op= STRING;
	    e->right->text= copystr(p);
	} else {			/* Set attribute to "true". */
	    e->right->op= TRUE;
	    e->right->text= inc(nullstr);
	}
	i++;
    }

    exec_include(h);
    h= dec(h, nil);

    if (fclose(out) == EOF) fatal(outfile);
    if (depfp != nil && fclose(depfp) == EOF) fatal(depfile);

    /* Cleanup. */
    assert(closes != nil);
    assert(closes->out == nil);
    assert(closes->macro == nil);
    closes= dec(closes, nil);

    assert(files == nil);
    assert(local == nil);
    global= dec(global, nil);

    for (i= 0; i < arraysize(macros); i++) {
	macros[i]= dec(macros[i], nil);
    }
    for (i= DEFINE; i <= CONTAINER; i++) {
	builtin_macros[i]= dec(builtin_macros[i], nil);
    }

    false= dec(false, nil);
    true= dec(true, nil);
    nullstr= dec(nullstr, nil);

    if (m_objcount != 0) {
	fprintf(stderr,
	"(The sloppy programmer of %s let %lu chunk%s of memory leak out)\n",
	    program, (unsigned long) m_objcount, m_objcount == 1 ? "" : "s");
    }
    return nr_errors == 0 ? 0 : 1;
}

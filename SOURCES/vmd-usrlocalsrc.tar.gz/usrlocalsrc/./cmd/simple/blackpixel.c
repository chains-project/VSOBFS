/*	blackpixel 1.1 - one black pixel proxy server	Author: Kees J. Bot
 *								1 Feb 2001
 * Note: Version number appears below!
 */
#define nil ((void*)0)
#include <sys/types.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <setjmp.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

/* One black pixel as a GIF. */
static unsigned char blackpixel[] = {
    0x47, 0x49, 0x46, 0x38, 0x37, 0x61, 0x01, 0x00, 0x01, 0x00, 0x80,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2C, 0x00, 0x00,
    0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x02, 0x02, 0x44, 0x01,
    0x00, 0x3B,
};

static char *arpa_date(time_t clock)
{
    struct tm *tm;
    static char timebuf[2][sizeof("ddd, dd mmm yyyy hh:mm GMT")];
    static unsigned timenr;
    static char *week_day[] = {
	"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
    };
    static char *months[] = {
	"Jan", "Feb", "Mar", "Apr", "May", "Jun",
	"Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
    };


    tm = gmtime(&clock);

    timenr = (timenr + 1) % 2;

    (void) sprintf(timebuf[timenr], "%s, %d %s %04d %02d:%02d GMT",
		   week_day[tm->tm_wday], tm->tm_mday,
		   months[tm->tm_mon], 1900 + tm->tm_year,
		   tm->tm_hour, tm->tm_min);
    return timebuf[timenr];
}

static void report(const char *label)
{
    fprintf(stderr, "blackpixel: %s: %s\n", label, strerror(errno));
}

static void fatal(const char *label)
{
    report(label);
    exit(1);
}

static jmp_buf jmpbuf;

static void onalarm(int sig)
{
    longjmp(jmpbuf, 1);
}

static void usage(void)
{
    fprintf(stderr, "Usage: blackpixel <port>\n");
    exit(1);
}

int main(int argc, char **argv)
{
    int s, n;
    char buf[8192];
    int a;
    struct sockaddr_in channel;
    static int on= 1;
    unsigned long port;
    char *end;
    struct sigaction sa;
    time_t now;
    size_t len;
    int r, nl;

    if (argc != 2) usage();
    port= strtoul(argv[1], &end, 0);
    if (port <= 0 || port >= 0xFFFFUL || *end != 0) usage();

    if ((s= socket(AF_INET, SOCK_STREAM, IPPROTO_TCP))<0) fatal("socket()");

    (void) setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *) &on, sizeof(on));
    memset(&channel, 0, sizeof(channel));
    channel.sin_family= AF_INET;
    channel.sin_addr.s_addr= htonl(INADDR_ANY);
    channel.sin_port= htons(port);
    if (bind(s, (struct sockaddr *) &channel, sizeof(channel)) < 0) {
	fatal("bind()");
    }

    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sa.sa_handler = onalarm;
    sigaction(SIGALRM, &sa, NULL);
    sa.sa_handler = SIG_IGN;
    sigaction(SIGPIPE, &sa, NULL);

    for (;;) {
	if (listen(s, 10) < 0) {
	    report("listen()");
	    sleep(10);
	    continue;
	}

	if ((a= accept(s, nil, nil)) < 0) {
	    report("accept()");
	    sleep(10);
	    continue;
	}

	if (setjmp(jmpbuf)) {
	    close(a);
	    continue;
	}
	alarm(2);
	nl= 0;
	while (nl < 2 && (r= read(a, buf, sizeof(buf))) > 0) {
	    char *p = buf;

	    do {
		switch (*p++) {
		case '\r':		break;
		case '\n':	nl++;	break;
		default:	nl= 0;	break;
		}
	    } while (--r > 0 && nl < 2);
	}
	alarm(0);

	now= time(nil);

	len= sprintf(buf,
	    "HTTP/1.0 200 Nothing much\r\n"
	    "Date: %s\r\n"
	    "Expires: %s\r\n"
	    "Server: Blackpixel 1.1 by kjb@cs.vu.nl\r\n"
	    "Content-type: image/gif\r\n\r\n",
	    arpa_date(now),
	    arpa_date(now + 3*24*3600));
	memcpy(buf + len, blackpixel, sizeof(blackpixel));

	(void) write(a, buf, len + sizeof(blackpixel));

	close(a);
    }
}

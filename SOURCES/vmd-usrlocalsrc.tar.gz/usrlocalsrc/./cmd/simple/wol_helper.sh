#!/usr/bin/perl -w
#
#	wol_helper 1.0 - Use wake_on_lan on a bunch of machines.
#							Author: Kees J. Bot
#								26 Jan 2005
$ENV{'PATH'} = '/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/sbin:/usr/sbin';

$0 =~ s:/+$::;
$0 =~ s:.*/::;

sub ip_aton
{
    die unless @_ == 1;
    local(@ip) = split(/\./, $_[0]);
    ($ip[0] << 24) | ($ip[1] << 16) | ($ip[2] << 8) | ($ip[3] << 0);
}

sub run
{
    die unless @_ > 0;
    #print "@_\n";
    system(@_);
}

@if = ();
open(IF, "ifconfig -a|") || die "$0: ifconfig: $!\n";
while (<IF>) {
    next unless m#^/dev/ip(\d+): address (\S+) netmask (\S+) #;
    push(@if, $1, &ip_aton($2), &ip_aton($3));
}
close(IF);
$? == 0 || exit(1);

while (<>) {
    /^\s*(\d+\.\d+\.\d+\.\d+)\s+(\S+)\s*\n/ || die "$0: Bad input: $_";
    ($ip, $mac) = (&ip_aton($1), $2);

    @iftmp = @if;
    while (@iftmp) {
	($if, $myip, $mask) = splice(@iftmp, 0, 3);
	if ((($ip ^ $myip) & $mask) == 0) {
	    &run('wake_on_lan', '-U', "/dev/udp$if", $mac);
	}
    }
}

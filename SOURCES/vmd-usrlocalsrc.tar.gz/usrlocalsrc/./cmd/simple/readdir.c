/*	readdir 1.3 - Display struct directs.		Author: Kees J. Bot
 *								10 Dec 1989
 */
#define nil 0
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "sys/types.h"
#include "sys/stat.h"
#include "dirent.h"

enum dirtype { UNKNOWN, V7, FLEX } dirtype= UNKNOWN;

struct dirent *getentry(FILE *d)
{
	static struct _fl_direct entry[8];
	struct _v7_direct v7entry;

	if (dirtype == V7) {
		if (fread((char *) &v7entry, sizeof(v7entry), 1, d) != 1)
			return nil;
		entry[0].d_ino= v7entry.d_ino;
		strncpy(entry[0].d_name, v7entry.d_name,
						sizeof(v7entry.d_name));
		entry[0].d_name[sizeof(v7entry.d_name)]= 0;
	} else {
		if (fread((char *) &entry[0], sizeof(entry[0]), 1, d) != 1)
			return nil;

		if (dirtype == UNKNOWN) {
			if (entry[0].d_extent != 0) {
				dirtype= V7;
				rewind(d);
				return getentry(d);
			} else
				dirtype= FLEX;
		}

		if (entry[0].d_extent > 0) {
			if (fread((char *) &entry[1], sizeof(entry[1]),
				entry[0].d_extent, d) != entry[0].d_extent
			) return nil;
		}
	}
	return (struct dirent *) entry;
}

int main(int argc, char **argv)
{
	FILE *d;
	char *dir;
	struct dirent *entry;
	int hole= 0;

	if (argc > 2) {
		fprintf(stderr, "Usage: readdir [dir]\n");
		exit(1);
	}

	dir= argc == 1 ? "." : argv[1];

	if ((d= fopen(dir, "r")) == nil) {
		fprintf(stderr, "readdir: can't open %s\n", dir);
		exit(1);
	}

	for (;;) {
		entry= getentry(d);

		if (entry == nil || entry->d_ino != 0) {
			if (hole != 0) {
				printf(dirtype == V7	? "     0 %dx\n"
							: "     0 0 %dx\n",
					hole);
				hole= 0;
			}
			if (entry == nil) break;

			if (dirtype == V7) {
				printf("%6d %s\n",
					entry->d_ino,
					entry->d_name);
			} else {
				printf("%6d %d %s\n",
					entry->d_ino,
					entry->d_extent,
					entry->d_name);
			}
		} else
			hole++;
	}
	exit(0);
}

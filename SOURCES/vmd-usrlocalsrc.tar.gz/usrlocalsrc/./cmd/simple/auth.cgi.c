/*	auth.cgi - User authentication for CGI scripts.
 *							Author: Kees J. Bot
 *								21 Nov 1998
 */
const char version[] = "auth.cgi-1.0";
/*
 * This is the setuid root forerunner to a program that
 * has the same name as this program with ".auth" added to its name.
 *
 * This program operates as follows:
 *    - If the first argument is a magic number that is stored in a database
 *	then a new magic number is computed to replace that magic number,
 *	permissions are switched to the associated user, and the .auth script
 *	is called with the first argument set to the new number.  All other
 *	arguments passed untouched.  The environment variables USER and HOME
 *	are set for the user making the request.
 *    - If no number is given, the number doesn't exist, or is expired then
 *	the .auth script is called as an unprivileged user with first argument
 *	-noauth (no authentication), -badpassword (user name or password bad),
 *	or -expired (authentication expired).  The script is expected to emit a
 *	form that inputs a 'user' and 'password' field, method=post, and
 *	action= precisely the URL it itself is called with.  If USER is set
 *	then it can be used as a default value in the 'user' input field.
 *    - If the first argument is "-*" then the user name and password
 *	sent by the form are checked, and if correct a new magic number is
 *	computed from some random data and put in the database together with
 *	the user's name.  A redirect is issued to retry the original call.
 *
 * It is up to the .auth script to call this program with the magic number as
 * its first argument, thereby authenticating the next query.  It can simply
 * add QUERY_STRING to URLs to make this happen.
 *
 * Next to the magic number in the URL also a magic number is computed and
 * sent to the browser as a cookie.  The next access is authenticated if
 * either the new magic number in the URL is used, or if the cookie is sent
 * back.  The magic number in the URL you see is already stale.  With cookies
 * this doesn't happen, so your browser's "back" and "reload" button work.
 *
 * PATH_AUTHDATA is best set to a file somewhere out of sight in /var.
 */
#define nil 0
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <time.h>
#include <limits.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>

#ifndef PATH_AUTHDATA
#error PATH_AUTHDATA not defined!
#endif

#define EXPIRE	     HOUR(1)	/* Expire magic number after this time. */
#define MAX_EXPIRE  HOUR(3*24)	/* Don't bother with times this old. */

#define HOUR(n)  ((time_t) (n) * 60 * 60)	/* N hours. */


/*============================================================================*/
/*
 * This code implements the MD5 message-digest algorithm.
 * The algorithm is due to Ron Rivest.  This code was
 * written by Colin Plumb in 1993, no copyright is claimed.
 * This code is in the public domain; do with it what you wish.
 *
 * Equivalent code is available from RSA Data Security, Inc.
 * This code has been tested against that, and is equivalent,
 * except that you don't need to include two pages of legalese
 * with every copy.
 *
 * To compute the message digest of a chunk of bytes, declare an
 * MD5Context structure, pass it to MD5Init, call MD5Update as
 * needed on buffers full of bytes, and then call MD5Final, which
 * will fill a supplied 16-byte array with the digest.
 */

struct MD5Context {
	unsigned long buf[4];
	unsigned long bits[2];
	unsigned char in[64];
};

/*
 * Start MD5 accumulation.  Set bit count to 0 and buffer to mysterious
 * initialization constants.
 */
void MD5Init(struct MD5Context *ctx)
{
    ctx->buf[0] = 0x67452301;
    ctx->buf[1] = 0xefcdab89;
    ctx->buf[2] = 0x98badcfe;
    ctx->buf[3] = 0x10325476;

    ctx->bits[0] = 0;
    ctx->bits[1] = 0;
}

static unsigned long get32(unsigned char const *cp)
{
    return ((unsigned long) cp[0] <<  0)
	 | ((unsigned long) cp[1] <<  8)
	 | ((unsigned long) cp[2] << 16)
	 | ((unsigned long) cp[3] << 24);
}

static void put32(unsigned char *cp, unsigned long value)
{
    cp[0] = (value >>  0) & 0xFF;
    cp[1] = (value >>  8) & 0xFF;
    cp[2] = (value >> 16) & 0xFF;
    cp[3] = (value >> 24) & 0xFF;
}

#ifndef ASM_MD5

/* The four core functions - F1 is optimized somewhat */

/* #define F1(x, y, z) (x & y | ~x & z) */
#define F1(x, y, z) (z ^ (x & (y ^ z)))
#define F2(x, y, z) F1(z, x, y)
#define F3(x, y, z) (x ^ y ^ z)
#define F4(x, y, z) (y ^ (x | ~z))

/* This is the central step in the MD5 algorithm. */
#define MD5STEP(f, w, x, y, z, data, s) \
	( w += f(x, y, z) + data,  w = w<<s | w>>(32-s),  w += x )

/*
 * The core of the MD5 algorithm, this alters an existing MD5 hash to
 * reflect the addition of 16 longwords of new data.  MD5Update blocks
 * the data and converts bytes into longwords for this routine.
 */
static void MD5Transform(unsigned long buf[4], const unsigned char inext[64])
{
    register unsigned long a, b, c, d, i;
    unsigned long in[16];
    
    for (i = 0; i < 16; i++)
      in[i] = get32(inext + 4 * i);

    a = buf[0];
    b = buf[1];
    c = buf[2];
    d = buf[3];

    MD5STEP(F1, a, b, c, d, in[0] + 0xd76aa478, 7);
    MD5STEP(F1, d, a, b, c, in[1] + 0xe8c7b756, 12);
    MD5STEP(F1, c, d, a, b, in[2] + 0x242070db, 17);
    MD5STEP(F1, b, c, d, a, in[3] + 0xc1bdceee, 22);
    MD5STEP(F1, a, b, c, d, in[4] + 0xf57c0faf, 7);
    MD5STEP(F1, d, a, b, c, in[5] + 0x4787c62a, 12);
    MD5STEP(F1, c, d, a, b, in[6] + 0xa8304613, 17);
    MD5STEP(F1, b, c, d, a, in[7] + 0xfd469501, 22);
    MD5STEP(F1, a, b, c, d, in[8] + 0x698098d8, 7);
    MD5STEP(F1, d, a, b, c, in[9] + 0x8b44f7af, 12);
    MD5STEP(F1, c, d, a, b, in[10] + 0xffff5bb1, 17);
    MD5STEP(F1, b, c, d, a, in[11] + 0x895cd7be, 22);
    MD5STEP(F1, a, b, c, d, in[12] + 0x6b901122, 7);
    MD5STEP(F1, d, a, b, c, in[13] + 0xfd987193, 12);
    MD5STEP(F1, c, d, a, b, in[14] + 0xa679438e, 17);
    MD5STEP(F1, b, c, d, a, in[15] + 0x49b40821, 22);

    MD5STEP(F2, a, b, c, d, in[1] + 0xf61e2562, 5);
    MD5STEP(F2, d, a, b, c, in[6] + 0xc040b340, 9);
    MD5STEP(F2, c, d, a, b, in[11] + 0x265e5a51, 14);
    MD5STEP(F2, b, c, d, a, in[0] + 0xe9b6c7aa, 20);
    MD5STEP(F2, a, b, c, d, in[5] + 0xd62f105d, 5);
    MD5STEP(F2, d, a, b, c, in[10] + 0x02441453, 9);
    MD5STEP(F2, c, d, a, b, in[15] + 0xd8a1e681, 14);
    MD5STEP(F2, b, c, d, a, in[4] + 0xe7d3fbc8, 20);
    MD5STEP(F2, a, b, c, d, in[9] + 0x21e1cde6, 5);
    MD5STEP(F2, d, a, b, c, in[14] + 0xc33707d6, 9);
    MD5STEP(F2, c, d, a, b, in[3] + 0xf4d50d87, 14);
    MD5STEP(F2, b, c, d, a, in[8] + 0x455a14ed, 20);
    MD5STEP(F2, a, b, c, d, in[13] + 0xa9e3e905, 5);
    MD5STEP(F2, d, a, b, c, in[2] + 0xfcefa3f8, 9);
    MD5STEP(F2, c, d, a, b, in[7] + 0x676f02d9, 14);
    MD5STEP(F2, b, c, d, a, in[12] + 0x8d2a4c8a, 20);

    MD5STEP(F3, a, b, c, d, in[5] + 0xfffa3942, 4);
    MD5STEP(F3, d, a, b, c, in[8] + 0x8771f681, 11);
    MD5STEP(F3, c, d, a, b, in[11] + 0x6d9d6122, 16);
    MD5STEP(F3, b, c, d, a, in[14] + 0xfde5380c, 23);
    MD5STEP(F3, a, b, c, d, in[1] + 0xa4beea44, 4);
    MD5STEP(F3, d, a, b, c, in[4] + 0x4bdecfa9, 11);
    MD5STEP(F3, c, d, a, b, in[7] + 0xf6bb4b60, 16);
    MD5STEP(F3, b, c, d, a, in[10] + 0xbebfbc70, 23);
    MD5STEP(F3, a, b, c, d, in[13] + 0x289b7ec6, 4);
    MD5STEP(F3, d, a, b, c, in[0] + 0xeaa127fa, 11);
    MD5STEP(F3, c, d, a, b, in[3] + 0xd4ef3085, 16);
    MD5STEP(F3, b, c, d, a, in[6] + 0x04881d05, 23);
    MD5STEP(F3, a, b, c, d, in[9] + 0xd9d4d039, 4);
    MD5STEP(F3, d, a, b, c, in[12] + 0xe6db99e5, 11);
    MD5STEP(F3, c, d, a, b, in[15] + 0x1fa27cf8, 16);
    MD5STEP(F3, b, c, d, a, in[2] + 0xc4ac5665, 23);

    MD5STEP(F4, a, b, c, d, in[0] + 0xf4292244, 6);
    MD5STEP(F4, d, a, b, c, in[7] + 0x432aff97, 10);
    MD5STEP(F4, c, d, a, b, in[14] + 0xab9423a7, 15);
    MD5STEP(F4, b, c, d, a, in[5] + 0xfc93a039, 21);
    MD5STEP(F4, a, b, c, d, in[12] + 0x655b59c3, 6);
    MD5STEP(F4, d, a, b, c, in[3] + 0x8f0ccc92, 10);
    MD5STEP(F4, c, d, a, b, in[10] + 0xffeff47d, 15);
    MD5STEP(F4, b, c, d, a, in[1] + 0x85845dd1, 21);
    MD5STEP(F4, a, b, c, d, in[8] + 0x6fa87e4f, 6);
    MD5STEP(F4, d, a, b, c, in[15] + 0xfe2ce6e0, 10);
    MD5STEP(F4, c, d, a, b, in[6] + 0xa3014314, 15);
    MD5STEP(F4, b, c, d, a, in[13] + 0x4e0811a1, 21);
    MD5STEP(F4, a, b, c, d, in[4] + 0xf7537e82, 6);
    MD5STEP(F4, d, a, b, c, in[11] + 0xbd3af235, 10);
    MD5STEP(F4, c, d, a, b, in[2] + 0x2ad7d2bb, 15);
    MD5STEP(F4, b, c, d, a, in[9] + 0xeb86d391, 21);

    buf[0] += a;
    buf[1] += b;
    buf[2] += c;
    buf[3] += d;
}

#endif

/*
 * Update context to reflect the concatenation of another buffer full
 * of bytes.
 */
void MD5Update(struct MD5Context *ctx, void const *buf, size_t len)
{
    unsigned char const *bp= buf;
    unsigned long t;

    /* Update bitcount */

    t = ctx->bits[0];
    if ((ctx->bits[0] = (t + ((unsigned long)len << 3)) & 0xffffffff) < t)
	ctx->bits[1]++;		/* Carry from low to high */
    ctx->bits[1] += len >> 29;

    t = (t >> 3) & 0x3f;	/* Bytes already in shsInfo->data */

    /* Handle any leading odd-sized chunks */

    if (t) {
	unsigned char *p = ctx->in + t;

	t = 64 - t;
	if (len < t) {
	    memcpy(p, bp, len);
	    return;
	}
	memcpy(p, bp, t);
	MD5Transform(ctx->buf, ctx->in);
	bp += t;
	len -= t;
    }
    /* Process data in 64-byte chunks */

    while (len >= 64) {
	memcpy(ctx->in, bp, 64);
	MD5Transform(ctx->buf, ctx->in);
	bp += 64;
	len -= 64;
    }

    /* Handle any remaining bytes of data. */

    memcpy(ctx->in, bp, len);
}

/*
 * Final wrapup - pad to 64-byte boundary with the bit pattern 
 * 1 0* (64-bit count of bits processed, MSB-first)
 */
void MD5Final(unsigned char digest[16], struct MD5Context *ctx)
{
    unsigned count;
    unsigned char *p;

    /* Compute number of bytes mod 64 */
    count = (ctx->bits[0] >> 3) & 0x3F;

    /* Set the first char of padding to 0x80.  This is safe since there is
       always at least one byte free */
    p = ctx->in + count;
    *p++ = 0x80;

    /* Bytes of padding needed to make 64 bytes */
    count = 64 - 1 - count;

    /* Pad out to 56 mod 64 */
    if (count < 8) {
	/* Two lots of padding:  Pad the first block to 64 bytes */
	memset(p, 0, count);
	MD5Transform(ctx->buf, ctx->in);

	/* Now fill the next block with 56 bytes */
	memset(ctx->in, 0, 56);
    } else {
	/* Pad block to 56 bytes */
	memset(p, 0, count - 8);
    }

    /* Append length in bits and transform */
    put32(ctx->in + 56, ctx->bits[0]);
    put32(ctx->in + 60, ctx->bits[1]);

    MD5Transform(ctx->buf, ctx->in);
    put32(digest, ctx->buf[0]);
    put32(digest + 4, ctx->buf[1]);
    put32(digest + 8, ctx->buf[2]);
    put32(digest + 12, ctx->buf[3]);
    memset(ctx, 0, sizeof(ctx));	/* In case it's sensitive */
}
/*============================================================================*/


static char *program;		/* The current program. */
static char **arguments;	/* The argument array of this program. */
extern char **environ;		/* And the environment. */
static time_t now;		/* The current time. */

static void report(const char *label)
{
    fprintf(stderr, "%s: %s: %s\n", program, label, strerror(errno));
}

static void fatal(const char *label)
{
    report(label);
    exit(1);
}

/* Generally useful macros. */
#define between(a,c,z)	((unsigned) ((c)-(a)) <= (unsigned) ((z)-(a)))
#define isspace(c)	between('\1', c, ' ')

#define N_MAGIC		16	/* Magic number is 16 bytes (128 bits) long */
#define N_AMAGIC   (N_MAGIC*2)	/* Twice as long in ASCII hex digits. */

typedef unsigned char magic_t[N_MAGIC];	/* Magic number type. */
typedef char amagic_t[N_AMAGIC+1];	/* Magic number in ASCII. */

typedef struct authdata {	/* Entry in the authentication data file. */
    magic_t	url;			/* URL magic number. */
    magic_t	cookie;			/* Cookie magic number. */
    time_t	time;			/* Time created. */
    time_t	expire;			/* Cookie expire time. */
    char	u_present, c_present;	/* Is either magic present? */
    char	user[32];		/* Authenticated user. */
} authdata_t;

static unsigned char hex2ascii[16] = "0123456789ABCDEF";
#define h2a(n)	(hex2ascii[n]+0)
static unsigned char ascii2hex[(unsigned char) -1 + 1];
#define a2h(a)	(ascii2hex[(unsigned char)(a)]+0)
#define BADH	((unsigned char) -1)

static void init_a2h(void)
{
    int i;

    memset(ascii2hex, BADH, sizeof(ascii2hex));
    for (i= 0x0; i < 0x10; i++) ascii2hex[h2a(i)]= i;
    for (i= 0xa; i <= 0xf; i++) ascii2hex[i-0xa+'a']= i;
}

static void magic2ascii(char *amagic, magic_t magic)
/* Convert magic number to a null terminated string of N_AMAGIC hex digits. */
{
    int i;

    for (i= 0; i < N_MAGIC; i++) {
	amagic[i*2+0] = h2a((magic[i] >> 4) & 0x0F);
	amagic[i*2+1] = h2a((magic[i] >> 0) & 0x0F);
    }
    amagic[N_AMAGIC]= 0;
}

static int ascii2magic(magic_t magic, char *amagic)
/* Convert a string of hex digits to a magic number.  Return true iff the
 * converted data is exactly N_AMAGIC hex digits.
 */
{
    int i;

    for (i= 0; i < N_AMAGIC; i++) if (a2h(amagic[i]) == BADH) return 0;
    if (amagic[N_AMAGIC] != 0) return 0;

    for (i= 0; i < N_MAGIC; i++) {
	magic[i]= (a2h(amagic[i*2+0]) << 4) | (a2h(amagic[i*2+1]) << 0);
    }
    return 1;
}

static void memerr(void)
{
    fprintf(stderr, "%s: Out of memory\n", program);
    exit(1);
}

static int printauth(FILE *adfp, authdata_t *auth)
/* Print an authorization record in datafile format. */
{
    amagic_t amagic[2];

    magic2ascii(amagic[0], auth->url);
    magic2ascii(amagic[1], auth->cookie);
    return fprintf(adfp, "%s %s %lu %s\n",
	amagic[0], amagic[1], (unsigned long) auth->time, auth->user);
}

static int findauth(authdata_t *auth, char *authfile)
/* Find the entry with the given magic number in the authentication data file,
 * purging the file of all old data and the data we're looking for.  Advisory
 * locking is used to keep auths out of each others hair.  Entry 0 is an
 * administrative entry whose checksum is updated each time with more random
 * data we happen to find.  On this administrative number the new magic number
 * for the user is based if it needs to be updated.
 * Return true iff the entry that produced 'auth' has been found.
 */
{
    int adfd;
    FILE *adfp;
    int c;
    amagic_t amagic;
    struct MD5Context md5c;
    authdata_t *ada, *adp;
    size_t adi, adn;
    size_t ufound, cfound, found;
    struct flock adlk;
    int i;
    unsigned long time;
    char **vp;
    struct timeval tv;
    pid_t pid;

    if ((ada= malloc((adn= 64) * sizeof(ada[0]))) == nil) memerr();
    adi= 0;

    if ((adfd= open(authfile, O_RDWR|O_CREAT, 0600)) < 0) fatal(authfile);

    adlk.l_type= F_WRLCK;
    adlk.l_whence= SEEK_SET;
    adlk.l_start= 0;
    adlk.l_len= 0;
    if (fcntl(adfd, F_SETLKW, &adlk) < 0) fatal(authfile);

    if ((adfp= fdopen(adfd, "r+")) == nil) fatal(authfile);

    while ((c= getc(adfp)) != EOF) {
	if (adi == adn) {
	    if ((ada= realloc(ada, (adn *= 2) * sizeof(ada[0]))) == nil) {
		memerr();
	    }
	}
	adp= &ada[adi];
	memset(adp, 0, sizeof(*adp));

	while (isspace(c) && c != '\n') c= getc(adfp);

	i= 0;
	while (!isspace(c) && c != EOF) {
	    if (i == N_AMAGIC) goto nextentry;
	    amagic[i++]= c;
	    c= getc(adfp);
	}
	amagic[i]= 0;
	if (!ascii2magic(adp->url, amagic)) goto nextentry;

	while (isspace(c) && c != '\n') c= getc(adfp);

	i= 0;
	while (!isspace(c) && c != EOF) {
	    if (i == N_AMAGIC) goto nextentry;
	    amagic[i++]= c;
	    c= getc(adfp);
	}
	amagic[i]= 0;
	if (!ascii2magic(adp->cookie, amagic)) goto nextentry;

	while (isspace(c) && c != '\n') c= getc(adfp);

	time= 0;
	while (!isspace(c) && c != EOF) {
	    if (!between('0', c, '9')) goto nextentry;
	    c -= '0';
	    if (time > (ULONG_MAX - c) / 10) goto nextentry;
	    time= time * 10 + c;
	    c= getc(adfp);
	}
	if (adi == 0) time= now;
	if (time < now-MAX_EXPIRE || time > now) goto nextentry;
	adp->time= time;

	while (isspace(c) && c != '\n') c= getc(adfp);

	i= 0;
	while (!isspace(c) && c != EOF) {
	    if (i == sizeof(adp->user)-1) goto nextentry;
	    adp->user[i++]= c;
	    c= getc(adfp);
	}
	adp->user[i]= 0;

	if (adi == 0 && strcmp(adp->user, version) != 0) goto nextentry;

	while (isspace(c) && c != '\n') c= getc(adfp);

	if (c != '\n') goto nextentry;

	adi++;	/* Entry good. */

      nextentry:
	while (c != EOF && c != '\n') c= getc(adfp);
	if (adi == 0) break;
    }

    if (ferror(adfp)) fatal(authfile);

    if (adi == 0) {
	/* Nothing read or no good; create an administrative entry. */
	memset(&ada[0], 0, sizeof(ada[0]));
	ada[0].time= now;
	strcpy(ada[0].user, version);
	adi++;
    }

    /* This many entries gathered. */
    adn= adi;

    /* Look for the user's magic numbers. */
    ufound= cfound= -1;
    for (adi= 1; adi < adn; adi++) {
	adp= &ada[adi];
	if ((auth->u_present
	    && memcmp(auth->url, adp->url, sizeof(magic_t)) == 0)
	) {
	    if (ufound != -1) { ufound= cfound= -1; break; }
	    ufound= adi;
	}
	if ((auth->c_present
	    && memcmp(auth->cookie, adp->cookie, sizeof(magic_t)) == 0)
	) {
	    if (cfound != -1) { ufound= cfound= -1; break; }
	    cfound= adi;
	}
    }

    /* Update the administrative entry by randomizing it further. */
    MD5Init(&md5c);
    MD5Update(&md5c, ada[0].url, sizeof(magic_t));
    for (vp= arguments; *vp != nil; vp++) {
	MD5Update(&md5c, *vp, strlen(*vp));
    }
    for (vp= environ; *vp != nil; vp++) {
	MD5Update(&md5c, *vp, strlen(*vp));
    }
    gettimeofday(&tv, nil);
    MD5Update(&md5c, &tv, sizeof(tv));
    pid= getpid();
    MD5Update(&md5c, &pid, sizeof(pid));
    pid= getppid();
    MD5Update(&md5c, &pid, sizeof(pid));
    MD5Final(ada[0].url, &md5c);

    /* Rewrite the authorization data file with the entries to keep. */
    if (fseek(adfp, 0, 0) == -1 || ftruncate(adfd, 0) < 0) fatal(authfile);

    for (adi= 0; adi < adn; adi++) {
	if (adi == ufound || adi == cfound) continue;
	if (printauth(adfp, &ada[adi]) == EOF) fatal(authfile);
    }
    if (fclose(adfp) == EOF) fatal(authfile);

    /* If both kinds of magic are found then prefer the newest. */
    found= ufound != -1 ? ufound : cfound;
    if (ufound != -1 && cfound != -1 && ufound != cfound) {
	if (ada[ufound].time > ada[cfound].time) {
	    found= ufound;
	} else {
	    found= cfound;
	}
    }

    /* Copy what we found into *auth. */
    if (found != -1) {
	adp= &ada[found];
	auth->u_present= ufound == found;
	auth->c_present= cfound == found;
	auth->time= adp->time;
	memcpy(auth->cookie, adp->cookie, sizeof(magic_t));
	strcpy(auth->user, adp->user);
    }

    /* The current administrative magic is used as the new URL magic
     * number, but with MD5 applied once more so that the magic given to
     * the user can't be used to guess the current administrative magic
     * number.
     */
    MD5Init(&md5c);
    MD5Update(&md5c, ada[0].url, sizeof(magic_t));
    MD5Final(auth->url, &md5c);

    free(ada);

    return found != -1;
}

static void appendauth(authdata_t *auth, char *authfile)
/* Append a new authorization magic number to the authorization data file. */
{
    int adfd;
    FILE *adfp;
    struct flock adlk;

    if ((adfd= open(authfile, O_WRONLY|O_APPEND, 0600)) < 0) fatal(authfile);

    adlk.l_type= F_WRLCK;
    adlk.l_whence= SEEK_SET;
    adlk.l_start= 0;
    adlk.l_len= 0;
    if (fcntl(adfd, F_SETLKW, &adlk) < 0) fatal(authfile);

    if ((adfp= fdopen(adfd, "w")) == nil) fatal(authfile);

    auth->time= now;
    if (printauth(adfp, auth) == EOF) fatal(authfile);
    if (fclose(adfp) == EOF) fatal(authfile);
}

static int checkpassword(authdata_t *auth)
/* Check if the user and password present on standard input are correct. */
{
    int got_user, got_password, got_other, bad;
    char user[32], password[32];
    char input[1024];
    unsigned long llen;
    size_t len;
    char *ip0, *ip1, *p, *q;
    char *end;
    struct passwd *pw;
    struct MD5Context md5c;

    got_user= got_password= got_other= bad= 0;

    if ((p= getenv("REQUEST_METHOD")) == nil) goto badinput;
    if (strcmp(p, "POST") != 0) goto badinput;
    if ((p= getenv("CONTENT_TYPE")) == nil) goto badinput;
    if (strcmp(p, "application/x-www-form-urlencoded") != 0) goto badinput;
    if ((p= getenv("CONTENT_LENGTH")) == nil) goto badinput;
    llen= strtoul(p, &end, 10);
    if (*end != 0 || llen > sizeof(input)-1) goto badinput;

    alarm(10);	/* Don't wait for input indefinitely. */
    len= fread(input, sizeof(input[0]), llen, stdin);
    if (ferror(stdin)) fatal("CGI input");
    alarm(0);

    input[len]= 0;
    ip1= input;
    while (ip1 != nil && *ip1 != 0) {
	if ((ip1= strchr(ip0= ip1, '&')) != nil) *ip1++ = 0;

	for (p= q= ip0; *p != 0; p++, q++) {
	    if (p[0] == '%' && a2h(p[1]) != BADH && a2h(p[2]) != BADH) {
		*q = (a2h(p[1]) << 4) | (a2h(p[2]) << 0);
		p+= 2;
	    } else
	    if (*p == '+') {
		*q = ' ';
	    } else {
		*q = *p;
	    }
	}
	*q= 0;
	if (strncmp(ip0, "user=", 5) == 0) {
	    got_user++;
	    if (strlen(ip0+5) > sizeof(user)-1) {
		bad= 1;
	    } else {
		strcpy(user, ip0+5);
	    }
	} else
	if (strncmp(ip0, "password=", 9) == 0) {
	    got_password++;
	    if (strlen(ip0+9) > sizeof(password)-1) {
		bad= 1;
	    } else {
		strcpy(password, ip0+9);
	    }
	} else {
	    got_other++;
	}
    }

  badinput:
    if (got_user != 1 || got_password != 1 || got_other != 0) {
	fprintf(stderr,
	    "%s: Authentication form supplies bad input: %d %d %d\n",
	    program, got_user, got_password, got_other);
	exit(1);
    }

    /* User's name. */
    strcpy(auth->user, user);

    if (!bad) {
	if ((pw= getpwnam(user)) == nil || pw->pw_uid == 0) bad= 1;
    }

    if (!bad) {
	if (strcmp(pw->pw_passwd, crypt(password, pw->pw_passwd)) != 0) bad= 1;
    }

    if (bad) {
	sleep(5);	/* Artificially delay password checking. */
	return 0;
    }

    /* Compute a cookie using the password of the user as extra random data. */
    MD5Init(&md5c);
    MD5Update(&md5c, auth->url, sizeof(magic_t));
    MD5Update(&md5c, password, strlen(password));
    MD5Final(auth->cookie, &md5c);

    return 1;
}

static void enccat(char **url, int encode, char *s)
/* Add a string to an URL, using % encoding if so desired. */
{
    char *pu;
    size_t ulen, slen;
    int c;

    ulen= *url == nil ? 0 : strlen(*url);
    slen= strlen(s);
    if (encode) slen *= 3;
    if ((*url= realloc(*url, (ulen + slen + 1) * sizeof(**url))) == nil) {
	memerr();
    }
    pu= *url + ulen;

    while ((c= *s++) != 0) {
	if (!encode || between('0', c, '9') || between('A', c & ~0x20, 'Z')
					|| strchr("_/.,-", c) != nil) {
	    *pu++ = c;
	} else {
	    *pu++ = '%';
	    *pu++ = h2a((c >> 4) & 0xF);
	    *pu++ = h2a((c >> 0) & 0xF);
	}
    }
    *pu= 0;
}

static void redirect(authdata_t *auth)
/* A new magic cookie has just been calculated, tell the browser to retry
 * with this cookie in the URL.
 */
{
    char *url;
    char *s;
    amagic_t amagic;
    char **vp;

    url= nil;

    enccat(&url, 0, "http://");
    if ((s= getenv("SERVER_NAME")) != nil) enccat(&url, 0, s);
    if ((s= getenv("SERVER_PORT")) != nil && strcmp(s, "80") != 0) {
	enccat(&url, 0, ":");
	enccat(&url, 0, s);
    }
    if ((s= getenv("SCRIPT_NAME")) != nil) enccat(&url, 1, s);
    if ((s= getenv("PATH_INFO")) != nil) enccat(&url, 1, s);
    enccat(&url, 0, "?");

    magic2ascii(amagic, auth->url);
    enccat(&url, 1, amagic);

    if (arguments[1] != nil) {
	for (vp= arguments+2; *vp != nil; vp++) {
	    enccat(&url, 0, "+");
	    enccat(&url, 1, *vp);
	}
    }

    printf("Status: 302 Authenticated\n"
	"Location: %s\n"
	"Content-type: text/html\n\n"
	"<html><head><title>302 Authenticated</title></head>\n"
	"<body><h1>Authenticated</h1>\n"
	"You are now authenticated to fetch\n"
	"<a href=\"%s\">%s</a>.\n"
	"</body></html>\n", url, url, url);
    free(url);
}

enum execcode { E_NOAUTH, E_BADPASSWORD, E_EXPIRED, E_AUTHORIZED };

static void execauth(enum execcode code, authdata_t *auth)
{
    amagic_t amagic;
    struct passwd *pw;
    char **vp, *env, *execpath;

    switch (code) {
    case E_NOAUTH:
	arguments[1]= "-noauth";
	break;
    case E_BADPASSWORD:
	arguments[1]= "-badpassword";
	break;
    case E_EXPIRED:
	arguments[1]= "-expired";
	break;
    case E_AUTHORIZED:
	magic2ascii(amagic, auth->url);
	arguments[1]= amagic;
	break;
    }

    /* Recompute QUERY_STRING to let it match the changed arguments. */
    env= nil;
    enccat(&env, 0, "QUERY_STRING=");
    vp= arguments+1;
    for (;;) {
	enccat(&env, 1, *vp++);
	if (*vp == nil) break;
	enccat(&env, 0, "+");
    }
    if (putenv(env) != 0) memerr();

    /* Set USER if the user name is known. */
    if (auth->user[0] != 0) {
	env= nil;
	enccat(&env, 0, "USER=");
	enccat(&env, 0, auth->user);
	if (putenv(env) != 0) memerr();
    }

    if (code < E_AUTHORIZED) {
	/* Run nonprivileged, all we want is a form. */
	if (setgid(getgid()) < 0) fatal("setgid()");
	if (setuid(getuid()) < 0) fatal("setuid()");
    } else {
	/* Run as the authenticated user. */
	if ((pw= getpwnam(auth->user)) == nil || pw->pw_uid == 0) {
	    execauth(E_BADPASSWORD, auth);
	    return;
	}
	if (initgroups(pw->pw_name, pw->pw_gid) < 0) fatal("initgroups()");
	if (setgid(pw->pw_gid) < 0) fatal("setgid()");
	if (setuid(pw->pw_uid) < 0) fatal("setuid()");
	env= nil;
	enccat(&env, 0, "HOME=");
	enccat(&env, 0, pw->pw_dir);
	if (putenv(env) != 0) memerr();
    }

    /* Call the authenticated program, the one with ".auth" added to my name. */
    execpath= nil;
    enccat(&execpath, 0, program);
    enccat(&execpath, 0, ".auth");
    arguments[0]= execpath;
    execv(execpath, arguments);
    fatal(execpath);
}

void emitcookie(authdata_t *auth)
/* Emit a "Set-Cookie" header to give our magic cookie to the browser.  This
 * is a more dependable way to get the cookie back then the "next URL" method.
 */
{
    amagic_t amagic;
    struct tm *tm;
    char *path;
    char *s;
    char date[30];
    time_t expire;

    path= nil;
    if ((s= getenv("SCRIPT_NAME")) == nil || strlen(s) > 1024) return;
    enccat(&path, 1, s);

    magic2ascii(amagic, auth->cookie);

    auth->expire= now + HOUR(1);	/* Refresh every hour. */
    expire= now + MAX_EXPIRE;		/* Let browser keep it a bit longer. */
    tm= gmtime(&expire);
    strftime(date, sizeof(date), "%a, %d %b %Y %T GMT", tm);

    printf("Set-Cookie: MAGIC=%s,%lu; path=%s; expires=%s\n",
	amagic, auth->expire, path, date);
    if (ferror(stdout)) fatal("CGI output");
    free(path);
}

void getcookie(authdata_t *auth)
/* Did the browser return our cookie? */
{
    amagic_t amagic;
    char *s, *end;

    auth->c_present= 0;

    if ((s= getenv("HTTP_COOKIE")) == nil) return;

    for (;;) {
	if (*s == 0) return;
	if (*s == 'M' && strncmp(s, "MAGIC=", 6) == 0) break;
	s++;
    }
    s += 6;
    strncpy(amagic, s, N_AMAGIC);
    amagic[N_AMAGIC]= 0;
    if (!ascii2magic(auth->cookie, amagic)) return;
    s += N_AMAGIC;
    if (*s++ != ',') return;
    auth->expire= strtoul(s, &end, 10);
    if (end == s) return;
    s= end;
    while (isspace(s)) s++;
    auth->c_present= (*s == 0 || *s == ';');
}

int main(int argc, char **argv)
{
    authdata_t auth;

    if (argc == 1) {
	/* We want to be able to set argv[1]. */
	static char *newargv[]= { nil, nil, nil };
	newargv[0]= argv[0];
	argv= newargv;
    }

    init_a2h();

    program= argv[0];
    arguments= argv;
    now= time(nil);

    /* No magic, no nothing. */
    memset(&auth, 0, sizeof(auth));

    /* Browser supplied cookie?. */
    getcookie(&auth);

    if (argc == 1) {
	/* No arguments at all, usually the first call. */

	if (auth.c_present) goto gotcookie;	/* Old authentication? */

	execauth(E_NOAUTH, &auth);
    } else
    if (argv[1][0] == '-') {
	/* A -xxx argument, a user name and password is POSTed our way. */

	(void) findauth(&auth, PATH_AUTHDATA);
	if (checkpassword(&auth)) {
	    appendauth(&auth, PATH_AUTHDATA);
	    emitcookie(&auth);
	    redirect(&auth);
	} else {
	    execauth(E_BADPASSWORD, &auth);
	}
    } else
    if (ascii2magic(auth.url, argv[1])) {
	/* A magic number, is it any good? */

	auth.u_present= 1;	/* Got a magic number from the URL. */

      gotcookie:
	if (findauth(&auth, PATH_AUTHDATA)) {
	    /* One of the magic numbers is ok. */
	    if (auth.time >= now - EXPIRE) {
		/* Magic numbers not yet expired, so grant access. */
		appendauth(&auth, PATH_AUTHDATA);
		if (auth.c_present && auth.expire < now) {
		    /* Browser cookie must be refreshed. */
		    emitcookie(&auth);
		}
		execauth(E_AUTHORIZED, &auth);
	    } else {
		execauth(E_EXPIRED, &auth);
	    }
	} else {
	    execauth(E_NOAUTH, &auth);
	}
    } else {
	char *ref;
	printf("Status: 400 Bad Request\n"
	    "Content-type: text/html\n\n"
	    "<html><head><title>400 Bad Request</title></head>\n"
	    "<body><h1>Bad Request</h1>\n"
	    "The arguments to this script are invalid.  This might be\n"
	    "caused by a wrong external link to this script, or by a bad\n"
	    "link generated by this script.  Please notify the author.\n");
	if ((ref= getenv("HTTP_REFERER")) != nil) {
	    printf("\n<p>\n"
		"The URL of the page you came from, <b>%s</b>,\n"
		"should tell you who to blame\n", ref);
	}
	printf("</body></html>\n");
    }
    return 0;
}

/*	nice/nohup 1.1 - Run nice process.
 */
#define nil 0
#include "string.h"
#include "sys/types.h"
#include "signal.h"
#include "errno.h"

#define NICE_INCR	10
#define NOHUP_INCR	 5

char NOHUPOUT[] = "nohup.out";

char *arg0;
int nohup;

void report(mess) char *mess;
{
	int e= errno;
	std_err(arg0);
	std_err(": ");
	errno= e;
	perror(mess);
}

void fatal(mess) char *mess;
{
	report(mess);
	exit(1);
}

void Usage()
{
	std_err("Usage: ");
	std_err(arg0);
	if (!nohup) std_err(" [-incr]");
	std_err(" command [arg] ...\n");
	exit(-1);
}

void redirect(fd) int fd;
{
	static int out= -1;

	if (out < 0) {
		close(fd);

		if ((out= creat(NOHUPOUT, 0666)) < 0)
			fatal(NOHUPOUT);

		if (out != fd) { dup2(out, fd); close(out); out= fd; }
	} else
		dup2(out, fd);
}

main(argc, argv) int argc; char **argv;
{
	int incr;

	if ((arg0= strrchr(argv[0], '/')) == nil) arg0= argv[0]; else arg0++;

	nohup= strcmp(argv[0], "nohup") == 0;

	incr= nohup ? NOHUP_INCR : NICE_INCR;

	if (!nohup && argc > 1 && argv[1][0] == '-') {
		if ((incr= atoi(argv[1] + 1)) == 0) Usage();
		argc--;
		argv++;
	}
	if (argc < 2) Usage();

	if (nohup) {
		if (isatty(1)) redirect(1);
		if (isatty(2)) redirect(2);

		signal(SIGHUP, SIG_IGN);
		signal(SIGTERM, SIG_IGN);
	}

	nice(incr);
	execvp(argv[1], argv + 1);

	fatal(argv[1]);
}
/* Kees J. Bot 6-5-89. */

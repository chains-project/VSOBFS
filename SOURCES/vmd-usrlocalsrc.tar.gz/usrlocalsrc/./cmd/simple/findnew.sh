#!/bin/sh

test $# = 0 && set /usr

>/tmp/t
utime /tmp/t || exit

#case "`uname -n`" in
#*.home.cs.vu.nl)
#	;;
#*)	for dir
#	do
#		remsync -s $dir /usr/src/tmp/state/`basename $dir`
#	done
#esac

find "$@" -xdev -newer /tmp/t \( -type f -o -type l \) -print | sort >/tmp/l

rm -f /tmp/t

exec "${EDITOR-vi}" /tmp/l

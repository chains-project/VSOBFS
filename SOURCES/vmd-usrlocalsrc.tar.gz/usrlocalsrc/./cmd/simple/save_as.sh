#!/bin/sh
#
# save_as 1.0 - Save the files in . in ./save		Author: Kees J. Bot

case $# in
1)	;;
*)	echo "Usage: save_as <name>" >&2
	exit 1
esac

test -d save || mkdir save || exit

tar cvf "save/$1.tar" `for i in *; do test -f "$i" && echo $i; done`

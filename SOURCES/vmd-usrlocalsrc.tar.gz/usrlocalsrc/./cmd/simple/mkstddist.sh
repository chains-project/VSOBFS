#!/bin/sh
#
#	mkstddist 1.4 - Make a standard Minix distribution.
#							Author: Kees J. Bot
#								8 May 2001

# Directories in that must be put in USR.TAZ, SYS.TAZ and CMD.TAZ:
usrdirs='adm ast bin etc include lib local man mdec preserve run spool src tmp'
sysdirs='include man src'
cmddirs='src/commands'

# Files that make up NET.TAZ (except for the kernel image.)
netfiles='
	usr/adm
	usr/bin/add_route
	usr/bin/del_route
	usr/bin/dhcpd
	usr/bin/hostaddr
	usr/bin/ifconfig
	usr/bin/in.rld
	usr/bin/in.rshd
	usr/bin/inet
	usr/bin/tcpd
	usr/bin/tcpdp
	usr/bin/nonamed
	usr/bin/ping
	usr/bin/pr_routes
	usr/bin/ps
	usr/bin/rcp
	usr/bin/rsh
	usr/bin/telnet
	usr/bin/urlget
	usr/run
'

@()
{
    # Dereference, i.e. y=z; x=y; $(@ $x) = z
    eval "echo \$$1"
}

usage()
{
    cat >&2 <<EOF
Usage:	$0 floppy arch std-path dist-path
	$0 usr arch std-path dist-path
	$0 src std-path dist-path
	$0 net arch std-path dist-path net-image
	$0 dos arch std-path dist-path
	arch:	   Architecture: i86, i386
	std-path:  Where the standard Minix system roots
	dist-path: Root of the distribution
	floppy:    The word "floppy", given when making ROOT.MNX and USR.MNX
	usr:       The word "usr", given when making USR.TAZ
	src:       The word "src", given when making SYS.TAZ and CMD.TAZ
	net:	   The word "net", given when making NET.TAZ
	net-image: A "fat" networking kernel image
	dos:	   The word "dos", given when making DOSMinix
EOF
    exit 1
}

# No options.
while getopts '' opt; do case "$opt" in ?) usage; esac; done
shift `expr $OPTIND - 1`

# Source is same for all architectures, but we need to cater to the lowest.
case "$1" in
src)	shift 1; set -- src i86 "$@"
esac

what="$1" arch="$2" std_path="$3" dist_path="$4" net_image="$5"

case "$#:$what:$arch" in
4:floppy:i86 | 4:floppy:i386)	:;;
4:usr:i86 | 4:usr:i386)		:;;
4:src:i86)			:;;
4:dos:i86 | 4:dos:i386)		:;;
5:net:i86 | 5:net:i386)		:;;
*)				usage
esac

# In 16-bit mode we can only compress using a 13-bit something.
case "$what:$arch" in
dos:*)	compress='false'		;;	# Making .zip here.
*:i86)	compress='compress -b13'	;;
*:i386)	compress='compress -b16'	;;
esac

# Check arguments and make them absolute so we can move around with 'cd'
# without losing track of what's where.

for var in std_path dist_path net_image
do
    case "$(@ $var)" in
    /*) : fine
	;;
    ?*)  setvar $var "`pwd`/$(@ $var)"
    esac
done

# We must be 0:0.
case "`id`" in
uid=0\(*gid=0\(*)
    : fine
    ;;
*)  echo "$0: You have to be root:operator for this" >&2
    exit 1
esac
umask 022

# Create stubs for directories that must be masked.
stubs=/tmp/.stubs
rm -rf $stubs

install -d -m 755 -o root $stubs/adm
>$stubs/adm/lastlog
>$stubs/adm/log
>$stubs/adm/wtmp

install -d -m 755 -o bin $stubs/include

install -d -m 775 -o bin $stubs/local
for dir in bin include lib man src
do
    install -d -m 775 -o bin $stubs/local/$dir
done

install -d -m 755 -o bin $stubs/man

install -d -m 755 -o root $stubs/run

install -d -m 755 -o bin $stubs/src
cp -p "$std_path"/usr/src/.??* $stubs/src

install -d -m 755 -o bin $stubs/src_commands

>/tmp/DONE

case "$what" in
floppy)
    d="$dist_path/$arch"
    mkdir -p "$d" || exit
    dd if=/dev/zero of="$d/ROOT.MNX" bs=1k count=480 conv=silent || exit
    dd if=/dev/zero of="$d/USR.MNX" bs=1k count=720 conv=silent || exit
    umount /dev/loop0 2>/dev/null
    umount /dev/loop1 2>/dev/null
    loop_ctrl -a /dev/loop0 "$d/ROOT.MNX" || exit
    loop_ctrl -a /dev/loop1 "$d/USR.MNX" || exit
    "$std_path/usr/bin/mkdist" "$std_path" /dev/loop0 /dev/loop1 || exit
    loop_ctrl -d /dev/loop0 || exit
    loop_ctrl -d /dev/loop1 || exit
    ;;
usr)
    for dir in adm include local man run src
    do
	umount "$std_path/usr/$dir" >/dev/null 2>&1
	mount -t lo $stubs/$dir "$std_path/usr/$dir" || exit
    done

    cd "$std_path/usr" || exit

    tar cvf - $usrdirs /tmp/DONE | $compress > "$dist_path/$arch/USR.TAZ"

    for dir in adm include local man run src
    do
	umount "$std_path/usr/$dir" || exit
    done
    ;;
src)
    mkdir -p "$dist_path/src" || exit

    umount "$std_path/usr/src/commands" >/dev/null 2>&1
    mount -t lo $stubs/src_commands "$std_path/usr/src/commands" || exit

    cd "$std_path/usr" || exit

    tar cvf - $sysdirs /tmp/DONE | $compress > "$dist_path/src/SYS.TAZ"

    umount "$std_path/usr/src/commands" || exit

    tar cvf - $cmddirs /tmp/DONE | $compress > "$dist_path/src/CMD.TAZ"

    install -d -m 755 "$dist_path/wwwman"
    man2www -v Minix "$std_path/usr/man" "$dist_path/wwwman"

    for i in usage boot
    do
	nroff -man "$std_path/usr/man/man8/$i.8" |
	    bsfilt - | sed 's/$//' >"$dist_path/$i.txt"
    done
    ;;
dos)
    umount /mnt >/dev/null 2>&1
    umount /fd0 >/dev/null 2>&1

    dmdisk=/usr/tmp/.dmdisk
    dd if=/dev/zero of=$dmdisk bs=1024k count=50 conv=silent || exit
    loop_ctrl -a /dev/loop0 $dmdisk || exit
    loop_ctrl -a -b 1k -s 1440k /dev/loop1 $dmdisk || exit
    loop_ctrl -a -b 1441k -s 4096k /dev/loop2 $dmdisk || exit
    loop_ctrl -a -b 5537k /dev/loop3 $dmdisk || exit

    partition -mf /dev/loop0 2 81:2880* 81:8192 81:60000+ || exit
    mkfs -t 2 -i 512 /dev/loop1 || exit
    mkfs -t swap /dev/loop2 || exit
    mkfs -t 2 /dev/loop3 || exit

    loop_ctrl -d /dev/loop2 || exit
    loop_ctrl -a /dev/loop2 "$dist_path/$arch/ROOT.MNX" || exit

    mount /dev/loop1 /mnt || exit
    mount /dev/loop2 /fd0 || exit

    cpdir -v /fd0 /mnt || exit

    echo >/mnt/etc/fstab "\
# Poor man's File System Table.

root=/dev/c0d0p0
swap=/dev/c0d0p1
usr=/dev/c0d0p2"
    rm /mnt/etc/issue || exit

    umount /fd0 || exit
    umount /mnt || exit

    installboot -m /dev/loop0 /usr/mdec/masterboot || exit
    installboot -d /dev/loop1 /usr/mdec/bootblock boot || exit
    edparams /dev/loop1 "rootdev=bootdev; save" || exit

    mount /dev/loop3 /mnt || exit

    cd /mnt || exit
    chmod 755 .
    for i in $arch/USR.TAZ src/SYS.TAZ src/CMD.TAZ
    do
	zcat < "$dist_path/$i" | tar xvfp - || exit
    done
    cd /

    umount /mnt || exit

    for i in 0 1 2 3; do loop_ctrl -d /dev/loop$i || exit; done

    dmzip=/tmp/.dmzip
    rm -rf $dmzip
    mkdir $dmzip || exit
    cd $dmzip || exit
    ln -s "$dist_path/dosminix.html" README.HTM || exit
    ln -s "$dist_path/dosminix.txt" README.TXT || exit
    ln -s "$dist_path/bochsrc.txt" minix.bxrc || exit
    ln -s /usr/mdec/boot.com BOOT.COM || exit
    ln -s /usr/mdec/mkfile.com MKFILE.COM || exit
    if [ -f "$dist_path/favicon.ico" ]
    then
	ln -s "$dist_path/favicon.ico" MINIX.ICO || exit
    elif [ -f "$dist_path/../favicon.ico" ]
    then
	ln -s "$dist_path/../favicon.ico" MINIX.ICO || exit
    else
	echo >&2 "$0: Can't find a favicon.ico near $dist_path"
	exit 1
    fi
    ln -s $dmdisk MINIX.MNX || exit

    rm -f "$dist_path/$arch/DOSMINIX.ZIP"
    zip -9 "$dist_path/$arch/DOSMINIX.ZIP" README.* *.bxrc *.COM MINIX.* || exit
    cd /
    rm -r $dmzip $dmdisk || exit
    ;;
net)
    net=/tmp/.net
    rm -rf $net
    mkdir $net || exit
    cd $net || exit
    mkdir minix usr usr/bin || exit
    ln -s "$net_image" minix
    for i in $netfiles
    do
	ln -s "$std_path/$i" "$i" || exit
    done
    tar cvfhD - minix/* $netfiles /tmp/DONE |
	$compress > "$dist_path/$arch/NET.TAZ"
    cd /
    rm -r $net
    ;;
esac

rm -r $stubs
exit 0

#!/bin/sh
#
#	fixperms 1.1 - fix up file permissions.		Author: Kees J. Bot

case $# in
0)	echo "Usage: fixperms <file|dir> ..." >&2
	exit 1
esac

# Directories.
find "$@" -type d -print0 | xargs -0 chmod 755

# Plain files.
find "$@" -type f ! -perm -100 -print0 | xargs -0 chmod 644

# Executables.
find "$@" -type f -perm -100 -print0 | xargs -0 chmod u+rwx,g+rx,g-w,o+rx,o-w

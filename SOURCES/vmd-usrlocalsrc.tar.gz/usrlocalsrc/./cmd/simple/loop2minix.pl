#!/usr/bin/perl -w
#
#	loop2minix 1.0 - point loop devices to subpartitions
#							Author: Kees J. Bot
#								16 May 1999

sub usage
{
    die "Usage: loop2minix [-d] [-o offset] minix-partition\n";
}

$debug = 0;
$loop_offset = 0;

while (@ARGV && $ARGV[0] =~ /^-/) {
    local($opts) = shift(@ARGV);

    last if $opts eq '--';

    while ($opts =~ /^-(.)(.*)$/) {
	if ($1 eq 'd') {
	    $debug = 1;
	    $opts = "-$2";
	}
	elsif ($1 eq 'o') {
	    if ($2 eq '') {
		&usage unless @ARGV;
	    	$loop_offset = shift(@ARGV);
	    } else {
	    	$loop_offset = $2;
	    }
	    $opts = '';
	} else {
	    &usage;
	}
    }
}

unless ($loop_offset =~ /^\d+$/) {
    die "loop2minix: Loop offset \"$loop_offset\" is not a number\n";
}

&usage unless @ARGV == 1;
$device = shift(@ARGV);

open(MDEV, "<$device") || die "loop2minix: $device: $!\n";

$sbr = '';
read(MDEV, $sbr, 512) || die "loop2minix: $device: $!\n";

close(MDEV);

if (unpack("v", substr($sbr, 510, 2)) != 0xAA55) {
    die "loop2minix: Bootstrap of $device doesn't have ",
	"a 0xAA55 boot signature\n";
}

die "Here we find out that absolute offsets in Minix subpartition tables\n",
    "aren't very nice when you don't know where the partition starts....\n";

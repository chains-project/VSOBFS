#!/usr/bin/perl
#
#	man2www 1.3 - transform a manual page tree to a "clickable" form.
#							Author: Kees J. Bot
#								20 Feb 1996

# Nroff attributes.
$top_lines = 5;			# Header lines at the top of a page.
$bot_lines = 4;			# Trailer lines at the end of a page.
$page_length = 59;		# Lines per page.

sub usage
{
	die "Usage: $0 [-v] <sysname> <mandir> <wwwdir>\n";
}

# Main program.
while (@ARGV > 0 && $ARGV[0] =~ /^-/) {
	local($flags) = substr(shift(@ARGV), 1);

	last if $flags eq '-';

	while ($flags ne '') {
		if ($flags =~ /^v/) {
			$verbose = 1;
		} else {
			&usage();
		}
		$flags = substr($flags, 1);
	}
}

&usage() if (@ARGV != 3);
$sysname = $ARGV[0];
$mandir = $ARGV[1];
$wwwdir = $ARGV[2];

open(WHATIS, "<$mandir/whatis") || die "$0: $mandir/whatis: $!\n";
open(WWWWHATIS, ">$wwwdir/whatis.html") || die "$0: $wwwdir/whatis.html: $!\n";

@whatis = ();

while ($wline = <WHATIS>) {
	# Transform one whatis line to html.

	$wline =~ /^([^ ,]+)([^(]*)(\(([0-9]+)\).*)/;

	push(@whatis, "$4/$1/$2/$3");
}
close(WHATIS);

print WWWWHATIS "<html>\n";
print WWWWHATIS "<head><title>List of $sysname manual pages</title></head>\n";
print WWWWHATIS "<body><h2>$sysname Manual Pages</h2>\n";

# Sort the result, first section, then title.  Create a whatis file in html
# form and transform each manual page.
foreach $wline (sort(@whatis)) {
	($section, $title, $aliases, $wline) = split('/', $wline, 4);

	$manpage = "$mandir/man$section/$title.$section";
	$wwwpage = "$wwwdir/man$section/$title.$section.html";

	next unless -f $manpage;

	print WWWWHATIS "<a href=\"man$section/$title.$section.html\">",
		"$title</a>$aliases$wline<br>\n";

	$mtime = (stat(_))[9];
	next if -f $wwwpage && (stat(_))[9] >= $mtime;

	if (! -d "$wwwdir/man$section") {
		mkdir("$wwwdir/man$section", 0755)
			|| die "$0: $wwwdir/man$section: $!\n";
		$verbose && print STDERR "mkdir $wwwdir/man$section\n";
	}

	$macros = $section eq '9' ? "-mnx" : "-man";

	$cmd = "nroff $macros '$manpage' |"
	     . "man2html -noheads -topm $top_lines -botm $bot_lines "
		. "-pgsize $page_length -title '$title($section)' "
		. "-cgiurl '../man\$section/\$title.\$section\$subsection.html'"
		. ">'$wwwpage'";

	if (system($cmd) != 0) {
		unlink($wwwpage);
		exit(1);
	}

	$verbose && print STDERR "nroff $manpage | man2html > $wwwpage\n";

	# Make links under the names of the aliases.
	foreach $alias (split(/[\s,]/, $aliases)) {
		next if $alias eq '';
		$alias = "$wwwdir/man$section/$alias.$section.html";
		if (!link($wwwpage, $alias)) {
			unlink($alias);
			link($wwwpage, $alias) ||
				die "$0: ln $wwwpage $alias: $!\n";
		}
		$verbose && print STDERR "ln $wwwpage $alias\n";
	}
}
print WWWWHATIS "</body>\n</html>\n";

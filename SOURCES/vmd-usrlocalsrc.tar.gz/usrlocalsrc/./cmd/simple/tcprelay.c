/*	tcprelay 1.0 - Relay TCP connections, possibly slowly
 *							Author: Kees J. Bot
 *								16 Oct 1997
 * Relay a TCP connection from one machine:port combination to
 * another in such as way that a service at one machine seems to exist
 * in two places.  One can also artificially delay the connection to speeds
 * that are normal on the Information Superdirtroad at rush hour.
 */
#define nil 0
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/asynchio.h>
#include <sys/ioctl.h>

#if !__minix_vmd && !__SVR4
#error It looks like you have some work to do
#endif

#if __minix_vmd
/* Minix specific include files and kludges. */
#include <net/netlib.h>
#include <net/hton.h>
#include <net/gen/in.h>
#include <net/gen/netdb.h>
#include <net/gen/tcp.h>
#include <net/gen/tcp_io.h>
#endif /* __minix_vmd */

#if __SVR4
/* Solaris / BSD socket specific include files. */
#include <sys/stropts.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#endif /* __SVR4 */

static void report(const char *label)
{
    fprintf(stderr, "tcprelay: %s: %s\n", label, strerror(errno));
}

static void fatal(const char *label)
{
    report(label);
    quit(1);
}

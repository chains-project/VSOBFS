#!/usr/bin/perl -w
#
#	rgetthis/rputthis 1.0 - Frontend for rget/rput and remsync
#							Author: Kees J. Bot
#								21 Sep 2002

$name = $0;
$name =~ s:^.*/::;

$lflag = $cflag = $hflag = 0;

sub usage
{
    die <<EOF;
Usage: $name [-lc] [-h host] key file
	-l: Open TCP socket and listen (default for rputthis)
	-c: Connect to a remote TCP socket (default for rgetthis)
	key: A word to hash into a port number, or simply a port number
EOF
}

# Main program.

die "Don't know what to do when you call me '$name'\n"
    unless $name =~ /^r(get|put)this$/;

while (@ARGV > 0 && $ARGV[0] =~ /^-/) {
    local($opt) = shift(@ARGV);

    last if $opt eq '--';

    while (($opt = substr($opt, 1)) ne '') {
	$lflag = 1 if $opt =~ /^l/;
	$cflag = 1 if $opt =~ /^c/;
	if ($opt =~ /^h/) {
	    $hflag = 1;
	    if (($host = substr($opt, 1)) eq '') {
		&usage if @ARGV == 0;
		$host = shift(@ARGV);
	    }
	    last;
	}
    }
}

&usage if @ARGV != 2;
($key, $file) = @ARGV;

# Defaults.
if (!$lflag && !$cflag) {
    $lflag = 1 if $name eq 'rputthis';
    $cflag = 1 if $name eq 'rgetthis';
}

# Constraints.
if ($lflag && $cflag) {
    die "$name: -c and -l don't mix\n";
    &usage;
}
if ($cflag && !$hflag) {
    die "$name: -c requires a host name given with -h\n";
    &usage;
}
if ($lflag && $hflag) {
    die "$name: -l does not require a host name given with -h\n";
    &usage;
}

# So they can be put in '':
($qhost = $host) =~ s/'/'\\''/ if $hflag;
($qkey = $key) =~ s/'/'\\''/;
($qfile = $file) =~ s/'/'\\''/;

undef $/;				# Don't break input at newlines.

# Flags needed to either listen or connect.
if ($lflag) {
    $rflags = "-l";
} else {
    $rflags = "-c -h '$qhost'";
}

if ($name eq 'rgetthis') {
    # Transmit a statefile to the other side and implement a dif.
    system("rput $rflags '$qkey' remsync -s '$qfile'") == 0 || exit 1;
    system("rget $rflags '$qkey' remsync -v '$qfile'") == 0 || exit 1;
} else {
    # Receive a statefile and send a dif to the other side.
    open(STATE, "rget $rflags '$qkey'|") || die "$name: rget: $!\n";
    $state = <STATE>;
    close(STATE);
    open(DIF, "|rput $rflags '$qkey' remsync -dv '$qfile'")
	|| die "$name: rput: $!\n";
    print DIF $state;
    close(DIF);
}
exit 0;

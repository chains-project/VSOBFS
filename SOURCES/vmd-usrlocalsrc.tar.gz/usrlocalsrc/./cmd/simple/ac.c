/* Notes */ /*{{{C}}}*//*{{{*/
/*
Written by Michael Haardt, 1995, 1997.
*/
/*}}}*/
/* #includes */ /*{{{*/
#undef  _POSIX_SOURCE
#define _POSIX_SOURCE   1
#undef  _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 2

#ifdef _XOPEN_SOURCE
#include <nl_types.h>
#else
typedef long nl_catd;
static nl_catd catopen(char *name, int oflag) { return 0; }
static char *catgets(nl_catd catd, int set_id, int msg_id, char *msg) { return msg; }
#endif

#include <assert.h>
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <utmp.h>

#ifdef __minix		/* Stuff missing in Minix */
#define NO_UT_DEFS	1
#define WTMP_FILE	"/usr/adm/wtmp"
#define OLD_TIME	-1		/* not used */
#define NEW_TIME	-2

static const char *utmp_file;
static FILE *utmp_fp;

void utmpname(const char *file)
{
  utmp_file=file;
}

struct utmp *getutent(void)
{
  static struct utmp ut;

  if (utmp_fp==0 && (utmp_fp=fopen(utmp_file, "r"))==0) return 0;
  if (fread(&ut,sizeof(ut),1,utmp_fp)!=1) return 0;
  return &ut;
}

#ifdef __minix_vmd
/* Bug in setlocale(), better avoid it. */
#define setlocale(category, locale)	"C"
#endif /* __minix_vmd */
#endif /* __minix */

#ifdef NO_UT_DEFS
extern struct utmp sample;
#define UT_LINESIZE sizeof(sample.ut_line)
#define UT_NAMESIZE sizeof(sample.ut_name)
#define UT_HOSTSIZE sizeof(sample.ut_host)
#endif
/*}}}*/
/* #defines */ /*{{{*/
#undef DEBUG

#define TOTAL        catgets(catd,1,1,"total")
#define USAGE        catgets(catd,1,2,"Usage: ac [-v][-d][-w wtmpfile][-p] [user ...]\n")
#define NOMEM        catgets(catd,1,3,"ac: out of memory.\n")
#define EXTRADEAD2   catgets(catd,1,4,"ac: Warning: Extra logout record for user %s on line %s.\n")
#define MISSLOGOUT   catgets(catd,1,5,"ac: Warning: Missing logout record for line %s.\n")
#define UNKNOWNREC   catgets(catd,1,6,"ac: Warning: Unknown record type %d.\n")
#define NULLUSER     catgets(catd,1,7,"ac: Warning: USER_PROCESS record with null user for line %s.\n")
/*}}}*/

/* types */ /*{{{*/
typedef struct
{
  char line[UT_LINESIZE];
  char name[UT_NAMESIZE];
  time_t login;
} Terminal;

typedef struct
{
  char name[UT_NAMESIZE];
  int ref;
  time_t login;
  time_t ac;
} User;
/*}}}*/
/* variables */ /*{{{*/
static Terminal **terminal=(Terminal**)0;
static int terminals=0,terminalc=0;
static User **user=(User**)0;
static unsigned int users=0,userc=0;
static nl_catd catd;
static int verbose=0;
#ifdef NO_UT_DEFS
struct utmp sample;
#endif
/*}}}*/

/* find_user */ /*{{{*/
static int find_user(const char *name)
{
  int i;

  assert(name!=(const char*)0);
  assert(*name!='\0');
  for (i=0; i<users; ++i) if (strncmp(user[i]->name,name,UT_NAMESIZE)==0) return i;
  return -1;
}
/*}}}*/
/* find_terminal */ /*{{{*/
static int find_terminal(const char *line)
{
  int i;

  assert(line!=(const char*)0);
  assert(*line!='\0');
  for (i=0; i<terminals; ++i) if (terminal[i]!=(Terminal*)0 && strncmp(line,terminal[i]->line,UT_LINESIZE)==0) return i;
  return -1;
}
/*}}}*/
/* deref_terminal */ /*{{{*/
static void deref_terminal(const char *line, time_t logout)
{
  int i,j;
  char namestr[UT_NAMESIZE+1];
  char linestr[UT_LINESIZE+1];

  assert(line!=(const char*)0);
  assert(*line!='\0');
  /* There may be extra logout records, because init does not know */
  /* if someone actually logged in on a tty.                       */
  if ((i=find_terminal(line))!=-1)
  {
    j=find_user(terminal[i]->name);
    assert(j!=-1);
    if (user[j]->ref==0)
    {
      strncpy(linestr,line,UT_LINESIZE);
      linestr[UT_LINESIZE]='\0';
      strncpy(namestr,terminal[i]->name,UT_LINESIZE);
      namestr[UT_NAMESIZE]='\0';  
      if (verbose) fprintf(stderr,EXTRADEAD2,namestr,linestr);
    }
    else
    {
      --user[j]->ref;      
      if (user[j]->ref==0) user[j]->ac+=logout-user[j]->login;
    }
    free(terminal[i]);
    terminal[i]=(Terminal*)0;    
  }
}
/*}}}*/
/* ref_user */ /*{{{*/
static void ref_user(const char *name, const char *line, time_t login)
{
  int i;

  assert(name!=(const char*)0);
  assert(*name!='\0');
  assert(line!=(const char*)0);
  assert(*line!='\0');
  if ((i=find_user(name))==-1) /* add user */ /*{{{*/
  {
    if (users==userc)
    {
      user=realloc(user,(userc ? (userc*=2) : (userc=32))*sizeof(User*));
      if (user==(User**)0)
      {
        fprintf(stderr,NOMEM);
        exit(2);
      }
    }    
    i=users;
    user[i]=malloc(sizeof(User));
    user[i]->ac=0; 
    user[i]->ref=0;
    strncpy(user[i]->name,name,UT_NAMESIZE);
    ++users;
  }
  /*}}}*/
  if (user[i]->ref==0) user[i]->login=login;
  ++user[i]->ref;
  if ((i=find_terminal(line))!=-1)
  {
    char linestr[UT_LINESIZE+1];
  
    strncpy(linestr,line,UT_LINESIZE);
    linestr[UT_LINESIZE]='\0';
    if (verbose) fprintf(stderr,MISSLOGOUT,linestr);
    deref_terminal(line,login);
  }  
  /* add_terminal */ /*{{{*/
  for (i=0; i<terminals && terminal[i]!=(Terminal*)0; ++i);
  if (i==terminalc)
  {
    terminal=realloc(terminal,(terminalc ? (terminalc*=2) : (terminalc=32))*sizeof(Terminal*));
    if (terminal==(Terminal**)0)
    {
      fprintf(stderr,NOMEM);
      exit(2);
    }
  }
  if (i==terminals) ++terminals;
  terminal[i]=malloc(sizeof(Terminal));
  strncpy(terminal[i]->line,line,UT_LINESIZE);
  strncpy(terminal[i]->name,name,UT_NAMESIZE);  
  terminal[i]->login=login;
  return;
  /*}}}*/
}
/*}}}*/
/* logoutall */ /*{{{*/
static void logoutall(struct utmp *u)
{
  unsigned int i;
  
  assert(u!=(struct utmp*)0);
  for (i=0; i<terminals; ++i) if (terminal[i]!=(Terminal*)0)
  {
    deref_terminal(terminal[i]->line,u->ut_time);
  }
  for (i=0; i<users; ++i) assert(user[i]->ref==0);
  for (i=0; i<terminals; ++i) assert(terminal[i]==(Terminal*)0);
}
/*}}}*/
/* update_ac */ /*{{{*/
static void update_ac(time_t t)
{
  unsigned int i;

  for (i=0; i<users; ++i) if (user[i]->ref)
  {
    user[i]->ac+=(t-user[i]->login);
    user[i]->login=t;
  }
}
/*}}}*/
/* print_users */ /*{{{*/
static void print_users(int argc, char *argv[], time_t t, int personal)
{
  /* variables */ /*{{{*/
  int i,j;
  int ok;
  time_t total;
  struct tm *tm;
  size_t datelen;
  char buf[80];
  /*}}}*/

  assert(argc>=0);
  tm=localtime(&t);
  assert(tm!=(struct tm*)0);
  if (strcmp(setlocale(LC_TIME,(const char*)0),"C")==0 || strcmp(setlocale(LC_TIME,(const char*)0),"POSIX")==0) strftime(buf,sizeof(buf),"%b %d  ",tm);
  else strftime(buf,sizeof(buf),"%x  ",tm);
  datelen=strlen(buf);
  for (total=0,i=0; i<users; ++i)
  {
    if (argc==0) ok=1;
    else
    {
      for (ok=0,j=0; j<argc; ++j) if (strncmp(argv[j],user[i]->name,UT_NAMESIZE)==0)
      {
        ok=1;
        break;
      }
    }
    if (ok && user[i]->ac)
    {
      char name[UT_NAMESIZE+1];

      total+=user[i]->ac;
      if (personal)
      {
        strncpy(name,user[i]->name,UT_NAMESIZE);
        name[UT_NAMESIZE]='\0';
        for (j=0; j<datelen; ++j) putchar(' ');
        printf("%-*s %3ld.%02ld\n",UT_NAMESIZE,name,user[i]->ac/3600,(100*(user[i]->ac%3600))/3600);
      }
      user[i]->ac=0;
    }
  }
  printf("%s%-*s %3ld.%02ld\n",buf,UT_NAMESIZE,TOTAL,total/3600,(100*(total%3600))/3600);
}
/*}}}*/

/* main */ /*{{{*/
int main(int argc, char *argv[], char *env[])
{
  /* variables */ /*{{{*/
  struct utmp *utmp;
  time_t now;
  struct tm tm;
  time_t next_midnight, last_time;
  int perday=0;
  int uptonow=1;
  int personal=0;
  int c;
  int peopleind;
  const char *wtmpfile=WTMP_FILE;
  /*}}}*/

  /* set locale */ /*{{{*/
  setlocale(LC_ALL,"");
  catd=catopen("ac",0);
  /*}}}*/
  /* parse options */ /*{{{*/
  while ((c=getopt(argc,argv,"vdw:p?"))!=EOF) switch(c)
  {
    case 'p': personal=1; break;
    case 'd': perday=1; break;
    case 'v': verbose=1; break;
    case 'w': wtmpfile=optarg; uptonow=0; break;
    default: fprintf(stderr,USAGE); exit(1);
  }
  peopleind=optind;
  utmpname(wtmpfile);
  /*}}}*/
  next_midnight=0;
  last_time=0;
  while ((utmp=getutent())!=(struct utmp*)0)
  {
    last_time=utmp->ut_time;
    if (perday)
    {
      if (next_midnight==0)
      /* determine first midnight after time of this entry */ /*{{{*/
      {
        time_t last_midnight;
        struct tm tm;

        tm=*localtime(&utmp->ut_time);
        tm.tm_hour=0;
        tm.tm_min=0;
        tm.tm_sec=0;
        last_midnight=mktime(&tm);
        next_midnight=last_midnight+((time_t)36)*3600;
        tm=*localtime(&next_midnight);
        tm.tm_hour=0;
        tm.tm_min=0;
        tm.tm_sec=0;
        next_midnight=mktime(&tm);
      }
      /*}}}*/
      while (utmp->ut_time>=next_midnight)
      /* print accounting records for passed day(s) */ /*{{{*/
      {
        update_ac(next_midnight);
        print_users(argc-peopleind,argv+peopleind,next_midnight-1,personal);
        next_midnight+=((time_t)36)*3600;
        tm=*localtime(&next_midnight);
        tm.tm_hour=0;
        tm.tm_min=0;
        tm.tm_sec=0;
        next_midnight=mktime(&tm);
      }
      /*}}}*/
    }
    switch (utmp->ut_type)
    {
      /* RUN_LVL */ /*{{{*/
      case RUN_LVL:
      {
        if (strncmp(utmp->ut_line,"~",UT_LINESIZE)==0)
        {
          if (strncmp(utmp->ut_user,"shutdown",UT_NAMESIZE)==0) logoutall(utmp);
          else if (strncmp(utmp->ut_user,"runlevel",UT_NAMESIZE)==0);
          #ifdef DEBUG    
          else fprintf(stderr,"runlevel change user %s\n",utmp->ut_user);
          #endif    
        }  
        #ifdef DEBUG
        else fprintf(stderr,"runlevel change tty %s user %s\n",utmp->ut_line,utmp->ut_user);
        #endif  
        break;
      }
      /*}}}*/
      /* BOOT_TIME */ /*{{{*/
      case BOOT_TIME:
      {
        if (strncmp(utmp->ut_line,"~",UT_LINESIZE)==0 && strncmp(utmp->ut_user,"reboot",UT_NAMESIZE)==0) logoutall(utmp);
        #ifdef DEBUG
        else fprintf(stderr,"boot time tty %s user %s\n",utmp->ut_line,utmp->ut_user);
        #endif  
        break;
      }
      /*}}}*/
      /* OLD_TIME */ /*{{{*/
      case OLD_TIME: break;
      /*}}}*/
      /* NEW_TIME */ /*{{{*/
      case NEW_TIME: break;
      /*}}}*/
      /* INIT_PROCESS */ /*{{{*/
      case INIT_PROCESS: break;
      /*}}}*/
      /* LOGIN_PROCESS */ /*{{{*/
      case LOGIN_PROCESS: break;
      /*}}}*/
      /* USER_PROCESS */ /*{{{*/
      case USER_PROCESS:
      {
        if (utmp->ut_line[0])
        {
          if (utmp->ut_user[0]) ref_user(utmp->ut_user,utmp->ut_line,utmp->ut_time);
          else if (verbose) fprintf(stderr,NULLUSER,utmp->ut_line);
        }
        break;
      }
      /*}}}*/
      /* DEAD_PROCESS */ /*{{{*/
      case DEAD_PROCESS: if (utmp->ut_line[0]) deref_terminal(utmp->ut_line,utmp->ut_time); break;
      /*}}}*/
      /* UT_UNKNOWN, EMPTY */ /*{{{*/
#ifdef EMPTY
      case EMPTY: break;
#endif
#ifdef UT_UNKNOWN
      case UT_UNKNOWN: break;
#endif
      /*}}}*/
      /* ACCOUNTING */ /*{{{*/
#ifdef ACCOUNTING
      case ACCOUNTING: break;
#endif
      /*}}}*/
      /* default       -- should not happen */ /*{{{*/
      default: if (verbose) fprintf(stderr,UNKNOWNREC,utmp->ut_type); break;
      /*}}}*/
    }
  }
  time(&now);
  if (perday && uptonow) while (now>=next_midnight)
  /* print accounting records for passed day(s) */ /*{{{*/
  {
    update_ac(next_midnight);
    print_users(argc-peopleind,argv+peopleind,next_midnight-1,personal);
    next_midnight+=((time_t)36)*3600;
    tm=*localtime(&next_midnight);
    tm.tm_hour=0;
    tm.tm_min=0;
    tm.tm_sec=0;
    next_midnight=mktime(&tm);
  }
  /*}}}*/
  if (uptonow) update_ac(now);
  print_users(argc-peopleind,argv+peopleind,uptonow ? now-1 : last_time-1,personal);
  return 0;
}
/*}}}*/

#!/usr/bin/perl -w
#
#	reindent 1.0 - Change the indentation level	Author: Kees J. Bot
#								12 Dec 1999

if (@ARGV < 2 || $ARGV[0] !~ /^\d+$/ || $ARGV[1] !~ /^\d+$/) {
    die "Usage: reindent <oldindent> <newindent> [file ...]\n";
}

$oldindent = shift(@ARGV);
$newindent = shift(@ARGV);
$bad = 0;

while (<>) {
    /^[ \t]*/;
    $spaces = $&;
    $rest = $';

    $indent = 0;
    for ($i = 0; $i < length($spaces); $i++) {
	if (substr($spaces, $i, 1) eq ' ') {
	    $indent++;
	} else {
	    $indent = ($indent + 8) - ($indent % 8);
	}
    }

    if ($indent % $oldindent == 0) {
	$indent = $indent / $oldindent * $newindent;
	print "\t" x ($indent / 8), " " x ($indent % 8), $rest;
    } else {
	print 'XXX', $spaces, $rest;
	$bad++;
    }
}

if ($bad > 0 && -t 2) {
    $s = $bad == 1 ? "" : "s";
    $theyhave = $bad == 1 ? "it has" : "they have";
    print STDERR <<"EOF";
reindent: $bad line$s had an indentation that was not a multiple of $oldindent,
	  $theyhave been marked with XXX at the beginning of the line.
EOF
}
exit(0);

#!/bin/sh
#
#	uncover 1.0 - Uncover binaries that should be hidden.
#							Author: Kees J. Bot

find "$@" \( -type d -perm -4000 -prune -o -print0 \) \
	| xargs -0 file | egrep ':.*(executable|object)'

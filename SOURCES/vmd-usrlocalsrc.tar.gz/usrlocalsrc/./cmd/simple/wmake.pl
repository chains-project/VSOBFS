#!/usr/bin/perl -w
#
#	wmake - "make" VU style HTML pages		Author: Kees J. Bot
#								October 1997

$version = '1.6';

$make = 'make';			# The 'make' program.

# Is this called as a CGI script or as a command line utility?
$cgi = defined($ENV{'SCRIPT_NAME'});

sub readcwd
# Read entries from the current directory.  Fill @allentries with directories
# and files, @dirs with directories, @files with files, @mhtml with MHTML
# files, and set bits in %dirs, %mhtml and %present for what we've seen.
{
    @allentries = @dirs = @files = ();
    %dirs = %mhtml = %present = ();

    opendir(DIR, '.') || die "$0: Can't read '$cwd': $!\n";

    while (defined($_ = readdir(DIR))) {
	next if $_ eq '.' || $_ eq '..' || /\s/;
	if (-d $_) {
	    push(@allentries, $_);
	    push(@dirs, $_);
	    $dirs{$_} = 1;
	}
	elsif (-f $_) {
	    push(@allentries, $_);
	    push(@files, $_);
	    push(@mhtml, $_) if /\.mhtml$/;
	    $present{$_} = 1;
	    $mhtml{$_} = 1 if /\.mhtml$/;
	}
    }
    close(DIR);
    @allentries = sort(@allentries);
    @dirs = sort(@dirs);
    @files = sort(@files);
    @mhtml = sort(@mhtml);
}

sub checkmodes
# Check if "." has mode 2777 and all files are mode 666 with "."'s group.
# Apply umask on modes.  Leave *.cgi alone.
{
    local(@stdot, @st);
    local($dirmode, $filemode);

    $dirmode = 02777 & ~$user_mask;
    $filemode = 0666 & ~$user_mask;

    (@stdot = stat('.')) || die "$0: '.': $!\n";

    if (($stdot[2] & 07777) != $dirmode) {
	printf("chmod %o .\n", $dirmode);
	chmod($dirmode, '.') || print STDERR "$0: can't set mode of '.': $!\n";
    }

    foreach ('.', @files) {
	next if /\.cgi$/;

	(@st = lstat($_)) || die "$0: $_: $!\n";
	next unless -f _;

	if ($st[5] != $stdot[5]) {
	    print "chgrp $stdot[5] $_\n";
	    chown(-1, $stdot[5], $_) ||
		print STDERR "$0: can't set group of $_: $!\n";
	}

	if (($st[2] & 07777) != $filemode) {
	    printf("chmod %o $_\n", $filemode);
	    chmod($filemode, $_) ||
		print STDERR "$0: can't set mode of $_: $!\n";
	}
    }
}

sub readmakefile
# Read the Makefile we may have generated on an earlier run.
{
    local($key, $mhtml);

    %make = %source = %depend = ();
    $make_extra = '';

    $dirty = 1;					# Recreate .makefile?
    $make{'index-menu.mhtml'} = 'mhtml';	# Don't look at this one.

    return unless $present{'.makefile'};

    open(MFILE, '.makefile') || die "$0: can't open .makefile: $!\n";

    while (<MFILE>) {
	if (/^#% Created by wmake ([\d.]+)/) {	# Version ok?
	    $dirty = 0 if $version eq $1;
	}
	elsif (/#%subdirs:\n$/) {		# Subdirectories.
	    while (($_ = <MFILE>) =~ /^\tcd (\S+) /) {
		$make{$1} = 'dir';
	    }
	}
	elsif (/#%html\s+(\S+)\s+(\S+):\n$/) {	# HTML from MHTML.
	    $key = $1;
	    $mhtml = $2;
	    $make{$mhtml} = 'mhtml';
	    (($_ = <MFILE>) =~ /^([^:]+):\s*(\S.*)\n$/) ||
		die "$0: Error parsing .makefile at line $.\n";
	    $make{$1} = $key;
	    $source{$1} = $mhtml;
	    $depend{$1} = $2;
	}
	elsif (/#%ignore\s+(\S+)\n$/) {		# Ignore this file or dir.
	    $make{$1} = 'ignore';
	}
	elsif (/#%extra:\n$/) {			# Extra handcrafted rules.
	    while (<MFILE>) {
		$make_extra .= $_;
	    }
	    last;
	}
    }
    close(MFILE);
}

sub writemakefile
{
    open(MFILE, ">.makefile") || die "$0: Can't write .makefile: $!\n";

    local($frame, $lang, $target);

    print MFILE "#% Created by wmake $version, do not edit!\n\n";
    print MFILE "MAKE =\twmake\n\n";

    print MFILE "HTML =";
    foreach (sort(keys(%make))) {
	next unless $make{$_} =~ /^(set|body|menu|icon)/;
	print MFILE "\t$_ \\\n";
    }
    print MFILE "\t#\n\n";

    print MFILE "html all::\t\$(HTML)\n\n";
    print MFILE "clean allclean::\n\trm -f \$(HTML)\n\n";
    print MFILE "all allclean::\t\t#%subdirs:\n";

    foreach (sort(keys(%make))) {
	next unless $make{$_} eq 'dir';
	print MFILE "\tcd $_ && \$(MAKE) -\$(MAKEFLAGS) \$\@\n";
    }

    print MFILE "\n\$(HTML):\t/usr/local/bin/htmlpp $0\n";

    foreach (sort(keys(%make))) {
	if ($make{$_} eq 'ignore') {
	    print MFILE "\n#%ignore $_\n";
	}
	elsif ($make{$_} =~ /^(set|body|menu|icon)/) {
	    if ($make{$_} =~ /^(.*)-(.*)$/) {
		$frame = $1;
		$lang = $2;
	    } else {
		$frame = $make{$_};
	    }
	    ($target = $source{$_}) =~ s/\.mhtml$//;

	    print MFILE "\n#%html $make{$_} $source{$_}:\n";
	    print MFILE "$_:\t$depend{$_}\n";
	    print MFILE "\thtmlpp -o \$\@ $source{$_}";
	    print MFILE " target=$target";
	    print MFILE " frame=$frame";
	    print MFILE " lang=$lang";
	    print MFILE "\n";
	}
    }
    print MFILE "\n#%extra:\n$make_extra";
    close(MFILE);
    $dirty = 0;				# .makefile written, so now "clean".
}

# Main program.

if ($cgi) {
    # XXX - Authentication form.
    &redirect('/') unless defined($ENV{'PATH_INFO'});
    $path = $ENV{'PATH_INFO'};
    $cwd = $ENV{'PATH_TRANSLATED'};
    chdir($cwd) || &cgi_fatal("$cwd: $!\n");
    &redirect("$path/") unless $path =~ m:/$:;
} else {
    ($cwd = `pwd`) =~ s/\r?\n//;
}

# Set umask to 022 if the directory we are working in is our primary group,
# *and* it is not group-writable.  Use 002 otherwise.  (This shouldn't be
# necessary.)
(@stdot = stat('.')) || die "$0: '.': $!\n";
if ($stdot[5] == ($( + 0) && !($stdot[2] & 0020)) {
    umask($user_mask = 0022);
} else {
    umask($user_mask = 0002);
}

&readcwd;

if (!$mhtml{'index.mhtml'} || !$mhtml{'index-menu.mhtml'}) {
    print STDERR "$0: No index.mhtml or index-menu.mhtml present in $cwd\n";
    exit(0);
}

if ($present{'Makefile'}) {
    # Some smart guy prefers his own Makefile.  So let's run make.
    exec($make, @ARGV) || die "$0: Can't execute $make: $!\n";
}

# Not setting 'umask' is a very common mistake, and sometimes unavoidable (SMB),
# furthermore, we have a lot of people doing web pages that can't be made to
# understand how UNIX groups work.
&checkmodes;

# What do we already know?
&readmakefile;

# Any MHTML or directories deleted?
foreach (keys(%make)) {
    next unless $make{$_} =~ /^(mhtml|dir|ignore)$/;
    next if $mhtml{$_} || $dirs{$_};

    delete $make{$_};

    foreach $html (keys(%source)) {
	next unless $source{$html} eq $_;

	delete $make{$html};
	delete $source{$html};
	delete $depend{$html};
	unlink $html;			# Make sure old targets go with .mhtml.
    }
    $dirty = 1;				# Will need to write .makefile.
}

# Any new MHTML files?
foreach (@mhtml) {
    next if $make{$_} eq 'ignore';	# Told to ignore.
    next if $make{$_} eq 'mhtml';	# Seen before.
    next unless -t 0;			# Need a terminal now.

    # A new MHTML file, what to do with it?
    print "\nDirectory $cwd contains a new .mhtml file\n";
    print "Are we to use $_? (y/n) [y] ";
    $answer = <STDIN>;

    if ($answer =~ /^(y|yes|sure)?\n$/i) {
	for (;;) {
	    print "Is it in English, Dutch, or both? (e/n/b) [b] ";
	    $answer = <STDIN>;
	    last if $answer =~ /^[enb]?\n?$/;
	    print "Please answer with one of these letters: e n b";
	}
	@lang = ();
	push(@lang, 'nl') unless $answer =~ /^e/i;
	push(@lang, 'en') unless $answer =~ /^n/i;

	@frame = ('set', 'body');

	if ($_ eq 'index.mhtml') {
	    push(@frame, 'menu');
	    print "Also create an icon frame? (y/n) [n] ";
	    $answer = <STDIN>;
	    push(@frame, 'icon') if $answer =~ /^(y|yes|sure)\n$/i;
	}

	foreach $frame (@frame) {
	    foreach $lang (@lang) {
		($page = $_) =~ s/\.mhtml$//;
		$key = $frame;
		$key .= '-' . $lang;
		$page .= '-' . ($frame eq 'set' ? $lang : $key) . '.html';

		$make{$_} = 'mhtml';
		$make{$page} = $key;
		$source{$page} = $_;
		$depend{$page} = $_;
	    }
	}
    } else {
	# MHTML file is to be ignored.
	$make{$_} = 'ignore';
    }
    $dirty = 1;				# Will need to write .makefile.
}

# Any new directories?
foreach (@dirs) {
    next if $make{$_} eq 'ignore';	# Told to ignore.
    next if $make{$_} eq 'dir';		# Seen before.
    next unless -f "$_/index.mhtml";	# Only if index stuff present.
    next unless -f "$_/index-menu.mhtml";
    next unless -t 0;			# Need a terminal now.

    print "\nDirectory $cwd contains a new subdirectory\n";
    print "Are we to use $_? (y/n) [y] ";
    $answer = <STDIN>;

    if ($answer =~ /^(y|yes|sure)?\n$/i) {
	$make{$_} = 'dir';
    } else {
	$make{$_} = 'ignore';
    }
    $dirty = 1;				# Will need to write .makefile.
}

# Create or rewrite .makefile.
&writemakefile if $dirty;

# Name a file for dependency output and put in environment.
$depfile = "/tmp/wmake.$$";
open(WDEP, ">$depfile") || die "$0: Can't create $depfile: $!\n";
close(WDEP);
$ENV{'HTMLPP_DEPEND'} = $depfile;

# Fork and execute 'make'.
print join(' ', ($make, '-f', '.makefile', @ARGV)), "\n";
if (($pid = fork) == 0) {
    exec($make, '-f', '.makefile', @ARGV) ||
	die "$0: Can't execute $make: $!\n";
}

do {
    ($r = wait) >= 0 || die "$0: wait: $!\n";
} until ($r == $pid);
$r = $?;

open(WDEP, $depfile) || die "$0: Can't reopen $depfile: $!\n";
unlink($depfile);

exit(1) if $r != 0;

# Read back new dependency information.
%newdepend = ();
while (<WDEP>) {
    /^([^:]+):(.*)\n$/ || die "$0: Bad dependency line from htmlpp: $_";
    if (defined($newdepend{$1})) {
	$newdepend{$1} .= ' ' . $2;
    } else {
	$newdepend{$1} = $2;
    }
}

# Different from what we know?
foreach (keys(%newdepend)) {
    if ($newdepend{$_} ne $depend{$_}) {
	$depend{$_} = $newdepend{$_};
	$dirty = 1;
    }
}

# Possibly update .makefile.
&writemakefile if $dirty;

# Done.
exit(0);

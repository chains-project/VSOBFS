/*	ethbridge 1.0 - Ethernet to ethernet bridge tunneled over IP.
 *							Author: Kees J. Bot
 *								5 Feb 2000
 */
#define nil ((void*)0)
#include <sys/types.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/asynchio.h>
#include <net/hton.h>
#include <net/netlib.h>
#include <net/gen/socket.h>
#include <net/gen/netdb.h>
#include <net/gen/in.h>
#include <net/gen/inet.h>
#include <net/gen/ether.h>
#include <net/gen/eth_io.h>
#include <net/gen/eth_hdr.h>
#include <net/gen/if_ether.h>
#include <net/gen/udp.h>
#include <net/gen/udp_hdr.h>
#include <net/gen/udp_io.h>

#define arraysize(a)	(sizeof(a) / sizeof((a)[0]))
#define arraylimit(a)	((a) + arraysize(a))

#define TUNNEL_PORT	57		/* UDP port for the tunnel. */
#define MAX_HOSTS	2048		/* Hosts we can track. */
#define PEER_CHANGE	120		/* Time to allow peer info change. */

static char **peer_name;		/* Names of the endpoints. */
static ipaddr_t *peer;			/* IP addresses of the endpoints. */
static unsigned n_peers;		/* Actual number of peers. */
static unsigned debug;			/* Debug level. */
static char *prog;			/* This program's name. */
static time_t now;			/* Current time. */
static udpport_t tunnel_port;		/* UDP port used for the tunnel. */

typedef struct host {		/* At what peer can a host be found? */
	ether_addr_t	eth;		/* Host's ethernet address. */
	u16_t		peer;		/* Peer number where it's found at. */
	unsigned	usage;		/* Usage count for entry. */
	time_t		age;		/* When last seen. */
} host_t;

#define PEER_NONE	((u16_t) -1)	/* Nothing here, really. */
#define PEER_ME		((u16_t) -2)	/* My peer number. */

static host_t host[MAX_HOSTS];		/* Table of known hosts. */

typedef struct eth_packet {	/* An ethernet packet. */
	eth_hdr_t	hdr;
	u8_t		data[ETH_MAX_PACK_SIZE - ETH_HDR_SIZE];
} eth_packet_t;

typedef struct udp_packet {	/* An UDP packet carrying an ethernet packet. */
	udp_io_hdr_t	hdr;
	eth_packet_t	data;
} udp_packet_t;

static void report(const char *label)
{
    char *err= strerror(errno);

    fprintf(stderr, label == nil ? "%s" : "%s: %s", prog, label);
    fprintf(stderr, ": %s", err);
}

static void fatal(const char *label)
{
    report(label);
    exit(1);
}

static unsigned eth_cache(unsigned peer, ether_addr_t *addr)
/* Look for an ethernet address in our hosts cache to see at what endpoint
 * it can be found (peer == PEER_NONE), or record that the address can be
 * found at a given endpoint (peer != PEER_NONE).  We have to be careful not
 * to label an ethernet address as local, because anything we transmit at
 * our ethernet tap is immediately thrown back in our face.
 */
{
    unsigned hash, n;
    host_t *hp;

    /* Don't bother with multicast or broadcast packets. */
    if (addr->ea_addr[0] & 0x01) return PEER_NONE;

    /* Use the last two bytes of the ethernet address as a hash key. */
    hash= ((u16_t *) addr->ea_addr)[2] % MAX_HOSTS;

    /* Find the ethernet address in the host cache. */
    n= MAX_HOSTS;
    hp= &host[hash];
    do {
	if (memcmp(addr, &hp->eth, sizeof(*addr)) == 0) break;
	if (++hp == arraylimit(host)) hp= host;
    } while (--n != 0);

    if (n != 0) {
	/* Address found in the cache. */
	if (peer != PEER_NONE) {
	    /* Address is seen at 'peer'.  Still the same peer? */
	    if (peer == hp->peer) {
		/* Yes, set age to "seen now" and increase usage count. */
		hp->age= now;
		hp->usage++;
	    } else
	    if (peer != PEER_ME || now > hp->age + PEER_CHANGE) {
		/* Address moved to a different network, and if it is now at
		 * my network then some time has passed, so it isn't a
		 * retransmission by myself.
		 */
		hp->peer= peer;
		hp->age= now;
		hp->usage= 1;
		if (debug >= 1) {
		    fprintf(stderr, "%s now at %s\n",
			ether_ntoa(&hp->eth),
			peer == PEER_ME ? "my place" : peer_name[peer]);
		}
	    }
	}
	return hp->peer;
    }

    if (peer != PEER_NONE) {
	/* Address not found.  Find an unused slot and add it. */
	for (;;) {
	    n= MAX_HOSTS;
	    hp= &host[hash];
	    do {
		if (hp->usage == 0) break;
		if (++hp == arraylimit(host)) hp= host;
	    } while (--n != 0);

	    if (n != 0) break;

	    /* All in use, lower usage and try again. */
	    for (hp= host; hp < arraylimit(host); hp++) hp->usage >>= 1;
	}

	/* Put the address in the cache. */
	memcpy(&hp->eth, addr, sizeof(*addr));
	hp->peer= peer;
	hp->usage= 1;
	hp->age= now;
	if (debug >= 1) {
	    fprintf(stderr, "%s new at %s\n",
		ether_ntoa(&hp->eth),
		peer == PEER_ME ? "my place" : peer_name[peer]);
	}
    }
    return peer;
}

static int is_tunneled(eth_packet_t *packet)
/* Packets sent through the tunnel may be seen on the Ethernet tap.  We have
 * to recognize them to avoid re-injecting them into the tunnel.  (We may
 * figure out eventually that the destination of the tunnel packet is on the
 * local net, requiring no tunnelling, but not before we go bonkers trying
 * to tunnel tunneled packets endlessly.)
 */
{
    return packet->data[0] == 0x45
	&& packet->data[9] == IPPROTO_UDP
	&& * (udpport_t *) (packet->data+20) == tunnel_port;
}

static void eth_tell(int rw, unsigned peer, eth_packet_t *packet)
/* Show an incoming/outgoing packet, for debug purposes. */
{
    fprintf(stderr, "%c %s ", rw, peer >= n_peers ? "[net]" : peer_name[peer]);
    fprintf(stderr, "%s -> ", ether_ntoa(&packet->hdr.eh_src));
    fprintf(stderr, "%s\n", ether_ntoa(&packet->hdr.eh_dst));
}

static void usage(void)
{
    fprintf(stderr,
	"Usage: %s [-d[level]] [-p port] eth_device peer ...\n", prog);
    exit(1);
}

int main(int argc, char **argv)
{
    int i;
    int eth_fd, udp_fd;
    asynchio_t asyn;
    time_t now;
    ssize_t r;
    size_t e2t_len, t2e_len;
    unsigned src_peer, dst_peer, e2t_peer;
    int e2t_bcast;
    char *eth_device, *udp_device;
    nwio_ethopt_t ethopt;
    nwio_udpopt_t udpopt;
    udp_packet_t e2t_packet, t2e_packet;

    if ((prog= strrchr(argv[0], '/')) == nil) prog= argv[0]; else prog++;

    tunnel_port= HTONS(TUNNEL_PORT);

    i= 1;
    while (i < argc && argv[i][0] == '-') {
	char *opt= argv[i++] + 1;
	char *end;
	unsigned long v;

	if (opt[0] == '-' && opt[1] == 0) break;	/* -- */

	switch (*opt++) {
	case 'd':
	    debug= 1;
	    if (*opt != 0) {
		debug= v= strtoul(opt, &end, 0);
		if (opt == end || *end != 0 || debug != v) usage();
	    }
	    break;
	case 'p':
	    if (*opt == 0) {
		if (i == argc) usage();
		opt= argv[i++];
	    }
	    v= strtoul(opt, &end, 0);
	    if (opt == end || *end != 0 || (v-1) > 0xFFFF-1) usage();
	    tunnel_port= htons(v);
	    break;
	default:
	    usage();
	}
    }

    if (i == argc) usage();
    eth_device= argv[i++];
    if ((udp_device= getenv("UDP_DEVICE")) == nil) udp_device= UDP_DEVICE;

    if ((n_peers= (argc - i)) == 0) usage();
    peer_name= argv + i;
    peer= malloc(n_peers * sizeof(peer[0]));
    if (peer == nil) fatal(nil);

    for (i= 0; i < n_peers; i++) {
	struct hostent *he;

	if ((he= gethostbyname(peer_name[i])) == nil
	    || he->h_addrtype != AF_INET || he->h_length != sizeof(ipaddr_t)
	) {
	    fprintf(stderr, "%s: %s: Unknown host\n", prog, peer_name[i]);
	    exit(1);
	}
	memcpy(&peer[i], he->h_addr, sizeof(ipaddr_t));
    }

    /* Set up the network tap. */
    if ((eth_fd= open(eth_device, O_RDWR)) < 0) fatal(eth_device);

    ethopt.nweo_flags= NWEO_COPY | NWEO_EN_LOC | NWEO_EN_BROAD |
			NWEO_EN_MULTI | NWEO_EN_PROMISC | NWEO_REMANY |
			NWEO_TYPEANY | NWEO_RWDATALL;

    if (ioctl(eth_fd, NWIOSETHOPT, &ethopt) < 0) fatal(eth_device);

    /* Set up the UDP tunnel. */
    if ((udp_fd= open(udp_device, O_RDWR)) < 0) fatal(udp_device);

    udpopt.nwuo_flags= NWUO_EXCL | NWUO_LP_SET | NWUO_EN_LOC | NWUO_DI_BROAD |
			NWUO_RP_SET | NWUO_RA_ANY | NWUO_RWDATALL |
			NWUO_DI_IPOPT;
    udpopt.nwuo_locport= tunnel_port;
    udpopt.nwuo_remport= tunnel_port;

    if (ioctl(udp_fd, NWIOSUDPOPT, &udpopt) < 0) fatal(udp_device);

    /* Nothing yet received, nothing yet to send. */
    e2t_len= t2e_len= 0;
    e2t_peer= 0;
    e2t_bcast= 0;
    asyn_init(&asyn);

    while (1) {
	now= time(nil);

	/* Ethernet tap to tunnel. */
	if (e2t_len == 0) {
	    /* Read from the ethernet. */
	    r= asyn_read(&asyn, eth_fd, &e2t_packet.data,
						sizeof(e2t_packet.data));
	    if (r == -1) {
		if (errno != EINPROGRESS) fatal(eth_device);
	    } else {
		/* Ethernet packet received. */
		if (!is_tunneled(&e2t_packet.data)) {
		    if (debug >= 2) eth_tell('R', PEER_ME, &e2t_packet.data);
		    src_peer= eth_cache(PEER_ME, &e2t_packet.data.hdr.eh_src);
		    dst_peer= eth_cache(PEER_NONE, &e2t_packet.data.hdr.eh_dst);
		    if (src_peer == PEER_ME && dst_peer != PEER_ME) {
			e2t_len= r;
			if (dst_peer != PEER_NONE) {
			    e2t_peer= dst_peer;
			    e2t_bcast= 0;
			} else {
			    e2t_peer= 0;
			    e2t_bcast= 1;
			}
			e2t_packet.hdr.uih_dst_addr= peer[e2t_peer];
			e2t_packet.hdr.uih_ip_opt_len= 0;
			e2t_packet.hdr.uih_data_len= e2t_len;
		    }
		}
	    }
	} else {
	    /* Write to the tunnel. */
	    r= asyn_write(&asyn, udp_fd, &e2t_packet,
						UDP_IO_HDR_SIZE + e2t_len);
	    if (r == -1) {
		if (errno != EINPROGRESS) fatal(udp_device);
	    } else {
		/* UDP packet sent. */
		if (debug >= 2) eth_tell('W', e2t_peer, &e2t_packet.data);
		if (e2t_bcast && ++e2t_peer < n_peers) {
		    e2t_packet.hdr.uih_dst_addr= peer[e2t_peer];
		} else {
		    e2t_len= 0;
		}
	    }
	}

	/* Tunnel to ethernet tap. */
	if (t2e_len == 0) {
	    /* Read from the tunnel. */
	    r= asyn_read(&asyn, udp_fd, &t2e_packet, sizeof(t2e_packet));
	    if (r == -1) {
		if (errno != EINPROGRESS) fatal(udp_device);
	    } else {
		/* Packet from tunnel received. */
		for (src_peer= 0; src_peer < n_peers; src_peer++) {
		    if (peer[src_peer] == t2e_packet.hdr.uih_src_addr) {
			t2e_len= r;
			break;
		    }
		}
		if (t2e_len == 0) {
		    fprintf(stderr, "%s: Packet from unknown peer at %s\n",
			prog, inet_ntoa(t2e_packet.hdr.uih_src_addr));
		} else {
		    if (debug >= 2) eth_tell('R', src_peer, &t2e_packet.data);
		    (void) eth_cache(src_peer, &t2e_packet.data.hdr.eh_src);
		}
	    }
	} else {
	    /* Write to the ethernet. */
	    r= asyn_write(&asyn, eth_fd, &t2e_packet.data,
						t2e_len - UDP_IO_HDR_SIZE);
	    if (r == -1) {
		if (errno != EINPROGRESS) fatal(eth_device);
	    } else {
		/* Ethernet packet sent. */
		if (debug >= 2) eth_tell('W', PEER_ME, &t2e_packet.data);
		t2e_len= 0;
	    }
	}

	/* Wait for I/O. */
	fflush(nil);
	if (asyn_wait(&asyn, 0, nil) < 0) fatal("asyn_wait()");
    }
}

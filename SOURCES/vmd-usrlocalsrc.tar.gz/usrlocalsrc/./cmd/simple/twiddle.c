/*	twiddle 1.2 - Remember [am]time, exec shell, restore times.
 *							Author: Kees J. Bot
 *								1988
 */
#define nil 0
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <utime.h>

static char *arg0;

void tell(char *mess)
{
	(void) write(2, mess, strlen(mess));
}

static void report(char *label)
{
	int err= errno;

	tell(arg0);
	tell(": ");
	tell(label);
	tell(": ");
	tell(strerror(err));
	tell("\n");
}

static void fatal(char *label)
{
	report(label);
	exit(255);
}

int main(int argc, char **argv, char **envp)
{
	time_t *mtime;
	struct stat st;
	int pid, i, status;

	if ((arg0= strrchr(argv[0], '/')) == nil) arg0= argv[0]; else arg0++;

	if ((mtime= malloc(argc * sizeof(mtime[0])))==nil)
		fatal("Out of memory");

	for (i=1; i<argc; i++) {
		if (stat(argv[i], &st)<0) fatal(argv[i]);
		mtime[i]=st.st_mtime;
	}
	switch (pid=fork()) {
	case -1:
		fatal("Cannot fork");
	case 0: {
		char *sh, *sh0;

		if ((sh=getenv("SHELL"))==nil) sh="/bin/sh";
		if ((sh0=strrchr(sh, '/'))==nil) sh0=sh; else sh0++;

		execle(sh, sh0, (char *) nil, envp);
		fatal(sh);
	}}
	signal(SIGINT, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);

	while ((i=wait(&status))!=pid) {
		if (i<0) fatal(arg0);
	}
	status = status!=0 ? 1 : 0;

	for (i=1; i<argc; i++) {
		struct utimbuf tms;

		if (stat(argv[i], &st)<0) {
			report(argv[i]);
			status=255;
			continue;
		}
		if (st.st_mtime != mtime[i]) {
			tms.actime= st.st_atime;
			tms.modtime= mtime[i];
			if (utime(argv[i], &tms)<0) {
				report(argv[i]);
				status=255;
			}
		}
	}
	return status;
}

#!/bin/sh

host="`uname -n`"
read root rest </etc/mtab

case $USER in
root)	# Gloves off.
	x=
	;;
*)	# Playact.
	x=echo
esac

case "$host:$root" in
darask.kjb.upwind.org:/dev/ram)
	thruput=''
	mdev=''
	cdev='p1s0 p1s2'
	wdev=''
	hdev=''
	sdsk=c0d0
	ddsk=c0d1
	;;
darask.kjb.upwind.org:*)
	thruput='-t 1m'
	mdev='/save /misc0 /misc1 /misc2 /misc3 /misc4'
	cdev='p0 p1s3 p2'
	wdev=''
	hdev=''
	sdsk=c0d0
	ddsk=c0d1
	;;
jetsam.cs.vu.nl:/dev/ram)
	thruput=''
	mdev=''
	cdev=''
	wdev=''
	sdsk=
	ddsk=
	;;
jetsam.cs.vu.nl:*)
	thruput='-t 256m'
	mdev=''
	cdev=''
	wdev=''
	sdsk=
	ddsk=
	;;
*)
	echo "backup: Don't know how to backup $host" >&2
	exit 1
esac

usage() {
	echo "Usage: $0 [-t throughput[kmg]]" >&2
	exit 1
}

while getopts 't:' opt
do
	case $opt in
	t)	thruput="-t $OPTARG"
		test "x$OPTARG" = xinf && thruput='-s 1m'
		;;
	?)	usage
	esac
done
shift `expr $OPTIND - 1`
test #1 = 0 || usage

# Mount to be copied Minix file systems read-only.
for d in $mdev
do
	$x umount $d || exit
	$x mount -o ro $d || exit
done

# Copy.
for d in $cdev
do
	echo "`date +%T` - Copying $sdsk$d to $ddsk$d"
	$x cpraw $thruput /dev/$sdsk$d /dev/$ddsk$d || exit
done

# Remount copied Minix file systems normally.
for d in $mdev
do
	$x mount -o remount,fstab $d || exit
done

# Relabel some copied Windows file systems.
for d in $wdev
do
	$x mtools label -n $ddsk$d:$ddsk$d
done

# Hide some copied Windows file systems.
for d in $hdev
do
	$x dd if=$ddsk$d of=$ddsk$d bs=1024k count=1 conv=swab,silent
done

echo "`date +%T` - Done."
exit 0

/*	dev2script 1.2 - create a shell script that would recreate /dev/
 *							Author: Kees J. Bot
 * (chmem =8192)
 */
#define nil 0
#include "stdio.h"
#include "sys/types.h"
#include "stddef.h"
#include "stdlib.h"
#include "unistd.h"
#include "sys/stat.h"
#include "pwd.h"
#include "grp.h"
#include "errno.h"
#include "dirent.h"
#include "string.h"

#define BLOCK_SIZE	1024

#ifndef major
#define	major(x)	((int) (((unsigned) (x) >> 8) & 0xFF))
#define	minor(x)	((int) ((x) & 0xFF))
#endif

#define ROOTUID		((uid_t) 0)

void report(label) char *label;
/* dev2script: /dev: No such file or directory */
{
	int e= errno;
	fprintf(stderr, "dev2script: ");
	fflush(stderr);
	errno= e;
	perror(label);
}

void fatal(label) char *label;
{
	report(label);
	exit(1);
}

void *alloc(n) size_t n;
{
	void *mem;

	if ((mem= malloc((unsigned) n)) == nil) {
		fprintf(stderr, "dev2script: Out of memory\n");
		exit(1);
	}
	return mem;
}

/* Remember an entry in /dev that has a link count above 1 in this simple
 * list sorted by ino.
 */

struct linkname {
	struct linkname	*next;
	char		*name;
	ino_t		ino;
	nlink_t		count;
} *links;

int hardlink(name, stp) char *name; struct stat *stp;
/* See if "name" is hard linked to a file seen earlier in /dev.
 * If so, print "ln <previous> name", otherwise remember "name".
 */
{
	struct linkname **alp= &links;

	if (stp->st_nlink < 2) return 0;

	while (*alp != nil && stp->st_ino > (*alp)->ino)
		alp= &(*alp)->next;

	if (*alp == nil || (*alp)->ino != stp->st_ino) {
		/* Missed */
		struct linkname *new;

		new= (struct linkname *) alloc(sizeof(*new));
		new->name= (char *) alloc((size_t) (strlen(name) + 1));
		strcpy(new->name, name);
		new->ino= stp->st_ino;
		new->count= stp->st_nlink - 1;
		new->next= *alp;
		*alp= new;

		return 0;
	} else {
		/* Gotcha */
		struct linkname *old= *alp;

		printf("ln %s %s\n", old->name, name);

		if (--old->count == 0) {
			*alp= old->next;
			free((void *) old->name);
			free((void *) old);
		}
		return 1;
	}
}

main(argc, argv) int argc; char **argv;
{
	int ex= 0;
	DIR *dp;
	struct dirent *e;
	char *dir, *fmt;
	struct stat st;
	struct passwd *pw;
	struct group *gr;
	unsigned size;
	gid_t rootgid;

	if (argc > 2) {
		fprintf(stderr, "Usage: dev2script [dir]\n");
		exit(1);
	}

	dir= argc == 1 ? "/dev" : argv[1];

	if (chdir(dir) < 0) fatal(dir);

	if ((dp= opendir(".")) == nil) fatal(dir);

	rootgid= (pw= getpwuid(ROOTUID)) != nil ? pw->pw_gid : 0;

	while ((e= readdir(dp)) != nil) {
		if (stat(e->d_name, &st) < 0) { report(e->d_name); ex= 1; }

		size= 0;

		switch (st.st_mode & S_IFMT) {
		case S_IFBLK:
			fmt= "mknod %s b %d %d %u;\t";
			size= st.st_size / BLOCK_SIZE;
			if ((off_t) size != st.st_size / BLOCK_SIZE) size= 0;
			break;
		case S_IFCHR:
			fmt= "mknod %s c %d %d;\t";
			break;
		case S_IFIFO:
			fmt= "mknod %s p;\t";
			break;
		default:
			continue;
		}

		if (hardlink(e->d_name, &st)) continue;

		printf(fmt, e->d_name, major(st.st_rdev), minor(st.st_rdev),
				size);

		if (st.st_uid != ROOTUID || st.st_gid != rootgid) {
			printf("chown ");
			if ((pw= getpwuid(st.st_uid)) == nil)
				printf("%d", st.st_uid);
			else
				printf("%s", pw->pw_name);
			if ((gr= getgrgid(st.st_gid)) == nil)
				printf(".%d", st.st_gid);
			else
				printf(".%s", gr->gr_name);
			printf(" %s;\t", e->d_name);
		}

		printf("chmod %o %s\n", st.st_mode & 07777, e->d_name);
	}
	exit(ex);
}
/* Kees J. Bot  16-2-91. */

/*	divideby 1.0 - Show assembly for division by reciprocal multiply.
 *							Author: Kees J. Bot
 *								10 Jun 2000
 * Algorithm by Terje Mathisen as shown in the Pentium
 * optimization guide by Agner Fog:
 *
 *	To divide x by d:
 *	b = (the number of bits in d) - 1
 *	r = 32 + b
 *	f = 2**r / d
 *	Case A, f is an integer:
 *		result = x >> b
 *	Case B, the fractional part of f < 0.5:
 *		round f down to the nearest integer
 *		result = ((x + 1) * f) >> r
 *	Case C, the fractional part of f > 0.5:
 *		round f up to the nearest integer
 *		result = (x * f) >> r
 */
#define nil ((void*)0)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#if __minix
/* No long long, use routines meant for disk drivers. */
#include <minix/u64.h>
#else
typedef unsigned long long u64_t;
typedef unsigned long u32_t;
#define make64(lo, hi)	(((u64_t) (lo)) | ((u64_t) (hi) << 32))
#define div64u(x, d)	(u32_t) ((x) / (d))
#define rem64u(x, d)	(u32_t) ((x) % (d))
#define mul64u(x, m)	((u64_t) (x) * (m))
#define ex64hi(x)	(u32_t) ((x) >> 32)
#endif

static enum arch_type { I86, I386, UNKNOWN } arch =
#if __i86
    I86
#elif __i386
    I386
#else
    UNKNOWN
#endif
    ;
static int all;			/* True if all "r" values must be show. */
static unsigned w;		/* Wordsize in bits. */
static unsigned long mask;	/* Mask to reduce values to a word. */

static void caseA(unsigned b)
{
    /* result = x >> b */
    switch (arch) {
    case I86:
	if (b > 0) printf("	shr	ax, %u\n", b);
	break;
    case I386:
	if (b > 0) printf("	shr	eax, %u\n", b);
	break;
    }
}

static void caseB(unsigned long max, unsigned long f, unsigned r)
{
    /* result = ((x+1) * f) >> r */
    switch (arch) {
    case I86:
	if (r >= w) {				/* doubleword multiply */
	    printf("	mov	dx, 0x%lX\n", f);
	    printf("	inc	ax\n");
	    if (max == mask) printf("	jz	0f\n");
	    printf("	mul	dx\n");
	    if (max == mask) printf("0:");
	    if (r-w > 0) printf("	shr	dx, %u\n", r-w);
	    printf("	mov	ax, dx\n");
	} else {				/* singleword multiply */
	    printf("	mov	dx, 0x%lX\n", f);
	    printf("	inc	ax\n");
	    printf("	mul	dx\n");
	    printf("	shr	ax, %u\n", r);
	}
	break;
    case I386:
	if (r >= w) {				/* doubleword multiply */
	    printf("	mov	edx, 0x%lX\n", f);
	    printf("	inc	eax\n");
	    if (max == mask) printf("	jz	0f\n");
	    printf("	mul	edx\n");
	    if (max == mask) printf("0:");
	    if (r-w > 0) printf("	shr	edx, %u\n", r-w);
	    printf("	mov	eax, edx\n");
	} else {				/* singleword multiply */
	    printf("	inc	eax\n");
	    printf("	imul	eax, 0x%lX\n", f);
	    printf("	shr	eax, %u\n", r);
	}
	break;
    }
}

static void caseC(unsigned long max, unsigned long f, unsigned r)
{
    /* result = (x * (f+1)) >> r */
    switch (arch) {
    case I86:
	if (r >= w) {				/* doubleword multiply */
	    printf("	mov	dx, 0x%lX\n", f+1);
	    printf("	mul	dx\n");
	    if (r-w > 0) printf("	shr	dx, %u\n", r-w);
	    printf("	mov	ax, dx\n");
	} else {				/* singleword multiply */
	    printf("	mov	dx, 0x%lX\n", f+1);
	    printf("	mul	dx\n");
	    printf("	shr	ax, %u\n", r);
	}
	break;
    case I386:
	if (r >= w) {				/* doubleword multiply */
	    printf("	mov	edx, 0x%lX\n", f+1);
	    printf("	mul	edx\n");
	    if (r-w > 0) printf("	shr	edx, %u\n", r-w);
	    printf("	mov	eax, edx\n");
	} else {				/* singleword multiply */
	    printf("	imul	eax, 0x%lX\n", f+1);
	    printf("	shr	eax, %u\n", r);
	}
	break;
    }
}

static int divbymul(unsigned long x, unsigned long d, unsigned long f,
			unsigned long m, unsigned b, unsigned r)
{
    /* Compute the division of x by multiplying with f, using an r-bit playing
     * field.  Simulate the same computations as in the machine code above.
     */
    unsigned long t;

    if (m == 0) {
	/* Case A: A simple bitshift... */
	t= x >> b;
    } else
    if (m <= d/2) {
	/* Case B: ((x+1) * f) >> r == x / d? */
	if (r >= w) {			/* doubleword multiply */
	    if (x == mask) {
		t= f;
	    } else
	    if (w == 16) {
		t= (((x+1) * f) >> w) & mask;
	    } else {
		t= ex64hi(mul64u(x+1, f));
	    }
	    t >>= (r-w);
	} else {			/* singleword multiply */
	    t= (((x+1) * f) & mask) >> r;
	}
    } else {
	/* Case C: (x * (f+1)) >> r == x / d? */
	if (r >= w) {			/* doubleword multiply */
	    if (w == 16) {
		t= ((x * (f+1)) >> w) & mask;
	    } else {
		t= ex64hi(mul64u(x, f+1));
	    }
	    t >>= (r-w);
	} else {			/* singleword multiply */
	    t= ((x * (f+1)) & mask) >> r;
	}
    }
    return t == x / d;
}

#if 0
static unsigned long findmax(unsigned long d, unsigned long f,
				unsigned long m, unsigned b, unsigned r)
{
    /* Determine the maximum number we can correctly divide.
     * Simulate the same computations as in the machine code above.
     */
#if 0
    unsigned long x;

    x= 0;
    while (divbymul(x, d, f, m, b, r) && (++x & mask) != 0) {}
    x= (x - 1) & mask;
    return x;
#endif
    unsigned long x, t;

    x= 0;
    if (m == 0) {
	/* Case A: A simple bitshift... */

	/* Full range is no problem. */
    } else
    if (m <= d/2) {
	/* Case B: ((x+1) * f) >> r == x / d? */
	if (r >= w) {			/* doubleword multiply */
	    do {
		if (x == mask) {
		    t= f;
		} else
		if (w == 16) {
		    t= (((x+1) * f) >> w) & mask;
		} else {
		    t= ex64hi(mul64u(x+1, f));
		}
		t >>= (r-w);
		if (t != x / d) break;
	    } while ((++x & mask) != 0);
	} else {			/* singleword multiply */
	    do {
		t= (((x+1) * f) & mask) >> r;
		if (t != x / d) break;
	    } while ((++x & mask) != 0);
	}
    } else {
	/* Case C: (x * (f+1)) >> r == x / d? */
	if (r >= w) {			/* doubleword multiply */
	    do {
		if (w == 16) {
		    t= ((x * (f+1)) >> w) & mask;
		} else {
		    t= ex64hi(mul64u(x, f+1));
		}
		t >>= (r-w);
	    if (t != x / d) break;
	    } while ((++x & mask) != 0);
	} else {			/* singleword multiply */
	    do {
		t= ((x * (f+1)) & mask) >> r;
	    if (t != x / d) break;
	    } while ((++x & mask) != 0);
	}
    }
    x= (x - 1) & mask;
    return x;
}
#endif

static int d_divbymul(unsigned long x, unsigned long d, unsigned long f,
			unsigned long m, unsigned b, unsigned r)
{
    /* Run divbymul on the range x-d+1 to x. */
    unsigned long i;

    i= 0;
    do {
	if (!divbymul(x-i, d, f, m, b, r)) return 0;
    } while (++i < d && i <= x);
    return 1;
}

static unsigned long findmax(unsigned long d, unsigned long f,
				unsigned long m, unsigned b, unsigned r)
{
    /* Determine the maximum number we can correctly divide. */
    unsigned long max, bit, x;

#if 1
    bit= 1;
    do {
	max= bit;
	bit= (bit << 1) & mask;
    } while (bit != 0 && d_divbymul(bit, d, f, m, b, r));

    bit= max;
    while ((bit >>= 1) != 0) {
	if (d_divbymul(max | bit, d, f, m, b, r)) max |= bit;
    }
    return max;
#else
    max= 0;
    while (divbymul(max, d, f, m, b, r) && (++max & mask) != 0) {}
    return max - 1;
#endif
}

static void divide(unsigned long d)
{
    unsigned b, r;
    unsigned long f, m, max;
    u64_t p2;
    int doneB= 0;

    /* b = (number of significant digits in d) - 1. */
    for (b= 0; b < 31 && (d >> (b+1)) != 0; b++) {}

    /* The reciprocal multiply is followed by an r bit shift.  Try several r. */
    for (r= w + b; r > b; r--) {
	/* p2 = 2**r. */
	p2= make64(r < 32 ? (1UL << r) : 0, r < 32 ? 0 : (1UL << (r-32)));

	/* f = 2**r / d. */
	/* m = 2**r % d. */
	f= div64u(p2, d);
	m= rem64u(p2, d);

	if (!all) {	/* Only show interesting r values. */
	    if (r == w + b) {
		/* Full range of input. */
	    } else
	    if (r == w) {
		/* High word shifted by 0 bits. */
	    } else
	    if (r == w/2 + b && b < w/2) {
		/* We can use a (cheaper?) singleword multiply. */
	    } else
	    if (doneB && m > d/2) {
		/* We emitted a "case B" previously, so this "case A" may be
		 * nicer.
		 */
	    } else {
		/* Skip this one, not interesting. */
		continue;
	    }
	}

	/* Maximum number we can correctly divide. */
	max= findmax(d, f, m, b, r);
	if (max < d && !all) continue;

	printf("\n_divide_upto_%lu_by_%lu:\n", max, d);

	doneB= 0;

	if (m == 0) {
	    /* Case A: f is an integer. */
	    caseA(b);
	} else
	if (m <= d/2) {
	    /* Case B: fractional part of f < 0.5. */
	    caseB(max, f, r);
	    doneB= 1;		/* Case B isn't too nice, remember this. */
	} else {
	    /* Case C: fractional part of f > 0.5. */
	    caseC(max, f, r);
	}

	switch (arch) {
	case I86:
	case I386:
	    printf("	ret\n");
	    break;
	}

	if (m == 0) break;	/* Case A is no fun. */
    }
}

static void usage(void)
{
    fprintf(stderr, "Usage: divideby [-a] [-m arch] divisor\n");
    exit(1);
}

int main(int argc, char **argv)
{
    int i;
    unsigned long d, max;
    char *divisor, *end;

    i= 1;
    while (i < argc && argv[i][0] == '-') {
	char *opt= argv[i++]+1;

	if (opt[0] == '-' && opt[1] == 0) break;	/* -- */

	while (*opt) switch (*opt++) {
	case 'a':
	    all= 1;
	    break;
	case 'm':
	    if (*opt == 0) {
		if (i == argc) usage();
		opt= argv[i++];
	    }
	    if (strcmp(opt, "i86") == 0) arch= I86;
	    else
	    if (strcmp(opt, "i386") == 0) arch= I386;
	    else {
		fprintf(stderr, "divideby: %s: Unknown architecture\n", opt);
		exit(1);
	    }
	    opt= "";
	    break;
	default:
	    usage();
	}
    }
    if (i == argc) usage();
    divisor= argv[i++];
    if (i != argc) usage();

    d= strtoul(divisor, &end, 0);
    max= arch == I86 ? 0xFFFFUL : 0xFFFFFFFFUL;
    if (end == divisor || *end != 0 || d < 1 || d > max) {
	fprintf(stderr, "divideby: %s is not a number between 1 and 0x%lX\n",
	    divisor, max);
	exit(1);
    }

    if (arch == UNKNOWN) {
	fprintf(stderr, "divideby: No architecture specified\n");
	exit(1);
    }

    /* Wordsize and wordmask. */
    w= arch == I86 ? 16 : 32;
    mask= 0xFFFFFFFFUL >> (32-w);

    divide(d);

    return 0;
}

#!/bin/sh
#
# unhide 1.1 - Show a path with hidden directories uncovered.

arch=`arch -a`
kernel=`arch -k`
machine=`arch -m`
hostname=`arch -h`
nodename=`arch -n`
release=`arch -r`
version=`arch -v`
sysname=`arch -s`

for path
do
	case $path in
	/*)	set - / `echo $path | sed 's:/: :g'`
		;;
	*)	set - `echo $path | sed 's:/: :g'`
	esac

	at='@'
	upath=

	while [ $# -ne 0 ]
	do
		file=$1; shift

		case $file in
		/)	mode=`ls -dl /`
			;;
		*)	mode=`ls -dl $upath/$file@`
		esac

		case $mode in
		d--[S=]------*)	hidden=$arch ;;
		d--[S=]-----x*)	hidden=$kernel ;;
		d--[S=]----w-*)	hidden=$machine ;;
		d--[S=]----wx*)	hidden=$hostname ;;
		d--[S=]---r--*)	hidden=$nodename ;;
		d--[S=]---r-x*)	hidden=$release ;;
		d--[S=]---rw-*)	hidden=$version ;;
		d--[S=]---rwx*)	hidden=$sysname ;;
		*)		hidden=
		esac

		case $hidden in
		'')	case $file in
			/)	upath=/
				;;
			*)	case $upath in
				''|/)	upath=$upath$file
					;;
				*)	upath=$upath/$file
				esac
			esac
			;;
		*)	case $upath in
			''|/)	upath=$upath$file$at
				;;
			*)	upath=$upath/$file$at
			esac
			at=
			set - $hidden $*
		esac
	done
	echo "$path = $upath"
done

#!/usr/bin/python
#
#	fdminix 2.7 - Bootable Minix-vmd on one or more floppies.
#							Author: Kees J. Bot
#								17 Sep 1994
# Creates single or dual floppy Minix-vmd systems:
#	'demo'	 - Single floppy demo.
#	'dist'	 - Single/dual floppy distribution install set.
#	'repair' - Dual floppy system repair set.
#	'sync'	 - One floppy to install or synchronize PC's at the VU.

# List of files to install on one or two floppies.
FILELIST= [
	[['root'],
		'/bin',
		'/bin/*',
		('/usr/mdec/boot', 'boot'),
		'/dev',
		[['repair'],
			'/dev/*',
		],
		'/etc',
		[['repair'],
			'/etc/*',
		],
		[['demo', 'dist', 'sync'],
			('/usr/src/etc/fstab', 'etc/fstab', 'root'),
			('/usr/src/etc/group', 'etc/group', 'root'),
			('/usr/src/etc/motd', 'etc/motd', 'root'),
			('/usr/src/etc/mtab', 'etc/mtab', 'root'),
			('/usr/src/etc/passwd', 'etc/passwd', 'root'),
			('/usr/src/etc/profile', 'etc/profile', 'root'),
			'/etc/rc',
			('/usr/src/etc/shadow', 'etc/shadow',
						'root', 'operator', 0600),
			('/usr/src/etc/termcap', 'etc/termcap', 'root'),
			('/usr/src/etc/timeinfo', 'etc/timeinfo', 'root'),
			('/usr/src/etc/ttytab', 'etc/ttytab', 'root'),
			('/usr/src/etc/utmp', 'etc/utmp', 'root'),
			[['dist', 'sync'],
			  ('/usr/src/etc/inetd.conf', 'etc/inetd.conf', 'root'),
			  ('/usr/src/etc/services', 'etc/services', 'root'),
			  ('/usr/src/etc/protocols', 'etc/protocols', 'root'),
			],
		],
		[['dist', 'repair'],
			'/fd0',
			'/fd1',
			'/home',
			'/opt',
			'/root',
		],
		'/minix',
		'/mnt',
		'/sbin',
		'/sbin/*',
		'/tmp',
		'/usr',
		'/var',
		[['repair'],
			'/misc?',
			'/save',
		],
	],
	[['demo:root', 'sync:root',
			'dist:usr', 'repair:usr', 'dist:net', 'repair:net'],
		'/usr/bin',
		'/usr/bin/arch',
		'/usr/bin/cp',
		'/usr/bin/dd',
		'/usr/bin/hostname',
		'/usr/bin/ln',
		'/usr/bin/login',
		'/usr/bin/mkdir',
		'/usr/bin/mv',
		'/usr/bin/rm',
		'/usr/bin/stty',
		'/usr/bin/sysenv',
		'/usr/bin/uname',
		[['demo', 'dist', 'repair'],
			'/usr/bin/chmod',
			'/usr/bin/df',
			'/usr/bin/kill',
			'/usr/bin/lc',
			'/usr/bin/less',
			'/usr/bin/lf',
			'/usr/bin/ll',
			'/usr/bin/lm',
			'/usr/bin/ls',
			'/usr/bin/lx',
			'/usr/bin/mined',
			'/usr/bin/mknod',
			'/usr/bin/more',
			'/usr/bin/ps',
			'/usr/bin/rawspeed',
			'/usr/bin/readall',
			'/usr/bin/sort',
		],
		[['dist', 'repair', 'sync'],
			'/usr/bin/gunzip',
			'/usr/bin/gzcat',
			'/usr/bin/gzip',
			'/usr/bin/mkfs',
			'/usr/bin/mkfs2f',
			'/usr/bin/sleep',
			'/usr/bin/zexec',
		],
		[['dist', 'repair'],
			'/usr/bin/badblocks',
			'/usr/bin/chgrp',
			'/usr/bin/clone',
			'/usr/bin/cpdir',
			'/usr/bin/de',
			'/usr/bin/du',
			'/usr/bin/format',
			'/usr/bin/head',
			'/usr/bin/mattrib',
			'/usr/bin/mcd',
			'/usr/bin/mdel',
			'/usr/bin/mdir',
			'/usr/bin/mformat',
			'/usr/bin/mlabel',
			'/usr/bin/mmd',
			'/usr/bin/mrd',
			'/usr/bin/mread',
			'/usr/bin/mren',
			'/usr/bin/mtools',
			'/usr/bin/mtype',
			'/usr/bin/mwrite',
			'/usr/bin/od',
			'/usr/bin/rmdir',
			'/usr/bin/sed',
			'/usr/bin/su',
			'/usr/bin/tail',
			'/usr/bin/tar',
			'/usr/bin/tget',
			'/usr/bin/vol',
		],
		[['net', 'sync'],
			'/usr/bin/hostaddr',
			'/usr/bin/rcp',
			'/usr/bin/rlogin',
			'/usr/bin/rsh',
			'/usr/bin/synctree',
		],
		[['net'],
			'/usr/bin/ftp',
			'/usr/bin/ping',
			'/usr/bin/telnet',
			'/usr/bin/rget',
			'/usr/bin/rput',
		],
		'/usr/etc',
		'/usr/etc/rc',
		[['demo', 'dist', 'repair'],
			'/usr/lib',
			'/usr/lib/keymaps',
			'/usr/lib/keymaps/*',
			'/usr/lib/pwdauth',
		],
		[['dist', 'repair', 'sync'],
			'/usr/mdec',
			'/usr/mdec/boot',
			'/usr/mdec/bootblock',
			'/usr/mdec/masterboot',
		],
		[['dist'],
			'/usr/mdec/dosboot.com',
		],
		'/usr/sbin',
		'/usr/sbin/getty',
		'/usr/sbin/update',
		[['dist', 'repair', 'sync'],
			'/usr/sbin/installboot',
			'/usr/sbin/repartition',
			'/usr/sbin/shutdown',
		],
		[['dist', 'repair'],
			'/usr/sbin/MAKEDEV',
			'/usr/sbin/chown',
			'/usr/sbin/edparams',
			'/usr/sbin/mkswap',
			'/usr/sbin/part',
		],
		[['sync'],
			'/usr/sbin/partition',
			'/usr/sbin/rdate',
		],
		[['net', 'sync'],
			'/usr/sbin/in.rld',
			'/usr/sbin/in.rshd',
			'/usr/sbin/inet',
			'/usr/sbin/inetd',
			'/usr/sbin/irdpd',
			'/usr/sbin/nonamed',
			'/usr/sbin/rarpd',
		],
		[['net'],
			'/usr/sbin/add_route',
			'/usr/sbin/ifconfig',
			'/usr/sbin/pr_routes',
		],
		'/usr/src',
		'/usr/src/.ashrc',
		'/usr/src/.profile',
		[['sync'],
			'/usr/local/sbin',
			'/usr/local/sbin/synchronize',
		],
	],
]

import sys, os, string
from stat import *
from sys import stdin, stdout, stderr
from glob import glob

# An exception for assert().
AssertionFailed= 'Assertion failed'

def assert(test):
	# Make sure that the state of the world is as expected.
	if not test: raise AssertionFailed

def shglob(pathname):
	# Like glob(), but don't let it return an empty list.  (Like the
	# shell does if it can't expand a wildcard.)  It also makes sure
	# that a name is a string.
	if type(pathname) is type(''):
		return glob(pathname) or [pathname]
	else:
		return [pathname]

def expand(pathlist):
	# Expand a list of pathnames.
	return reduce(lambda l1, l2: l1 + l2, map(shglob, pathlist), [])

def flatten(pathlist):
	# Flatten a list of lists of paths.  Sublists are prefixed by a test
	# that must be true for the sublist to be included.

	def recflatten(pathname):
		if type(pathname) is type([]):
			# Pathname is really a sublist headed by a guard.
			if (how + ":" + floppy) in pathname[0] \
			    or how in pathname[0] or floppy in pathname[0]:
				return flatten(pathname[1:])
			else:
				return []
		else:
			return [pathname]

	return reduce(lambda l1, l2: l1 + l2, map(recflatten, pathlist), [])

def select_newest(dir):
	# Select the newest file from a directory, a kernel image perhaps?

	def time_pair(file):
		# Pair a filename with its modified time.
		attr= os.lstat(file)
		if S_ISREG(attr[ST_MODE]):
			return [(attr[ST_MTIME], file)]
		else:
			return []

	files= os.listdir(dir)
	for i in range(len(files)):
		files[i]= os.path.join(dir, files[i])

	files= reduce(lambda l1, l2: l1 + l2, map(time_pair, files))
	files.sort()
	files.reverse()
	return files[0][1]

def select_compress(files):
	# Select files that may be compressed executables.  If /usr/bin/zexec
	# is to be installed then all binaries in the /usr/bin and /usr/sbin
	# directories may be compressed except, of course, zexec and the gzip
	# links.
	global zexecfile
	zexecfile= {}

	if '/usr/bin/zexec' not in files: return

	for file in files:
		if type(file) is type(()): file= file[0]

		if os.path.split(file)[0] in ['/usr/bin', '/usr/sbin']:
			zexecfile[file]= None

	for file in ['/usr/bin/zexec', '/usr/bin/gzip', '/usr/bin/gunzip',
							'/usr/bin/gzcat']:
		if zexecfile.has_key(file):
			del zexecfile[file]

def major(rdev):
	return (rdev >> 8) & 0xFF

def minor(rdev):
	return (rdev >> 0) & 0xFF

def install(file, prefix, dir):
	# Install a file in the directory dir (first strip prefix).  Preserve
	# ownership, mode, etc.  There must be an (initially empty) dictionary
	# 'installed' that can be used to track links.  The dictionary
	# 'zexecfile' tells which executables may be compressed.  Tuples
	# of (name, target [, owner [,group]]) form name files that must be
	# installed from a different source.

	if prefix[-1] != '/': prefix= prefix + '/'

	owner= group= mode= None
	if type(file) is type(()):
		instspec= file
		file, target= instspec[0], os.path.join(dir, instspec[1])
		if len(instspec) >= 3: owner= instspec[2]
		if len(instspec) >= 4: group= instspec[3]
		if len(instspec) >= 5: mode= instspec[4]
	else:
		assert(prefix == file[:len(prefix)])
		target= os.path.join(dir, file[len(prefix):])

	if zexecfile.has_key(file):
		instopt= '-cs6'
	else:
		instopt= '-cs'

	try:
		attr_file= os.lstat(file)
	except os.error, (errno, msg):
		print "WARNING: %s: %s" % (file, msg)
		return

	st_mode, st_ino, st_dev, st_uid, st_gid, st_rdev= \
		attr_file[ST_MODE], attr_file[ST_INO], \
		attr_file[ST_DEV], attr_file[ST_UID], \
		attr_file[ST_GID], attr_file[ST_RDEV]
	if owner: st_uid= owner
	if group: st_gid= group
	if mode: st_mode= (st_mode & ~07777) | (mode & 07777)

	if installed.has_key((st_dev, st_ino)):
		print "ln", installed[(st_dev, st_ino)], target
		os.link(installed[(st_dev, st_ino)], target)
	elif S_ISDIR(st_mode):
		do(1, 1, "install -d -m %o -o %s -g %s %s" %
			(st_mode & 07777, st_uid, st_gid, target))
	elif S_ISREG(st_mode):
		do(1, 1, "install %s -m %o -o %s -g %s %s %s" %
			(instopt, st_mode & 07777,
					st_uid, st_gid, file, target))
	elif S_ISLNK(st_mode):
		print "ln -s", os.readlink(file), target
		os.symlink(os.readlink(file), target)
	elif S_ISBLK(st_mode) or S_ISCHR(st_mode):
		print "mknod %s %c %d %d" % (target,
				(S_ISBLK(st_mode) and 'b' or 'c'),
				major(st_rdev), minor(st_rdev))
		os.mknod(target, st_mode, st_rdev)
		os.chmod(target, st_mode & 07777)
		os.chown(target, st_uid, st_gid)
	else:
		assert(0)

	installed[(st_dev, st_ino)]= target

# Only root can make device files and such.
if os.geteuid() != 0:
	stderr.write("fdminix must be run by root\n")
	sys.exit(1)

def usage():
	stderr.write("Usage: fdminix demo|dist|repair|sync <device>\n")
	sys.exit(1)

if len(sys.argv) != 3: usage()

how, device= sys.argv[1], sys.argv[2]

if how not in ['demo', 'dist', 'repair', 'sync']: usage()

# First word on the mounted device table is the root device.
f= open('/etc/mtab')
rootdev= string.split(f.readline())[0];
f.close()

def do(echo, check, command):
	# Execute a command, optionally with echoing and an error check.
	if echo: print command
	if os.system(command) != 0 and check: sys.exit(1)

# Make sure the device is free for use.
do(0, 0, "umount -v %s 2>/dev/null" % (device))

# First the root floppy.
floppy= 'root'
files= expand(flatten(FILELIST))
installed= {}
select_compress(files)

print "Insert the", how, "floppy and hit RETURN"
stdin.readline()

# Add the newest Minix kernel image to the list of files.
if '/minix' in files:
	files.append(select_newest('/minix'))

# Number of files on the root file system.  Don't forget what MAKEDEV adds
# many devices.  (Counting the current /dev/* is not exactly OK.)
nfiles= len(files)
if how != 'repair':
	nfiles= nfiles + len(glob('/dev/*'))

# Mkfs, mount, copy, make bootable.
if how == 'demo':
	do(1, 1, "mkfs -t 2f -i %d %s 1200" % (nfiles + 64, device))
elif how in ['dist', 'repair']:
	do(1, 1, "mkfs -t 2f -i %d %s  720" % (nfiles + 32, device))
else:
	assert(how == 'sync')
	do(1, 1, "mkfs -t 2f -i %d %s 1200" % (nfiles + 32, device))

do(0, 1, "mount %s /mnt" % device)

os.chmod("/mnt", 0755)

# Install the files from the root directory.
for file in files:
	install(file, "/", "/mnt")

# Fix up the wrongly copied mountpoints if any.
for dir in ('mnt', 'var', 'opt', 'home'):
	if os.path.exists("/mnt/%s" % dir): os.chmod("/mnt/%s" % dir, 0555)

# Add the standard devices to /dev.
if how != 'repair': do(1, 1, "cd /mnt/dev && MAKEDEV std")

# Adapt the demo and sync fstab to the device it is likely to see.
if how in ['demo', 'sync']:
	f= open("/mnt/etc/fstab", "w")
	f.write("""\
# fstab - File System Table
#
# Device	Dir	Type	Options		Freq	Pass	Time
/dev/fd0	/	2f	rw		0	1	0
""")
	f.close()

# Adapt the sync passwd file to something simpler.
if how == 'sync':
	f= open("/mnt/etc/passwd", "w")
	f.write("""\
root::0:0:Big Brother:/usr/src:
daemon:*:1:1:The Deuce:/etc:
synch::0:0:Synchronize:/tmp:/usr/local/sbin/synchronize
bin::2:0:Binaries:/usr/src:
uucp::5:5:UNIX to UNIX copy:/usr/spool/uucp:/usr/sbin/uucico
news:*:6:6:Usenet news:/usr/spool/news:
ftp:*:7:7:Anonymous FTP:/var/ftp:
nobody:*:9999:99::/tmp:
ast::8:3:Andrew S. Tanenbaum:/usr/ast:
""")
	f.close()

# Unmount and make bootable.
do(0, 1, "umount /mnt")
do(1, 1, "installboot -device %s /usr/mdec/bootblock boot >/dev/null" % device)

# Copy the boot parameters to a repair floppy.
if how == 'repair':
	do(0, 1, "dd if=%s of=%s skip=1 seek=1 count=1" % (rootdev, device))

# A demo floppy needs no RAM disk.
if how == 'demo':
	do(0, 1, "edparams %s 'rootdev=bootdev;save'" % device)

# A sync floppy has its own weird menu.
if how == 'sync':
	do(0, 1, """edparams %s '
		a(a,no variant) { unset variant; menu }
		b(b,variant=minix) { variant=minix; menu }
		c(c,variant=samba311) { variant=samba311; menu }
		d(d,variant=samba411) { variant=samba411; menu }
		e(e,variant=minix,samba311) { variant=minix,samba311; menu }
		f(f,variant=minix,samba411) { variant=minix,samba411; menu }
		5(5,DPETH0=280:5) { DPETH0=280:5; menu }
		0(0,DPETH0=300:10) { DPETH0=300:10; menu }
		minix(=,Minix-vmd){boot}
		servers=inet
		save'
		""" % device)

# Now do the /usr partition (if any.)
floppy= 'usr'
files= expand(flatten(FILELIST))
installed= {}
select_compress(files)

# Are there files for /usr?
if not files: sys.exit(0)

# Mkfs, mount, copy, make *not* bootable.
do(0, 1, "partition -m %s 0 81:1440 0:0 81:1440 >/dev/null" % device)
do(0, 1, "repartition %s >/dev/null" % device)
do(1, 1, "mkfs -t 2f -i %d %sc" % (len(files) + 16, device))

do(0, 1, "mount %sc /mnt" % device)

os.chmod("/mnt", 0755)

# Install the files from the /usr directory.
for file in files:
	install(file, "/usr", "/mnt")

# Unmount and make it boot something else if booted.
do(0, 1, "umount /mnt")
do(1, 1, "installboot -master %sc /usr/mdec/masterboot >/dev/null" % device)

# Now do the network /usr floppy (if any.)
floppy= 'net'
files= expand(flatten(FILELIST))
installed= {}
select_compress(files)

# Are there files for /usr?
if not files: sys.exit(0)

print "Insert the network /usr floppy and hit RETURN"
stdin.readline()

# Mkfs, mount, copy, make *not* bootable.
do(1, 1, "mkfs -t 2f -i %d %s 1200" % (len(files) + 16, device))

do(0, 1, "mount %s /mnt" % device)

os.chmod("/mnt", 0755)

# Install the files from the /usr directory.
for file in files:
	install(file, "/usr", "/mnt")

# Unmount and make it boot something else if booted.
do(0, 1, "umount /mnt")
do(1, 1, "installboot -master %s /usr/mdec/masterboot >/dev/null" % device)

# Done.

#!/bin/sh
# 10 Dec 2000

ex=0

for i
do
    pid="/usr/run/$i.pid"
    if [ -f "$pid" ]
    then
	pid=`cat "$pid"` || exit
	if kill "$pid"
	then
	    for t in 1 2 4 8
	    do
		kill -0 "$pid" 2>/dev/null || break
		sleep $t
	    done
	    if kill -0 "$pid" 2>/dev/null
	    then
		echo "killd: $i still lives" 2>&1
		ex=1
	    fi
	fi
    else
	echo "killd: No $pid exists" >&2
	ex=1
    fi
done
exit $ex

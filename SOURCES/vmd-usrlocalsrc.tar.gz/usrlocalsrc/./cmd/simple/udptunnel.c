/*	udptunnel 1.0 - Create an encrypted IP tunnel over UDP
 *							Author: Kees J. Bot
 *								1 Nov 2000
 */
#define nil ((void*)0)
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <time.h>
#include <configfile.h>
#include <sys/asynchio.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <crypto/rijndael.h>
#include <net/hton.h>
#include <net/netlib.h>
#include <net/gen/in.h>
#include <net/gen/netdb.h>
#include <net/gen/socket.h>
#include <net/gen/inet.h>
#include <net/gen/ip_hdr.h>
#include <net/gen/ip_io.h>
#include <net/gen/udp.h>
#include <net/gen/udp_hdr.h>
#include <net/gen/udp_io.h>

#define KEEPALIVE	 (1*60)		/* Keepalive interval. */
#define ODDALIVE	   (30)		/* Not too often odd "alive"s. */
#define EXPIRE		(30*60)		/* Expiry interval. */
#define NEVER		LONG_MAX	/* Don't do this ever. */
#define DEFAULT_CONFIG	"/etc/udptunnel.conf";
static char RANDOM[] =	"/dev/random";

#define IPBUFLEN	1800		/* Max IP packet size. */
#define UDPBUFLEN	2000		/* + headers and stuff is UDP max. */

#define IPHDRLEN	(int)sizeof(ip_hdr_t)
#define UDPHDRLEN	(int)sizeof(udp_io_hdr_t)

#define BROADCAST	HTONL(0xFFFFFFFFUL)
#define isbroadcast(ip)	\
	(((ip ^ HTONL(0xE0000000UL)) & HTONL(0xE0000000UL)) == 0)

#define B(a)		((u8_t *) (a))	/* Look at something as a byte array. */

static char *program;		/* Name of this program. */
static unsigned debug;		/* Debug level. */
static time_t now;		/* The current time. */
static time_t oddalive;		/* When to send "alive" on odd events. */
static time_t lastbcast;	/* Last time a broadcast was sent by me. */

/* Data for various cryptos. */

typedef enum crypto {		/* Available cryptos. */
	PLAINTEXT,			/* Plaintext. */
	DES,				/* DES. */
	RIJNDAEL128,			/* Rijndael with 128 bit key. */
	RIJNDAEL192,			/* Rijndael with 192 bit key. */
	RIJNDAEL256,			/* Rijndael with 256 bit key. */
	NR_CRYPTOS			/* # available. */
} crypto_t;

/* Relative strength of the cryptos. */
static u8_t cryptstrength[NR_CRYPTOS] = {
	0, 1, 2, 3, 4
};

typedef union cryptodata {
	rd_keyinstance	rijndael;	/* Rijndael "key instance". */
} cryptodata_t;

/* Function to encode or decode an IP packet using a certain crypto. */
typedef ssize_t codefun(u8_t *data, size_t len, struct peer *peer);

/* Description of one endpoint in the tunnel. */
typedef struct peer {
	struct peer	*next;
	ipaddr_t	tip;		/* Address of peer within tunnel. */
	ipaddr_t	cip;		/* Current address of peer. */
	udpport_t	port;		/* Port used for tunneled traffic. */
	time_t		expire;		/* When does 'cip' expire? */
	const char	*admin;		/* Email address of admin. */
	const char	*key[NR_CRYPTOS];/* Keys available. */
	crypto_t	prefer;		/* Crypto this peer prefers. */
	cryptodata_t	cryptodata;	/* Key schedules and such. */
	codefun		*encode;	/* Encode an IP packet. */
	codefun		*decode;	/* Decode an IP packet. */
	u8_t		sIV[16];	/* Sending initialization vector. */
	u8_t		rIV[16];	/* Receiving IV. */
	unsigned	sync_ct;	/* Out of sync while > 0. */
} peer_t;

#define P_NR_SYNC	4		/* Send this many "full IVs" to sync. */

/* List of networks handled by the various tunnel endpoints. */
typedef struct network {
	struct network	*next;
	ipaddr_t	ip;		/* Base IP address of a network. */
	ipaddr_t	mask;		/* Netmask. */
	peer_t		*peer;		/* Peer where this net is found at. */
} network_t;

static peer_t *peer_table;
static network_t *net_table;

static ipaddr_t my_tip;			/* My tunnel endpoint IP address. */
static peer_t *myself;			/* My endpoint's description. */

static void *allocate(void *mem, size_t len)
{
    /* Allocate or reallocate a memory block of 'len' bytes. */

    if ((mem= realloc(mem, len)) == nil) {
	fprintf(stderr, "%s: Can't allocate %lu bytes memory: %s\n",
	    program, (unsigned long) len, strerror(errno));
	exit(1);
    }
    return mem;
}

#define between(a, c, z)	((unsigned) (c) - (a) <= (unsigned) (z) - (a))

static int mask2len(ipaddr_t mask)
{
    /* Length of the network prefix of an IP address given it's netmask. */
    ipaddr_t testmask= 0xFFFFFFFFUL;
    int n;

    for (n= 32; n >= 0; n--) {
	if (mask == htonl(testmask)) break;
	testmask= (testmask << 1) & 0xFFFFFFFFUL;
    }
    return n;
}

static void parse_config(char *configfile)
{
    /* Parse the tunnel configuration file. */
    config_t *cfg;
    peer_t *pr, **apr;
    network_t *nt, **ant;
    u8_t startIV[16];
    int rfd;
    ssize_t n, r;

    /* Pull a starting initialization vector out of the random device. */
    if ((rfd= open(RANDOM, O_RDONLY)) < 0) {
	fprintf(stderr, "%s: %s: %s\n", program, RANDOM, strerror(errno));
	exit(1);
    }
    for (n= 0; n < sizeof(startIV); n += r) {
	r= read(rfd, startIV + n, sizeof(startIV) - n);
	if (r <= 0) {
	    fprintf(stderr, "%s: %s: %s\n", program, RANDOM,
		r < 0 ? strerror(errno) : "Unexpected EOF");
	    exit(1);
	}
    }
    close(rfd);

    /* Read the configuration file and fill the peer and network tables. */
    cfg= config_read(configfile, 0, nil);
    apr= &peer_table;

    while (cfg != nil) {
	config_t *cmd= cfg->list;
	cfg= cfg->next;

	if (strcmp(cmd->word, "peer") == 0) {
	    /* Information on an endpoint in the tunnel. */
	    config_t *info;
	    struct hostent *he;

	    if (config_length(cmd) != 4
		|| !config_isatom(cmd->next)
		|| !config_isatom(cmd->next->next)
		|| !config_issub(cmd->next->next->next)
	    ) {
		fprintf(stderr,
		"\"%s\", line %u: Usage: peer tunnel-name open-name { ... }\n",
		    cmd->file, cmd->line);
		exit(1);
	    }

	    pr= allocate(nil, sizeof(*pr));
	    pr->next= nil;
	    pr->port= 0;
	    pr->admin= nil;
	    pr->key= nil;
	    memcpy(pr->sIV, startIV, sizeof(pr->sIV));
	    memset(pr->rIV, 0, sizeof(pr->rIV));
	    pr->sync_ct= P_NR_SYNC;

	    /* Look up the IP address of the tunnel endpoint. */
	    if ((he= gethostbyname(cmd->next->word)) == nil
		|| he->h_addrtype != AF_INET
		|| he->h_length != sizeof(ipaddr_t)
	    ) {
		fprintf(stderr, "\"%s\", line %u: %s: Lookup failed\n",
		    cmd->next->file, cmd->next->line, cmd->next->word);
		exit(1);
	    }
	    memcpy(&pr->tip, he->h_addr, sizeof(pr->tip));

	    /* Is it perhaps the definition of my tunnel endpoint? */
	    if (pr->tip == my_tip) myself= pr;

	    /* Add a "host route" for the tunnel endpoint. */
	    nt= allocate(nil, sizeof(*nt));
	    nt->ip= pr->tip;
	    nt->mask= HTONL(0xFFFFFFFFUL);
	    nt->peer= pr;
	    for (ant= &net_table; *ant != nil; ant= &(*ant)->next) {
		if (nt->mask > (*ant)->mask) break;

		if (nt->ip == (*ant)->ip) {
		    fprintf(stderr,
			"\"%s\", line %u: Peer %s has already been defined\n",
			cmd->next->file, cmd->next->line, cmd->next->word);
		    exit(1);
		}
	    }
	    nt->next= *ant;
	    *ant= nt;

	    /* Look up the outside IP address if given. */
	    if (strcmp(cmd->next->next->word, "*") == 0) {
		pr->cip= 0;
		pr->port= 0;
	    } else {
		char *colon, *end;
		unsigned long p;

		if ((colon= strchr(cmd->next->next->word, ':')) == nil) {
		    fprintf(stderr,
			"\"%s\", line %u: %s should be hostname:port\n",
			cmd->next->next->file, cmd->next->next->line,
			cmd->next->next->word);
		    exit(1);
		}
		*colon++ = 0;
		p= strtoul(colon, &end, 0);
		if (end == colon || *end != 0 || p <= 0 || p > 0xFFFF) {
		    fprintf(stderr,
			"\"%s\", line %u: %s: Bad port number\n",
			cmd->next->next->file, cmd->next->next->line,
			cmd->next->next->word);
		    exit(1);
		}
		pr->port= ntohs(p);

		if ((he= gethostbyname(cmd->next->next->word)) == nil
		    || he->h_addrtype != AF_INET
		    || he->h_length != sizeof(ipaddr_t)
		) {
		    fprintf(stderr, "\"%s\", line %u: %s: Lookup failed\n",
			cmd->next->next->file, cmd->next->next->line,
			cmd->next->next->word);
		    exit(1);
		}
		memcpy(&pr->cip, he->h_addr, sizeof(pr->cip));
		*--colon= ':';
	    }
	    pr->expire= pr->cip == 0 ? 0 : NEVER;

	    if (debug >= 1) {
		fprintf(stderr, "peer %s ", inet_ntoa(pr->tip));
		fprintf(stderr, "%s:%u {\n",
		    inet_ntoa(pr->cip), ntohs(pr->port));
	    }

	    info= cmd->next->next->next->list;
	    while (info != nil) {
		config_t *cmd= info->list;
		info= info->next;

		if (strcmp(cmd->word, "admin") == 0) {
		    if (config_length(cmd) != 2 || !config_isatom(cmd->next)) {
			fprintf(stderr,
			    "\"%s\", line %u: Usage: admin \"email-address\"\n",
			    cmd->file, cmd->line);
			exit(1);
		    }
		    pr->admin= cmd->next->word;
		    if (debug >= 1) {
			fprintf(stderr, "\tadmin \"%s\";\n", pr->admin);
		    }
		} else
		if (strcmp(cmd->word, "key") == 0) {
		    if (config_length(cmd) != 2 || !config_isatom(cmd->next)) {
			fprintf(stderr,
			    "\"%s\", line %u: Usage: key hex-digits\n",
			    cmd->file, cmd->line);
			exit(1);
		    }
		    pr->key= cmd->next->word;
		    if (rijndael_makekey(&pr->keyinst, RD_KEY_HEX, pr->key)
								< 0) {
			fprintf(stderr,
			    "\"%s\", line %u: Not a proper Rijndael key\n",
			    cmd->next->file, cmd->next->line);
			exit(1);
		    }
		    if (debug >= 1) fprintf(stderr, "\tkey ...;\n");
		} else
		if (strcmp(cmd->word, "network") == 0) {
		    const char *ip;
		    char *len, *end;
		    unsigned long l;

		    if (config_length(cmd) != 2 || !config_isatom(cmd->next)) {
			fprintf(stderr,
			    "\"%s\", line %u: Usage: network CIDR-block\n",
			    cmd->file, cmd->line);
			exit(1);
		    }

		    nt= allocate(nil, sizeof(*nt));
		    ip= cmd->next->word;
		    if (strcmp(ip, "*") == 0) {
			nt->ip= HTONL(0);
			nt->mask= HTONL(0);
		    } else {
			l= 32;
			if ((len= strchr(ip, '/')) != nil) {
			    *len++ = 0;
			    l= strtoul(len, &end, 10);
			}
			if (!inet_aton(ip, &nt->ip) || (len != nil && (
			    end == len || *end != 0 || l > 32)
			)) {
			    if (len != nil) *--len= '/';
			    fprintf(stderr,
			    "\"%s\", line %u: %s is not a proper CIDR-block\n",
				cmd->next->file, cmd->next->line, ip);
			    exit(1);
			}
			if (len != nil) *--len= '/';
			nt->mask= htonl(l == 0 ? 0 : 0xFFFFFFFFUL << (32 - l));
		    }

		    for (ant= &net_table; *ant != nil; ant= &(*ant)->next) {
			if (nt->mask > (*ant)->mask) break;

			if (nt->mask == (*ant)->mask
			    && ((nt->ip ^ (*ant)->ip) & nt->mask) == 0
			) {
			    fprintf(stderr,
	    "\"%s\", line %u: Network %s has already been defined for %s\n",
				cmd->next->file, cmd->next->line,
				ip, inet_ntoa((*ant)->peer->tip));
			    exit(1);
			}
		    }
		    nt->peer= pr;
		    nt->next= *ant;
		    *ant= nt;

		    if (debug >= 1) {
			fprintf(stderr, "\tnetwork %s/%d;\n",
			    inet_ntoa(nt->ip), mask2len(nt->mask));
		    }
		} else {
		    fprintf(stderr, "\"%s\", line %u: Unknown keyword, '%s'\n",
			cmd->file, cmd->line, cmd->word);
		    exit(1);
		}
	    }

	    if (pr->admin == nil || pr->key == nil) {
		fprintf(stderr,
		"\"%s\", line %u: The definition of peer %s is incomplete\n",
		    cmd->file, cmd->line, cmd->next->word);
		exit(1);
	    }

	    (*apr)= pr;
	    apr= &pr->next;

	    if (debug >= 1) fprintf(stderr, "};\n");
	} else {
	    fprintf(stderr, "\"%s\", line %u: Unknown keyword, '%s'\n",
		cmd->file, cmd->line, cmd->word);
	    exit(1);
	}
    }

    if (myself == nil) {
	fprintf(stderr, "%s: There is no \"peer\" in %s for myself\n",
	    program, configfile);
	exit(1);
    }

    if (debug >= 1) {
	fprintf(stderr, "Tunnel routing table:\n");
	for (nt= net_table; nt != 0; nt= nt->next) {
	    fprintf(stderr, "\t%s/%d", inet_ntoa(nt->ip), mask2len(nt->mask));
	    fprintf(stderr, " -> %s\n", inet_ntoa(nt->peer->tip));
	}
    }
}

static peer_t *find_peer(ipaddr_t ip, udpport_t port)
/* Find a peer given its current IP address and port if port != 0, or find
 * a peer given its tunnel IP address if port == 0.
 */
{
    static struct {
	ipaddr_t	ip;
	udpport_t	port;
	peer_t		*peer;
    } pcache[256], *pc;

    pc= &pcache[((u8_t *) &ip)[3]];

    /* Is it in the cache now? */
    if (pc->ip != ip || pc->port != port) {
	peer_t *pr;

	/* Walk through the list of peers. */
	for (pr= peer_table; pr != nil; pr= pr->next) {
	    if ((pr->tip == ip && port == 0)
		|| (pr->cip == ip && pr->port == port && pr->cip != 0)
	    ) {
		pc->ip= ip;
		pc->port= port;
		pc->peer= pr;
		goto found;
	    }
	}
	return nil;
    }
found:
    return pc->peer;
}

/* Command byte at the end of a packet on the open net.  Values below
 * OCMD_FIRST tell the low 7 bits of the IV used while in sync.
 */
#define OCMD_FIRST	0x80	/* Non-IV-bits commands starting value */
#define OCMD_IV		0x80	/* Complete IV is sent (we lost sync). */
#define OCMD_RESYNC	0x81	/* Need to reestablish sync. */

/* Commands within the tunnel. */
#define TCMD_ALIVE	0x00	/* I'm alive! (Carries current IP and port). */

#define CKSUM_LEN	8

static void cksum(const u8_t *data, size_t len, u8_t *sum)
{
    /* Compute an XOR checksum of a data area.  It is expected that this in
     * itself weak checksum will be encrypted with the data to make it secure.
     */
    size_t i;
    u8_t s;

    s= 0;
    for (i= 0; i < CKSUM_LEN; i++) sum[i]= 0;
    for (i= 0; i < len; i++) sum[i % CKSUM_LEN] ^= (s ^= data[i]);
}

static void warpIV(u8_t *IV, unsigned low)
/* Increment or decrement an IV at the minimum distance needed to make the low
 * 7 bits equal to 'low'.  Being fond of little endian we choose to do that.
 */
{
    unsigned b;
    int i;

    goto up;	/* (In a perfect world we only increment by one.) */
    do {
	if (b < 0x40) {
	    /* Up is closer. */
	up: if (++IV[0] == 0x00) {
		for (i= 1; i < 16 && ++IV[i] == 0x00; i++) {}
	    }
	} else {
	    /* Down is closer. */
	    if (--IV[0] == 0xFF) {
		for (i= 1; i < 16 && --IV[i] == 0xFF; i++) {}
	    }
	}
    } while ((b= ((low - IV[0]) & 0x7F)) != 0);
}

static ssize_t encode(u8_t *data, size_t len, peer_t *peer)
/* Encode data to be sent to the given peer.  Return the new size after adding
 * a checksum and stuff, or -1 on error.
 */
{
    u8_t iv[16];

    /* First add a checksum. */
    cksum(data, len, data + len);
    len += CKSUM_LEN;

    /* Encrypt the data with the peer's key and the sending IV. */
    memcpy(iv, peer->sIV, 16);
    if (rijndael_cbc_encrypt(&peer->keyinst, data, data, len, &iv) < 0) {
	return -1;
    }

    /* Add the IV if out of sync, otherwise just the low bits. */
    if (peer->sync_ct > 0) {
	memcpy(data+len, peer->sIV, 16);
	len += 16;
	data[len++] = OCMD_IV;
	peer->sync_ct--;		/* We're getting in sync. */
    } else {
	data[len++] = (peer->sIV[0] & 0x7F);
    }

    /* Increment the IV, never use it twice. */
    warpIV(peer->sIV, peer->sIV[0] + 1);

    return len;
}

static ssize_t decode(u8_t *data, size_t len, peer_t *peer)
/* Decode data received from a given peer (may be a null pointer for an as
 * yet unknown peer).  Return the new size after removing the checksum and
 * stuff, or -1 on error.
 */
{
    u8_t iv[16], riv[16], sum[8];

    if (len == 0) return -1;
    len--;
    if (data[len] >= OCMD_FIRST) {
	switch (data[len]) {
	case OCMD_IV:
	    /* A whole IV has been sent, I guess we lost sync. */
	    if (len < 16) return -1;
	    len -= 16;
	    memcpy(riv, data + len, 16);
	    break;
	case OCMD_RESYNC:
	    /* This is just to tell us that they lost sync with us. */
	    if (len != 0) return -1;
	    if (peer != nil) peer->sync_ct= P_NR_SYNC;
	    if (myself->expire != NEVER) {
		/* Maybe the other side rebooted?  Broadcast "alive". */
		myself->expire= oddalive;
		if (oddalive <= now) oddalive= now + ODDALIVE;
		lastbcast= 0;
	    }
	    return 0;	/* No data. */
	default:
	    return -1;	/* Garbage. */
	}
    } else {
	/* Only the low few bits have been sent. */
	if (peer == nil) return -1;
	memcpy(riv, peer->rIV, 16);
	warpIV(riv, data[len]);
    }

    /* Expecting at least an IP header and a checksum. */
    if (len < 20+CKSUM_LEN) return -1;

    /* Decrypt the packet with my key. */
    memcpy(iv, riv, 16);
    if (rijndael_cbc_decrypt(&myself->keyinst, data, data, len, &iv) < 0) {
	return -1;
    }

    /* Compute the checksum and compare. */
    len -= CKSUM_LEN;
    cksum(data, len, sum);
    if (memcmp(data + len, sum, CKSUM_LEN) != 0) return -1;

    /* Looks OK to me, update the receiving IV and return. */
    if (peer != nil) memcpy(peer->rIV, riv, 16);
    return len;
}

/* Buffers for packets. */
typedef struct buf {
	struct buf	*next;		/* Next on the free list. */
	enum { UDP, PSIP, AIR } net;	/* Source of this packet. */
	udp_io_hdr_t	*udp;		/* UDP header in payload. */
	ip_hdr_t	*ip;		/* IP header in payload. */
	u8_t		*data;		/* User data in payload. */
	u8_t		*end;		/* End of useful data. */
	u8_t		buf[UDPBUFLEN];	/* Payload. */
} buf_t;

buf_t *freebuf;		/* Currently unused buffers. */

static void get_buf(buf_t **bp)
{
    /* Allocate and return a buffer pointer iff *bp == nil. */
    if (*bp != nil) {
	/* Already has one. */
    } else
    if (freebuf != nil) {
	/* There is a free buffer. */
	*bp= freebuf;
	freebuf= freebuf->next;
    } else {
	/* Get one from the heap. */
	buf_t *new= allocate(nil, sizeof(*(*bp)));
	new->udp= (udp_io_hdr_t *) new->buf;
	new->ip= (ip_hdr_t *) (new->udp + 1);
	new->data= (u8_t *) (new->ip + 1);
	*bp= new;
    }
}

static void put_buf(buf_t **bp)
{
    /* Return a buffer to the free list. */
    if (*bp != nil) {
	(*bp)->next= freebuf;
	freebuf= *bp;
	*bp= nil;
    }
}

static void give_buf(buf_t **dbp, buf_t **sbp)
{
    /* Hand over a buffer to another variable. */
    put_buf(dbp);
    *dbp= *sbp;
    *sbp= nil;
}

static peer_t *route(ip_hdr_t *iphdr)
/* Determine where an IP packet should be forwarded to. */
{
    static struct {
	ipaddr_t	src;
	ipaddr_t	dst;
	peer_t		*peer;
    } rcache[256], *rc;

    rc= &rcache[((u8_t *) &iphdr->ih_src)[3] ^ ((u8_t *) &iphdr->ih_dst)[3]];

    /* Is it in the cache? */
    if (rc->dst != iphdr->ih_dst || rc->src != iphdr->ih_src) {
	network_t *nt;

	/* Walk through the list of known networks. */
	for (nt= net_table; nt != nil; nt= nt->next) {
	    if (((nt->ip ^ iphdr->ih_dst) & nt->mask) == 0) {
		/* Got it. */
		rc->dst= iphdr->ih_dst;
		rc->src= iphdr->ih_src;
		rc->peer= nt->peer;
		goto found;
	    }
	}
	return nil;
    }
found:
    /* XXX - Implement packet filtering here. */
    return rc->peer;
}

static void usage(void)
{
    fprintf(stderr,
	"Usage: %s [-d[level]] [-f config] tunnel-net open-net\n"
	"	tunnel-net: Network number of the pseudo-ip tunnel endpoint\n"
	"	open-net: Network number of the Internet transport network\n",
	program);
    exit(1);
}

int main(int argc, char **argv)
{
    static char ps_device[]= "/dev/psipXXX";
    static char udp_device[]= "/dev/udpXXX";
    static char ip_device[]= "/dev/ipXXX";
#define set_net(device, net) (strncpy((device)+(sizeof(device)-4), (net), 3))
    char *ps_net, *udp_net;
    int ps_fd[2], udp_fd[2], ip_fd;
    asynchio_t asyn;
    nwio_ipconf_t ipconf;
    nwio_udpopt_t udpopt;
    int i;
    char *configfile;
    struct timeval tv, *tvp;
    buf_t *udp_buf, *ps_buf, *buf;
    ssize_t r;

    program= argv[0];

    configfile= DEFAULT_CONFIG;
    debug= 0;
    i= 1;
    while (i < argc && argv[i][0] == '-') {
	char *opt= argv[i++]+1;

	if (opt[0] == '-' && opt[1] == 0) break;	/* -- */

	while (*opt != 0) switch (*opt++) {
	case 'f':
	    if (*opt == 0) {
		if (i == argc) usage();
		opt= argv[i++];
	    }
	    configfile= opt;
	    opt= "";
	    break;
	case 'd':
	    debug= 1;
	    if (between('0', *opt, '9')) debug= strtoul(opt, &opt, 10);
	    break;
	default:
	    usage();
	}
    }
    if ((argc - i) != 2) usage();
    ps_net= argv[i+0];
    udp_net= argv[i+1];

    /* Set the network numbers of the networks involved. */
    set_net(ps_device, ps_net);
    set_net(udp_device, udp_net);
    set_net(ip_device, ps_net);

    /* Figure out what the IP address of my own pseudo-IP network is. */
    if ((ip_fd= open(ip_device, O_RDWR)) < 0) {
	fprintf(stderr, "%s: Can't open %s: %s\n",
	    program, ip_device, strerror(errno));
	exit(1);
    }
    if (ioctl(ip_fd, NWIOGIPCONF, &ipconf) < 0) {
	fprintf(stderr, "%s: Can't obtain the IP address of %s: %s\n",
	    program, ip_device, strerror(errno));
	exit(1);
    }
    my_tip= ipconf.nwic_ipaddr;
    close(ip_fd);
    if (debug >= 1) {
	fprintf(stderr, "My tunnel endpoint address is %s\n",
	    inet_ntoa(my_tip));
    }

    /* Read and interpret the configuration file. */
    parse_config(configfile);

    if ((ps_fd[0]= open(ps_device, O_RDWR)) < 0) {
	fprintf(stderr, "%s: Can't open %s: %s\n",
	    program, ps_device, strerror(errno));
	exit(1);
    }

    if ((udp_fd[0]= open(udp_device, O_RDWR)) < 0) {
	fprintf(stderr, "%s: Can't open %s: %s\n",
	    program, udp_device, strerror(errno));
	exit(1);
    }

    udpopt.nwuo_flags= NWUO_EXCL | NWUO_EN_LOC | NWUO_DI_BROAD | NWUO_RP_ANY
			| NWUO_RA_ANY | NWUO_RWDATALL | NWUO_DI_IPOPT
			| (myself->expire == NEVER ? NWUO_LP_SET : NWUO_LP_SEL);
    udpopt.nwuo_locport= myself->port;

    if (ioctl(udp_fd[0], NWIOSUDPOPT, &udpopt) == -1
	|| ioctl(udp_fd[0], NWIOGUDPOPT, &udpopt) == -1
    ) {
	fprintf(stderr, "%s: %s: %s\n", program, udp_device, strerror(errno));
	exit(1);
    }

    if (myself->expire == NEVER && myself->cip != udpopt.nwuo_locaddr) {
	fprintf(stderr, "%s: My address on %s is %s, expected ",
	    program, udp_device, inet_ntoa(udpopt.nwuo_locaddr));
	fprintf(stderr, "%s\n", inet_ntoa(myself->cip));
	exit(1);
    }

    if ((ps_fd[1]= dup(ps_fd[0])) < 0 || (udp_fd[1]= dup(udp_fd[0])) < 0) {
	fprintf(stderr, "%s: Unable to dup() file descriptors: %s\n",
	    program, strerror(errno));
	exit(1);
    }

    udp_buf= ps_buf= buf= nil;
    asyn_init(&asyn);

    for (;;) {
	now= time(nil);

	if (buf == nil) {
	    /* Reading UDP tunneled packets from the open network. */
	    get_buf(&udp_buf);
	    r= asyn_read(&asyn, udp_fd[0], udp_buf->udp, UDPBUFLEN);

	    if (r >= UDPHDRLEN) {
		peer_t *pr;

		udp_buf->end= udp_buf->buf + r;

		/* The packet must first be decrypted. */
		pr= find_peer(udp_buf->udp->uih_src_addr,
				udp_buf->udp->uih_src_port);
		r= decode(B(udp_buf->ip), udp_buf->end - B(udp_buf->ip), pr);

		if (r > 0) {
		    /* Decoded fine. */
		    udp_buf->end= B(udp_buf->ip) + r;
		    udp_buf->net= UDP;
		    give_buf(&buf, &udp_buf);
		} else
		if (r < 0) {
		    /* Oops, we got garbage.  Tell source to resync. */
		    if (debug >= 1) {
			fprintf(stderr,
			    "Got garbage, telling %s:%u to resync\n",
			    inet_ntoa(udp_buf->udp->uih_src_addr),
			    ntohs(udp_buf->udp->uih_src_port));
		    }
		    udp_buf->udp->uih_dst_addr= udp_buf->udp->uih_src_addr;
		    udp_buf->udp->uih_dst_port= udp_buf->udp->uih_src_port;
		    udp_buf->udp->uih_ip_opt_len= 0;
		    udp_buf->udp->uih_data_len= 1;
		    udp_buf->end= udp_buf->buf + UDPHDRLEN + 1;
		    udp_buf->buf[UDPHDRLEN]= OCMD_RESYNC;
		    if (write(udp_fd[1], udp_buf->udp,
					udp_buf->end - B(udp_buf->udp)) < 0) {
			fprintf(stderr, "%s(%d): %s: %s\n",
			    program, __LINE__, udp_device, strerror(errno));
			sleep(10);
		    }
		} else {
		    /* No data, this can only be a resync. */
		    if (debug >= 1) {
			fprintf(stderr, "Got a resync request from %s:%u\n",
			    inet_ntoa(udp_buf->udp->uih_src_addr),
			    ntohs(udp_buf->udp->uih_src_port));
		    }
		}
	    } else
	    if (r != -1 || errno != EINPROGRESS) {
		fprintf(stderr, "%s(%d): %s: Input error: %s\n",
		    program, __LINE__, udp_device,
		    r == -1 ? strerror(errno) : "Short read");
		sleep(10);
	    }
	}

	if (buf == nil) {
	    /* Reading packets from the PSIP device that I should tunnel. */
	    get_buf(&ps_buf);
	    r= asyn_read(&asyn, ps_fd[0], ps_buf->ip, IPBUFLEN);

	    if (r >= IPHDRLEN) {
		ps_buf->net= PSIP;
		ps_buf->end= B(ps_buf->ip) + r;
		give_buf(&buf, &ps_buf);
	    } else
	    if (r != -1 || errno != EINPROGRESS) {
		fprintf(stderr, "%s(%d): %s: Input error: %s\n",
		    program, __LINE__, ps_device,
		    r == -1 ? strerror(errno) : "Short read");
		sleep(10);
	    }
	}

	if (buf == nil && myself->expire <= now) {
	    /* Time to broadcast a keepalive packet. */

	    if (ioctl(udp_fd[1], NWIOGUDPOPT, &udpopt) == -1) {
		fprintf(stderr, "%s(%d): %s: %s\n", program, __LINE__,
		    udp_device, strerror(errno));
		exit(1);
	    }
	    if (udpopt.nwuo_locaddr != myself->cip) {
		/* My address went and changed on me! */
		lastbcast= 0;
		if (debug >= 1) {
		    fprintf(stderr, "My current open address is %s:%u\n",
			inet_ntoa(udpopt.nwuo_locaddr),
			ntohs(udpopt.nwuo_locport));
		}
	    }
	    myself->cip= udpopt.nwuo_locaddr;
	    myself->port= udpopt.nwuo_locport;
	    myself->expire= now + KEEPALIVE;

	    if (lastbcast <= now - KEEPALIVE) {
		get_buf(&buf);
		buf->net= AIR;	/* (Pulled out of thin air) */

		/* Setting the IP header to all zeros invalidates it as a
		 * packet any TCP/IP stack could have produced.  We test for
		 * a zero first byte to recognize them as tunnel commands.
		 */
		memset(buf->ip, 0, sizeof(*buf->ip));
		buf->ip->ih_src= myself->tip;
		buf->ip->ih_dst= BROADCAST;
		buf->data[0]= TCMD_ALIVE;
		memcpy(buf->data+1, &myself->cip, 4);
		memcpy(buf->data+5, &myself->port, 2);
		buf->end= buf->data + 1 + 4 + 2;
	    }
	}

	if (buf != nil) {
	    /* A new packet has come in, where do we route it to? */
	    peer_t *pr;

	    pr= route(buf->ip);
	    if (debug >= 2) {
		switch (buf->net) {
		case UDP:
		    fprintf(stderr, "%s:%u: ",
			inet_ntoa(buf->udp->uih_src_addr),
			ntohs(buf->udp->uih_src_port));
		    break;
		case PSIP:
		    fprintf(stderr, "%s: ", inet_ntoa(myself->tip));
		    break;
		case AIR:
		    fprintf(stderr, "[tunnel]: ");
		    break;
		}
		fprintf(stderr, "%s -> ", inet_ntoa(buf->ip->ih_src));
		fprintf(stderr, "%s (%d), route to ",
		    inet_ntoa(buf->ip->ih_dst), (int) (buf->end - B(buf->ip)));
		fprintf(stderr, "%s\n",
		    pr == nil ? "bit bucket" : inet_ntoa(pr->tip));
	    }

	    /* A packet from a tunnel member that is addressed to me, or that
	     * is broadcast to all tunnel members must be delivered here.
	     */
	    if (pr != nil && buf->net == UDP
		&& (pr == myself || isbroadcast(buf->ip->ih_dst))
	    ) {
		if (buf->ip->ih_vers_ihl == 0) {
		    /* First byte is zero: A tunnel command. */
		    peer_t *bpr;

		    if (debug >= 2) {
			fprintf(stderr, "\tIn-tunnel command %02X\n",
			    buf->data[0]);
		    }

		    /* An in-tunnel command. */
		    switch (buf->data[0]) {
		    case TCMD_ALIVE:
			/* We got the sender's current open address. */
			if ((bpr= find_peer(buf->ip->ih_src, 0)) != nil) {
			    memcpy(&bpr->cip, buf->data+1, 4);
			    memcpy(&bpr->port, buf->data+5, 2);
			    bpr->expire= now + EXPIRE;
			    if (debug >= 1) {
				fprintf(stderr, "%s is alive at ",
				    inet_ntoa(buf->ip->ih_src));
				fprintf(stderr, "%s:%u\n",
				    inet_ntoa(bpr->cip), ntohs(bpr->port));
			    }
			}
			break;
		    default:
			fprintf(stderr, "Unknown tunnel command %02X from %s\n",
			    buf->data[0], inet_ntoa(buf->ip->ih_src));
		    }
		} else {
		    /* Deliver to the networks behind me. */
		    r= write(ps_fd[1], buf->ip, buf->end - B(buf->ip));
		    if (r < 0) {
			fprintf(stderr, "%s(%d): %s: %s\n",
			    program, __LINE__, ps_device, strerror(errno));
			sleep(10);
		    } else
		    if (debug >= 2) {
			fprintf(stderr, "\tDelivered at %s\n",
			    inet_ntoa(myself->tip));
		    }
		}
	    }

	    /* If a broadcast packet is routed to me then I'm apparently the
	     * one who knows everything.  Duplicate for all peers.
	     */
	    if (pr == myself && isbroadcast(buf->ip->ih_dst)) {
		/* I'm the one that does broadcasts. */
		buf_t *tmp_buf= nil;

		get_buf(&tmp_buf);
		for (pr= peer_table; pr != nil; pr= pr->next) {
		    if (pr == myself
			|| pr->expire <= now
			|| (buf->net==UDP && pr->cip == buf->udp->uih_src_addr
				&& pr->port == buf->udp->uih_src_port)
		    ) {
			/* Not back in my face, and not back to the sender. */
			continue;
		    }

		    r= buf->end - B(buf->ip);
		    memcpy(tmp_buf->ip, buf->ip, r);
		    r= encode(B(tmp_buf->ip), r, pr);
		    if (r < 0) continue;

		    tmp_buf->end= B(tmp_buf->ip) + r;
		    tmp_buf->udp->uih_src_addr= myself->cip;
		    tmp_buf->udp->uih_src_port= myself->port;
		    tmp_buf->udp->uih_dst_addr= pr->cip;
		    tmp_buf->udp->uih_dst_port= pr->port;
		    tmp_buf->udp->uih_ip_opt_len= 0;
		    tmp_buf->udp->uih_data_len= r;
		    r= write(udp_fd[1], tmp_buf->buf,
					tmp_buf->end - B(tmp_buf->buf));
		    if (r < 0) {
			fprintf(stderr, "%s(%d): %s: %s\n",
			    program, __LINE__, udp_device, strerror(errno));
			sleep(10);
		    } else
		    if (debug >= 2) {
			fprintf(stderr, "\tBroadcast to %s:%u\n",
			    inet_ntoa(pr->cip), ntohs(pr->port));
		    }
		}
		put_buf(&tmp_buf);
		/* pr == nil */
	    }

	    /* The packet is for some other peer, and it didn't by chance
	     * originate there.  Send it yonder.
	     */
	    if (pr != nil && pr != myself && pr->expire > now
		&& !(buf->net == UDP && pr->cip == buf->udp->uih_src_addr
			&& pr->port == buf->udp->uih_src_port)
	    ) {
		/* Forward to the proper tunnel endpoint. */

		if (isbroadcast(buf->ip->ih_dst)) lastbcast= now;

		r= buf->end - B(buf->ip);
		r= encode(B(buf->ip), r, pr);
		if (r >= 0) {
		    buf->end= B(buf->ip) + r;
		    buf->udp->uih_src_addr= myself->cip;
		    buf->udp->uih_src_port= myself->port;
		    buf->udp->uih_dst_addr= pr->cip;
		    buf->udp->uih_dst_port= pr->port;
		    buf->udp->uih_ip_opt_len= 0;
		    buf->udp->uih_data_len= r;
		    r= write(udp_fd[1], buf->buf, buf->end - B(buf->buf));
		    if (r < 0) {
			fprintf(stderr, "%s(%d): %s: %s\n",
			    program, __LINE__, udp_device, strerror(errno));
			sleep(10);
		    } else {
			if (debug >= 2) {
			    fprintf(stderr, "\tForwarded to %s:%u\n",
				inet_ntoa(pr->cip), ntohs(pr->port));
			}
		    }
		}
	    }

	    put_buf(&buf);
	}

	/* Can my open network address expire? */
	if (myself->expire == NEVER) {
	    tvp= nil;
	} else {
	    tv.tv_sec= myself->expire;
	    tv.tv_usec= 0;
	    tvp= &tv;
	}

	/* Wait for I/O. */
	if (asyn_wait(&asyn, 0, tvp) < 0) {
	    if (errno != EINTR) {
		fprintf(stderr, "%s: fwait(): %s\n", program, strerror(errno));
		exit(1);
	    }
	}

	if (debug >= 1) {
	    static size_t lastbrk;
	    extern int _end;

	    if ((size_t) sbrk(0) != lastbrk) {
		lastbrk= (size_t) sbrk(0);
		fprintf(stderr, "Memory use = %lu\n",
		    (unsigned long) (lastbrk - (size_t)&_end));
	    }
	}
    }
    return 0;
}

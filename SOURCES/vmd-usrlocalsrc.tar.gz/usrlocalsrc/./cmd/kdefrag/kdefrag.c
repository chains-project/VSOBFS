/*	kdefrag 1.2 - Copy a filesystem raw.		Author: Kees J. Bot
 *								3 May 2003
 *
 * Random notes:
 *	Use -I/usr/src or -I/usr/src/sys to get to the 'fs' include files.
 *
 *	Should not use _t on type names, C standard reserved...
 *
 *	Directory support not needed so not present in generic FS part.
 *
 *	Inodes are copied one-to-one by number.  Compacting the inode blocks
 *	would require remapping the inode numbers in the directory blocks.
 *
 *	Empty directory entries are also not removed.
 */
#define nil ((void*)0)
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>
#include <limits.h>
#include <fcntl.h>
#include <minix/config.h>
#include <minix/const.h>
#include <minix/type.h>
#include <fs/const.h>
#include <fs/type.h>
#include <fs/buf.h>
#include <fs/super.h>
#include <fs/inode.h>

#define CACHE_SIZE	16	/* Number of disk blocks in my cache. */

/* Minix and Minix-vmd differences swept under the rug. */
#if __minix_vmd
typedef struct v12_super_block super_block_t;	/* Superblock of file system */
#define s_log_zone_size s_dummy			/* Zones are obsolete. */
#define IMAP	0				/* Inode bitmap index. */
#define ZMAP	1				/* Zone bitmap index. */
#else
typedef struct super_block super_block_t;	/* Superblock of file system */
#define SUPER_V1 SUPER_MAGIC			/* V1 magic has a weird name. */
#endif

/* Even if Minix doesn't know symlinks, this program can still copy them. */
#ifndef S_IFLNK
#define S_IFLNK	((mode_t) 0120000)
#endif

static char *prog;		/* This program's name. */

struct filesystem;		/* (forward decl) */

/* Data connected to a disk buffer. */
typedef struct cache {
    struct filesystem *fs;	/* Filesystem it lives on. */
    block_t	nr;		/* Block number. */
    int		dirty;		/* Dirty if modified. */
    unsigned	usage;		/* Second chance usage counter. */
    unsigned	count;		/* In-use reference counter. */
    struct buf	buf;		/* Payload. */
} cache_t;

/* Data connected to a set of bitmap blocks. */
typedef struct bitmap {
    bit_t	nr_bits;	/* How many bits. */
    unsigned	nr_blocks;	/* How many bitmap blocks. */
    bit_t	first_free;	/* Search from here for a free bit. */
    bitchunk_t	*bits;		/* Pointer to an array of bitmap words. */
} bitmap_t;

#define BITCHUNK_BITS	(sizeof(bitchunk_t) * CHAR_BIT)
#define BITS_PER_BLOCK	(BITMAP_CHUNKS * BITCHUNK_BITS)

static void init_bitmap(bitmap_t *map)
{
    map->nr_blocks= 0;
    map->first_free= 0;
    map->bits= nil;
}

/* Data connected to a file system. */
typedef struct filesystem {
    int		fd;		/* Open device. */
    char	*devname;	/* Name of open device. */
    int		dirty;		/* Superblock or bitmaps have changed? */
    super_block_t super;	/* Superblock contents. */
    unsigned	nr_dzones;	/* Number of direct zone numbers. */
    unsigned	nr_tzones;	/* Total zone numbers in inode. */
    unsigned	nr_indirects;	/* Number of zone numbers per indirect block. */
    unsigned	inodes_per_block;/* Number of inodes in an inode block. */
    bitmap_t	bitmap[2];	/* Inode and zone bitmaps. */
} filesystem_t;

static void init_filesystem(filesystem_t *fs, int fd, char *devname)
/* Inititialize a new filesystem_t. */
{
    fs->fd= fd;
    fs->devname= devname;
    fs->dirty= 0;
    fs->super.s_magic= 0;
    init_bitmap(&fs->bitmap[IMAP]);
    init_bitmap(&fs->bitmap[ZMAP]);
}

/* Data connected to a file. */
typedef struct file {
    filesystem_t *fs;		/* File system that the file lives on. */
    int 	dirty;		/* True if modified. */
    ino_t	ino;		/* Inode number. */
    struct inode inode;		/* Inode entry. */
} file_t;

static void init_file(file_t *f, filesystem_t *fs)
{
    f->fs= fs;
    f->dirty= 0;
}

/* To translate a zone number to a zone bitmap bit number and vv. */
#define zone2bit(fs, z)	((bit_t) ((z) - (fs)->super.s_firstdatazone) + 1)
#define bit2zone(fs, b)	((zone_t) ((b) - 1) + (fs)->super.s_firstdatazone)

/* To translate an inode number to an inode bitmap bit number and vv. */
#define ino2bit(fs, i)	((void) &(fs)->super, (bit_t) (i))
#define bit2ino(fs, b)	((void) &(fs)->super, (ino_t) (b))
/* (Disappointing, eh?  Didn't even need <fs>, but let the compiler check.) */

/* My block cache.  Doesn't have to be big, just two inode blocks and a few
 * indirect blocks are enough to keep things going smoothly.
 */
static cache_t cache[CACHE_SIZE];
static size_t cache_sc;			/* Second chance search index. */
static unsigned cache_live;		/* Total in-use cache blocks. */

static void clean_block(cache_t *cp)
/* Write a cache block back to the disk if necessary. */
{
    if (cp->dirty) {
	filesystem_t *fs= cp->fs;
	int n;

	if (lseek(fs->fd, cp->nr * BLOCK_SIZE, SEEK_SET) == -1
	    || (n= write(fs->fd, &cp->buf, BLOCK_SIZE)) == -1
	) {
	    fprintf(stderr, "%s: %s: Can't read block %lu: %s\n",
		prog, fs->devname, (unsigned long) cp->nr, strerror(errno));
	    exit(7);
	}

	if (n < BLOCK_SIZE) {
	    fprintf(stderr, "%s: %s: Unexpected EOF writing block %lu\n",
		prog, fs->devname, (unsigned long) cp->nr);
	    exit(7);
	}
	cp->dirty= 0;
    }
}

typedef enum { FETCH, WIPE } gb_action_t;

static cache_t *get_block(filesystem_t *fs, block_t bnr, gb_action_t action)
/* Fetch block <bnr> from file system <fs> and return a pointer to it. */
{
    int i, n;
    cache_t *cp;

    /* Present in the cache? */
    for (i= 0; i < CACHE_SIZE; i++) {
	cp= &cache[i];
	if (cp->fs == fs && cp->nr == bnr) {
	    /* Increase the reference counter to keep it in the cache. */
	    if (cp->count++ == 0) cache_live++;
	    return cp;
	}
    }

    /* Choose the least used block. */
    assert(cache_live < CACHE_SIZE);
    do {
	if (cache_sc == CACHE_SIZE) cache_sc= 0;
	cp= &cache[cache_sc++];
    } while ((cp->usage >>= 1) != 0 || cp->count > 0);

    clean_block(cp);

    if (action == FETCH) {
	/* The data in the block is needed. */
	if (lseek(fs->fd, bnr * BLOCK_SIZE, SEEK_SET) == -1
	    || (n= read(fs->fd, &cp->buf, BLOCK_SIZE)) == -1
	) {
	    fprintf(stderr, "%s: %s: Can't read block %lu: %s\n",
		prog, fs->devname, (unsigned long) bnr, strerror(errno));
	    exit(7);
	}

	if (n < BLOCK_SIZE) {
	    fprintf(stderr, "%s: %s: Unexpected EOF reading block %lu\n",
		prog, fs->devname, (unsigned long) bnr);
	    exit(7);
	}
    } else {
	/* The block will be (partially) overwritten, so wipe it. */
	assert(action == WIPE);
	memset(&cp->buf, 0, BLOCK_SIZE);
	cp->dirty= 1;
    }

    cp->fs= fs;
    cp->nr= bnr;
    cp->usage= 0;
    cp->count= 1;
    cache_live++;
    return cp;
}

static void put_block(cache_t *cp)
/* Release a cache block.  Decrease the number of references to this block,
 * and increase the second chance usage counter to show how popular it is.
 */
{
    assert(cp->count > 0);
    if (--cp->count == 0) cache_live--;
    cp->usage++;
}

static void cache_flush(void)
/* Flush and invalidate all cache blocks. */
{
    int i;
    cache_t *cp;

    for (i= 0; i < CACHE_SIZE; i++) {
	cp= &cache[i];
	assert(cp->count == 0);
	clean_block(cp);
    }
}

static int get_super(filesystem_t *fs)
/* Read the super block and bitmaps of a file system.  Return true iff Minix. */
{
    cache_t *cp;
    int i, n;
    struct buf *bitmaps;

    cp= get_block(fs, SUPER_BLOCK, FETCH);
    memcpy(&fs->super, &cp->buf, sizeof(fs->super));
    put_block(cp);

    /* Check magic number and get/compute per filesystem information. */
    switch (fs->super.s_magic) {
    case SUPER_V1:
	fs->super.s_zones= fs->super.s_nzones;
	fs->inodes_per_block= V1_INODES_PER_BLOCK;
	fs->nr_dzones= V1_NR_DZONES;
	fs->nr_tzones= V1_NR_TZONES;
	fs->nr_indirects= V1_INDIRECTS;
	break;
    case SUPER_V2:
	fs->inodes_per_block= V2_INODES_PER_BLOCK;
	fs->nr_dzones= V2_NR_DZONES;
	fs->nr_tzones= V2_NR_TZONES;
	fs->nr_indirects= V2_INDIRECTS;
	break;
    default:
	return 0;	/* Not a Minix filesystem. */
    }

    /* Allocate memory for the inode and zone bitmap blocks. */
    n= fs->super.s_imap_blocks + fs->super.s_zmap_blocks;
    bitmaps= malloc(n * BLOCK_SIZE);
    if (bitmaps == nil) {
	fprintf(stderr, "%s: %s: Can't allocate memory for %d bitmap blocks\n",
	    prog, fs->devname, n);
    }

    /* Read all the bitmap blocks into memory.  (They're adjacent, yay.) */
    for (i= 0; i < n; i++) {
	cp= get_block(fs, SUPER_BLOCK + 1 + i, FETCH);
	memcpy(&bitmaps[i], &cp->buf, sizeof(cp->buf));
	put_block(cp);
    }

    fs->bitmap[IMAP].nr_bits= ino2bit(fs, fs->super.s_ninodes) + 1;
    fs->bitmap[IMAP].nr_blocks= fs->super.s_imap_blocks;
    fs->bitmap[IMAP].bits= bitmaps[0].b_bitmap;
    fs->bitmap[ZMAP].nr_bits= zone2bit(fs, fs->super.s_zones);
    fs->bitmap[ZMAP].nr_blocks= fs->super.s_zmap_blocks;
    fs->bitmap[ZMAP].bits= bitmaps[fs->super.s_imap_blocks].b_bitmap;
    return 1;
}

static void put_super(filesystem_t *fs)
/* Return the superblock and bitmaps to disk, if changed. */
{
    cache_t *cp;
    int i, n;
    struct buf *bitmaps;

    if (fs->dirty) {
	/* Write superblock and bitmaps back to disk. */
	if (fs->super.s_magic == SUPER_V1) {
	    fs->super.s_nzones= fs->super.s_zones;
	}
	cp= get_block(fs, SUPER_BLOCK, FETCH);
	memcpy(&cp->buf, &fs->super, sizeof(fs->super));
	cp->dirty= 1;
	put_block(cp);

	n= fs->super.s_imap_blocks + fs->super.s_zmap_blocks;
	bitmaps= (struct buf *) fs->bitmap[IMAP].bits;
	for (i= 0; i < n; i++) {
	    cp= get_block(fs, SUPER_BLOCK + 1 + i, WIPE);
	    memcpy(&cp->buf, &bitmaps[i], sizeof(cp->buf));
	    cp->dirty= 1;
	    put_block(cp);
	}
    }
    free(fs->bitmap[IMAP].bits);
    fs->bitmap[IMAP].bits= nil;
}

static void set_bit(filesystem_t *fs, int maptype, bit_t bnr, int b)
/* Set a bitmap bit at position <bnr> to <b>.  Unhappy unless it changes.
 * May be used to set NO_BIT, but shouldn't clear it.
 */
{
    bitmap_t *map= &fs->bitmap[maptype];
    bitchunk_t *pword;
    int pos;

    assert(!(bnr == NO_BIT && b == 0));
    assert(bnr < map->nr_bits);
    assert((unsigned) b <= 1);

    pword= &map->bits[bnr / BITCHUNK_BITS];
    pos= bnr % BITCHUNK_BITS;
    if (((*pword >> pos) & 1) == b) {
	fprintf(stderr, "%s: %s: %s %lu is already %s\n",
	    prog, fs->devname,
	    maptype == IMAP ? "Inode" : "Zone",
	    (unsigned long) (maptype == IMAP ? bit2ino(fs, bnr)
						: bit2zone(fs, bnr)),
	    b ? "allocated" : "free");
	exit(6);
    }
    *pword ^= 1 << pos;
    if (b == 0 && map->first_free > bnr) map->first_free= bnr;
    fs->dirty= 1;
}

static int get_bit(filesystem_t *fs, int maptype, bit_t bnr)
/* Return the bitmap bit at position <bnr>.  Allow NO_BIT to be queried. */
{
    bitmap_t *map= &fs->bitmap[maptype];

    assert(bnr < map->nr_bits);

    return (map->bits[bnr / BITCHUNK_BITS] >> (bnr % BITCHUNK_BITS)) & 1;
}

static bit_t alloc_bit(filesystem_t *fs, int maptype)
/* Find a free bit in a bitmap.  Return that bit or NO_BIT if none found. */
{
    bitmap_t *map= &fs->bitmap[maptype];
    bitchunk_t word;
    bit_t i;

    assert((map->bits[0] & 1) != 0);	/* Bit 0 (NO_BIT) must be in-use! */

    /* Look for a free bit from the word containing first_free up. */
    for (i= map->first_free & ~(BITCHUNK_BITS-1);
				i < map->nr_bits; i += BITCHUNK_BITS) {
	word= map->bits[i / BITCHUNK_BITS];
	if (word != (bitchunk_t) -1) {
	    /* A bitmap word with at least one free bit! */
	    while (word & 1) {
		i++;
		word >>= 1;
	    }
	    break;
	}
    }
    if (i >= map->nr_bits) return NO_BIT;	/* Oops, full. */
    set_bit(fs, maptype, i, 1);
    map->first_free= i+1;
    return i;
}

static void get_inode(file_t *f, ino_t ino)
/* Read inode <ino> into file structure <f>. */
{
    block_t i_block;
    unsigned i_offset;
    filesystem_t *fs= f->fs;
    cache_t *cp;

    assert(!f->dirty);

    if (!(0 < ino && ino <= fs->super.s_ninodes)) {
	fprintf(stderr,
	    "%s: %s: Inode number %lu is out of range, please run fsck\n",
	    prog, fs->devname, (unsigned long) ino);
	exit(6);
    }
    f->ino= ino;

    /* Compute the block the inode lives in.  Inode 1 is first in block 0. */
    i_block= (ino - 1) / fs->inodes_per_block;
    i_offset= (ino - 1) % fs->inodes_per_block;

    /* First inode block follows the bitmaps. */
    i_block += SUPER_BLOCK + 1
	+ fs->super.s_imap_blocks + fs->super.s_zmap_blocks;

    /* Fetch the inode block. */
    cp= get_block(fs, i_block, FETCH);

    /* Read the inode into an in-core structure. */
    if (fs->super.s_magic == SUPER_V1) {
	d1_inode *dip;
	int i;

	dip= &cp->buf.b_v1_ino[i_offset];

	f->inode.i_mode= dip->d1_mode;
	f->inode.i_nlinks= dip->d1_nlinks;
	f->inode.i_uid= dip->d1_uid;
	f->inode.i_gid= dip->d1_gid;
	f->inode.i_size= dip->d1_size;
	f->inode.i_atime= dip->d1_mtime;
	f->inode.i_mtime= dip->d1_mtime;
	f->inode.i_ctime= dip->d1_mtime;
	for (i= 0; i < V1_NR_TZONES; i++) f->inode.i_zone[i]= dip->d1_zone[i];
    } else {
	d2_inode *dip;
	int i;

	dip= &cp->buf.b_v2_ino[i_offset];

	f->inode.i_mode= dip->d2_mode;
	f->inode.i_nlinks= dip->d2_nlinks;
	f->inode.i_uid= dip->d2_uid;
	f->inode.i_gid= dip->d2_gid;
	f->inode.i_size= dip->d2_size;
	f->inode.i_atime= dip->d2_atime;
	f->inode.i_mtime= dip->d2_mtime;
	f->inode.i_ctime= dip->d2_ctime;
	for (i= 0; i < V2_NR_TZONES; i++) f->inode.i_zone[i]= dip->d2_zone[i];
    }
    put_block(cp);
}

static void put_inode(file_t *f)
/* Write inode back if modified. */
{
    filesystem_t *fs= f->fs;
    block_t i_block;
    unsigned i_offset;
    cache_t *cp;

    if (f->dirty) {
	/* Write the inode back. */
	i_block= (f->ino - 1) / fs->inodes_per_block;
	i_offset= (f->ino - 1) % fs->inodes_per_block;

	i_block += SUPER_BLOCK + 1
	    + fs->super.s_imap_blocks + fs->super.s_zmap_blocks;

	cp= get_block(fs, i_block, FETCH);

	if (fs->super.s_magic == SUPER_V1) {
	    d1_inode *dip;
	    int i;

	    dip= &cp->buf.b_v1_ino[i_offset];

	    dip->d1_mode= f->inode.i_mode;
	    dip->d1_nlinks= f->inode.i_nlinks;
	    dip->d1_uid= f->inode.i_uid;
	    dip->d1_gid= f->inode.i_gid;
	    dip->d1_size= f->inode.i_size;
	    dip->d1_mtime= f->inode.i_mtime;
	    for (i= 0; i<V1_NR_TZONES; i++) dip->d1_zone[i]= f->inode.i_zone[i];
	} else {
	    d2_inode *dip;
	    int i;

	    dip= &cp->buf.b_v2_ino[i_offset];

	    dip->d2_mode= f->inode.i_mode;
	    dip->d2_nlinks= f->inode.i_nlinks;
	    dip->d2_uid= f->inode.i_uid;
	    dip->d2_gid= f->inode.i_gid;
	    dip->d2_size= f->inode.i_size;
	    dip->d2_atime= f->inode.i_atime;
	    dip->d2_mtime= f->inode.i_mtime;
	    dip->d2_ctime= f->inode.i_ctime;
	    for (i= 0; i<V2_NR_TZONES; i++) dip->d2_zone[i]= f->inode.i_zone[i];
	}
	cp->dirty= 1;
	put_block(cp);
    }
    f->dirty= 0;
}

static zone_t new_zone(filesystem_t *fs)
/* Allocate a new zone in filesystem <fs>. */
{
    bit_t bit;
    zone_t z;
    block_t b;
    int i;

    if ((bit= alloc_bit(fs, ZMAP)) == NO_BIT) {
	fprintf(stderr, "%s: %s: Out of zones\n", prog, fs->devname);
	exit(5);
    }
    z= bit2zone(fs, bit);

    /* Clear all blocks in the new zone. */
    b= (block_t) z << fs->super.s_log_zone_size;
    for (i= 0; i < (1 << fs->super.s_log_zone_size); i++) {
	put_block(get_block(fs, b + i, WIPE));
    }
    return z;
}

static block_t file_map(file_t *f, block_t fb, int extend)
/* Map file block <fb> to a disk block.  Return NO_BLOCK if the file has a hole
 * at that position.  If <extend> is set then replace a hole by a new block.
 */
{
    filesystem_t *fs= f->fs;
    zone_t fzone, dzone, ind_size;
    unsigned zone_index;
    int i;
    cache_t *cp;

    /* Calculate zone in which the datablock number is contained. */
    fzone= (zone_t) (fb >> fs->super.s_log_zone_size);

    /* Calculate index of the block within the zone. */
    zone_index= fb - ((block_t) fzone << fs->super.s_log_zone_size);

    /* With what zone entry do we start and how many indirects to follow? */
    if (fzone < fs->nr_dzones) {
    	/* Directly referenced from the inode. */
	i= (int) fzone;
	ind_size= 1;
    } else {
	/* Single, double, triple indirect? */
	i= fs->nr_dzones;
	fzone -= fs->nr_dzones;
	ind_size= fs->nr_indirects;
	while (fzone >= ind_size) {
	    i++;
	    fzone -= ind_size;
	    ind_size *= fs->nr_indirects;
	}
	if (i >= fs->nr_tzones) {
	    /* Beyond maximum filesize? */
	    if (!extend) return NO_BLOCK;
	    fprintf(stderr,
		"%s: %s: Can't extend inode %lu past maximum filesize!\n",
		prog, fs->devname, (unsigned long) f->ino);
	    exit(5);
	}
    }

    /* Follow the inode zone entry. */
    dzone= f->inode.i_zone[i];
    if (dzone == NO_ZONE) {
	if (!extend) return NO_BLOCK;
	f->inode.i_zone[i]= dzone= new_zone(fs);
	f->dirty= 1;
    }

    /* Follow the indirect block chain. */
    while (ind_size > 1) {
	ind_size /= fs->nr_indirects;	/* Numer of zones at lower level. */
	i= fzone / ind_size;		/* Index in indirect block. */
	fzone %= ind_size;		/* Zone offset at lower level. */

	cp= get_block(fs, (block_t) dzone << fs->super.s_log_zone_size, FETCH);
	if (fs->super.s_magic == SUPER_V1) {
	    dzone= cp->buf.b_v1_ind[i];
	    if (dzone == NO_ZONE) {
		if (!extend) { put_block(cp); return NO_BLOCK; }
		cp->buf.b_v1_ind[i]= dzone= new_zone(fs);
		cp->dirty= 1;
	    }
	} else {
	    dzone= cp->buf.b_v2_ind[i];
	    if (dzone == NO_ZONE) {
		if (!extend) { put_block(cp); return NO_BLOCK; }
		cp->buf.b_v2_ind[i]= dzone= new_zone(fs);
		cp->dirty= 1;
	    }
	}
	put_block(cp);
    }

    /* Calculate absolute datablock number */
    return ((block_t) dzone << fs->super.s_log_zone_size) + zone_index;
}

/* Above this point is generic support stuff, below finally does something. */

static void copyfile(file_t *srcfile, file_t *dstfile)
/* Copy all the blocks from one file to another. */
{
    block_t nr_blocks, fb, sb, db;
    cache_t *scp, *dcp;

    nr_blocks= (srcfile->inode.i_size + BLOCK_SIZE-1) / BLOCK_SIZE;

    for (fb= 0; fb < nr_blocks; fb++) {
	if ((sb= file_map(srcfile, fb, 0)) != NO_BLOCK) {
	    if (get_bit(srcfile->fs, ZMAP, zone2bit(srcfile->fs, sb)) == 0) {
		fprintf(stderr,
		    "%s: %s: Zone %lu isn't marked in-use, please run fsck\n",
		    prog, srcfile->fs->devname,
		    (unsigned long) sb >> srcfile->fs->super.s_log_zone_size);
		exit(6);
	    }
	    db= file_map(dstfile, fb, 1);
	    scp= get_block(srcfile->fs, sb, FETCH);
	    dcp= get_block(dstfile->fs, db, WIPE);
	    memcpy(&dcp->buf, &scp->buf, sizeof(dcp->buf));
	    dcp->dirty= 1;
	    put_block(scp);
	    put_block(dcp);
	}
    }
}

static void basic_check(filesystem_t *fs, int empty)
/* Perform a few basic checks on a filesystem to make sure that we won't trip
 * over it.  Optionally check if it's empty as mkfs makes it.
 */
{
    bit_t b, blimit;

    if (!get_bit(fs, IMAP, 0) || !get_bit(fs, IMAP, 1)
	|| !get_bit(fs, ZMAP, 0) || !get_bit(fs, ZMAP, 1)
    ) {
	fprintf(stderr, "%s: %s fails a few basic checks, please run fsck\n",
	    prog, fs->devname);
	exit(6);
    }

    if (empty) {
	/* Check that the destination file system is empty as mkfs makes it. */
	blimit= ino2bit(fs, fs->super.s_ninodes) + 1;
	for (b= ino2bit(fs, 2); b != blimit; b++) {
	    if (get_bit(fs, IMAP, b)) {
		fprintf(stderr, "%s: %s is not empty, please run mkfs on it\n",
		    prog, fs->devname);
		exit(4);
	    }
	}
    }
}

static void usage(void)
{
    fprintf(stderr, "Usage: %s input-device output-device\n", prog);
    exit(1);
}

int main(int argc, char **argv)
{
    char *srcdev, *dstdev;
    int i;
    filesystem_t srcfs, dstfs;
    file_t srcfile, dstfile;
    int fd;
    ino_t inum;

    if ((prog= strrchr(argv[0], '/')) == nil) prog= argv[0]; else prog++;

    /* Option processing. */
    i= 1;
    while (i < argc && argv[i][0] == '-') {
	char *opt= argv[i++]+1;

	if (opt[0] == '-' && opt[1] == 0) break;

	while (*opt != 0) switch (*opt++) {
	default:
	    usage();
	}
    }

    /* Arguments. */
    if ((argc - i) != 2) usage();
    srcdev= argv[i++];
    dstdev= argv[i++];

    /* Open source and target file systems. */
    if ((fd= open(srcdev, O_RDONLY)) < 0) {
	fprintf(stderr, "%s: Can't open %s: %s\n",
	    prog, srcdev, strerror(errno));
	exit(2);
    }
    init_filesystem(&srcfs, fd, srcdev);
    if (!get_super(&srcfs)) {
	fprintf(stderr, "%s: %s: Not a Minix file system\n", prog, srcdev);
	exit(3);
    }

    if ((fd= open(dstdev, O_RDWR)) < 0) {
	fprintf(stderr, "%s: Can't open %s: %s\n",
	    prog, dstdev, strerror(errno));
	exit(2);
    }
    init_filesystem(&dstfs, fd, dstdev);
    if (!get_super(&dstfs)) {
	fprintf(stderr, "%s: %s: Not a Minix file system\n", prog, dstdev);
	exit(3);
    }

    /* Minimum checks to make sure that alloc_bit() and such don't choke. */
    basic_check(&srcfs, 0);
    basic_check(&dstfs, 1);	/* Dest must be empty. */

    /* Remove the root inode and the one directory block from the target to
     * make it completely empty.
     */
    set_bit(&dstfs, IMAP, 1, 0);
    set_bit(&dstfs, ZMAP, 1, 0);

    /* Look at all the inodes and copy stuff. */
    init_file(&srcfile, &srcfs);
    init_file(&dstfile, &dstfs);
    for (inum= 1; inum != (ino_t) (srcfs.super.s_ninodes + 1); inum++) {
	get_inode(&srcfile, inum);

	/* A file with a non-zero mode should be in-use and vv. */
	if (((srcfile.inode.i_mode & S_IFMT) != 0)
	    != get_bit(&srcfs, IMAP, ino2bit(&srcfs, inum))
	) {
	    fprintf(stderr,
    "%s: %s: Inode %lu %s, but inode bitmap says otherwise, please run fsck\n",
		prog, srcdev, (unsigned long) inum,
		(srcfile.inode.i_mode & S_IFMT) != 0 ? "in-use" : "unused");
	    exit(6);
	}

	/* Only do in-use inodes. */
	if ((srcfile.inode.i_mode & S_IFMT) != 0) {
	    if (inum >= dstfs.super.s_ninodes) {
		fprintf(stderr, "%s: %s: Inode %lu can't be put here\n",
		    prog, dstfs.devname, (unsigned long) inum);
		exit(5);
	    }
	    get_inode(&dstfile, inum);
	    dstfile.inode= srcfile.inode;	/* Copy attributes. */
	    dstfile.dirty= 1;

	    switch (srcfile.inode.i_mode & S_IFMT) {
	    case S_IFLNK:
	    case S_IFREG:
	    case S_IFDIR:
		/* Copy file-like objects block by block. */
		for (i= 0; i < V2_NR_TZONES; i++) dstfile.inode.i_zone[i]= 0;
		copyfile(&srcfile, &dstfile);
		break;

	    case S_IFBLK:
	    case S_IFCHR:
	    case S_IFIFO:
		/* All these don't have blocks. */
		break;

	    default:
	    	fprintf(stderr,
		    "%s: %s: Inode %lu has strange mode 0%06o, can't copy it\n",
		    prog, srcdev, (unsigned long) inum,
		    (unsigned) srcfile.inode.i_mode);
		exit(6);
	    }
	    put_inode(&dstfile);
	    set_bit(&dstfs, IMAP, ino2bit(&dstfs, inum), 1);
	}
	put_inode(&srcfile);
    }
    put_super(&srcfs);
    put_super(&dstfs);
    cache_flush();
    return 0;
}

/*	relay.c - relay message library			Author: Kees J. Bot
 *								20 Mar 1989
 */
#define nil 0
#include <sys/types.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#if __minix
#include <net/gen/in.h>
#include <net/gen/inet.h>
#include <net/gen/netdb.h>
#include <net/gen/socket.h>
#include <net/gen/tcp.h>
#include <net/gen/tcp_hdr.h>
#include <net/gen/tcp_io.h>
#include <net/hton.h>
#include <net/netlib.h>
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#endif
#include "relay.h"

typedef struct udp_channels {
	int		fd;		/* Open channel. */
	ipaddr_t	addr;		/* IP address. */
	ipaddr_t	mask;		/* And netmask. */
} udp_channels_t;

#define NR_NETS		4

static udp_channels_t channels[4];

static char udp_dev0[]= "/dev/udp0";

#define udp_dev(i)	(udp_dev[8]= '0'+i, udp_dev)

static void relay_init(void)
/* Open channels to all configured udp devices. */
{
	static int init_done;
	int i;
	udp_channels_t *udpcp;

	if (init_done) return;
	init_done= 1;

	for (i= 0; i < NR_NETS; i++) {
		udpcp= &channel[i];
		if ((udpcp->fd= open(udp_dev(i), O_RDWR|O_NONBLOCK)) < 0)
			continue;

		if (ioctl(

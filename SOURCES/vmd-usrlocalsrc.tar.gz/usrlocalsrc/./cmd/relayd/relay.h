/*	relay.h - message relaying definitions		Author: Kees J. Bot
 *								7 Oct 1995
 */

#define RELAY_PORT		4665	/* UDP port for relay messages. */

#define RELAY_TYPE_SERVER	   0	/* I'm a server for a port. */
#define RELAY_TYPE_CLIENT	   1	/* I'm a client for a port. */
#define RELAY_TYPE_SQUELCH	   2	/* Keep the noise down. */
#define RELAY_TYPE_DONE		   3	/* Forget me. */
#define RELAY_PORT_LEN		  32	/* Max relay port name length. */

typedef struct relay_header {
	u32_t	src;			/* Original sender's IP address. */
	u32_t	id;			/* Sender's ID on local machine. */
	u8_t	type;			/* Packet type. */
	u8_t	port[RELAY_PORT_LEN+1];	/* Null terminated port name. */
} relay_header_t;

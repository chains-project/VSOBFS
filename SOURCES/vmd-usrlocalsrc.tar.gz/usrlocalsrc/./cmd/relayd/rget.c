/*	rget/rput 2.2 - remote pipe			Author: Kees J. Bot
 *								20 Mar 1989
 *
 * here$ ... | rput keyword		there$ rget keyword | ...
 * here$ rput keyword command ...	there$ rget keyword command ...
 */
#define nil 0
#include <sys/types.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#if __minix
#include <net/gen/in.h>
#include <net/gen/inet.h>
#include <net/gen/netdb.h>
#include <net/gen/socket.h>
#include <net/gen/tcp.h>
#include <net/gen/tcp_hdr.h>
#include <net/gen/tcp_io.h>
#include <net/hton.h>
#include <net/netlib.h>
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#endif

#define RELAY_PORT		4665	/* UDP port for relay messages. */

#define RELAY_TYPE_SERVER	   0	/* I'm a server for a port. */
#define RELAY_TYPE_CLIENT	   1	/* I'm a client for a port. */
#define RELAY_TYPE_SQUELCH	   2	/* Keep the noise down. */
#define RELAY_TYPE_DONE		   3	/* Forget me. */

typedef struct relay_header {
	ipaddr_t	src;		/* Original sender. */
	u32_t		id;		/* Sender's ID on local machine. */
	unsigned char	type;		/* Packet type. */
	unsigned char	port[33];	/* Null terminated port name. */
} relay_header_t;

static char *name;

static void fatal(const char *label)
{
	int err= errno;

	fprintf(stderr, "%s: %s: %s\n", name, label, strerror(err));
	exit(1);
}

static int name2port(char *n)
{
	int port= 1;

	while (*n != 0) port *= (*n++ & 0xFF);

	return port | 0x8000;
}

void execute(int infd, int outfd, char **argv)
/* Run a command with I/O redirection to the TCP channel. */
{
	if (infd != 0) {
		dup2(infd, 0);
		close(infd);
	}
	if (outfd != 1) {
		dup2(outfd, 1);
		close(outfd);
	}
	execvp(argv[0], argv);
	fatal(argv[0]);
}

void copy(char *infile, int infd, char *outfile, int outfd)
/* Copy to or from a TCP channel into or out of a command. */
{
	static char buf[1024 << sizeof(char *)];
	ssize_t n;

	while ((n= read(infd, buf, sizeof(buf))) > 0) {
		if (write(outfd, buf, n) != n) fatal(outfile);
	}
	if (n < 0) fatal(infile);
}

void rget(int argc, char **argv)
{
	int s, n;
	struct hostent *h;
	char buf[8192];
#if __minix
	char *tcp_device;
	nwio_tcpconf_t tcpconf;
	nwio_tcpcl_t tcpconnopt;
#else
	static struct sockaddr_in channel;
#endif

	if (argc > 1) {
		if (strcmp(argv[1], "-h") == 0) {
			argv++;
			argc--;
		} else {
			fprintf(stderr,
"[The 'rget host key' form will soon be obsolete, use 'rget -h host key']\n");
		}
	}
	if (argc < 3) {
		fprintf(stderr,
		"Usage: %s -h remote-host keyword [command [arg ...]]\n",
			name);
		exit(1);
	}
	if ((h= gethostbyname(argv[1])) == nil) {
		fprintf(stderr, "%s: %s: Name lookup failed\n", name, argv[1]);
		exit(1);
	}

#if __minix
	if ((tcp_device= getenv("TCP_DEVICE")) == nil) tcp_device= "/dev/tcp";

	n=60;
	for (;;) {
		if ((s= open(tcp_device, O_RDWR)) < 0) fatal(tcp_device);

		tcpconf.nwtc_flags= NWTC_LP_SEL | NWTC_SET_RA | NWTC_SET_RP;
		tcpconf.nwtc_remaddr= * (ipaddr_t *) h->h_addr;
		tcpconf.nwtc_remport= htons(name2port(argv[2]));
		if (ioctl(s, NWIOSTCPCONF, &tcpconf) < 0) fatal("NWIOSTCPCONF");

		tcpconnopt.nwtcl_flags= 0;
		if (ioctl(s, NWIOTCPCONN, &tcpconnopt) == 0) break;

		if (--n>0) sleep(2); else fatal("NWIOTCPCONN");
		close(s);
	}
#else
	n=60;
	for (;;) {
		if ((s= socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
			fatal("socket()");

		channel.sin_family= AF_INET;
		channel.sin_addr.s_addr= * (u_long *) h->h_addr;
		channel.sin_port= htons(name2port(argv[2]));
		if (connect(s, (struct sockaddr *) &channel,
						sizeof(channel)) >= 0) break;

		if (--n > 0) sleep(2); else fatal("connect()");
		close(s);
	}
#endif

	if (argc > 3) execute(s, 1, argv + 3);

	copy("read from network", s, "write to command", 1);

	exit(0);
}

void rput(int argc, char **argv)
{
	int s, get, n;
	char buf[8192];
#if __minix
	char *tcp_device;
	struct nwio_tcpconf tcpconf;
	struct nwio_tcpcl tcplistenopt;
#else
	static struct sockaddr_in channel, get_chan;
	static int on= 1;
#endif

	if (argc < 2) {
		fprintf(stderr,
			"Usage: %s keyword [command [arg ...]]\n", name);
		exit(1);
	}

#if __minix
	if ((tcp_device= getenv("TCP_DEVICE")) == nil) tcp_device= "/dev/tcp";
	if ((s= open(tcp_device, O_RDWR)) < 0) fatal(tcp_device);

	tcpconf.nwtc_flags= NWTC_EXCL | NWTC_LP_SET | NWTC_UNSET_RA |
							NWTC_UNSET_RP;
	tcpconf.nwtc_locport= htons(name2port(argv[1]));
	if (ioctl(s, NWIOSTCPCONF, &tcpconf) < 0) fatal("NWIOSTCPCONF");

	tcplistenopt.nwtcl_flags= 0;
	if (ioctl(s, NWIOTCPLISTEN, &tcplistenopt) < 0) fatal("NWIOTCPLISTEN");
	get= s;
#else
	if ((s= socket(AF_INET, SOCK_STREAM, IPPROTO_TCP))<0) fatal("socket()");

	(void) setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *) &on,
								sizeof(on));
	channel.sin_family= AF_INET;
	channel.sin_addr.s_addr= htonl(INADDR_ANY);
	channel.sin_port= htons(name2port(argv[1]));
	if (bind(s, (struct sockaddr *) &channel, sizeof(channel)) < 0)
		fatal("bind()");

	if (listen(s, 1) < 0) fatal("listen()");

	n= sizeof(get_chan);

	if ((get= accept(s, (struct sockaddr *) &get_chan, &n)) < 0)
		fatal("accept()");
#endif

	if (argc > 2) execute(0, get, argv + 2);

	copy("read from command", 0, "write to network", get);

	exit(0);
}

int main(int argc, char **argv)
{
	char *p;

	if ((name= strrchr(argv[0], '/')) == nil) name= argv[0]; else name++;

	p = name + strlen(name);
	if (p >= name + 3) p-= 3;

	if (strcmp(p, "get") == 0) rget(argc, argv);
	if (strcmp(p, "put") == 0) rput(argc, argv);
	fprintf(stderr, "Don't know what to do if you call me '%s'\n", name);
	exit(1);
}

/*	km 1.0 - KM system interpreter.			Author: Kees J. Bot
 *								29 Sep 2001
 */

#include "types.h"

#define nil ((void*)0)
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <math.h>
#include <sys/utsname.h>

#if has_int(W) && has_flt(4) && has_flt(8)

#define VERSION	    01000	/* Machine version. */

#define MEGS_DEF	8	/* Default memory size in megabytes. */

#define PC_CACHE	1	/* XXX - Is a 10% speedup worth the bother? */
#define PC_CACHE_SIMPLE	1	/* XXX - Caching one page add 7% more? */

#if __minix_vmd
#define FWAIT		1	/* Use fwait() for async I/O. */
#else
#define SELECT		1	/* Use select() for async I/O. */
#endif

/* Don't want GNU C in ANSI mode to complain about long long constants. */
#if __GNUC__
#define LL(n)		__extension__(n##LL)
#define ULL(n)		__extension__(n##ULL)
#else
#define LL(n)		n##LL
#define ULL(n)		n##ULL
#endif

static char *program;		/* Name of this program. */
static unsigned version= VERSION;/* Requested emulator version. */
static int tlevel;		/* Tracing level. */

static char *disk;		/* Disk file name. */
static int dfd;			/* Disk file descriptor. */
static char *log_file;		/* Log file name and open file pointer. */
static FILE *logfp;

#define DISK_MAGIC	0x480018CD	/* Boot disk magic number. */
#define DUMP_MAGIC	0x480418CD	/* Memory dump magic number. */

/* Virtual memory uses pages of the size shown below.  It is up to the page
 * fault trap handler to fill our virtual memory mapping table.  This TLB is
 * indexed by a code/data address space identifier (ASID) and the low N bits
 * of the page number.  The c/d asids for the trap handler (the kernel?)
 * should be kept reserved.  Note that a TLB implemented in hardware would
 * use associative memory indexed by (page, asid) tuples.  In software we
 * must do it as done below, by using big arrays and simple indexing.  KM
 * code shouldn't know the difference.  KM code is only aware of the page
 * size and the existence of address spaces.  It must query the number of
 * address spaces supported.
 */
#define PAGE_BITS	12		/* 4K */
#define PAGE_SIZE	((memory) 1 << PAGE_BITS)
#define PAGE_MASK	(PAGE_SIZE - 1)

/* Min, max, default and current number of code/data address spaces. */
#define ASID_MIN	4
#define ASID_MAX	(1<<(PAGE_BITS-pBITS))
#define ASID_DEF	8
unsigned asid_size;

/* TLB page number bits (4M / 16M per task without chance of trashing). */
#define TPAGE_BITS	10
#define TPAGE_SIZE	(1 << TPAGE_BITS)
#define TPAGE_MASK	(TPAGE_SIZE - 1)

/* The stale TLB is a cache of old TLB entries.  It is larger than the ordinary
 * TLB, but is used for all address spaces.  It is also rougher, i.e. several
 * adjacent TLB entries share a cache slot, but it is also indexed by more page
 * bits to allow larger ranges.  So 9 random memory accesses may clash at one
 * TLB entry, or three very large memory ranges may compete.  (Ranges cut into
 * random accesses and vice-versa.)  The cache is maintained as LRU lists.
 * XXX - Best size should be measured by fault hit/miss counting.
 */
#define STALE_SKEW	2	/* Bits put in the same cache bucket. */
#define STALE_BITS	(TPAGE_BITS - STALE_SKEW + 2)
#define STALE_SIZE	(1 << STALE_BITS)
#define STALE_MASK	(STALE_SIZE - 1)
#define STALE_DEPTH	(1 << (STALE_SKEW + 1))

typedef struct tlb {
	unsw	vir;		/* Virtual address, asid and protection bits. */
	memory	v2m;		/* Add to Virtual to get Memory address. */
} tlb_t;

/* Protection bits.  A type of access is granted if the protection bit is
 * *not* set in the 'vir' field.
 */
#define pBITS		  4	/* Four protection bits. */
#define pMASK		0xF	/* Mask to select protection bits. */
#define pP		0x8	/* Present. */
#define pR		0x4	/* Read. */
#define pW		0x2	/* Write. */
#define pX		0x1	/* Execute. */

/* Part of virtual memory may be linearly mapped, i.e. a fixed offset between
 * virtual and physical.  Within the linear area TLB misses never lead to
 * faults, which is nice for an O.S. that doesn't do paging, or to map the
 * kernel.  It is a requirement for trap handlers.  Memory outside the
 * linear area is paged and causes faults that must be fixed by a trap
 * handler by filling in the TLB.
 */
typedef struct linear {
	unsw	base;		/* Virtual address where linear area starts. */
	unsw	size;		/* Virtual address space size. */
	unsw	prot;		/* Protection bits. */
	unsw	v2p;		/* Add to Virtual to get a Physical address. */
} linear_t;

static tlb_t (*tlb)[TPAGE_SIZE];/* Virtual memory translation table. */
static tlb_t stale_tlb[STALE_SIZE][STALE_DEPTH];
				/* LRU Cache of stale TLB entries. */
static linear_t linear[ASID_MAX];
				/* Linear limits. */
#define S_CODE	0		/* Index selecting code space. */
#define S_DATA	1		/* Index selecting data space. */
static tlb_t *ctlb[2];		/* Current task's code and data TLBs. */

/* Memory for the machine.  There are three kinds of addresses: Virtual (within
 * a task), Physical (mapped to the machine's idea of memory), and Memory
 * (mapped to this interpreter's memory array.)  Note that the memory and unsw
 * types may differ in size, with either one being bigger than the other, so
 * Physical to Memory mapping must be done carefully so that computations wrap
 * properly.  If unsw is big enough to address emulator memory then you may
 * choose to have Physical and Memory be the same, so that the machine can
 * address the interpreter's memory directly.  (That is allowed, there are no
 * checks to keep the machine inside it's dedicated memory area, all emulator
 * memory is fair game.  You may run into byte order problems though...)
 */
static memory mem_addr;		/* Main memory area. */
static memory mem_size;		/* Size of main memory. */
static memory mem_base;		/* Machine physical address zero. */
static memory mem_phys;		/* Memory area physical address. */

/* KM is a little endian machine, but this interpreter may run on a big endian.
 * Words are byteswapped when transferred to or from the outside world, so as
 * far as words are concerned everything is native byte order.  When addressing
 * objects smaller than a word we have to fix the addressing by XOR-ing the
 * proper low address bits to reach the proper subword at the other end of the
 * whole word.  Objects larger than a word (flt8 if W = 4) must be wordswapped
 * with special care.  (So there's no fmem8() below.)
 */
#if LITTLE_ENDIAN		/* Little-endian, everything's peachy. */
#define X(a, w)		((void) (w), (a))
#endif

#if BIG_ENDIAN			/* Big-endian, must flip lower address bits. */
#define X(a, w)		((a) ^ (W-(w)))
#endif

/* Memory objects of several sizes and types. */
#define imem1(a)	(* (int1 *) X((a), 1))
#define imem2(a)	(* (int2 *) X((a), 2))
#define imem4(a)	(* (int4 *) X((a), 4))
#define imemw(a)	(* (intw *) X((a), W))
#define umem1(a)	(* (uns1 *) X((a), 1))
#define umem2(a)	(* (uns2 *) X((a), 2))
#define umem4(a)	(* (uns4 *) X((a), 4))
#define umemw(a)	(* (unsw *) X((a), W))
#define fmem4(a)	(* (flt4 *) X((a), 4))

/* Registers can be treated as signed, unsigned or halfword pairs. */
typedef union { intw i; unsw u; int4 i4[W/4]; uns4 u4[W/4]; } regw;

/* Task state: CPU Registers and flags. */
typedef struct task {
    regw reg[62];		/* Ordinary registers. */
    unsw fp;			/* Frame pointer. */
    unsw sp;			/* Stack pointer. */
    flt8 tmp[8*W/8];		/* 8 user special registers / Alignment. */
    unsw tfun;			/* User trap handler function. */
    unsw tmask;			/* Mask telling traps handled by user. */
    unsw flags;			/* Special flags. */
    unsw fmask;			/* Flags you're not allowed to modify. */
    unsw ffake;			/* Fake settings for unmodifiable flags. */
    unsw pc;			/* Program counter. */
    unsw asid[2];		/* Code/data address space ids. */
    /* Rest reserved - Used by the machine/emulator for bookkeeping. */
    unsw info[5];		/* Trap information. */
    memory link;		/* Queue link pointer. */
} task_t;

/* Register numbers of some registers. */
#define FP	62
#define SP	63
#define FLAGS	74
#define PC	77
#define RESV	80

/* CPU flags. */
#define F_(t)  ((unsw)1 << (t))	/* Trap enable flag bit for trap code t. */

/* Task memory object. */
#define T(a)	(* (task_t *) (a))

task_t T;			/* Currently running task. */
memory context;			/* Address where current context came from. */
memory runq, *runqt;		/* Run queue (context list by 'link'). */
memory waitq, *waitqt;		/* Wait queue (trap handlers). */
memory faultq, *faultqt;	/* Fault queue (faulted tasks). */
sig_atomic_t think, think_io;	/* True when an external event is triggered. */

static void tlb_expunge(unsigned s)
/* Remove all TLB entries for address space s by marking all as "not present".
 * Used when a new task takes ownership of an address space id.
 */
{
    unsigned d, p;

    for (p= 0; p < TPAGE_SIZE; p++) tlb[s][p].vir= pP;

    s <<= pBITS;
    for (p= 0; p < STALE_SIZE; p++) {
	for (d= 0; d < STALE_DEPTH; d++) {
	    tlb_t *tp= &stale_tlb[p][d];
	    if ((tp->vir & (PAGE_MASK & ~pMASK)) == s) tp->vir= pP;
	}
    }
}

#define arraysize(a)	(sizeof(a) / sizeof((a)[0]))
#define arraylimit(a)	((a) + arraysize(a))

static void where(void)
/* Show task state for debug purposes. */
{
    static struct {
	char	name[8];
	unsw	*reg;
	char	sep[4];
    } registers[] = {
	{ "%pc",	&T.pc,		"  "	},
	{ "%fp",	&T.fp,		"  "	},
	{ "%sp",	&T.sp,		"  "	},
	{ "%code",	&T.asid[0],	"\n"	},
	{ "%flags",	&T.flags,	"  "	},
	{ "%fmask",	&T.fmask,	"  "	},
	{ "%ffake",	&T.ffake,	"  "	},
	{ "%data",	&T.asid[1],	"\n"	},
    };
    int i;

    for (i= 0; i < arraysize(registers); i++) {
	fprintf(logfp, "%7s = "PrW"%s",
	    registers[i].name, *registers[i].reg, registers[i].sep);
    }
}

/* Trap and fault codes. */
#define T_IDIVZ		 0	/* Integer divide by 0 */
#define T_IOVFL		 1	/* Integer overflow */
#define T_FDIVZ		 2	/* Floating divide by 0.0 */
#define T_FOVFL		 3	/* Floating overflow */
#define T_FUNFL		 4	/* Floating underflow */
#define T_FUNDEF	 5	/* Undefined float */
#define T_FINXCT	 6	/* Inexact result */
#define T_SUPER		10	/* Operation priviliged to supervisor */
#define T_TRACE		11	/* Tracing active */
#define T_STEP		12	/* Single step trap active */
#define T_ALIGN		13	/* Alignment fault */
#define T_INTR		14	/* Hardware interrupt */
#define T_ILLINS	15	/* Illegal instruction */
#define T_MEMFLT	16	/* Addressing non existent memory */
#define T_PAGEFLT	17	/* Page fault */
#define T_INVAL		18	/* Invalid argument */
#define T_USER		24	/* First user trap */

/* Traps that may be handled in user mode. */
#define T_USERMASK	( \
	F_(T_IDIVZ) | F_(T_IOVFL) | F_(T_FDIVZ) | F_(T_FOVFL) | \
	F_(T_FUNFL) | F_(T_FUNDEF) | F_(T_FINXCT) | F_(T_ALIGN) | \
	F_(T_ILLINS) | F_(T_MEMFLT) | F_(T_INVAL) | -F_(T_USER))

static char faultnames[][8] = {
    /*  0 */	"IDIVZ",   "IOVFL",   "FDIVZ",   "FOVFL",
    /*  4 */	"FUNFL",   "FUNDEF",  "FINXCT",  "RES7",
    /*  8 */	"RES8",    "RES9",    "SUPER",   "TRACE",
    /* 12 */	"STEP",    "ALIGN",   "INTR",    "ILLINS",
    /* 16 */	"MEMFLT",  "PAGEFLT", "INVAL",   "RES19",
    /* 20 */	"RES20",   "RES21",   "RES22",   "RES23",
};

static char *faultname(unsigned type)
{
    static char username[sizeof("USER####")];

    if (type < arraysize(faultnames)) {
	return faultnames[type];
    } else {
	sprintf(username, "USER%u", type);
	return username;
    }
}

static void fault(unsigned type, unsigned asid, unsw arg1, unsw arg2);

static char *showprot(unsigned prot)
{
    static char p[5];

    p[0]= (prot & pP) ? 'P' : '-';
    p[1]= (prot & pR) ? 'R' : '-';
    p[2]= (prot & pW) ? 'W' : '-';
    p[3]= (prot & pX) ? 'X' : '-';
    return p;
}

/* Check if a TLB entry has the proper virtual address and protection bits.  If
 * not then we have a TLB miss.
 */
#define tlb_chk0(ptp, spidx, addr, prot)	\
	(*(ptp)= &ctlb[spidx][((addr) >> PAGE_BITS) & TPAGE_MASK], \
	 ((*(ptp))->vir & (~PAGE_MASK | (prot))) == ((addr) & ~PAGE_MASK))

#define tlb_chk(ptp, spidx, addr, prot)	\
	(tlb_chk0(ptp, spidx, addr, prot) \
		|| tlb_miss(*(ptp), (spidx), (addr), (prot)))

/* Translate a virtual to a memory address given a TLB entry. */
#define tlb_v2m(tp, addr)	((memory) (addr) + (tp)->v2m)

static int tlb_miss(tlb_t *tp, unsigned spidx, unsw addr, unsigned prot)
/* A TLB miss.  If the page is wrong or missing then we first try to repair
 * the situation using an entry from the LRU cache.  If that fails, but the
 * task is linearly mapped then we can fix the TLB ourselves easily.
 * Otherwise it's up to the trap handler.  Return true if the miss was
 * avoided, otherwise raise a page fault and return false.
 */
{
    unsigned asid= T.asid[spidx];
    unsw apage= (addr & ~PAGE_MASK);		/* Virtual page address. */
    unsw apgid= apage | (asid << pBITS);	/* Virtual page + ASID. */
    linear_t *lp= &linear[asid];

    /* Is it a true miss, i.e. the page number is not as expected or the page
     * is not present?
     */
    if ((tp->vir & (~pMASK | pP)) != apgid) {
	/* See if an entry in the cache would have given access. */
	tlb_t *stp, tmp;
	unsigned d;

	/* Stale TLB cache bucket. */
	stp= stale_tlb[(apage >> (PAGE_BITS+STALE_SKEW)) & STALE_MASK];

	for (d= 0; d < STALE_DEPTH; d++) {
	    if ((stp->vir & (~pMASK | prot)) == apgid) {
		/* Contending entry that matches address and access found! */
		tmp= *stp;
		while (d > 0) {
		    /* Move entries before the entry found downward. */
		    d--;
		    stp--;
		    stp[1]= stp[0];
		}
		*stp= *tp;	/* Current entry is now most recent. */
		*tp= tmp;	/* Old entry is now active. */
		return 1;
	    }
	    stp++;
	}

	/* Nothing good found.  Move the current entry out into the cache,
	 * unless it can simply be remade from the linear area.
	 */
	if ((tp->vir & pP) == 0) {
	    if (!((tp->vir - lp->base) < lp->size
		&& (tp->vir & pMASK) == lp->prot
	    )) {
		do {
		    stp--;
		    stp[0]= stp[-1];
		} while (--d > 1);
		stp[-1]= *tp;
	    }
	    tp->vir= pP;	/* Current entry free to be replaced. */
	}
    }

    /* Linearly mapped? */
    if ((apage - lp->base) < lp->size && (lp->prot & prot) == 0) {
	if (tlevel >= 1) {
	    fprintf(logfp,
	    "Linear fault, PC = "PrW", %s space %d, addr = "PrW", prot %s\n",
		T.pc-4,
		spidx == S_CODE ? "code" : "data",
		asid, addr, showprot(prot));
	}
	tp->vir= apgid | lp->prot;
	tp->v2m= (mem_base + (apage + lp->v2p)) - apage;
	return 1;
    }

    /* Throw a page fault and let a trap handler figure it out.  The PC is
     * set back so that the instruction is restarted if the trap handler
     * has managed to fix things.
     */
    T.pc -= 4;
    fault(T_PAGEFLT, asid, addr, prot);
    return 0;
}

/* Check if an address is aligned to some wordsize, otherwise raise a trap. */
#define aligned0(addr, size)	(((addr) & ((size)-1)) == 0)
#define aligned(addr, size)	(aligned0((addr), (size)) || (trap(T_ALIGN), 0))

#if PC_CACHE
#if PC_CACHE_SIMPLE
/* Remember the page we're currently executing from in pc_page. */
static unsw pc_page;

/* Virtual to physical translation for the current PC page. */
static memory pc_vir2mem;

/* Check if the PC is still on the current page. */
#define pc_chk0(pc)	(((pc) & ~PAGE_MASK) == pc_page)
#define pc_chk(pc)	(pc_chk0(pc) || pc_dblchk(pc))

static int pc_dblchk(unsw pc)
/* We've moved outside the current PC page.  Establish a new one. */
{
    tlb_t *tp;

    if (!tlb_chk(&tp, S_CODE, pc, pP|pX)) return 0;

    pc_vir2mem= tp->v2m;
    pc_page= pc & ~PAGE_MASK;

    if (tlevel >= 1) {
	fprintf(logfp, "Context "PrW", ASID %u, PC == "PrW"\n",
	    (unsw)(context - mem_base), (unsigned) T.asid[S_CODE], pc);
    }
    return 1;
}

/* Translate a pointer within the current PC page. */
#define pc_v2m(addr)	((memory) (addr) + pc_vir2mem)

/* Disable the current PC page.  (Context switch?) */
#define pc_expunge()	(void)(pc_page= -1)

#else /* !PC_CACHE_SIMPLE */
/* Boundaries of know good memory around the Program Counter.  As long as
 * ((PC - pc_base) < pc_size) there are no chances of faults.
 */
static unsw pc_base, pc_size;

/* Virtual to physical translation for the known good PC area. */
#define C_V2P_BITS	4
#define C_V2P_SIZE	(1 << C_V2P_BITS)
#define C_V2P_MASK	(C_V2P_SIZE - 1)
static memory pc_vir2mem[C_V2P_SIZE];

/* Check if the PC is still within a known good bit of code. */
#define pc_chk(pc)	(((pc) - pc_base) < pc_size || pc_dblchk(pc))

static int pc_dblchk(unsw pc)
/* Check if the page under the PC can be added to explored code. */
{
    tlb_t *tp;

    if (!tlb_chk(&tp, S_CODE, pc, pP|pX)) return 0;

    pc_vir2mem[(pc >> PAGE_BITS) & C_V2P_MASK]= tp->v2m;

    if ((pc & ~PAGE_MASK) == pc_base + pc_size) {
	/* The PC just moved into the next page. */
	pc_size += PAGE_SIZE;
	if (pc_size > C_V2P_SIZE * PAGE_SIZE) {
	    /* Too many pages to keep track of. */
	    pc_base += PAGE_SIZE;
	    pc_size -= PAGE_SIZE;
	}
    } else {
	/* The new PC is far outside the current interval. */
	pc_base= pc & ~PAGE_MASK;
	pc_size= PAGE_SIZE;
    }

    if (tlevel >= 1) {
	fprintf(logfp,
	    "Context "PrW", ASID %u, PC cache: "PrW" <= PC < "PrW"\n",
	    (unsw)(context - mem_base), (unsigned) T.asid[S_CODE],
	    pc_base, pc_base + pc_size);
    }
    return 1;
}

/* Translate a pointer into the known good code area. */
#define pc_v2m(addr) \
	((memory) (addr) + pc_vir2mem[((addr) >> PAGE_BITS) & C_V2P_MASK])

/* Disable the known good area.  (Context switch?) */
#define pc_expunge()	(void)(pc_size= 0)

#endif /* !PC_CACHE_SIMPLE */
#endif /* PC_CACHE */

static void save_context(void)
/* Dump the registers into the currently running context. */
{
    int i;

    for (i= 0; i < RESV; i++) (&umemw(context))[i] = ((unsw*)&T)[i];
}

static void load_context(void)
/* Load the registers from the new current context.  The new values must have
 * been checked beforehand.
 */
{
    int i;

    for (i= 0; i < RESV; i++) ((unsw*)&T)[i] = (&umemw(context))[i];

    ctlb[S_CODE]= tlb[T.asid[S_CODE]];
    ctlb[S_DATA]= tlb[T.asid[S_DATA]];
#if PC_CACHE
    pc_expunge();
#endif
    think= 1;	/* Tracing?  Interrupts now enabled?  Think! */
}

static void telltrap(unsigned type, unsigned asid, unsw arg1, unsw arg2)
{
    fprintf(logfp, "Trap %u (%s), ASID %d, address "PrW", ",
	type, faultname(type), asid, arg1);
    if (type == T_PAGEFLT) {
	fprintf(logfp, "prot %s\n", showprot(arg2));
    } else {
	fprintf(logfp, "op "Pr4" (%02X:%08o)\n", (uns4) arg2,
	    (unsigned) (arg2 >> 24), (unsigned) (arg2 & 077777777));
    }
}

static void schedule(void)
/* Find a task to run, but first try to enable a trap handler if there are
 * any tasks that faulted.  Die if there's nothing runnable.  (No external
 * interrupts yet, or we'd be happy having at least a task on the wait queue.)
 */
{
    memory t;

    if (faultq != 0 && waitq != 0) {
	/* Copy fault data to a waiting trap handler and make the handler
	 * runnable by putting it on the front (!) of the run queue.
	 */
	unsw r= T(waitq).info[0];
	T(waitq).reg[r+0].u =
	    (unsw)(faultq - mem_base) - linear[T(waitq).asid[S_DATA]].v2p;
	T(waitq).reg[r+1].u = T(faultq).info[0];
	T(waitq).reg[r+2].u = T(faultq).info[1];
	T(waitq).reg[r+3].u = T(faultq).info[2];
	T(waitq).reg[r+4].u = T(faultq).info[3];

	faultq= T(faultq).link;		/* Owned by the handler now. */

	t= waitq;			/* Handler off the wait queue. */
	waitq= T(waitq).link;

	if (runq == 0) runqt= &T(t).link;
	T(t).link = runq;
	runq= t;			/* Handler on the run queue. */
    }

    if (runq == 0) {
	/* Nothing to do! Report the last fault if it's fresh and the trap
	 * fault routine didn't do so already for tlevel > 0.
	 */
	if (context == faultq) {
	    if (tlevel == 0) {
		telltrap(T(faultq).info[0], T(faultq).info[1],
			T(faultq).info[2], T(faultq).info[3]);
	    }
	    where();
	}
	fprintf(logfp, "Nothing left to do!\n");
	exit(1);
    }

    context= runq;			/* Take one off the run queue. */
    runq= T(runq).link;
    load_context();			/* And run it. */
}

static void fault(unsigned type, unsigned asid, unsw arg1, unsw arg2)
/* A trap or fault.  Switch to a trap handler, if we have one. */
{
    if (tlevel >= 1) telltrap(type, asid, arg1, arg2);

    /* Save registers and trap data. */
    save_context();
    T(context).info[0] = type;
    T(context).info[1] = asid;
    T(context).info[2] = arg1;
    T(context).info[3] = arg2;

    /* Add to fault queue. */
    *(faultq == 0 ? &faultq : faultqt) = context;
    *(faultqt = &T(context).link) = 0;

    /* Find a new task to run. */
    schedule();
}

static void trap(unsigned type)
/* Simple trap, i.e. anything other than a page fault. */
{
    unsw pc;
    uns4 op;
    tlb_t *tp;

    /* The faulting instruction is at... */
    pc= T.pc - 4;

    /* The operation that faulted. */
#if PC_CACHE
    op= umem4(pc_v2m(pc));
#else
    tp= &ctlb[S_CODE][(pc >> PAGE_BITS) & TPAGE_MASK];
    op= umem4(tlb_v2m(tp, pc));
#endif

    if (((unsw) 1 << type) & T.tmask & T_USERMASK) {
	/* Trap is handled by a user trap handler. */
	unsw sp= T.sp;

	pc= T.tfun;
	if (!aligned0(pc, 4) || !aligned0(sp, W)) { type= T_ALIGN; goto fault; }
	sp -= W;
	if (!tlb_chk(&tp, S_DATA, sp, pP|pW)) return;
	umemw(tlb_v2m(tp, sp))= op;
	sp -= W;
	if (!tlb_chk(&tp, S_DATA, sp, pP|pW)) return;
	umemw(tlb_v2m(tp, sp))= type;
	sp -= W;
	if (!tlb_chk(&tp, S_DATA, sp, pP|pW)) return;
	umemw(tlb_v2m(tp, sp))= T.pc;
	T.sp= sp;
	T.pc= pc;
	if (tlevel >= 1) telltrap(type, T.asid[S_CODE], pc, op);
    } else {
    fault:
	/* Trap is handled by a trap handler task. */
	fault(type, T.asid[S_CODE], pc, op);
    }
}

/* To address the low and high halves of a bigger object. */
#define L	(LITTLE_ENDIAN ? 0 : 1)
#define H	(LITTLE_ENDIAN ? 1 : 0)

#if W < 8 && BIG_ENDIAN
/* KM is a little endian machine, but this interpreter may be big endian.
 * If W = 4 then double precision big-endian floats must be wordswapped
 * when put in or taken out of a pair of registers.
 */
static flt8 ldf8(regw w[2])
{
    flt8 f;

    ((unsw*)&f)[L]= w[0].u;
    ((unsw*)&f)[H]= w[1].u;
    return f;
}

static void stf8(regw w[2], flt8 f)
{
    w[0].u = ((unsw*)&f)[L];
    w[1].u = ((unsw*)&f)[H];
}
#else /* W == 8 || LITTLE_ENDIAN */
#define ldf8(w)		(* (flt8 *) (w))
#define stf8(w, f)	((void) (* (flt8 *) (w) = (f)))
#endif

/* Zero/sign/jump/backjump extension from n-bits up. */
#define zxt(u, n)	((uns4) (u) & ((uns4) -1 >> (32-(n))))
#define sxt(i, n)	((int4) ((i) << (32-(n))) >> (32-(n)))
#define jxt(i, n)	((int4) ((i) << (32-(n))) >> (32-(n)-2))
#define bjxt(u, n)	(((uns4) (u) << 2) | ((unsw) -1 << ((n)+2)))

/* Make 4 byte float by padding a constant field. */
#define fxt(pf, c, n)	(* (uns4 *) (pf) = (uns4) (c) << (32-(n)))

/* Various interpretations of instruction operands. */
typedef enum optype {
	J24, R_J18, R, R_S18, R_R_R, R_R_S12, R_R_U6, R_S12_R, R_RiRaS, R_RaS,
	PCaS, R_PCaS, R_RaU, R_U18W, U18W, R_F18, ILL, R_R, CALL, R2R_R,
	R2R_S12, R2R_U6, R2R, R_R_N, R_Ri_N, R_R_R_R, R2_R2,
	R2R_F12, R_R_F12, R_F12_R, R_R_BJ12, J18iR, R_R_BS6
} optype_t;

typedef struct operation {
	char		name[8];	/* Instruction name */
	optype_t	type;		/* Operand type */
	int		flags;		/* Misc. flags. */
} operation_t;

#define OF_CMP		0x0001

/* Encoding used for each operation. */
static operation_t optab[256] = {
	{ "jmp",	J24,	0	},	/* 00 */
	{ "jl",		R_J18,	0	},	/* 01 */
	{ "jg",		R_J18,	0	},	/* 02 */
	{ "jle",	R_J18,	0	},	/* 03 */
	{ "jge",	R_J18,	0	},	/* 04 */
	{ "je",		R_J18,	0	},	/* 05 */
	{ "jne",	R_J18,	0	},	/* 06 */
	{ "jmp",	PCaS,	0	},	/* 07 */
	{ "jmp",	R,	0	},	/* 08 */
	{ "call",	PCaS,	0	},	/* 09 */
	{ "call",	R,	0	},	/* 0A */
	{ "mov",	R2_R2,	0	},	/* 0B */
	{ "mov",	R_S18,	0	},	/* 0C */
	{ "add",	R_S18,	0	},	/* 0D */
	{ "add",	R_S18,	0	},	/* 0E */
	{ "add",	R_S18,	0	},	/* 0F */
	{ "add",	R2R_R,	0	},	/* 10 */
	{ "sub",	R2R_R,	0	},	/* 11 */
	{ "and",	R2R_R,	0	},	/* 12 */
	{ "or",		R2R_R,	0	},	/* 13 */
	{ "xor",	R2R_R,	0	},	/* 14 */
	{ "mul",	R2R_R,	0	},	/* 15 */
	{ "divu",	R2R_R,	0	},	/* 16 */
	{ "divs",	R2R_R,	0	},	/* 17 */
	{ "shl",	R2R_R,	0	},	/* 18 */
	{ "shr",	R2R_R,	0	},	/* 19 */
	{ "sar",	R2R_R,	0	},	/* 1A */
	{ "add4",	R2R_R,	0	},	/* 1B */
	{ "sub4",	R2R_R,	0	},	/* 1C */
	{ "mul4",	R2R_R,	0	},	/* 1D */
	{ "ill",	ILL,	0	},	/* 1E */
	{ "ill",	ILL,	0	},	/* 1F */
	{ "shl4",	R2R_R,	0	},	/* 20 */
	{ "cmpa",	R_R_R,	OF_CMP	},	/* 21 */
	{ "cmpbe",	R_R_R,	OF_CMP	},	/* 22 */
	{ "mul4",	R2R_S12,0	},	/* 23 */
	{ "shl4",	R2R_U6,	0	},	/* 24 */
	{ "cmpg",	R_R_R,	OF_CMP	},	/* 25 */
	{ "cmple",	R_R_R,	OF_CMP	},	/* 26 */
	{ "sub4",	R_S12_R,0	},	/* 27 */
	{ "cmpe",	R_R_R,	OF_CMP	},	/* 28 */
	{ "cmpne",	R_R_R,	OF_CMP	},	/* 29 */
	{ "cmov",	R_R_R_R,0	},	/* 2A */
	{ "andn",	R2R_R,	0	},	/* 2B */
	{ "remu",	R2R_R,	0	},	/* 2C */
	{ "rems",	R2R_R,	0	},	/* 2D */
	{ "bic",	R2R_R,	0	},	/* 2E */
	{ "bis",	R2R_R,	0	},	/* 2F */
	{ "add",	R2R_S12,0	},	/* 30 */
	{ "add4",	R2R_S12,0	},	/* 31 */
	{ "and",	R2R_S12,0	},	/* 32 */
	{ "or",		R2R_S12,0	},	/* 33 */
	{ "xor",	R2R_S12,0	},	/* 34 */
	{ "mul",	R2R_S12,0	},	/* 35 */
	{ "divu",	R2R_S12,0	},	/* 36 */
	{ "divs",	R2R_S12,0	},	/* 37 */
	{ "shl",	R2R_U6,	0	},	/* 38 */
	{ "shr",	R2R_U6,	0	},	/* 39 */
	{ "sar",	R2R_U6,	0	},	/* 3A */
	{ "bix",	R2R_R,	0	},	/* 3B */
	{ "bix",	R2R_U6,	0	},	/* 3C */
	{ "sxto",	R_R_U6,	0	},	/* 3D */
	{ "sal4",	R2R_R,	0	},	/* 3E */
	{ "sar4",	R2R_R,	0	},	/* 3F */
	{ "sal4",	R2R_U6,	0	},	/* 40 */
	{ "cmpa",	R_R_S12,OF_CMP	},	/* 41 */
	{ "cmpbe",	R_R_S12,OF_CMP	},	/* 42 */
	{ "sar4",	R2R_U6,	0	},	/* 43 */
	{ "ill",	ILL,	0	},	/* 44 (official) */
	{ "cmpg",	R_R_S12,OF_CMP	},	/* 45 */
	{ "cmple",	R_R_S12,OF_CMP	},	/* 46 */
	{ "ill",	ILL,	0	},	/* 47 */
	{ "cmpe",	R_R_S12,OF_CMP	},	/* 48 */
	{ "cmpne",	R_R_S12,OF_CMP	},	/* 49 */
	{ "cmovt",	R_R_S12,0	},	/* 4A */
	{ "cmovf",	R_R_S12,0	},	/* 4B */
	{ "sub",	R_S12_R,0	},	/* 4C */
	{ "cjne",	R_R_BJ12,0	},	/* 4D */
	{ "bswap",	R_R_BS6,0	},	/* 4E */
	{ "ill",	ILL,	0	},	/* 4F */
	{ "adcc",	R_R_R_R,0	},	/* 50 */
	{ "sbbb",	R_R_R_R,0	},	/* 51 */
	{ "mulh",	R_R_R,	0	},	/* 52 */
	{ "addo",	R2R_R,	0	},	/* 53 */
	{ "subo",	R2R_R,	0	},	/* 54 */
	{ "mulo",	R2R_R,	0	},	/* 55 */
	{ "zxt",	R_R_U6,	0	},	/* 56 */
	{ "sxt",	R_R_U6,	0	},	/* 57 */
	{ "remu",	R2R_S12,0	},	/* 58 */
	{ "rems",	R2R_S12,0	},	/* 59 */
	{ "adc",	R_R_R_R,0	},	/* 5A */
	{ "sbb",	R_R_R_R,0	},	/* 5B */
	{ "bit",	R2R_R,	0	},	/* 5C */
	{ "bic",	R2R_U6,	0	},	/* 5D */
	{ "bis",	R2R_U6,	0	},	/* 5E */
	{ "bit",	R2R_U6,	0	},	/* 5F */
	{ "ld8",	R_RiRaS,0	},	/* 60 */
	{ "st8",	R_RiRaS,0	},	/* 61 */
	{ "ld4u",	R_RiRaS,0	},	/* 62 */
	{ "ld4s",	R_RiRaS,0	},	/* 63 */
	{ "st4",	R_RiRaS,0	},	/* 64 */
	{ "ld2u",	R_RiRaS,0	},	/* 65 */
	{ "ld2s",	R_RiRaS,0	},	/* 66 */
	{ "st2",	R_RiRaS,0	},	/* 67 */
	{ "ld1u",	R_RiRaS,0	},	/* 68 */
	{ "ld1s",	R_RiRaS,0	},	/* 69 */
	{ "st1",	R_RiRaS,0	},	/* 6A */
	{ "jmp",	J18iR,	0	},	/* 6B */
	{ "ld8",	R_RaS,	0	},	/* 6C */
	{ "st8",	R_RaS,	0	},	/* 6D */
	{ "ld4u",	R_RaS,	0	},	/* 6E */
	{ "ld4s",	R_RaS,	0	},	/* 6F */
	{ "st4",	R_RaS,	0	},	/* 70 */
	{ "ld2u",	R_RaS,	0	},	/* 71 */
	{ "ld2s",	R_RaS,	0	},	/* 72 */
	{ "st2",	R_RaS,	0	},	/* 73 */
	{ "ld1u",	R_RaS,	0	},	/* 74 */
	{ "ld1s",	R_RaS,	0	},	/* 75 */
	{ "st1",	R_RaS,	0	},	/* 76 */
	{ "lea",	R_PCaS,	0	},	/* 77 */
	{ "ld8",	R_PCaS,	0	},	/* 78 */
	{ "ld4u",	R_PCaS,	0	},	/* 79 */
	{ "ld4s",	R_PCaS,	0	},	/* 7A */
	{ "ld",		R_Ri_N,	0	},	/* 7B */
	{ "st",		R_Ri_N,	0	},	/* 7C */
	{ "copy",	R_R_R,	0	},	/* 7D */
	{ "fill",	R_R_R,	0	},	/* 7E */
	{ "scan",	R_R_R,	0	},	/* 7F */
	{ "in8",	R_RaU,	0	},	/* 80 */
	{ "out8",	R_RaU,	0	},	/* 81 */
	{ "in4",	R_RaU,	0	},	/* 82 */
	{ "out4",	R_RaU,	0	},	/* 83 */
	{ "in2",	R_RaU,	0	},	/* 84 */
	{ "out2",	R_RaU,	0	},	/* 85 */
	{ "in1",	R_RaU,	0	},	/* 86 */
	{ "out1",	R_RaU,	0	},	/* 87 */
	{ "mov",	R_R,	0	},	/* 88 */
	{ "mov",	R_R,	0	},	/* 89 */
	{ "enter",	R_U18W,	0	},	/* 8A */
	{ "leave",	R,	0	},	/* 8B */
	{ "return",	R_U18W,	0	},	/* 8C */
	{ "ret",	U18W,	0	},	/* 8D */
	{ "queue",	R_S18,	0	},	/* 8E */
	{ "trap",	R_R_S12,0	},	/* 8F */
	{ "fadd",	R2R_R,	0	},	/* 90 */
	{ "fsub",	R2R_R,	0	},	/* 91 */
	{ "fmul",	R2R_R,	0	},	/* 92 */
	{ "fdiv",	R2R_R,	0	},	/* 93 */
	{ "frem",	R2R_R,	0	},	/* 94 */
	{ "ill",	ILL,	0	},	/* 95 */
	{ "fcmpg",	R_R_R,	OF_CMP	},	/* 96 */
	{ "fcmple",	R_R_R,	OF_CMP	},	/* 97 */
	{ "ill",	ILL,	0	},	/* 98 */
	{ "fcmpe",	R_R_R,	OF_CMP	},	/* 99 */
	{ "fcmpne",	R_R_R,	OF_CMP	},	/* 9A */
	{ "finsx",	R_R_R,	0	},	/* 9B */
	{ "fmadd",	R_R_R_R,0	},	/* 9C */
	{ "ill",	ILL,	0	},	/* 9D */
	{ "ill",	ILL,	0	},	/* 9E */
	{ "ill",	ILL,	0	},	/* 9F */
	{ "fadd",	R2R_F12,0	},	/* A0 */
	{ "fsub",	R2R_F12,0	},	/* A1 */
	{ "fmul",	R2R_F12,0	},	/* A2 */
	{ "fdiv",	R2R_F12,0	},	/* A3 */
	{ "frem",	R2R_F12,0	},	/* A4 */
	{ "fcmpl",	R_R_F12,OF_CMP	},	/* A5 */
	{ "fcmpg",	R_R_F12,OF_CMP	},	/* A6 */
	{ "fcmple",	R_R_F12,OF_CMP	},	/* A7 */
	{ "fcmpge",	R_R_F12,OF_CMP	},	/* A8 */
	{ "fcmpe",	R_R_F12,OF_CMP	},	/* A9 */
	{ "fcmpne",	R_R_F12,OF_CMP	},	/* AA */
	{ "finsx",	R_R_S12,0	},	/* AB */
	{ "fsub",	R_F12_R,0	},	/* AC */
	{ "fdiv",	R_F12_R,0	},	/* AD */
	{ "ill",	ILL,	0	},	/* AE */
	{ "ill",	ILL,	0	},	/* AF */
	{ "fmov",	R_F18,	0	},	/* B0 */
	{ "fextx",	R_R,	0	},	/* B1 */
	{ "fround",	R_R,	0	},	/* B2 */
	{ "ftrunc",	R_R,	0	},	/* B3 */
	{ "ill",	ILL,	0	},	/* B4 */
	{ "fcfi",	R_R,	0	},	/* B5 */
	{ "fcif",	R_R,	0	},	/* B6 */
	{ "fcfu",	R_R,	0	},	/* B7 */
	{ "fcuf",	R_R,	0	},	/* B8 */
	{ "fcds",	R_R,	0	},	/* B9 */
	{ "fcsd",	R_R,	0	},	/* BA */
	{ "fld4",	R_RiRaS,0	},	/* BB */
	{ "fst4",	R_RiRaS,0	},	/* BC */
	{ "fld4",	R_RaS,	0	},	/* BD */
	{ "fst4",	R_RaS,	0	},	/* BE */
	{ "fld4",	R_PCaS,	0	},	/* BF */
	{ "ill",	ILL,	0	},	/* C0 */
	{ "ill",	ILL,	0	},	/* C1 */
	{ "ill",	ILL,	0	},	/* C2 */
	{ "ill",	ILL,	0	},	/* C3 */
	{ "ill",	ILL,	0	},	/* C4 */
	{ "ill",	ILL,	0	},	/* C5 */
	{ "ill",	ILL,	0	},	/* C6 */
	{ "ill",	ILL,	0	},	/* C7 */
	{ "ill",	ILL,	0	},	/* C8 */
	{ "ill",	ILL,	0	},	/* C9 */
	{ "ill",	ILL,	0	},	/* CA */
	{ "ill",	ILL,	0	},	/* CB */
	{ "ill",	ILL,	0	},	/* CC */
	{ "ill",	ILL,	0	},	/* CD */
	{ "ill",	ILL,	0	},	/* CE */
	{ "ill",	ILL,	0	},	/* CF */
	{ "ill",	ILL,	0	},	/* D0 */
	{ "ill",	ILL,	0	},	/* D1 */
	{ "ill",	ILL,	0	},	/* D2 */
	{ "ill",	ILL,	0	},	/* D3 */
	{ "ill",	ILL,	0	},	/* D4 */
	{ "ill",	ILL,	0	},	/* D5 */
	{ "ill",	ILL,	0	},	/* D6 */
	{ "ill",	ILL,	0	},	/* D7 */
	{ "ill",	ILL,	0	},	/* D8 */
	{ "ill",	ILL,	0	},	/* D9 */
	{ "ill",	ILL,	0	},	/* DA */
	{ "ill",	ILL,	0	},	/* DB */
	{ "ill",	ILL,	0	},	/* DC */
	{ "ill",	ILL,	0	},	/* DD */
	{ "ill",	ILL,	0	},	/* DE */
	{ "ill",	ILL,	0	},	/* DF */
	{ "ill",	ILL,	0	},	/* E0 */
	{ "ill",	ILL,	0	},	/* E1 */
	{ "ill",	ILL,	0	},	/* E2 */
	{ "ill",	ILL,	0	},	/* E3 */
	{ "ill",	ILL,	0	},	/* E4 */
	{ "ill",	ILL,	0	},	/* E5 */
	{ "ill",	ILL,	0	},	/* E6 */
	{ "ill",	ILL,	0	},	/* E7 */
	{ "ill",	ILL,	0	},	/* E8 */
	{ "ill",	ILL,	0	},	/* E9 */
	{ "ill",	ILL,	0	},	/* EA */
	{ "ill",	ILL,	0	},	/* EB */
	{ "ill",	ILL,	0	},	/* EC */
	{ "ill",	ILL,	0	},	/* ED */
	{ "ill",	ILL,	0	},	/* EE */
	{ "ill",	ILL,	0	},	/* EF */
	{ "call",	CALL,	0	},	/* F0 */
	{ "call",	CALL,	0	},	/* F1 */
	{ "call",	CALL,	0	},	/* F2 */
	{ "call",	CALL,	0	},	/* F3 */
	{ "call",	CALL,	0	},	/* F4 */
	{ "call",	CALL,	0	},	/* F5 */
	{ "call",	CALL,	0	},	/* F6 */
	{ "call",	CALL,	0	},	/* F7 */
	{ "call",	CALL,	0	},	/* F8 */
	{ "call",	CALL,	0	},	/* F9 */
	{ "call",	CALL,	0	},	/* FA */
	{ "call",	CALL,	0	},	/* FB */
	{ "call",	CALL,	0	},	/* FC */
	{ "call",	CALL,	0	},	/* FD */
	{ "call",	CALL,	0	},	/* FE */
	{ "call",	CALL,	0	},	/* FF */
};

static char *reg(int r)
/* Return the name of register r.  Allow this function to be called 8 times
 * in one printf() call.
 */
{
    static char special[][8] = {
	"%fp", "%sp",
	"%64", "%65", "%66", "%67", "%68", "%69", "%70", "%71",
	"%tfun", "%tmask", "%flags", "%fmask",
	"%ffake", "%pc", "%code", "%data",
    };
    static char regname[8][8];
    static int n= 0;

    if ((r - FP) < arraysize(special)) return special[r-FP];
    if (n == 8) n= 0;
    sprintf(regname[n], "%%%d", r);
    return regname[n++];
}

static char *regoff(int r, int offset)
/* Return the [register+offset] operand form. */
{
    static char roff[sizeof("[%63+2047]")];

    sprintf(roff, offset == 0 ? "[%s]" : "[%s%+d]", reg(r), offset);
    return roff;
}

void trace(uns4 op)
/* Decode a K code instruction. */
{
    typedef unsigned long ulong;
    operation_t *opn;
    int opcode= (op >> 24) & 0xFF;
    int r1= (op >> 18) & 077;
    int r2= (op >> 12) & 077;
    int r3= (op >>  6) & 077;
    int r4= (op >>  0) & 077;
    int s6= sxt(op, 6);
    int s12= sxt(op, 12);
    int4 s18= sxt(op, 18);
    int4 s24= sxt(op, 24);
    int4 s28= sxt(op, 28);
    unsigned u6= zxt(op, 6);
    unsigned u12= zxt(op, 12);
    unsigned u18= zxt(op, 18);
    unsw pc= T.pc;
    char *name;
    float fc;
    static uns4 prevop;

    if (opcode == 0x88) r2 += 64;
    if (opcode == 0x89) r1 += 64;

    fprintf(logfp, PrW" %02X:%08o "PrW" "PrW" "PrW"   ",
	(pc - 4), opcode, zxt(op, 24),
	T.reg[r1].u, T.reg[r2].u, T.reg[r3].u);

    opn= &optab[opcode];
    name= opn->name;

    switch (opn->type) {
    case J24:
	if (op == 0x00000000UL) {
	    fprintf(logfp, "nop");
	    break;
	}
	fprintf(logfp, "%-7s 0x"PrW, name, pc + s24*4);
	break;
    case R_J18:
	if ((opcode == 0x05 || opcode == 0x06)
	    && (optab[prevop >> 24].flags & OF_CMP)
	) {
	    name= opcode == 0x05 ? "jf" : "jt";
	}
	fprintf(logfp, "%-7s %s, 0x"PrW, name, reg(r1), pc + s18*4);
	break;
    case J18iR:
	fprintf(logfp, "%-7s 0x"PrW"[%s]", name, pc + s18*4, reg(r1));
	break;
    case R_R_BJ12:
	fprintf(logfp, "%-7s %s, %s, 0x"PrW, name, reg(r1), reg(r2),
	    pc - (1<<14) + u12*4);
	break;
    case R_R_BS6:
	fprintf(logfp, "%-7s %s, %s", name, reg(r1), reg(r2));
	if (u6 == 0) {
	    /**/
	} else
	if (u6 % 8 == 0) {
	    fprintf(logfp, ", %u", W - (u6 / 8));
	} else {
	    fprintf(logfp, ", %u/8", W * 8 - u6);
	}
	break;
    case R:
	fprintf(logfp, "%-7s %s", name, reg(r1));
	break;
    case R_S18:
	r2= r1;
	if (opcode == 0x0D) r2= FP;
	if (opcode == 0x0E) r2= SP;
	if (opcode != 0x0C && s18 < 0) {
	    name= "sub";
	    s18= -s18;
	}
	if (r1 == r2) {
	    fprintf(logfp, "%-7s %s, %d", name, reg(r1), s18);
	} else {
	    fprintf(logfp, "%-7s %s, %s, %d", name, reg(r1), reg(r2), s18);
	}
	break;
    case R2R_R:
	if (r1 == r2) {
	    fprintf(logfp, "%-7s %s, %s", name, reg(r1), reg(r3));
	    break;
	}
	/*FALL THROUGH*/
    case R_R_R:
	fprintf(logfp, "%-7s %s, %s, %s", name, reg(r1), reg(r2), reg(r3));
	break;
    case R2_R2:
	if ((r1 == r4 && r2 == r3) || (W == 4 && r2 == r1+1 && r4 == r3+1)) {
	    name= r1 == r4 ? "xchg" : "mov8";
	    fprintf(logfp, "%-7s %s, %s", name, reg(r1), reg(r3));
	    break;
	}
	/*FALL THROUGH*/
    case R_R_R_R:
	fprintf(logfp, "%-7s %s, %s, %s, %s",
	    name, reg(r1), reg(r2), reg(r3), reg(r4));
	break;
    case R2R_S12:
	if (opcode == 0x30 && s12 == 0) {
	    fprintf(logfp, "%-7s %s, %s", "mov", reg(r1), reg(r2));
	    break;
	}
	if (opcode == 0x30 && s12 < 0) {
	    name= "sub";
	    s12= -s12;
	}
	if (opcode == 0x31 && s12 < 0) {
	    name= "sub4";
	    s12= -s12;
	}
	if (r1 == r2) {
	    fprintf(logfp, "%-7s %s, %d", name, reg(r1), s12);
	    break;
	}
	/*FALL THROUGH*/
    case R_R_S12:
	fprintf(logfp, "%-7s %s, %s, %d", name, reg(r1), reg(r2), s12);
	break;
    case R2R_U6:
	if (r1 == r2) {
	    fprintf(logfp, "%-7s %s, %u", name, reg(r1), u6);
	    break;
	}
	/*FALL THROUGH*/
    case R_R_U6:
	fprintf(logfp, "%-7s %s, %s, %u", name, reg(r1), reg(r2), u6);
	break;
    case R_S12_R:
	if (opcode == 0x4C && s12 == 0) {
	    name= "neg";
	    fprintf(logfp, "%-7s %s, %s", name, reg(r1), reg(r2));
	} else {
	    fprintf(logfp, "%-7s %s, %d, %s", name, reg(r1), s12, reg(r2));
	}
	break;
    case R_RiRaS:
	fprintf(logfp, "%-7s %s, %s%s", name, reg(r1), reg(r2), regoff(r3, s6));
	break;
    case R_RaS:
	fprintf(logfp, "%-7s %s, %s", name, reg(r1), regoff(r2, s12));
	break;
    case PCaS:
	fprintf(logfp, "%-7s [0x"PrW"]", name, pc + s24*4);
	break;
    case R_PCaS:
	fprintf(logfp, "%-7s %s, [0x"PrW"]", name, reg(r1), pc + s18*4);
	break;
    case R_RaU:
	fprintf(logfp, "%-7s %s, %s", name, reg(r1), regoff(r2, u12));
	break;
    case R_U18W:
	fprintf(logfp, "%-7s %s", name, reg(r1));
	if (u18 != 0) fprintf(logfp, ", %u", u18*W);
	break;
    case U18W:
	if (u18 == 0) {
	    fprintf(logfp, "%-7s", name);
	    break;
	}
	fprintf(logfp, "%-7s %u", name, u18*W);
	break;
    case R2R_F12:
	fxt(&fc, op, 12);
	if (r1 == r2) {
	    fprintf(logfp, "%-7s %s, %g", name, reg(r1), fc);
	    break;
	}
	/*FALL THROUGH*/
    case R_R_F12:
	fxt(&fc, op, 12);
	fprintf(logfp, "%-7s %s, %s, %g", name, reg(r1), reg(r2), fc);
	break;
    case R_F12_R:
	fxt(&fc, op, 12);
	if (opcode == 0xAC && u12 == 0x800) {
	    name= "fneg";
	    fprintf(logfp, "%-7s %s, %s", name, reg(r1), reg(r2));
	} else {
	    fprintf(logfp, "%-7s %s, %g, %s", name, reg(r1), fc, reg(r2));
	}
	break;
    case R_F18:
	fxt(&fc, op, 18);
	fprintf(logfp, "%-7s %s, %g", name, reg(r1), fc);
	break;
    case ILL:
	fprintf(logfp, op == 0x44444444UL ? "ill" : "ill.%02X", opcode);
	break;
    case R2R:
	if (r1 == r2) {
	    fprintf(logfp, "%-7s %s", name, reg(r1));
	    break;
	}
	/*FALL THROUGH*/
    case R_R:
	fprintf(logfp, "%-7s %s, %s", name, reg(r1), reg(r2));
	break;
    case R_R_N:
	fprintf(logfp, "%-7s %s, %s, %u", name, reg(r1), reg(r2), u6+1);
	break;
    case R_Ri_N:
	fprintf(logfp, "%-7s %s, [%s], %u", name, reg(r1), reg(r2), u6+1);
	break;
    case CALL:
	fprintf(logfp, "%-7s 0x"PrW, name, pc + s28*4);
	break;
    }
    fputc('\n', logfp);
    prevop= op;
}

#if FWAIT
static fwait_t fw;		/* Asynchronous I/O results. */
#endif
unsigned long instr_count;

static void *getmem(unsw vir, unsw len, int prot)
/* Copy a memory buffer of a task to a memory buffer in emulator memory for
 * monitor calls.  It better not be so long that the TLB can't hold it all.
 * Only presence is required, not read/write permissions.  (This may be used
 * for something that doesn't count as a read or write.)
 */
{
    tlb_t *tp;
    memory phys;
    static unsigned char *buf;
    unsigned char *bp;
    size_t n;

    if ((buf= realloc(buf, len)) == nil) {
	fprintf(stderr, "%s: Can't allocate %lu bytes: %s\n",
	    program, (unsigned long) len, strerror(errno));
	exit(1);
    }

    bp= buf;
    while (len > 0) {
	if (!tlb_chk(&tp, S_DATA, vir, pP)) return nil;
	phys= tlb_v2m(tp, vir);
	n= PAGE_SIZE - (phys & PAGE_MASK);
	if (n > len) n= len;
	vir += n;
	len -= n;
	do *bp++ = umem1(phys++); while (--n > 0);
    }
    bp= buf;
    buf= nil;
    return bp;
}

static void putmem(unsw vir, unsw len, void *buf)
/* Copy a local buffer back to some task's address space.  Use a smaller count
 * if only so much data was changed, zero if none was changed.
 */
{
    tlb_t *tp;
    memory phys;
    unsigned char *bp;
    size_t n;

    bp= buf;
    while (len > 0) {
	if (!tlb_chk(&tp, S_DATA, vir, pP)) return;
	phys= tlb_v2m(tp, vir);
	n= PAGE_SIZE - (phys & PAGE_MASK);
	if (n > len) n= len;
	vir += n;
	len -= n;
	do umem1(phys++) = *bp++; while (--n > 0);
    }
    free(buf);
}

static void monitor(uns4 op)
/* Execute a "monitor call", things that KM code wants the interpreter to do. */
{
    int r1, r2, call;

    r1= (op >> 18) & 077;
    r2= (op >> 12) & 077;
    call= sxt(op, 12);

    switch (call) {
    case -1:{		/* New address space. */
	unsw asid, prot;
	unsw base, size, phys;
	linear_t *lp;

	asid= T.reg[r2+0].u;
	prot= T.reg[r2+1].u;
	base= T.reg[r2+2].u;
	size= T.reg[r2+3].u;
	phys= T.reg[r2+4].u;

	/* Basic checks.  Note that we don't check if physical memory exists,
	 * that's for tlb_miss() to worry about.
	 */
	if (asid >= asid_size
	    || (prot & ~pMASK) != 0
	    || ((base | phys) & PAGE_MASK) != 0
	) {
	    trap(T_INVAL); return;
	}

	lp= &linear[asid];

	if (asid == T.asid[S_CODE]) {
	    /* Running task adjusts its own code space.  Fix PC. */
	    T.pc = T.pc + lp->v2p - phys + base;
#if PC_CACHE
	    pc_expunge();
#endif
	}

	/* Remove any traces of old occupants and initialize the linear part. */
	tlb_expunge(asid);
	lp->base= base;
	lp->size= size;
	lp->prot= (~prot & pMASK);
	lp->v2p= phys - base;
	break;}

    case -2:{		/* Query address space. */
	unsw asid;
	linear_t *lp;

	asid= T.reg[r2+0].u;

	if (asid >= asid_size) { trap(T_INVAL); return; }

	lp= &linear[asid];
	T.reg[r1+0].u = asid;
	T.reg[r1+1].u = (~lp->prot & pMASK);
	T.reg[r1+2].u = lp->base;
	T.reg[r1+3].u = lp->size;
	T.reg[r1+4].u = lp->base + lp->v2p;
	break;}

    case -3:{		/* Load TLB entry. */
	unsw asid, prot;
	unsw vir, phys;
	tlb_t *tp;

	asid= T.reg[r2+0].u;
	prot= T.reg[r2+1].u;
	vir=  T.reg[r2+2].u;
	phys= T.reg[r2+3].u;

	if (asid >= asid_size
	    || (prot & ~pMASK) != 0
	    || ((phys - vir) & PAGE_MASK) != 0
	) {
	    trap(T_INVAL); return;
	}

	tp= &tlb[asid][(vir >> PAGE_BITS) & TPAGE_MASK];
	tp->vir= (vir & ~PAGE_MASK) | (asid << pBITS) | (~prot & pMASK);
	tp->v2m= (mem_base + phys) - vir;
	break;}

    case -4:{		/* Environment item. */
	unsw item;
	static unsw all_items[]= {
	    VERSION, 0, 0, 0, 0, 0,
	    TPAGE_BITS, STALE_SKEW, STALE_BITS, STALE_DEPTH, BIG_ENDIAN
	};

	if (T.reg[r2+0].u < version) version= T.reg[r2+0].u;
	item= T.reg[r2+1].u;
	if (item >= arraysize(all_items)) { trap(T_INVAL); return; }

	all_items[1]= version;
	all_items[2]= dfd;
	all_items[3]= mem_size;
	all_items[4]= mem_phys;
	all_items[5]= asid_size;

	T.reg[r1].u = all_items[item];
	break;}

    case -5:{		/* Random object name byte #i. */
	unsw o, i;
	char *s;
	struct utsname uts;

	o= T.reg[r2+0].u;
	i= T.reg[r2+1].u;

	s= "";
	switch (o) {
	case 0:		/* Disk name. */
	    s= disk;
	    break;
	case 1:		/* O.S. name. */
	    if (uname(&uts) == 0) s= uts.sysname;
	    break;
	default:
	    trap(T_INVAL);
	}
	while (i > 0 && *s != 0) { s++; i--; }

	T.reg[r1].u = * (unsigned char *) s;
	break;}

    case -6:{		/* Environment string #i byte #j. */
	unsw i, j;
	extern char **environ;
	char **epp, *ep;

	i= T.reg[r2+0].u;
	j= T.reg[r2+1].u;

	for (epp= environ; i > 0 && *epp != nil; epp++) {}
	for (ep= *epp == nil ? "" : *epp; j > 0 && *ep != 0; ep++, j--) {}

	T.reg[r1].u = * (unsigned char *) ep;
	break;}

    case -7:		/* Exit. */
	if (tlevel >= 2) {
	    fprintf(logfp, "%lu instructions executed\n", instr_count);
	}
	exit(T.reg[r2+0].i);
	break;

    case -8:		/* Boot: Load a sector from "disk" and run it. */
    case -9:{		/* Load: Load bytes from "disk". */
	unsw pos, vir, phys, count, total;
	memory mem= 0;
	int i, r;
	unsigned char buf[1024];
	linear_t *lp;

	pos= T.reg[r2+0].u;
	vir= T.reg[r2+1].u;
	lp= &linear[T.asid[S_DATA]];

	/* Memory address to load into must be linear and just be present. */
	phys= vir + lp->v2p;
	if ((vir - lp->base) >= lp->size || (lp->prot & pP) != 0) {
	    trap(T_MEMFLT); return;
	}

	if (call == -8) {
	    /* A bootstrap load is one sector to a word aligned address. */
	    if (call == -8 && !aligned(vir, W)) break;
	    count= 512;
	} else {
	    /* Ordinary load has a byte count. */
	    count= T.reg[r2+2].u;
	}

	total= 0;
	while (count > 0) {
	    /* How many bytes can we move without problems? */
	    r= PAGE_SIZE - (phys & PAGE_MASK);
	    if (r > sizeof(buf)) r= sizeof(buf);
	    if (r > count) r= count;

	    if (lseek(dfd, (off_t) pos, SEEK_SET) == -1
		|| (r= read(dfd, buf, r)) < 0
	    ) {
		fprintf(stderr, "%s: Can't read at offset %lu of %s: %s\n",
		    program, (unsigned long) pos, disk,
		    strerror(errno));
		exit(1);
	    }
	    if (r == 0) break;

	    /* Copy data to memory, byte swapped if needed. */
	    mem= mem_base + phys;
	    for (i= 0; i < r; i++) umem1(mem+i) = buf[i];
	    phys += r;
	    pos += r;
	    count -= r;
	    total += r;
	}

	if (call == -8) {
	    /* Check stuff then jump to the start of the bootstrap. */
	    char *bad= nil;

	    if (total != 512) {
		bad= "Short read";
	    } else
	    if (umem4(mem) != DISK_MAGIC
		|| umem2(mem+510) != 0xAA55
	    ) {
		bad= "Bad signature";
	    }
	    if (bad != nil) {
		fprintf(stderr, "%s: %s: Can't boot from offset %lu: %s\n",
		    program, disk, (unsigned long) T.reg[r2+0].u, bad);
		exit(1);
	    }
	    T.pc= vir;
	} else {
	    /* Return bytes read. */
	    T.reg[r1+0].u = total;
	}
	break;}

    case -10:{		/* read(fd, buf, len). */
	intw fd;
	unsw vir;
	unsw len;
	char *buf;
	ssize_t r;

	fd= T.reg[r2+0].i;
	vir= T.reg[r2+1].u;
	len= T.reg[r2+2].u;

	if ((buf= getmem(vir, len, pP|pW)) == nil) return;
	r= read(fd, buf, len);
	putmem(vir, r > 0 ? r : 0, buf);
	if (r < 0) r= -errno;

	T.reg[r1+0].i = r;

	break;}

    case -11:{		/* write(fd, buf, len). */
	intw fd;
	unsw vir;
	unsw len;
	char *buf;
	ssize_t r;

	fd= T.reg[r2+0].i;
	vir= T.reg[r2+1].u;
	len= T.reg[r2+2].u;

	if ((buf= getmem(vir, len, pP|pW)) == nil) return;
	r= write(fd, buf, len);
	putmem(vir, 0, buf);
	if (r < 0) r= -errno;

	T.reg[r1+0].i = r;

	break;}

    default:
	trap(T_ILLINS);
    }
}

#if XXX
static void showdouble(flt8 d)
/* Show a double precision float, bit by bit. */
{
    int b;

    printf("%+11.3e ", d);

    for (b= 63; b >= 0; b--) {
	printf("%d", (int) ((((uns4*)&d)[b/32] >> (b%32)) & 1));

	if (b == 63) fputc(' ', stdout);

	if (b == 52) printf(" %d ", (((uns4*)&d)[1] & 0x7FF00000UL) != 0);
    }
    printf("\n");
}
#endif

/* Double precision float equal to 1 << (n), with n <= 62. */
#define db(n)	((flt8) (1UL << ((n)/2)) * (flt8) (1UL << (((n)+1)/2)))

static flt8 ftrunc(volatile flt8 d)
{
    /* Truncate a double precision float.  (Round to zero). */
    unsigned e;

#if M == 4
    e= (((uns4*)&d)[H] >> 20) & 0x7FF;		/* Biased Exponent. */

    if (e <  0 + 0x3FF) {	/* d < 1.0, truncate to �0.0. */
	((uns4*)&d)[L]= 0;
	((uns4*)&d)[H] &= 0x80000000UL;
    } else
    if (e < 20 + 0x3FF) {	/* d < (1<<20), truncate high bits. */
	((uns4*)&d)[L]= 0;
	((uns4*)&d)[H] &= 0x80000000UL | ~(0x000FFFFFUL >> (e - ( 0+0x3FF)));
    } else
    if (e < 52 + 0x3FF) {	/* d < (1<<52), truncate low bits. */
	((uns4*)&d)[L] &= ~(0xFFFFFFFFUL >> (e - (20+0x3FF)));
    } else {
	/* Too big to have bits to the right of the decimal point. */
    }
#else
    e= ((*(uns8*)&d) >> 52) & 0x7FF;		/* Biased Exponent. */

    if (e <  0 + 0x3FF) {	/* d < 1.0, truncate to �0.0. */
	(*(uns8*)&d) &= ULL(0x8000000000000000);
    } else
    if (e < 52 + 0x3FF) {	/* d < (1<<52), truncate some bits. */
	(*(uns8*)&d) &= ULL(0x8000000000000000)
			| ~(ULL(0x000FFFFFFFFFFFFF) >> (e - (0+0x3FF)));
    } else {
	/* Too big to have bits to the right of the decimal point. */
    }
#endif
    return d;
}

static intw itrunc(volatile flt8 d)
{
    /* Truncate and convert to integer. */

#if W == 4
    /* Overflow? */
    if ((((uns4*)&d)[H] & 0x7FF00000UL) > ((30+0x3FF) << 20)) {
	return 0x80000000UL;
    }

    /* Truncate and force bits we want down to the low word. */
    d = ftrunc(d) + (db(51) + db(52));
    return ((int4*)&d)[L];
#else
    unsigned e;
    int8 w;

    e= ((*(uns8*)&d) >> 52) & 0x7FF;		/* Biased Exponent. */

    if (e <  0 + 0x3FF) {	/* d < 1.0, truncate to 0. */
	w= 0;
    } else
    if (e < 63 + 0x3FF) {	/* d < (1<<63), grab and shift mantissa. */
	w= (*(uns8*)&d) & ULL(0x000FFFFFFFFFFFFF);
	w |= ULL(0x0010000000000000);		/* hidden integer */
	if (e <= 52 + 0x3FF) {
	    w >>= (52 + 0x3FF) - e;		/* shift down and truncate */
	} else {
	    w <<= e - (52 + 0x3FF);		/* shift up */
	}
	if ((*(int8*)&d) < 0) w= -w;
    } else {			/* Overflow. */
	w= ULL(0x8000000000000000);
    }
    return w;
#endif
}

static unsw utrunc(volatile flt8 d)
{
    /* Truncate and convert to unsigned integer. */

#if W == 4
    /* Overflow? */
    if ((((uns4*)&d)[H] & 0x7FF00000UL) > ((31+0x3FF) << 20)) {
	return 0xFFFFFFFFUL;
    }

    /* Truncate and force bits we want down to the low word. */
    d = ftrunc(d) + (db(51) + db(52));
    return ((uns4*)&d)[L];
#else
    unsigned e;
    uns8 w;

    e= ((*(uns8*)&d) >> 52) & 0x7FF;		/* Biased Exponent. */

    if (e <  0 + 0x3FF) {	/* d < 1.0, truncate to 0. */
	w= 0;
    } else
    if (e < 64 + 0x3FF) {	/* d < (1<<64), grab and shift mantissa. */
	w= (*(uns8*)&d) & ULL(0x000FFFFFFFFFFFFF);
	w |= ULL(0x0010000000000000);		/* hidden integer */
	if (e <= 52 + 0x3FF) {
	    w >>= (52 + 0x3FF) - e;		/* shift down and truncate */
	} else {
	    w <<= e - (52 + 0x3FF);		/* shift up */
	}
	if ((*(int8*)&d) < 0) w= -w;
    } else {			/* Overflow. */
	w= ULL(0x8000000000000000);
    }
    return w;
#endif
}

static flt8 fround(volatile flt8 d)
{
    /* Round a double precision float.  (Round to nearest or even). */
    static flt8 magic= db(52);

#if M == 4
    /* Remove the sign bit. */
    uns4 s= ((uns4*)&d)[H] & 0x80000000UL;
    ((uns4*)&d)[H] -= s;

    /* Add magic to numbers smaller than (1<<52) to cause rounding. */
    if (((uns4*)&d)[H] < ((52 + 0x3FF) << 20)) {
	d += magic;
	d -= magic;
    }

    /* Restore the sign bit. */
    ((uns4*)&d)[H] |= s;
#else
    /* Remove the sign bit. */
    uns8 s= (*(uns8*)&d) & ULL(0x8000000000000000);
    (*(uns8*)&d) -= s;

    /* Add magic to numbers smaller than (1<<52) to cause rounding. */
    if ((*(uns8*)&d) < ((uns8) (52 + 0x3FF) << 52)) {
	d += magic;
	d -= magic;
    }

    /* Restore the sign bit. */
    (*(uns8*)&d) |= s;
#endif
    return d;
}

#if BIG_ENDIAN
static void copy(memory dst, memory src, unsw cnt)
{
    if ((dst | src | cnt) & (W-1)) {
	/* Not word aligned.  Painfully copy byte by byte. */
	if (dst < src) {
	    do {
		umem1(dst++) = umem1(src++);
	    } while (--cnt > 0);
	} else {
	    dst += cnt;
	    src += cnt;
	    do {
		umem1(--dst) = umem1(--src);
	    } while (--cnt > 0);
	}
    } else {
	/* Word aligned, so no byte order trickery. */
	memmove(&umemw(dst), &umemw(src), cnt);
    }
}

static void fill(memory dst, unsw byte, unsw cnt)
{
    if ((dst | cnt) & (W-1)) {
	/* Not word aligned.  Painfully fill byte by byte. */
	do {
	    umem1(dst++) = byte;
	} while (--cnt > 0);
    } else {
	/* Word aligned, so no byte order trickery. */
	memset(&umemw(dst), byte, cnt);
    }
}

static memory scan(memory src, unsw byte, unsw cnt)
{
    /* Look for a byte in a memory area a byte at a time. */
    do {
	if (umem1(src) == (uns1) byte) return src;
	src++;
    } while (--cnt > 0);
    return 0;
}
#endif

#if LITTLE_ENDIAN
#define copy(dst, src, cnt)	memmove(&umem1(dst), &umem1(src), (cnt))
#define fill(dst, byte, cnt)	memset(&umem1(dst), (byte), (cnt))
#define scan(src, byte, cnt)	((memory) memchr(&umem1(src), (byte), (cnt)))
#endif

static void run(void)
{
    uns4 op;		/* Next opcode. */
    int r1, r2, r3;	/* Register fields (except little used r4). */

    for (;;) {		/* Main loop of the interpreter. */
    run:
	{
	    unsw pc= T.pc;
#if PC_CACHE
	    T.pc= pc + 4;
	    if (!pc_chk(pc)) goto run;
	    op= umem4(pc_v2m(pc));
#else
	    tlb_t *tp;

	    T.pc= pc + 4;
	    if (!tlb_chk(&tp, S_CODE, pc, pP|pX)) goto run;
	    op= umem4(tlb_v2m(tp, pc));
#endif
	}

#if FWAIT
	if (fw.fw_flags == 0) think= think_io= 1;
#endif
	if (think) {
	    /* Interpreter tracing? */
	    if (tlevel >= 2) {
		instr_count++;
		if (tlevel >= 3) trace(op);
		think= 1;
	    }

	    /* Task being traced by another? */
	    if (T.flags & F_(T_TRACE)) {
		if (T.flags & F_(T_STEP)) {
		    /* Single step trap active. */
		    trap(T_TRACE);
		    goto run;
		}
		/* This instruction may execute, the next is trapped. */
		T.flags |= F_(T_STEP);
		think= 1;
	    }
	}

	r1= (op >> 18) & 077;
	r2= (op >> 12) & 077;
	r3= (op >>  6) & 077;

	switch (op >> 24) {
	case 0x00:		/*	jmp	s24*4		*/
	    T.pc += jxt(op, 24);
	    break;

	case 0x01:		/*	jl	%r1, s18*4	*/
	    if (T.reg[r1].i < 0) T.pc += jxt(op, 18);
	    break;

	case 0x02:		/*	jg	%r1, s18*4	*/
	    if (T.reg[r1].i > 0) T.pc += jxt(op, 18);
	    break;

	case 0x03:		/*	jle	%r1, s18*4	*/
	    if (T.reg[r1].i <= 0) T.pc += jxt(op, 18);
	    break;

	case 0x04:		/*	jge	%r1, s18*4	*/
	    if (T.reg[r1].i >= 0) T.pc += jxt(op, 18);
	    break;

	case 0x05:		/*	je	%r1, s18*4	*/
	    if (T.reg[r1].i == 0) T.pc += jxt(op, 18);
	    break;

	case 0x06:		/*	jne	%r1, s18*4	*/
	    if (T.reg[r1].i != 0) T.pc += jxt(op, 18);
	    break;

	case 0x07:{		/*	jmp	[s24*4]		*/
	    tlb_t *tp;
	    unsw pc;

	    pc= T.pc + jxt(op, 24);
	    if (W > 4 && !aligned(pc, W)) goto run;
	    if (!tlb_chk(&tp, S_CODE, pc, pP|pX)) goto run;
	    pc += umemw(tlb_v2m(tp, pc));
	    if (!aligned(pc, 4)) goto run;
	    T.pc= pc;
	    break;}

	case 0x08:{		/*	jmp	%r1		*/
	    unsw pc= T.reg[r1].u;
	    if (!aligned(pc, 4)) goto run;
	    T.pc= pc;
	    break;}

	case 0x6B:{		/*	jmp	(s18*4)[%r1]	*/
	    tlb_t *tp;
	    unsw pc;

	    pc= T.pc + jxt(op, 18) + (T.reg[r1].u * 4);
	    if (!tlb_chk(&tp, S_CODE, pc, pP|pX)) goto run;
	    pc += imem4(tlb_v2m(tp, pc));
	    if (!aligned(pc, 4)) goto run;
	    T.pc= pc;
	    break;}

	case 0x09:{		/*	call	[s24*4]		*/
	    tlb_t *tp;
	    unsw pc;
	    unsw sp= T.sp - W;

	    pc= T.pc + jxt(op, 24);
	    if (W > 4 && !aligned(pc, W)) goto run;
	    if (!tlb_chk(&tp, S_CODE, pc, pP|pX)) goto run;
	    pc += umemw(tlb_v2m(tp, pc));
	    if (!aligned(pc, 4)) goto run;
	    if (!aligned(sp, W)) goto run;
	    if (!tlb_chk(&tp, S_DATA, sp, pP|pW)) goto run;
	    umemw(tlb_v2m(tp, sp))= T.pc;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0A:{		/*	call	%r1		*/
	    tlb_t *tp;
	    unsw pc= T.reg[r1].u;
	    unsw sp= T.sp - W;

	    if (!aligned(pc, 4)) goto run;
	    if (!aligned(sp, W)) goto run;
	    if (!tlb_chk(&tp, S_DATA, sp, pP|pW)) goto run;
	    umemw(tlb_v2m(tp, sp))= T.pc;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	case 0x0B:{		/*	mov	%r1, %r2, %r3, %r4	*/
	    unsw t= T.reg[zxt(op, 6)].u;
	    T.reg[r1].u = T.reg[r3].u;
	    T.reg[r2].u = t;
	    break;}

	case 0x0C:		/*	mov	%r1, s18	*/
	    T.reg[r1].u = sxt(op, 18);
	    break;

	case 0x0D:		/*	add	%r1, %fp, s18	*/
	    T.reg[r1].u = T.fp + sxt(op, 18);
	    break;

	case 0x0E:		/*	add	%r1, %sp, s18	*/
	    T.reg[r1].u = T.sp + sxt(op, 18);
	    break;

	case 0x0F:		/*	add	%r1, %r1, s18	*/
	    T.reg[r1].u += sxt(op, 18);
	    break;

	case 0x1B:		/*	add4	%r1, %r2, %r3	*/
#if W > 4
	    T.reg[r1].u = (uns4)(T.reg[r2].u4[L] + T.reg[r3].u4[L]);
	    break;
#endif
	case 0x10:		/*	add	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u + T.reg[r3].u;
	    break;

	case 0x1C:		/*	sub4	%r1, %r2, %r3	*/
#if W > 4
	    T.reg[r1].u = (uns4)(T.reg[r2].u4[L] - T.reg[r3].u4[L]);
	    break;
#endif
	case 0x11:		/*	sub	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u - T.reg[r3].u;
	    break;

	case 0x12:		/*	and	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u & T.reg[r3].u;
	    break;

	case 0x2B:		/*	andn	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u & ~T.reg[r3].u;
	    break;

	case 0x13:		/*	or	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u | T.reg[r3].u;
	    break;

	case 0x14:		/*	xor	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u ^ T.reg[r3].u;
	    break;

	case 0x1D:		/*	mul4	%r1, %r2, %r3	*/
#if W > 4
	    T.reg[r1].u = (uns4)(T.reg[r2].u4[L] * T.reg[r3].u4[L]);
	    break;
#endif
	case 0x15:		/*	mul	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u * T.reg[r3].u;
	    break;

	case 0x16:		/*	divu	%r1, %r2, %r3	*/
	    if (T.reg[r3].u == 0) {
		T.reg[r1].u = -1;
		if (T.flags & F_(T_IDIVZ)) trap(T_IDIVZ);
		break;
	    }
	    T.reg[r1].u = T.reg[r2].u / T.reg[r3].u;
	    break;

	case 0x17:		/*	divs	%r1, %r2, %r3	*/
	    if (T.reg[r3].i == 0) {
		T.reg[r1].u = (unsw) 1 << (W*8-1);
		if (T.flags & F_(T_IDIVZ)) trap(T_IDIVZ);
		break;
	    }
	    T.reg[r1].i = T.reg[r2].i / T.reg[r3].i;
	    break;

	case 0x2C:		/*	remu	%r1, %r2, %r3	*/
	    if (T.reg[r3].u == 0) {
		T.reg[r1].u = 0;
		if (T.flags & F_(T_IDIVZ)) trap(T_IDIVZ);
		break;
	    }
	    T.reg[r1].u = T.reg[r2].u % T.reg[r3].u;
	    break;

	case 0x2D:		/*	rems	%r1, %r2, %r3	*/
	    if (T.reg[r3].i == 0) {
		T.reg[r1].u = 0;
		if (T.flags & F_(T_IDIVZ)) trap(T_IDIVZ);
		break;
	    }
	    T.reg[r1].i = T.reg[r2].i % T.reg[r3].i;
	    break;

	case 0x3E:		/*	sal4	%r1, %r2, %r3	*/
#if W > 4
	    T.reg[r1].i = (int4)(T.reg[r2].i4[L] << T.reg[r3].u);
	    break;
#endif
	case 0x20:		/*	shl4	%r1, %r2, %r3	*/
#if W > 4
	    T.reg[r1].u = (uns4)(T.reg[r2].u4[L] << T.reg[r3].u);
	    break;
#endif
	case 0x18:		/*	shl	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u << T.reg[r3].u;
	    break;

	case 0x19:		/*	shr	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u >> T.reg[r3].u;
	    break;

	case 0x3F:		/*	sar4	%r1, %r2, %r3	*/
#if W > 4
	    T.reg[r1].i = T.reg[r2].i4[L] >> T.reg[r3].u;
	    break;
#endif
	case 0x1A:		/*	sar	%r1, %r2, %r3	*/
	    T.reg[r1].i = T.reg[r2].i >> T.reg[r3].u;
	    break;

	case 0x2E:		/*	bic	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u & ~((unsw) 1 << T.reg[r3].u);
	    break;

	case 0x2F:		/*	bis	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u | ((unsw) 1 << T.reg[r3].u);
	    break;

	case 0x3B:		/*	bix	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u ^ ((unsw) 1 << T.reg[r3].u);
	    break;

	case 0x5C:		/*	bit	%r1, %r2, %r3	*/
	    T.reg[r1].u = (T.reg[r2].u >> T.reg[r3].u) & 1;
	    break;

	case 0x21:		/*	cmpa	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u > T.reg[r3].u;
	    break;

	case 0x22:		/*	cmpbe	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u <= T.reg[r3].u;
	    break;

	case 0x25:		/*	cmpg	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].i > T.reg[r3].i;
	    break;

	case 0x26:		/*	cmple	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].i <= T.reg[r3].i;
	    break;

	case 0x28:		/*	cmpe	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u == T.reg[r3].u;
	    break;

	case 0x29:		/*	cmpne	%r1, %r2, %r3	*/
	    T.reg[r1].u = T.reg[r2].u != T.reg[r3].u;
	    break;

	case 0x2A:		/*	cmov	%r1, %r2, %r3, %r4	*/
	    T.reg[r1].u = T.reg[r2].u != 0 ? T.reg[r3].u : T.reg[zxt(op, 6)].u;
	    break;

	case 0x31:		/*	add4	%r1, %r2, s12	*/
#if W > 4
	    T.reg[r1].u = (uns4)(T.reg[r2].u4[L] + sxt(op, 12));
	    break;
#endif
	case 0x30:		/*	add	%r1, %r2, s12	*/
	    T.reg[r1].u = T.reg[r2].u + sxt(op, 12);
	    break;

	case 0x32:		/*	and	%r1, %r2, s12	*/
	    T.reg[r1].u = T.reg[r2].u & sxt(op, 12);
	    break;

	case 0x33:		/*	or	%r1, %r2, s12	*/
	    T.reg[r1].u = T.reg[r2].u | sxt(op, 12);
	    break;

	case 0x34:		/*	xor	%r1, %r2, s12	*/
	    T.reg[r1].u = T.reg[r2].u ^ sxt(op, 12);
	    break;

	case 0x23:		/*	mul4	%r1, %r2, s12	*/
#if W > 4
	    T.reg[r1].u = (uns4)(T.reg[r2].u4[L] * sxt(op, 12));
	    break;
#endif
	case 0x35:		/*	mul	%r1, %r2, s12	*/
	    T.reg[r1].u = T.reg[r2].u * sxt(op, 12);
	    break;

	case 0x36:{		/*	divu	%r1, %r2, s12	*/
	    intw c = sxt(op, 12);

	    if (c == 0) {
		T.reg[r1].u = -1;
		if (T.flags & F_(T_IDIVZ)) trap(T_IDIVZ);
		break;
	    }
	    T.reg[r1].u = T.reg[r2].u / c;
	    break;}

	case 0x37:{		/*	divs	%r1, %r2, s12	*/
	    intw c = sxt(op, 12);

	    if (c == 0) {
		T.reg[r1].u = (unsw) 1 << (W*8-1);
		if (T.flags & F_(T_IDIVZ)) trap(T_IDIVZ);
		break;
	    }
	    T.reg[r1].i = T.reg[r2].i / c;
	    break;}

	case 0x58:{		/*	remu	%r1, %r2, s12	*/
	    intw c = sxt(op, 12);

	    if (c == 0) {
		T.reg[r1].u = 0;
		if (T.flags & F_(T_IDIVZ)) trap(T_IDIVZ);
		break;
	    }
	    T.reg[r1].u = T.reg[r2].u % c;
	    break;}

	case 0x59:{		/*	rems	%r1, %r2, s12	*/
	    intw c = sxt(op, 12);

	    if (c == 0) {
		T.reg[r1].u = 0;
		if (T.flags & F_(T_IDIVZ)) trap(T_IDIVZ);
		break;
	    }
	    T.reg[r1].i = T.reg[r2].i % c;
	    break;}

	case 0x40:		/*	sal4	%r1, %r2, u6	*/
#if W > 4
	    T.reg[r1].i = (int4)(T.reg[r2].i4[L] << zxt(op, 6));
	    break;
#endif
	case 0x24:		/*	shl4	%r1, %r2, u6	*/
#if W > 4
	    T.reg[r1].u = (uns4)(T.reg[r2].u4[L] << zxt(op, 6));
	    break;
#endif
	case 0x38:		/*	shl	%r1, %r2, u6	*/
	    T.reg[r1].u = T.reg[r2].u << zxt(op, 6);
	    break;

	case 0x39:		/*	shr	%r1, %r2, u6	*/
	    T.reg[r1].u = T.reg[r2].u >> zxt(op, 6);
	    break;

	case 0x43:		/*	sar4	%r1, %r2, u6	*/
#if W > 4
	    T.reg[r1].i = T.reg[r2].i4[L] >> zxt(op, 6);
	    break;
#endif
	case 0x3A:		/*	sar	%r1, %r2, u6	*/
	    T.reg[r1].i = T.reg[r2].i >> zxt(op, 6);
	    break;

	case 0x5D:		/*	bic	%r1, %r2, u6	*/
	    T.reg[r1].u = T.reg[r2].u & ~((unsw) 1 << zxt(op, 6));
	    break;

	case 0x5E:		/*	bis	%r1, %r2, u6	*/
	    T.reg[r1].u = T.reg[r2].u | ((unsw) 1 << zxt(op, 6));
	    break;

	case 0x3C:		/*	bix	%r1, %r2, u6	*/
	    T.reg[r1].u = T.reg[r2].u ^ ((unsw) 1 << zxt(op, 6));
	    break;

	case 0x5F:		/*	bit	%r1, %r2, u6	*/
	    T.reg[r1].u = (T.reg[r2].u >> zxt(op, 6)) & 1;
	    break;

	case 0x41:		/*	cmpa	%r1, %r2, s12	*/
	    T.reg[r1].u = T.reg[r2].u > sxt(op, 12);
	    break;

	case 0x42:		/*	cmpbe	%r1, %r2, s12	*/
	    T.reg[r1].u = T.reg[r2].u <= sxt(op, 12);
	    break;

	case 0x45:		/*	cmpg	%r1, %r2, s12	*/
	    T.reg[r1].u = T.reg[r2].i > sxt(op, 12);
	    break;

	case 0x46:		/*	cmple	%r1, %r2, s12	*/
	    T.reg[r1].u = T.reg[r2].i <= sxt(op, 12);
	    break;

	case 0x48:		/*	cmpe	%r1, %r2, s12	*/
	    T.reg[r1].u = T.reg[r2].u == sxt(op, 12);
	    break;

	case 0x49:		/*	cmpne	%r1, %r2, s12	*/
	    T.reg[r1].u = T.reg[r2].u != sxt(op, 12);
	    break;

	case 0x4A:		/*	cmovt	%r1, %r2, s12	*/
	    if (T.reg[r2].u != 0) T.reg[r1].u = sxt(op, 12);
	    break;

	case 0x4B:		/*	cmovf	%r1, %r2, s12	*/
	    if (T.reg[r2].u == 0) T.reg[r1].u = sxt(op, 12);
	    break;

	case 0x27:		/*	sub4	%r1, s12, %r2	*/
#if W > 4
	    T.reg[r1].u = (uns4)(sxt(op, 12) - T.reg[r2].u4[L]);
	    break;
#endif
	case 0x4C:		/*	sub	%r1, s12, %r2	*/
	    T.reg[r1].u = sxt(op, 12) - T.reg[r2].u;
	    break;

	case 0x4D:		/*	cjne	%r1, %r2, address	*/
	    if (T.reg[r1].u != T.reg[r2].u) T.pc += bjxt(op, 12);
	    break;

	case 0x4E:{		/*	bswap	%r1, %r2, u6	*/
	    unsw s;

	    s= T.reg[r2].u;
#if W == 4
	    s= ((s >> 24) & 0x000000FF)
	     | ((s >>  8) & 0x0000FF00)
	     | ((s <<  8) & 0x00FF0000)
	     | ((s << 24) & 0xFF000000);
#else
	    s= ((s >> 56) & ULL(0x00000000000000FF))
	     | ((s >> 40) & ULL(0x000000000000FF00))
	     | ((s >> 24) & ULL(0x0000000000FF0000))
	     | ((s >>  8) & ULL(0x00000000FF000000))
	     | ((s <<  8) & ULL(0x000000FF00000000))
	     | ((s << 24) & ULL(0x0000FF0000000000))
	     | ((s << 40) & ULL(0x00FF000000000000))
	     | ((s << 56) & ULL(0xFF00000000000000));
#endif
	    T.reg[r1].u = s >> zxt(op, 6);
	    break;}

	case 0x5A:		/*	adc	%r1, %r2, %r3, %r4	*/
	    T.reg[r1].u = T.reg[r2].u + T.reg[r3].u + (T.reg[zxt(op, 6)].u & 1);
	    break;

	case 0x50:{		/*	adcc	%r1, %r2, %r3, %r4	*/
	    unsw s = T.reg[r2].u + T.reg[r3].u;
	    T.reg[r1].u = s < T.reg[r2].u
			|| (s + (T.reg[zxt(op, 6)].u & 1)) < s;
	    break;}

	case 0x5B:		/*	sbb	%r1, %r2, %r3, %r4	*/
	    T.reg[r1].u = T.reg[r2].u - T.reg[r3].u - (T.reg[zxt(op, 6)].u & 1);
	    break;

	case 0x51:{		/*	sbbb	%r1, %r2, %r3, %r4	*/
	    unsw s = T.reg[r2].u - T.reg[r3].u;
	    T.reg[r1].u = T.reg[r2].u < T.reg[r3].u
			|| s < (T.reg[zxt(op, 6)].u & 1);
	    break;}

	case 0x52:{		/*	mulh	%r1, %r2, %r3	*/
#if has_int(2*W)
	    T.reg[r1].u = ((unsdw) T.reg[r2].u * (unsdw) T.reg[r3].u) >> (W*8);
#else
	    unsw r2h = T.reg[r2].u >> (W/2*8);
	    unsw r2l = T.reg[r2].u & (((unsw) -1) >> (W/2*8));
	    unsw r3h = T.reg[r3].u >> (W/2*8);
	    unsw r3l = T.reg[r3].u & (((unsw) -1) >> (W/2*8));
	    unsw hl, lh, middle;
	    unsw ml, mh;

	    ml = r2l * r3l;
	    mh = r2h * r3h;
	    hl = r2h * r3l;
	    lh = r2l * r3h;

	    mh += (hl >> (W/2*8)) + (lh >> (W/2*8));
	    hl &= (((unsw) -1) >> (W/2*8));
	    lh &= (((unsw) -1) >> (W/2*8));

	    middle = hl + lh + (ml >> (W/2*8));
    if(0)   ml &= ((unsw) -1) >> (W/2*8);
    if(0)   ml += middle << (W/2*8);
	    mh += middle >> (W/2*8);
	    T.reg[r1].u = mh;
#endif
	    break;}

	case 0x53:{		/*	addo	%r1, %r2, %r3	*/
	    unsw w2, w3;
	    unsw r;

	    w2= T.reg[r2].u;
	    w3= T.reg[r3].u;
	    T.reg[r1].u = r= w2 + w3;
	    if (T.flags & F_(T_IOVFL)) {
		if ((((~(w2 | w3) & r) | (w2 & w3 & ~r)) >> (W*8-1)) != 0) {
		    trap(T_IOVFL);
		}
	    }
	    break;}

	case 0x54:{		/*	subo	%r1, %r2, %r3	*/
	    unsw w2, w3;
	    unsw r;

	    w2= T.reg[r2].u;
	    w3= T.reg[r3].u;
	    T.reg[r1].u = r= w2 - w3;
	    if (T.flags & F_(T_IOVFL)) {
		if ((((~w2 & w3 & r) | (w2 & ~(w3 | r))) >> (W*8-1)) != 0) {
		    trap(T_IOVFL);
		}
	    }
	    break;}

	case 0x55:{		/*	mulo	%r1, %r2, %r3	*/
	    unsw w2, w3;
	    unsw ar, aw2, aw3;

	    w2= T.reg[r2].u;
	    w3= T.reg[r3].u;
	    T.reg[r1].u = w2 * w3;

	    if (T.flags & F_(T_IOVFL)) {
		if (w2 > 1 && w3 > 1) {
		    aw2= (w2 >> (W*8-1)) ? -w2 : w2;
		    aw3= (w3 >> (W*8-1)) ? -w3 : w3;
		    ar= aw2 * aw3;
		    if (ar > (((unsw) -1 >> 1) + ((w2 ^ w3) >> (W*8-1)))
					    || ar / aw2 != aw3) {
			trap(T_IOVFL);
		    }
		}
	    }
	    break;}

	case 0x56:{		/*	zxt	%r1, %r2, u6	*/
	    int s= W*8 - zxt(op, 6);

	    T.reg[r1].u = (T.reg[r2].u << s) >> s;
	    break;}

	case 0x57:{		/*	sxt	%r1, %r2, u6	*/
	    int s= W*8 - zxt(op, 6);

	    T.reg[r1].i = (T.reg[r2].i << s) >> s;
	    break;}

	case 0x3D:{		/*	sxto	%r1, %r2, u6	*/
	    int s= W*8 - zxt(op, 6);
	    intw w;

	    w= T.reg[r2].i;
	    T.reg[r1].i = (w << s) >> s;
	    if (T.flags & F_(T_IOVFL)) {
		if (T.reg[r1].i != w) trap(T_IOVFL);
	    }
	    break;}

	case 0x60:{		/*	ld8	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 8);
	    if (W != 8 && !aligned(addr, W)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    if (W == 8) {
		if (aligned0(addr, W)) {
		    T.reg[r1].u = umemw(tlb_v2m(tp, addr));
		} else {
		    unsigned s = addr & (W-1);
		    unsw w;

		    addr -= s;
		    s *= 8;
		    w = umemw(tlb_v2m(tp, addr)) >> s;
		    addr += W;
		    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
		    T.reg[r1].u = w | (umemw(tlb_v2m(tp, addr)) << (W*8 - s));
		}
	    } else {
		unsw w0= umemw(tlb_v2m(tp, addr));
		addr += W;
		if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
		T.reg[r1+0].u = w0;
		T.reg[r1+1].u = umemw(tlb_v2m(tp, addr));
	    }
	    break;}

	case 0x61:{		/*	st8	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 8);
	    if (!aligned(addr, W)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
	    umemw(tlb_v2m(tp, addr))= T.reg[r1].u;
	    if (W < 8) {
		addr += W;
		if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
		umemw(tlb_v2m(tp, addr))= T.reg[r1+1].u;
	    }
	    break;}

#if W > 4
	case 0x62:{		/*	ld4u	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 4);
	    if (!aligned(addr, 4)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    T.reg[r1].u = umem4(tlb_v2m(tp, addr));
	    break;}
#else
	case 0x62:		/*	ld4u	%r1, %r2[%r3+s6]	*/
#endif
	case 0x63:{		/*	ld4s	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 4);
	    if (W != 4 && !aligned(addr, 4)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    if (W != 4 || aligned0(addr, W)) {
		T.reg[r1].i = imem4(tlb_v2m(tp, addr));
	    } else {
		unsigned s = addr & (W-1);
		unsw w;

		addr -= s;
		s *= 8;
		w = umemw(tlb_v2m(tp, addr)) >> s;
		addr += W;
		if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
		T.reg[r1].u = w | (umemw(tlb_v2m(tp, addr)) << (W*8 - s));
	    }
	    break;}

	case 0x64:{		/*	st4	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 4);
	    if (!aligned(addr, 4)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
	    umem4(tlb_v2m(tp, addr))= T.reg[r1].u;
	    break;}

	case 0x65:{		/*	ld2u	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 2);
	    if (!aligned(addr, 2)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    T.reg[r1].u = umem2(tlb_v2m(tp, addr));
	    break;}

	case 0x66:{		/*	ld2s	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 2);
	    if (!aligned(addr, 2)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    T.reg[r1].i = imem2(tlb_v2m(tp, addr));
	    break;}

	case 0x67:{		/*	st2	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 2);
	    if (!aligned(addr, 2)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
	    umem2(tlb_v2m(tp, addr))= T.reg[r1].u;
	    break;}

	case 0x68:{		/*	ld1u	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 1);
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    T.reg[r1].u = umem1(tlb_v2m(tp, addr));
	    break;}

	case 0x69:{		/*	ld1s	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 1);
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    T.reg[r1].i = imem1(tlb_v2m(tp, addr));
	    break;}

	case 0x6A:{		/*	st1	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 1);
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
	    umem1(tlb_v2m(tp, addr))= T.reg[r1].u;
	    break;}

	case 0x6C:{		/*	ld8	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + sxt(op, 12);
	    if (W != 8 && !aligned(addr, W)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    if (W == 8) {
		if (aligned0(addr, W)) {
		    T.reg[r1].u = umemw(tlb_v2m(tp, addr));
		} else {
		    unsigned s = addr & (W-1);
		    unsw w;

		    addr -= s;
		    s *= 8;
		    w = umemw(tlb_v2m(tp, addr)) >> s;
		    addr += W;
		    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
		    T.reg[r1].u = w | (umemw(tlb_v2m(tp, addr)) << (W*8 - s));
		}
	    } else {
		unsw w0= umemw(tlb_v2m(tp, addr));
		addr += W;
		if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
		T.reg[r1+0].u = w0;
		T.reg[r1+1].u = umemw(tlb_v2m(tp, addr));
	    }
	    break;}

	case 0x6D:{		/*	st8	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + sxt(op, 12);
	    if (!aligned(addr, W)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
	    umemw(tlb_v2m(tp, addr))= T.reg[r1].u;
	    if (W < 8) {
		addr += W;
		if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
		umemw(tlb_v2m(tp, addr))= T.reg[r1+1].u;
	    }
	    break;}

#if W > 4
	case 0x6E:{		/*	ld4u	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + sxt(op, 12);
	    if (!aligned(addr, 4)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    T.reg[r1].u = umem4(tlb_v2m(tp, addr));
	    break;}
#else
	case 0x6E:		/*	ld4u	%r1, [%r2+s12]	*/
#endif
	case 0x6F:{		/*	ld4s	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + sxt(op, 12);
	    if (W != 4 && !aligned(addr, 4)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    if (W != 4 || aligned0(addr, W)) {
		T.reg[r1].i = imem4(tlb_v2m(tp, addr));
	    } else {
		unsigned s = addr & (W-1);
		unsw w;

		addr -= s;
		s *= 8;
		w = umemw(tlb_v2m(tp, addr)) >> s;
		addr += W;
		if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
		T.reg[r1].u = w | (umemw(tlb_v2m(tp, addr)) << (W*8 - s));
	    }
	    break;}

	case 0x70:{		/*	st4	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + sxt(op, 12);
	    if (!aligned(addr, 4)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
	    umem4(tlb_v2m(tp, addr))= T.reg[r1].u;
	    break;}

	case 0x71:{		/*	ld2u	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + sxt(op, 12);
	    if (!aligned(addr, 2)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    T.reg[r1].u = umem2(tlb_v2m(tp, addr));
	    break;}

	case 0x72:{		/*	ld2s	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + sxt(op, 12);
	    if (!aligned(addr, 2)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    T.reg[r1].i = imem2(tlb_v2m(tp, addr));
	    break;}

	case 0x73:{		/*	st2	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + sxt(op, 12);
	    if (!aligned(addr, 2)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
	    umem2(tlb_v2m(tp, addr))= T.reg[r1].u;
	    break;}

	case 0x74:{		/*	ld1u	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + sxt(op, 12);
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    T.reg[r1].u = umem1(tlb_v2m(tp, addr));
	    break;}

	case 0x75:{		/*	ld1s	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + sxt(op, 12);
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    T.reg[r1].i = imem1(tlb_v2m(tp, addr));
	    break;}

	case 0x76:{		/*	st1	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    addr= T.reg[r2].u + sxt(op, 12);
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
	    umem1(tlb_v2m(tp, addr))= T.reg[r1].u;
	    break;}

	case 0x77:{		/*	lea	%r1, [%pc+s18*4]	*/
	    unsw addr;
	    tlb_t *tp;

	    addr= T.pc + jxt(op, 18);
	    if (!tlb_chk(&tp, S_CODE, addr, pP|pX)) goto run;
	    T.reg[r1].u = addr + umemw(tlb_v2m(tp, addr));
	    break;}

	case 0x78:{		/*	ld8	%r1, [%pc+s18*4]	*/
	    unsw addr;
	    tlb_t *tp;

	    addr= T.pc + jxt(op, 18);
	    if (W > 4 && !aligned(addr, W)) goto run;
	    if (!tlb_chk(&tp, S_CODE, addr, pP|pX)) goto run;
	    if (W == 8) {
		T.reg[r1].u = umemw(tlb_v2m(tp, addr));
	    } else {
		unsw w0= umemw(tlb_v2m(tp, addr));
		addr += W;
		if (!tlb_chk(&tp, S_CODE, addr, pP|pX)) goto run;
		T.reg[r1+0].u = w0;
		T.reg[r1+1].u = umemw(tlb_v2m(tp, addr));
	    }
	    break;}

#if W > 4
	case 0x79:{		/*	ld4u	%r1, [%pc+s18*4]	*/
	    unsw addr;
	    tlb_t *tp;

	    addr= T.pc + jxt(op, 18);
	    if (!tlb_chk(&tp, S_CODE, addr, pP|pX)) goto run;
	    T.reg[r1].u = umem4(tlb_v2m(tp, addr));
	    break;}
#else
	case 0x79:		/*	ld4u	%r1, [%pc+s18*4]	*/
#endif
	case 0x7A:{		/*	ld4s	%r1, [%pc+s18*4]	*/
	    unsw addr;
	    tlb_t *tp;

	    addr= T.pc + jxt(op, 18);
	    if (!tlb_chk(&tp, S_CODE, addr, pP|pX)) goto run;
	    T.reg[r1].i = imem4(tlb_v2m(tp, addr));
	    break;}

	case 0x7B:{		/*	ld	%r1, [%r2], n	*/
	    unsw addr, tst;
	    tlb_t *tp;
	    int n = zxt(op, 6);

	    if (r1 + n >= 64) goto illegal;
	    addr= T.reg[r2].u;
	    if (!aligned(addr, W)) goto run;
	    tst= addr + n*W;
	    if (!tlb_chk(&tp, S_DATA, tst, pP|pR)) goto run;
	    do {
		if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
		T.reg[r1].u = umemw(tlb_v2m(tp, addr));
		r1++;
		addr += W;
	    } while (--n >= 0);
	    break;}

	case 0x7C:{		/*	st	%r1, [%r2], n	*/
	    unsw addr, tst;
	    tlb_t *tp;
	    int n = zxt(op, 6);

	    if (r1 + n >= 64) goto illegal;
	    addr= T.reg[r2].u;
	    if (!aligned(addr, W)) goto run;
	    tst= addr + n*W;
	    if (!tlb_chk(&tp, S_DATA, tst, pP|pW)) goto run;
	    do {
		if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
		umemw(tlb_v2m(tp, addr))= T.reg[r1].u;
		r1++;
		addr += W;
	    } while (--n >= 0);
	    break;}

	case 0x7D:{		/*	copy	%r1, %r2, %r3	*/
	    unsw svir, dvir, addr;
	    memory smem, dmem;
	    unsw cnt, scnt, dcnt;
	    tlb_t *tp;

	    dvir= T.reg[r1].u;
	    svir= T.reg[r2].u;
	    if ((cnt= T.reg[r3].u) == 0) break;

	    /* Destination before or outside source? */
	    if ((dvir - svir) >= cnt) {
		/* Copy forward. */
		if (!tlb_chk(&tp, S_DATA, dvir, pP|pW)) goto run;
		dmem= tlb_v2m(tp, dvir);

		if (!tlb_chk(&tp, S_DATA, svir, pP|pR)) goto run;
		smem= tlb_v2m(tp, svir);

		dcnt= PAGE_SIZE - (dmem & PAGE_MASK);
		scnt= PAGE_SIZE - (smem & PAGE_MASK);
		if (dcnt > scnt) dcnt= scnt;
		if (dcnt > cnt) dcnt= cnt;
		copy(dmem, smem, dcnt);

		T.reg[r1].u = dvir + dcnt;
		T.reg[r2].u = svir + dcnt;
		cnt -= dcnt;
	    } else {
	   	/* Copy backward. */
		dvir += cnt;
		svir += cnt;
		dcnt = dvir - ((dvir - 1) & ~PAGE_MASK);
		if (dcnt > cnt) dcnt= cnt;
		scnt = svir - ((svir - 1) & ~PAGE_MASK);
		if (scnt > dcnt) scnt= dcnt;

		addr= dvir - scnt;
		if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
		dmem= tlb_v2m(tp, addr);

		addr= svir - scnt;
		if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
		smem= tlb_v2m(tp, addr);

		copy(dmem, smem, scnt);
		dvir -= scnt;
		svir -= scnt;
		cnt -= scnt;
	    }
	    if ((T.reg[r3].u = cnt) != 0) T.pc -= 4;	/* Done yet? */
	    break;}

	case 0x7E:{		/*	fill	%r1, %r2, %r3	*/
	    unsw dvir;
	    memory dmem;
	    unsw cnt, dcnt;
	    tlb_t *tp;

	    dvir= T.reg[r1].u;
	    if ((cnt= T.reg[r3].u) == 0) break;

	    if (!tlb_chk(&tp, S_DATA, dvir, pP|pW)) break;
	    dmem= tlb_v2m(tp, dvir);

	    dcnt= PAGE_SIZE - (dmem & PAGE_MASK);
	    if (dcnt > cnt) dcnt= cnt;
	    fill(dmem, T.reg[r2].u, dcnt);

	    T.reg[r1].u = dvir + dcnt;
	    if ((T.reg[r3].u = cnt - dcnt) != 0) T.pc -= 4;  /* Done yet? */
	    break;}

	case 0x7F:{		/*	scan	%r1, %r2, %r3	*/
	    unsw svir;
	    memory smem, place;
	    unsw cnt, scnt;
	    tlb_t *tp;

	    svir= T.reg[r1].u;
	    if ((cnt= T.reg[r3].u) == 0) break;

	    if (!tlb_chk(&tp, S_DATA, svir, pP|pW)) break;
	    smem= tlb_v2m(tp, svir);

	    scnt= PAGE_SIZE - (smem & PAGE_MASK);
	    if (scnt > cnt) scnt= cnt;
	    place= scan(smem, T.reg[r2].u, scnt);

	    if (place == 0) {
	    	/* Not found. */
		T.reg[r1].u = svir + scnt;
		if ((T.reg[r3].u = cnt - scnt) != 0) T.pc -= 4;  /* Done yet? */
	    } else {
	    	/* Found. */
	    	scnt= place - smem;
		T.reg[r1].u = svir + scnt;
		T.reg[r3].u = cnt - scnt;
	    }
	    break;}

	case 0x80:		/*	in8	*/
	case 0x81:		/*	out8	*/
	case 0x82:		/*	in4	*/
	case 0x83:		/*	out4	*/
	case 0x84:		/*	in2	*/
	case 0x85:		/*	out2	*/
	case 0x86:		/*	in1	*/
	case 0x87:		/*	out1	*/
	    /* XXX - Must create pseudo devices here. */
	    goto illegal;

	case 0x88:{		/*	mov	%r1, %sr2	*/
	    unsw w;

	    r2 += 64;

	    w= T.reg[r2].u;
	    if (r2 < FLAGS) {
		/* User special. */
	    } else
	    if (r2 == FLAGS) {
		w= (w & ~T.fmask) | T.ffake;
	    } else
	    if ((T.flags & F_(T_SUPER)) || r2 >= RESV) {
		trap(T_SUPER); goto run;
	    }
	    T.reg[r1].u = w;
	    break;}

	case 0x89:{		/*	mov	%sr1, %r2	*/
	    unsw w;

	    r1 += 64;

	    w= T.reg[r2].u;
	    if (r1 < FLAGS) {
		/* User special. */
	    } else
	    if (r1 == FLAGS) {
		if ((w & T.fmask) != T.ffake) { trap(T_SUPER); goto run; }
		w= (w & ~T.fmask) | (T.flags & T.fmask);
		think= 1;
	    } else
	    if ((T.flags & F_(T_SUPER)) || r1 >= PC) {
		trap(T_SUPER); goto run;
	    }
	    T.reg[r1].u = w;
	    break;}

	case 0x8A:{		/*	enter	%r1, u18	*/
	    unsw sp= T.sp;
	    unsw fp= sp - W;
	    tlb_t *tp;
	    int r;

	    if (r1 > FP) goto illegal;
	    r= FP+1;
	    if (!aligned(sp, W)) goto run;
	    do {
		sp -= W;
		if (!tlb_chk(&tp, S_DATA, sp, pP|pW)) goto run;
		umemw(tlb_v2m(tp, sp))= T.reg[--r].u;
	    } while (r > r1);
	    T.fp= fp;
	    T.sp= sp - zxt(op, 18) * W;
	    break;}

	case 0x8B:{		/*	leave	%r1	*/
	    unsw sp= T.fp - (FP - r1) * W;
	    tlb_t *tp;

	    if (r1 > FP) goto illegal;
	    if (!aligned(sp, W)) goto run;
	    do {
		if (!tlb_chk(&tp, S_DATA, sp, pP|pR)) goto run;
		T.reg[r1++].u = umemw(tlb_v2m(tp, sp));
		sp += W;
	    } while (r1 <= FP);
	    T.sp= sp;
	    break;}

	case 0x8C:{		/*	return	%r1, u18	*/
	    unsw sp;
	    unsw pc;
	    tlb_t *tp;

	    if (r1 > FP) goto illegal;
	    sp= T.fp + W;
	    if (!aligned(sp, W)) goto run;
	    if (!tlb_chk(&tp, S_DATA, sp, pP|pR)) goto run;
	    pc= umemw(tlb_v2m(tp, sp));
	    if (!aligned(pc, 4)) goto run;
	    sp= T.fp - (FP - r1) * W;
	    do {
		if (!tlb_chk(&tp, S_DATA, sp, pP|pR)) goto run;
		T.reg[r1++].u = umemw(tlb_v2m(tp, sp));
		sp += W;
	    } while (r1 <= FP);
	    T.sp= sp + W + zxt(op, 18) * W;
	    T.pc= pc;
	    break;}

	case 0x8D:{		/*	ret	u18	*/
	    unsw sp, pc;
	    tlb_t *tp;

	    sp= T.sp;
	    if (!aligned(sp, W)) goto run;
	    if (!tlb_chk(&tp, S_DATA, sp, pP|pR)) goto run;
	    pc= umemw(tlb_v2m(tp, sp));
	    if (!aligned(pc, 4)) goto run;
	    T.sp= sp + W + zxt(op, 18) * W;
	    T.pc= pc;
	    break;}

	case 0x8E:{		/*	queue	%r1, s18	*/
	    tlb_t *tp;
	    unsw cvir;
	    memory cmem;
	    memory *qp;
	    int q = sxt(op, 18);

	    /* Must run in supervisor mode. */
	    if (T.flags & F_(T_SUPER)) { trap(T_SUPER); goto run; }

	    cvir= T.reg[r1].u;

	    if (q <= 2) {
		/* A context must be present, word aligned and unbroken. */
		if (!aligned(cvir, W)) goto run;
		if (!tlb_chk(&tp, S_DATA, cvir, pP|pR|pW)) goto run;
		cmem= tlb_v2m(tp, cvir);
		cvir += 127;
		if (!tlb_chk(&tp, S_DATA, cvir, pP|pR|pW)) goto run;
		if (tlb_v2m(tp, cvir) != cmem+127) { trap(T_INVAL); goto run; }
	    }

	    switch (q) {
	    case 0:			/* Add to run queue. */
	    case 1:			/* Remove from any queue. */
		/* Can't work on myself. */
		if (cmem == context) { trap(T_INVAL); goto run; }

		/* On any queue? */
		for (qp= &runq; *qp != 0 && *qp != cmem; qp= &T(*qp).link) {}
		if (*qp == 0)
		for (qp= &waitq; *qp != 0 && *qp != cmem; qp= &T(*qp).link) {}
		if (*qp == 0)
		for (qp= &faultq; *qp != 0 && *qp != cmem; qp= &T(*qp).link) {}

		if (q == 0) {		/* Enqueue. */
		    /* Should not be queued already. */
		    if (*qp != 0) { trap(T_INVAL); goto run; }

		    /* New %pc is ok? */
		    if (!aligned(T(cmem).pc, 4)) goto run;

		    /* Let's hope it runs. */
		    *(runq == 0 ? &runq : runqt) = cmem;
		    *(runqt= &T(cmem).link) = 0;
		} else {			/* Dequeue. */
		    if (*qp == 0) { trap(T_INVAL); goto run; }
		    *qp= T(cmem).link;
		    if (runqt == &T(cmem).link) runqt= &T(*qp).link;
		    if (waitqt == &T(cmem).link) waitqt= &T(*qp).link;
		    if (faultqt == &T(cmem).link) faultqt= &T(*qp).link;
		}
		break;

	    case 2:			/* Move self. */
		context= cmem;
		break;

	    case 3:			/* Wait for an exception. */
		save_context();
		T(context).info[0]= r1;
		*(waitq == 0 ? &waitq : waitqt) = context;
		*(waitqt= &T(context).link) = 0;
		schedule();
		break;

	    default:
		goto illegal;
	    }
	    break;}

	case 0x8F:{		/*	trap	%r1, %r2, s12	*/
	    int t= sxt(op, 12);

	    if (t < 0) {
		/* Traps with negative numbers are monitor calls. */
		monitor(op);
	    } else {
		/* In user mode one can only use traps >= T_USER. */
		if ((T.flags & F_(T_SUPER)) && t < T_USER) t= T_SUPER;

		/* No more traps than bits in %tmask. */
		if (t >= W*8) t= T_INVAL;

		trap(t);
	    }
	    break;}

	case 0x90:		/*	fadd	%r1, %r2, %r3	*/
	    if (W < 8 && (op & 01010100)) goto illegal;
	    stf8(&T.reg[r1], ldf8(&T.reg[r2]) + ldf8(&T.reg[r3]));
	    break;

	case 0x91:		/*	fsub	%r1, %r2, %r3	*/
	    if (W < 8 && (op & 01010100)) goto illegal;
	    stf8(&T.reg[r1], ldf8(&T.reg[r2]) - ldf8(&T.reg[r3]));
	    break;

	case 0x92:		/*	fmul	%r1, %r2, %r3	*/
	    if (W < 8 && (op & 01010100)) goto illegal;
	    stf8(&T.reg[r1], ldf8(&T.reg[r2]) * ldf8(&T.reg[r3]));
	    break;

	case 0x93:{		/*	fdiv	%r1, %r2, %r3	*/
	    flt8 f3= ldf8(&T.reg[r3]);

	    if (W < 8 && (op & 01010100)) goto illegal;
	    stf8(&T.reg[r1], ldf8(&T.reg[r2]) / f3);
	    if (f3 == 0.0 && (T.flags & F_(T_FDIVZ))) trap(T_FDIVZ);
	    break;}

	case 0x94:{		/*	frem	%r1, %r2, %r3	*/
	    flt8 f2= ldf8(&T.reg[r2]);
	    flt8 f3= ldf8(&T.reg[r3]);

	    if (W < 8 && (op & 01010100)) goto illegal;
	    stf8(&T.reg[r1], f2 - ftrunc(f2 / f3) * f3);
	    if (f3 == 0.0 && (T.flags & F_(T_FDIVZ))) trap(T_FDIVZ);
	    break;}

	case 0x96:		/*	fcmpg	%r1, %r2, %r3	*/
	    if (W < 8 && (op & 00010100)) goto illegal;
	    T.reg[r1].u = ldf8(&T.reg[r2]) > ldf8(&T.reg[r3]);
	    break;

	case 0x97:		/*	fcmple	%r1, %r2, %r3	*/
	    if (W < 8 && (op & 00010100)) goto illegal;
	    T.reg[r1].u = ldf8(&T.reg[r2]) <= ldf8(&T.reg[r3]);
	    break;

	case 0x99:		/*	fcmpe	%r1, %r2, %r3	*/
	    if (W < 8 && (op & 00010100)) goto illegal;
	    T.reg[r1].u = ldf8(&T.reg[r2]) == ldf8(&T.reg[r3]);
	    break;

	case 0x9A:		/*	fcmpne	%r1, %r2, %r3	*/
	    if (W < 8 && (op & 00010100)) goto illegal;
	    T.reg[r1].u = ldf8(&T.reg[r2]) != ldf8(&T.reg[r3]);
	    break;

	case 0x9B:		/*	finsx	%r1, %r2, %r3	*/
	    if (W < 8 && (op & 01010000)) goto illegal;
	    stf8(&T.reg[r1], ldexp(ldf8(&T.reg[r2]), T.reg[r3].i));
	    break;

	case 0xA0:{		/*	fadd	%r1, %r2, f12	*/
	    flt4 fc;
	    if (W < 8 && (op & 01010000)) goto illegal;
	    fxt(&fc, op, 12);
	    stf8(&T.reg[r1], ldf8(&T.reg[r2]) + fc);
	    break;}

	case 0xA1:{		/*	fsub	%r1, %r2, f12	*/
	    flt4 fc;
	    if (W < 8 && (op & 01010000)) goto illegal;
	    fxt(&fc, op, 12);
	    stf8(&T.reg[r1], ldf8(&T.reg[r2]) - fc);
	    break;}

	case 0xA2:{		/*	fmul	%r1, %r2, f12	*/
	    flt4 fc;
	    if (W < 8 && (op & 01010000)) goto illegal;
	    fxt(&fc, op, 12);
	    stf8(&T.reg[r1], ldf8(&T.reg[r2]) * fc);
	    break;}

	case 0xA3:{		/*	fdiv	%r1, %r2, f12	*/
	    flt4 fc;
	    if (W < 8 && (op & 01010000)) goto illegal;
	    fxt(&fc, op, 12);
	    stf8(&T.reg[r1], ldf8(&T.reg[r2]) / fc);
	    if (r3 == 0 && (T.flags & F_(T_FDIVZ))) trap(T_FDIVZ);
	    break;}

	case 0xA4:{{		/*	frem	%r1, %r2, f12	*/
	    flt4 fc;
	    flt8 f2= ldf8(&T.reg[r2]);

	    if (W < 8 && (op & 01010000)) goto illegal;
	    fxt(&fc, op, 12);
	    stf8(&T.reg[r1], f2 - ftrunc(f2 / fc) * fc);
	    if (r3 == 0 && (T.flags & F_(T_FDIVZ))) trap(T_FDIVZ);
	    break;}}

	case 0xA5:{		/*	fcmpl	%r1, %r2, f12	*/
	    flt4 fc;
	    if (W < 8 && (op & 00010000)) goto illegal;
	    fxt(&fc, op, 12);
	    T.reg[r1].u = ldf8(&T.reg[r2]) < fc;
	    break;}

	case 0xA6:{		/*	fcmpg	%r1, %r2, f12	*/
	    flt4 fc;
	    if (W < 8 && (op & 00010000)) goto illegal;
	    fxt(&fc, op, 12);
	    T.reg[r1].u = ldf8(&T.reg[r2]) > fc;
	    break;}

	case 0xA7:{		/*	fcmple	%r1, %r2, f12	*/
	    flt4 fc;
	    if (W < 8 && (op & 00010000)) goto illegal;
	    fxt(&fc, op, 12);
	    T.reg[r1].u = ldf8(&T.reg[r2]) <= fc;
	    break;}

	case 0xA8:{		/*	fcmpge	%r1, %r2, f12	*/
	    flt4 fc;
	    if (W < 8 && (op & 00010000)) goto illegal;
	    fxt(&fc, op, 12);
	    T.reg[r1].u = ldf8(&T.reg[r2]) >= fc;
	    break;}

	case 0xA9:{		/*	fcmpe	%r1, %r2, f12	*/
	    flt4 fc;
	    if (W < 8 && (op & 00010000)) goto illegal;
	    fxt(&fc, op, 12);
	    T.reg[r1].u = ldf8(&T.reg[r2]) == fc;
	    break;}

	case 0xAA:{		/*	fcmpne	%r1, %r2, f12	*/
	    flt4 fc;
	    if (W < 8 && (op & 00010000)) goto illegal;
	    fxt(&fc, op, 12);
	    T.reg[r1].u = ldf8(&T.reg[r2]) != fc;
	    break;}

	case 0xAB:		/*	finsx	%r1, %r2, s12	*/
	    if (W < 8 && (op & 01010000)) goto illegal;
	    stf8(&T.reg[r1], ldexp(ldf8(&T.reg[r2]), sxt(op, 12)));
	    break;

	case 0xAC:{		/*	fsub	%r1, f12, %r2	*/
	    flt4 fc;
	    if (W < 8 && (op & 01010000)) goto illegal;
	    fxt(&fc, op, 12);
	    stf8(&T.reg[r1], fc - ldf8(&T.reg[r2]));
	    break;}

	case 0xAD:{		/*	fdiv	%r1, f12, %r2	*/
	    flt4 fc;
	    flt8 f2= ldf8(&T.reg[r2]);

	    if (W < 8 && (op & 01010000)) goto illegal;
	    fxt(&fc, op, 12);
	    stf8(&T.reg[r1], fc / f2);
	    if (f2 == 0.0 && (T.flags & F_(T_FDIVZ))) trap(T_FDIVZ);
	    break;}

	case 0xB0:{		/*	fmov	%r1, f18	*/
	    flt4 fc;

	    if (W < 8 && (op & 01000000)) goto illegal;
	    fxt(&fc, op, 18);
	    stf8(&T.reg[r1], fc);
	    break;}

	case 0xB1:{		/*	fextx	%r1, %r2	*/
	    int e;

	    if (W < 8 && (op & 00010000)) goto illegal;
	    (void) frexp(ldf8(&T.reg[r2]), &e);
	    T.reg[r1].u = e;
	    break;}

	case 0xB2:		/*	fround	%r1, %r2	*/
	    if (W < 8 && (op & 01010000)) goto illegal;
	    stf8(&T.reg[r1], fround(ldf8(&T.reg[r2])));
	    break;

	case 0xB3:		/*	ftrunc	%r1, %r2	*/
	    if (W < 8 && (op & 01010000)) goto illegal;
	    stf8(&T.reg[r1], ftrunc(ldf8(&T.reg[r2])));
	    break;

	case 0xB5:		/*	fcfi	%r1, %r2	*/
	    if (W < 8 && (op & 00010000)) goto illegal;
	    T.reg[r1].i = itrunc(ldf8(&T.reg[r2]));
	    break;

	case 0xB6:		/*	fcif	%r1, %r2	*/
	    if (W < 8 && (op & 01000000)) goto illegal;
	    stf8(&T.reg[r1], (flt8) T.reg[r2].i);
	    break;

	case 0xB7:		/*	fcfu	%r1, %r2	*/
	    if (W < 8 && (op & 00010000)) goto illegal;
	    T.reg[r1].u = utrunc(ldf8(&T.reg[r2]));
	    break;

	case 0xB8:		/*	fcuf	%r1, %r2	*/
	    if (W < 8 && (op & 01000000)) goto illegal;
	    stf8(&T.reg[r1], (flt8) T.reg[r2].u);
	    break;

	case 0xB9:{		/*	fcds	%r1, %r2	*/
	    flt4 f;

	    if (W < 8 && (op & 00010000)) goto illegal;
	    f= ldf8(&T.reg[r2]);
	    T.reg[r1].u = * (uns4 *) &f;
	    break;}

	case 0xBA:{		/*	fcsd	%r1, %r2	*/
	    flt4 f;

	    if (W < 8 && (op & 01000000)) goto illegal;
	    * (uns4 *) &f = T.reg[r2].u;
	    stf8(&T.reg[r1], f);
	    break;}

	case 0xBB:{		/*	fld4	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    if (W < 8 && (op & 01000000)) goto illegal;
	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 4);
	    if (!aligned(addr, 4)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    stf8(&T.reg[r1], fmem4(tlb_v2m(tp, addr)));
	    break;}

	case 0xBC:{		/*	fst4	%r1, %r2[%r3+s6]	*/
	    tlb_t *tp;
	    unsw addr;

	    if (W < 8 && (op & 01000000)) goto illegal;
	    addr= T.reg[r2].u + ((T.reg[r3].u + sxt(op, 6)) * 4);
	    if (!aligned(addr, 4)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
	    fmem4(tlb_v2m(tp, addr))= ldf8(&T.reg[r1]);
	    break;}

	case 0xBD:{		/*	fld4	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    if (W < 8 && (op & 01000000)) goto illegal;
	    addr= T.reg[r2].u + sxt(op, 12);
	    if (!aligned(addr, 4)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pR)) goto run;
	    stf8(&T.reg[r1], fmem4(tlb_v2m(tp, addr)));
	    break;}

	case 0xBE:{		/*	fst4	%r1, [%r2+s12]	*/
	    tlb_t *tp;
	    unsw addr;

	    if (W < 8 && (op & 01000000)) goto illegal;
	    addr= T.reg[r2].u + sxt(op, 12);
	    if (!aligned(addr, 4)) goto run;
	    if (!tlb_chk(&tp, S_DATA, addr, pP|pW)) goto run;
	    fmem4(tlb_v2m(tp, addr))= ldf8(&T.reg[r1]);
	    break;}

	case 0xBF:{		/*	fld4	%r1, [%pc+s18*4]	*/
	    unsw addr;
	    tlb_t *tp;

	    if (W < 8 && (op & 01000000)) goto illegal;
	    addr= T.pc + jxt(op, 18);
	    if (!tlb_chk(&tp, S_CODE, addr, pP|pX)) goto run;
	    stf8(&T.reg[r1], fmem4(tlb_v2m(tp, addr)));
	    break;}

	case 0xE0: case 0xE1: case 0xE2: case 0xE3: case 0xE4: case 0xE5:
	case 0xE6: case 0xE7: case 0xE8: case 0xE9: case 0xEA: case 0xEB:
	case 0xEC: case 0xED: case 0xEE: case 0xEF:{
				/* packed simple instructions */
	    /* XXX - See what instructions and choose 4 or 5 bits for the
	     * registers and 5 or 4 bits for the opcode.
	     */
	    do {
		r1 = (op >> 5) & 0x1F;
		r2 = (op >> 0) & 0x1F;
		switch ((op >> 10) & 0xF) {
		case 0x0:		/*	mov	%r1, %r2	*/
		    T.reg[r1].u = T.reg[r2].u;
		    break;
		default:
		    goto illegal;
		}
	    } while ((op >>= 14) != 0);
	    break;}

	case 0xF0: case 0xF1: case 0xF2: case 0xF3: case 0xF4: case 0xF5:
	case 0xF6: case 0xF7: case 0xF8: case 0xF9: case 0xFA: case 0xFB:
	case 0xFC: case 0xFD: case 0xFE: case 0xFF:{
				/*	call	address		*/
	    tlb_t *tp;
	    unsw pc= T.pc + jxt(op, 28);
	    unsw sp= T.sp - W;
	    if (!aligned(sp, W)) goto run;
	    if (!tlb_chk(&tp, S_DATA, sp, pP|pW)) goto run;
	    umemw(tlb_v2m(tp, sp))= T.pc;
	    T.sp= sp;
	    T.pc= pc;
	    break;}

	default:
	illegal:
	    trap(T_ILLINS);
	}
    }
}

static void machine_init(void)
/* Initialize the interpreter to bootup state. */
{
    int i;

    linear[0].base= 0;		/* All memory is linear. */
    linear[0].size= mem_size;
    linear[0].prot= 0;		/* RWX is OK. */
    linear[0].v2p= mem_phys;	/* vir byte 0 == mem byte 0. */

				/* Most registers set to zero. */
    for (i= 0; i < RESV; i++) T.reg[i].u = 0;

    T.sp= mem_size - 128*W;	/* Stack and context at the far end. */
    context= mem_addr + T.sp;

    T.pc= 0;			/* First instruction at address 0. */

    T.flags= 0;			/* All traps masked. */

				/* Code space 0, common I&D. */
    T.asid[S_CODE]= T.asid[S_DATA]= 0;

				/* Unmap all address spaces. */
    for (i= 0; i < asid_size; i++) tlb_expunge(i);

				/* Set pointers to the current TLB. */
    ctlb[S_CODE]= tlb[T.asid[S_CODE]];
    ctlb[S_DATA]= tlb[T.asid[S_DATA]];
    pc_expunge();

    think= 1;			/* Tracing? */
}

static void usage(void)
{
    fprintf(stderr,
"Usage: %s [-t[level]] [-s asids] [-m memsize] [-p] [-l logfile] boot-disk ...\n",
	program);
    exit(1);
}

int main(int argc, char **argv)
{
    int i;
    unsigned megs, phys;
    char *m;

    program= argv[0];

    /* Process options and arguments. */
    asid_size= ASID_DEF;
    megs= MEGS_DEF;
    phys= 0;
    log_file= nil;
    i= 1;
    while (i < argc && argv[i][0] == '-') {
	char *opt= argv[i++] + 1;
	unsigned long n;
	char *end;

	if (opt[0] == '-' && opt[1] == 0) break;	/* -- */

	while (*opt != 0) switch (*opt++) {
	case 't':
	    n= strtoul(opt, &end, 10);
	    tlevel= end == opt ? 1 : n;
	    opt= end;
	    break;
	case 's':
	    if (*opt == 0) {
		if (i == argc) usage();
		opt= argv[i++];
	    }
	    n= strtoul(opt, &end, 0);
	    if (end == opt || *end != 0) usage();
	    if (n < ASID_MIN || n > ASID_MAX) {
		fprintf(stderr,
		    "%s: #asids must be between %d and %d, not %s\n",
		    program, ASID_MIN, ASID_MAX, opt);
		exit(1);
	    }
	    asid_size= n;
	    opt= "";
	    break;
	case 'm':
	    if (*opt == 0) {
		if (i == argc) usage();
		opt= argv[i++];
	    }
	    n= strtoul(opt, &end, 0);
	    if (end == opt || *end != 0) usage();
	    if (n < 1 || n >= ((unsw) 1 << (W*8 - 20))
		|| n > ((size_t) -1 >> 20)
	    ) {
		fprintf(stderr, "%s: Memory size %s is undoable\n",
		    program, opt);
		exit(1);
	    }
	    megs= n;
	    opt= "";
	    break;
	case 'p':
	    if (M > W) {
		fprintf(stderr,
	"%s: %d-bit Emulator memory not addressable with a %d-bit pointer\n",
		    program, M*8, W*8);
		exit(1);
	    }
	    phys= 1;
	    break;
	case 'l':
	    if (*opt == 0) {
		if (i == argc) usage();
		opt= argv[i++];
	    }
	    log_file= opt;
	    opt= "";
	    break;
	default:
	    usage();
	}
    }
    if ((argc - i) != 1) usage();
    disk= argv[i];

    /* Obtain memory and TLBs. */
    mem_size= (memory) megs << 20;
    if ((m= malloc(mem_size + (asid_size * sizeof(*tlb)) + PAGE_SIZE)) == nil) {
	fprintf(stderr, "%s: Can't obtain %u megabytes of memory\n",
	    program, megs);
	exit(1);
    }

    /* It never hurts to align our bit of memory to the page size. */
    mem_addr= ((memory) m + (PAGE_SIZE - 1)) & ~PAGE_MASK;

    /* TLB. */
    tlb= (void *) (mem_addr + mem_size);

    if (!phys) {
	/* Only the allocated memory area. */
	mem_base= mem_addr;
    } else {
	/* Emulator memory and emulated machine memory are one. */
	mem_base= 0;
    }
    mem_phys= mem_addr - mem_base;

    /* Open the log file and make it line buffered. */
    if (log_file == nil) {
	int fd;
	log_file= "stdout";
	if ((fd= dup(1)) < 0 || (logfp= fdopen(fd, "w")) == nil) {
	    fprintf(stderr, "%s: Can't dup() stdout: %s\n",
		program, strerror(errno));
	    exit(1);
	}
    } else
    if ((logfp= fopen(log_file, "w")) == nil) {
	fprintf(stderr, "%s: %s: %s\n", program, log_file, strerror(errno));
	exit(1);
    }
    setvbuf(logfp, nil, _IOLBF, 0);

    /* Open the "disk". */
    if ((dfd= open(disk, O_RDWR)) == -1) {
	if (errno == EACCES) dfd= open(disk, O_RDONLY);
	if (dfd == -1) {
	    fprintf(stderr, "%s: Can't open %s: %s\n",
		program, disk, strerror(errno));
	    exit(1);
	}
    }

#if FWAIT
    /* Asynchronous I/O uses 'fw' to collect results signalled by fw.fw_flags
     * becoming zero.  So it better not be zero now.
     */
    fw.fw_flags= !0;
#endif

    /* Initialize the machine to a simple (most things 0) state. */
    machine_init();

    /* Get signature. */
    T.reg[2].u = 4;		/*	mov	%2, 4		*/
    monitor(0x8F080FF7UL);	/*	trap	%2, %0, -9	*/

    if (T.reg[2].u == 4 && umem4(mem_addr) == DUMP_MAGIC) {
	/* Memory dump.  Load entire file and run from the start. */
	T.reg[2].u = -1;	/*	mov	%2, -1		*/
	monitor(0x8F080FF7UL);	/*	trap	%2, %0, -9	*/
    } else {
	/* Otherwise a disk image.  Try to boot it. */
	T.reg[2].u = 0;
	monitor(0x8F000FF8UL);	/*	trap	%0, %0, -8	*/
    }

    /* Let er rip. */
    run();
    return 0;
}

#else /* !(has_int(W) && !has_flt(4) && !has_flt(8)) */

int main(void)
{
    fprintf(stderr,
	"This program doesn't work because the compiler doesn't offer "
#if !has_int(W)
	"an integer\ntype of %d bytes.\n", W
#elif !has_flt(4)
	"a floating\npoint type of 4 bytes.\n"
#elif !has_flt(8)
	"a floating\npoint type of 8 bytes.\n"
#endif
    );
}
#endif

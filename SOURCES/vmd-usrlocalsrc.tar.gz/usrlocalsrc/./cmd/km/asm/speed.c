int main(void)
{
	int i, j;
	volatile int t;
	static int mem[32*1024*1024/4];

	i= 100000000;
	j= 0;
	do {
		t= * (int *) ((char*)mem + j);
		j += 4096;
		j &= sizeof(mem)-1;
	} while (--i != 0);
	return 0;
}

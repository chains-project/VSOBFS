/*	rpc.c - Pseudo remote procedure call.		Author: Kees J. Bot
 */
#define nil NULL
#define _POSIX_SOURCE	1
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include "rpc.h"

vector_t nullvec = { nil, 0 };	/* For null rpc's. */

typedef struct state {
	char		*name;		/* Name of this process. */
	vector_t	*inbox;		/* Receive mailbox. */
	procid_t	client;		/* Working for process X. */
	vector_t	*(*serve)(vector_t **inbox);
					/* Handles requests. */
} state_t;

vector_t *death(vector_t **inbox) { return &nullvec; }

static state_t state[NR_PROCS]= {
	{ "Death",	&nullvec, 0, death },
	{ "Source",	&nullvec, 0, nil },
	{ "Destination",&nullvec, 0, nil },
	{ "Patchtree",	&nullvec, 0, nil },
	{ "Mediator",	&nullvec, 0, nil },
};

static procid_t current;

static FILE *rpc_in, *rpc_out;	/* Input and output rpc channel. */

#define VEC_END		0xFF	/* Lenght byte indicates end of data. */
#define VEC_MANY	0xFE	/* Lenght byte escape indicates large packet. */

typedef enum ptype { REQUEST, REPLY } ptype_t;	/* Packet type. */

char *pname(void)
/* "print name", a nice name to use in error prints. */
{
	static char name[10 + NR_PROCS + 2] = "patchtree[";
	char *np= name+10;
	state_t *stp;

	for (stp= state+1; stp < state+NR_PROCS; stp++) {
		if (stp->serve != nil) *np++= stp->name[0];
	}
	*np++= ']';
	*np= 0;
	return name;
}

#if DEBUG
int log= 0;

static int getchan(void)
{
	int c= getc(rpc_in);

	if (c != EOF && log != 0) fprintf(stderr, " %02x", c);
	return c;
}

static int putchan(int c)
{
	c= putc(c, rpc_out);

	if (c != EOF && log == 1) fprintf(stderr, " %02x", c);
	return c;
}
#else
#define getchan()	getc(rpc_in)
#define putchan(c)	putc((c), rpc_out)
#endif

static void channel_error(FILE *channel)
{
	char *what= "Unknown error";

	if (ferror(channel)) what= strerror(errno);
	if (feof(channel)) what= "Unexpected end of file";

	fprintf(stderr, "%s: pseudo RPC channel: %s\n", pname(), what);

#if DEBUG
	if (!feof(channel)) abort();
#endif
	exit(1);
}

static void getchan_error(void) { channel_error(rpc_in); }
static void putchan_error(void) { channel_error(rpc_out); }

static void send_intro(ptype_t ptype, procid_t dst, procid_t src, int hopct)
/* Tell that a packet is coming (everything else is error output. */
{
	if (putchan('\0') == EOF) putchan_error();
#if DEBUG
	fprintf(stderr, "%s>>>", pname()+9);
	log++;
#endif
	if (putchan(ptype) == EOF) putchan_error();
	if (putchan(dst) == EOF) putchan_error();
	if (putchan(src) == EOF) putchan_error();
	if (putchan(hopct) == EOF) putchan_error();
}

static void rec_intro(ptype_t *ptype, procid_t *dst, procid_t *src, int *hopct)
/* Get a packet intro, send everything else to standard error. */
{
	int c;
	int needflush= 0;

	while ((c= getchan()) != 0) {
		if (c == EOF) getchan_error();
		(void) putc(c, stderr);
		needflush= 1;
	}
	if (needflush) (void) fflush(stderr);

#if DEBUG
	fprintf(stderr, "%s<<<", pname()+9);
	log++;
#endif
	if ((c= getchan()) == EOF) getchan_error();
	*ptype= c;
	if ((c= getchan()) == EOF) getchan_error();
	*dst= c;
	if ((c= getchan()) == EOF) getchan_error();
	*src= c;
	if ((c= getchan()) == EOF) getchan_error();
	*hopct= c;
}

static int send_vector(vector_t *putv)
/* Send the bytes pointed to by the vector into the pit. */
{
	unsigned char *dp= putv->addr;
	size_t dl= putv->len;

	if (dp == nil) {
		/* End of vector. */
		if (putchan(VEC_END) == EOF) putchan_error();
#if DEBUG
		fputc('\n', stderr);
		fflush(stderr);
		log= 0;
#endif
		if (fflush(rpc_out) == EOF) putchan_error();
		return 0;
	}

	if (dl < VEC_MANY) {
		/* Small array. */
		if (putchan(dl) == EOF) putchan_error();
	} else {
		/* Large array, send large count. */
		if (putchan(VEC_MANY) == EOF) putchan_error();
		if (putchan(dl & 0xFF) == EOF) putchan_error();
		if (putchan(dl >> 8) == EOF) putchan_error();
	}

	while (dl > 0) {
		if (putchan(*dp++) == EOF) putchan_error();
		dl--;
	}
	return 1;
}

static int rec_vector(vector_t *recv)
/* Fill a buffer through a vector. */
{
	char *dp= recv->addr, *dp_max= dp + recv->len;
	size_t dl;
	int c;

	if ((c= getchan()) == EOF) getchan_error();
	dl= c;
	if (dl == VEC_END) {
#if DEBUG
		fputc('\n', stderr);
		fflush(stderr);
		log= 0;
#endif
		return 0;
	}

	if (dl == VEC_MANY) {
		/* Large array. */
		if ((c= getchan()) == EOF) getchan_error();
		dl= c;
		if ((c= getchan()) == EOF) getchan_error();
		dl|= c << 8;
	}

	while (dl > 0) {
		if ((c= getchan()) == EOF) getchan_error();
		if (dp < dp_max) *dp++= c;
		dl--;
	}
	return 1;
}

static int sendrec_vector(void)
/* Pass one buffer on from the input to the output channel. */
{
	size_t dl;
	int c;

	if ((c= getchan()) == EOF) getchan_error();
	if (putchan(c) == EOF) putchan_error();
	dl= c;
	if (dl == VEC_END) {
#if DEBUG
		fputc('\n', stderr);
		fflush(stderr);
		log= 0;
#endif
		if (fflush(rpc_out) == EOF) putchan_error();
		return 0;
	}

	if (dl == VEC_MANY) {
		/* Large array. */
		if ((c= getchan()) == EOF) getchan_error();
		if (putchan(c) == EOF) putchan_error();
		dl= c;
		if ((c= getchan()) == EOF) getchan_error();
		if (putchan(c) == EOF) putchan_error();
		dl|= c << 8;
	}

	while (dl > 0) {
		if ((c= getchan()) == EOF) getchan_error();
		if (putchan(c) == EOF) putchan_error();
		dl--;
	}
}

static void rpc_err(char *what, procid_t from, procid_t to)
{
	fprintf(stderr, "%s: %s -> %s: pseudo rpc error: %s\n", pname(),
		state[from].name,
		state[to].name,
		what);
#if DEBUG
	abort();
#else
	exit(1);
#endif
}

static void send(procid_t server, ptype_t ptype, vector_t *sendp)
/* Send the packet to the server. */
{
	send_intro(ptype, server, current, 100);

	while (send_vector(sendp)) sendp++;
}

static void receive(vector_t *recp)
/* Receive a packet from any source and do the following with it:
 *	- If it is for the current process: Get it and return.
 *	- If it is for a local server: Get it, call server, send reply.
 *	- Otherwise send it on.
 */
{
	procid_t server, client, oldcurrent;
	ptype_t ptype;
	int hopct;
	state_t *stp;
	vector_t *outbox;
	vector_t *vp;

	for (;;) {
		rec_intro(&ptype, &server, &client, &hopct);

		stp= &state[server];

		if (stp->serve == nil) {
			/* Not for me. */
			if (--hopct == 0)
				rpc_err("deadlock", client, server);  /* Ouch */

			send_intro(ptype, server, client, hopct);

			while (sendrec_vector()) {}

			continue;
		}

		/* If it is a reply then it must be for the current process. */
		if (ptype == REPLY) {
			if (server != current)
				rpc_err("bad reply", client, server);
			break;
		}

		/* The packet is for a local process, copy it in. */

		vp= stp->inbox;
		while (rec_vector(vp)) vp++;

		/* Call the local process. */
		oldcurrent= current;

		stp->client= client;

		current= server;

		/* Execute server process. */
		vp= (*stp->serve)(&stp->inbox);

		/* Do: send(client, REPLY, vp) */
		send_intro(REPLY, client, current, 100);

		while (send_vector(vp)) vp++;

		current= oldcurrent;
	}

	/* Get the reply packet. */

	vp= recp;
	while (rec_vector(vp)) vp++;
}

void rpc(procid_t server, vector_t *sendp, vector_t *recp)
/* Do a remote procedure call with "server", sending packet "sendp" and
 * receiving the reply in "recp".
 */
{
	state_t *stp= &state[server];
	vector_t *cvp, *svp;

	if (stp->serve != nil) {
		/* Server is not a separate process, simply pass the packet
		 * to the proper server routine.
		 */

		cvp= sendp;
		svp= stp->inbox;
		while (cvp->addr != nil) {
			memcpy(svp->addr, cvp->addr,
				svp->len > cvp->len ? cvp->len : svp->len);
			cvp++;
			svp++;
		}

		stp->client= current;

		current= server;

		svp= (*stp->serve)(&stp->inbox);

		current= stp->client;

		cvp= recp;
		while (svp->addr != nil) {
			memcpy(cvp->addr, svp->addr,
				cvp->len > svp->len ? svp->len : cvp->len);
			svp++;
			cvp++;
		}
	} else {
		/* The server is a remote process, send the packet over the
		 * rpc channel and read the reply.
		 */
		send_intro(REQUEST, server, current, 100);
		svp= sendp;
		while (send_vector(svp)) svp++;
		receive(recp);
	}
}

void init_server(procid_t server, vector_t *(*serve)(vector_t **inbox))
/* Set the server routine, making the server a local process. */
{
	state[server].serve= serve;
}

void life(life_t role, int infd, int outfd)
/* Initialize the rpc channel and live your life. */
{
	if (infd >= 0) {
		if ((rpc_in= fdopen(infd, "r")) == nil)
			getchan_error();
		if ((rpc_out= fdopen(outfd, "w")) == nil)
			putchan_error();
	}

	if (role == MASTER) {
		/* Initialize everything and then cause death. */
		procid_t server;

		current= MEDIATOR;
		for (server= DEATH+1; server <= MEDIATOR; server++)
			rpc(server, &nullvec, &nullvec);

		if (infd >= 0) {
			current= DEATH;
			send(DEATH, REPLY, &nullvec);
			receive(&nullvec);
		}
	} else {
		/* Slaves only wait for death.  (Depressing isn't it?) */
		current= DEATH;
		receive(&nullvec);
		send(DEATH, REPLY, &nullvec);	/* Pass it on. */
	}
	if (infd >= 0) {
		fclose(rpc_in);
		fclose(rpc_out);
	}
	/* R.I.P. */
}

void rpc_h2ns(void *ns, u16_t hs)
/* Host to "network" short. */
{
	unsigned char *cns= ns;

	cns[0]= hs & 0xFF;
	cns[1]= (hs >> 8) & 0xFF;
}

u16_t rpc_n2hs(void *ns)
/* Network to host short. */
{
	unsigned char *cns= ns;

	return cns[0] | (cns[1] << 8);
}

void rpc_h2nl(void *nl, u32_t hl)
/* Host to network long. */
{
	unsigned char *cnl= nl;

	cnl[0]= hl & 0xFF;
	cnl[1]= (hl >>  8) & 0xFF;
	cnl[2]= (hl >> 16) & 0xFF;
	cnl[3]= (hl >> 24) & 0xFF;
}

u32_t rpc_n2hl(void *nl)
/* Network to host long. */
{
	unsigned char *cnl= nl;

	return cnl[0] | (cnl[1] << 8) | (cnl[2] << 16) | (cnl[3] << 24);
}
/* Kees J. Bot 20-3-93. */

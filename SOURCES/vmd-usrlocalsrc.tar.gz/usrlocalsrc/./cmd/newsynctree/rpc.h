/*	rpc.h - pseudo remote procedure call.		Author: Kees J. Bot
 *
 * This module defines functions to implement a pipe(2) based remote
 * procedure call.
 */

#define NR_PROCS	5

typedef enum procid {
	DEATH, SOURCE, DESTINATION, PATCHTREE, MEDIATOR
} procid_t;

typedef struct vector {
	void	*addr;		/* Address of a random bit of data. */
	size_t	len;		/* Length of this data. */
} vector_t;

extern vector_t nullvec;	/* Useful for null rpc's. */

typedef enum life { MASTER, SLAVE } life_t;	/* Role to play in life. */

/* Functions.
 * The main process should start the other processes with pipes connecting
 * them circularly.  Each process then calls init_server() for all local
 * servers, and then calls life() to start its tasks.
 * Only the main process call life() as a master, to initialize all servers.
 * Initialization is done with null rpc()'s.  All servers should immediately
 * exit with their input vector initialized.  Only the mediator can do as it
 * wishes and return last.  After this life() ends and the main process can
 * exit.
 * Rpc() can be used as a normal function call (there is only one flow of
 * control in all processes combined), except that the arguments must be
 * marshalled and made byte-order independent.
 * When a server routine is called the server must initialize its inbox
 * before calling rpc(), this makes recursive calls possible.
 */

char *pname(void);
	/* "print name", a nice name to use in error prints. */

void init_server(procid_t server, vector_t *(*serve)(vector_t **inbox));
	/* Set the server routine for a local server. */

void life(life_t role, int infd, int outfd);
	/* Initialize the command channel and live your life accepting packets
	 * and calling the local servers to handle them.
	 */

void rpc(procid_t server, vector_t *sendp, vector_t *recp);
	/* Do a remote procedure call with "server", sending packet sendp[]
	 * and receiving the reply in recp[].
	 */

/* Marshalling utilities. */

void rpc_h2ns(void *ns, u16_t hs);
	/* Host to "network" short. */

u16_t rpc_n2hs(void *ns);
	/* Network to host short. */

void rpc_h2nl(void *nl, u32_t hl);
	/* Host to network long. */

u32_t rpc_n2hl(void *nl);
	/* Network to host long. */

/*	rpcpager 1.1 - test the rpc package		Author: Kees J. Bot
 */
#define nil 0
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/wait.h>
#include "rpc.h"

typedef enum srcdst_cmd {
	SD_OPEN, SD_POPEN, SD_READ, SD_WRITE, SD_CLOSE, SD_WAIT
} srcdst_cmd_t;

vector_t *src_dst(vector_t **inbox)
/* Performs open, read, write, close. */
{
	int fd, len, r, pid, status, mode, mine, thine;
	int pfd[2];
	static char opcode;
	static char num[2][4];
	static char buf[1024];
	static vector_t reqv[] = {
		{ &opcode, 1 }, { num[0], 4 }, { num[1], 4 },
		{ buf, sizeof(buf) }
	};
	static vector_t repv[] = {
		{ num[0], 4 }, { num[1], 4 }, { buf, sizeof(buf) }, { nil, 0 }
	};

	if (*inbox == &nullvec) {
		/* Initialization null rpc. */
		*inbox= reqv;
		return &nullvec;
	}

	switch (opcode) {
	case SD_OPEN:
		mode= num[0][0];

		fd= open(buf, mode == 'r' ? O_RDONLY : O_WRONLY|O_CREAT, 0666);

		rpc_h2nl(num[0], (long) fd);

		if (fd < 0) {
			strcpy(buf, strerror(errno));
			repv[2].len= strlen(buf)+1;
		} else {
			repv[2].len= 0;
		}
		break;
	case SD_POPEN:
		mode= num[0][0];
		if (mode == 'r') mine= 0, thine= 1; else mine= 1, thine= 0;

		r= pipe(pfd);
		if (r < 0) {
			pfd[0]= pfd[1]= -1;
		} else {
			if ((r= fork()) == 0) {
				close(pfd[mine]);
				if (pfd[thine] != thine) {
					dup2(pfd[thine], thine);
					close(pfd[thine]);
				}
				execl("/bin/sh", "sh", "-c", buf, (char *) nil);
				exit(127);
			}
		}

		if (r >= 0) {
			close(pfd[thine]);
			fd= pfd[mine];
		} else {
			fd= -1;
		}

		rpc_h2nl(num[0], (long) fd);
		rpc_h2nl(num[1], (long) r);

		if (r < 0) {
			strcpy(buf, strerror(errno));
			repv[2].len= strlen(buf)+1;
			if (pfd[0] >= 0) close(pfd[0]);
			if (pfd[1] >= 0) close(pfd[1]);
		} else {
			repv[2].len= 0;
		}
		break;
	case SD_READ:
		fd= rpc_n2hl(num[0]);
		len= rpc_n2hl(num[1]);

		if (len > sizeof(buf)) len= sizeof(buf);

		r= read(fd, buf, len);

		rpc_h2nl(num[0], (long) r);

		if (r < 0) {
			strcpy(buf, strerror(errno));
			repv[2].len= strlen(buf)+1;
		} else {
			repv[2].len= r;
		}
		break;
	case SD_WRITE:
		fd= rpc_n2hl(num[0]);
		len= rpc_n2hl(num[1]);

		if (len > sizeof(buf)) len= sizeof(buf);

		r= write(fd, buf, len);

		rpc_h2nl(num[0], (long) r);

		if (r < 0) {
			strcpy(buf, strerror(errno));
			repv[2].len= strlen(buf)+1;
		} else {
			repv[2].len= 0;
		}
		break;
	case SD_CLOSE:
		fd= rpc_n2hl(num[0]);

		r= close(fd);

		rpc_h2nl(num[0], (long) r);

		if (r < 0) {
			strcpy(buf, strerror(errno));
			repv[2].len= strlen(buf)+1;
		} else {
			repv[2].len= 0;
		}
		break;
	case SD_WAIT:
		pid= rpc_n2hl(num[0]);

		r= waitpid(pid, &status, 0);

		rpc_h2nl(num[0], (long) r);
		rpc_h2nl(num[1], (long) status);

		if (r < 0) {
			strcpy(buf, strerror(errno));
			repv[2].len= strlen(buf)+1;
		} else {
			repv[2].len= 0;
		}
		break;
	default:
		fprintf(stderr, "tstpager: bad command to src_dst()\n");
		exit(1);
	}
	return repv;
}

/* Stubs for the src_dst task. */

static char errstr[64];

int sd_open(int server, char *name, int mode)
{
	static char num[1][4];
	static char opcode= SD_OPEN;
	static vector_t reqv[]= {
		{ &opcode, 1 }, { num[0], 1 }, { num[0], 0 }, { nil, 0 },
		{ nil, 0 }
	};
	static vector_t repv[]= {
		{ num[0], 4 }, { num[0], 0 }, { errstr, sizeof(errstr)-1 }
	};

	switch (mode) {
	case O_RDONLY:		num[0][0]= 'r';	break;
	case O_WRONLY|O_CREAT:	num[0][0]= 'w';	break;
	default:		errno= EINVAL;	return -1;
	}

	reqv[3].addr= name;
	reqv[3].len= strlen(name)+1;

	rpc(server, reqv, repv);

	return rpc_n2hl(num[0]);
}

int sd_popen(int server, int *pid, char *cmd, int mode)
{
	static char num[2][4];
	static char opcode= SD_POPEN;
	static vector_t reqv[]= {
		{ &opcode, 1 }, { num[0], 1 }, { num[0], 0 }, { nil, 0 },
		{ nil, 0 }
	};
	static vector_t repv[]= {
		{ num[0], 4 }, { num[1], 4 }, { errstr, sizeof(errstr)-1 }
	};

	switch (mode) {
	case O_RDONLY:		num[0][0]= 'r';	break;
	case O_WRONLY:		num[0][0]= 'w';	break;
	default:		errno= EINVAL;	return -1;
	}

	reqv[3].addr= cmd;
	reqv[3].len= strlen(cmd)+1;

	rpc(server, reqv, repv);

	*pid= rpc_n2hl(num[1]);
	return rpc_n2hl(num[0]);
}

int sd_read(int server, int fd, char *buf, int len)
{
	static char num[2][4];
	static char opcode= SD_READ;
	static vector_t reqv[]= {
		{ &opcode, 1 }, { num[0], 4 }, { num[1], 4 }, { nil, 0 }
	};
	static vector_t repv[]= {
		{ num[0], 4 }, { num[0], 0 }, { nil, 0 }
	};
	int r;

	rpc_h2nl(num[0], (long) fd);
	rpc_h2nl(num[1], (long) len);

	repv[2].addr= buf;
	repv[2].len= len;

	rpc(server, reqv, repv);

	r= rpc_n2hl(num[0]);
	if (r < 0) {
		buf[sizeof(errstr)-1]= 0;	/* This is not ok. */
		strcpy(errstr, buf);
	}
	return r;
}

int sd_write(int server, int fd, char *buf, int len)
{
	static char num[2][4];
	static char opcode= SD_WRITE;
	static vector_t reqv[]= {
		{ &opcode, 1 }, { num[0], 4 }, { num[1], 4 }, { nil, 0 },
		{ nil, 0 }
	};
	static vector_t repv[]= {
		{ num[0], 4 }, { num[0], 0 }, { errstr, sizeof(errstr)-1 }
	};
	int r;

	rpc_h2nl(num[0], (long) fd);
	rpc_h2nl(num[1], (long) len);

	reqv[3].addr= buf;
	reqv[3].len= len;

	rpc(server, reqv, repv);

	return rpc_n2hl(num[0]);
}

int sd_close(int server, int fd)
{
	static char num[1][4];
	static char opcode= SD_CLOSE;
	static vector_t reqv[]= {
		{ &opcode, 1 }, { num[0], 4 }, { nil, 0 }
	};
	static vector_t repv[]= {
		{ num[0], 4 }, { num[0], 0 }, { errstr, sizeof(errstr)-1 }
	};

	rpc_h2nl(num[0], (long) fd);

	rpc(server, reqv, repv);

	return rpc_n2hl(num[0]);
}

int sd_wait(int server, int pid, int *status)
{
	static char num[2][4];
	static char opcode= SD_WAIT;
	static vector_t reqv[]= {
		{ &opcode, 1 }, { num[0], 4 }, { nil, 0 }
	};
	static vector_t repv[]= {
		{ num[0], 4 }, { num[1], 4 }, { errstr, sizeof(errstr)-1 }
	};

	rpc_h2nl(num[0], (long) pid);

	rpc(server, reqv, repv);

	if (status != 0) *status= rpc_n2hl(num[1]);
	return rpc_n2hl(num[0]);
}

vector_t *patchtree(vector_t **inbox)
{
	return &nullvec;
}

int Argc;
char **Argv;
int ex= 0;

vector_t *mediator(vector_t **inbox)
{
	int i, fd0, fd1, n, pid, status;
	char buf[1024];
	char *file;
	char *pager;

	if (!isatty(1)) {
		fd1= 1;
		pager= "stdout";
	} else {
		if ((pager= getenv("PAGER")) == nil) pager= "more";

		if (Argc == 1 && isatty(0)) {
			fprintf(stderr,
				"rpcpager: can't read from a terminal\n");
			ex= 1;
			goto bail_out;
		}

		if ((fd1= sd_popen(DESTINATION, &pid, pager, O_WRONLY)) < 0) {
			fprintf(stderr, "rpcpager: %s: %s\n", pager, errstr);
			ex= 1;
			goto bail_out;
		}
	}

	i= 1;
	file= "stdin";
	fd0= 0;
	do {
		if (i < Argc) fd0= sd_open(SOURCE, file= Argv[i], O_RDONLY);

		if (fd0 < 0) {
			fprintf(stderr, "rpcpager: %s: %s\n", file, errstr);
			ex= 1;
			goto bail_wait;
		}
		while ((n= sd_read(SOURCE, fd0, buf, sizeof(buf))) > 0) {
			int s= 0, r;

			while (s < n) {
				r= sd_write(DESTINATION, fd1, buf+s, n-s);
				if (r < 0) {
					fprintf(stderr, "rpcpager: %s: %s\n",
						pager, errstr);
					ex= 1;
					goto bail_wait;
				}
				s+= r;
			}
		}

		if (n < 0) {
			fprintf(stderr, "rpcpager: %s: %s\n", file, errstr);
			ex= 1;
			goto bail_wait;
		}
		if (i < Argc) sd_close(SOURCE, fd0);
	} while (++i < Argc);

bail_wait:
	if (fd1 != 1) {
		sd_close(DESTINATION, fd1);
		sd_wait(DESTINATION, pid, &status);
	}
bail_out:
	return &nullvec;
}

int main(int argc, char **argv)
{
	int m_s1[2], s1_s2[2], s2_m[2];

	signal(SIGPIPE, SIG_IGN);

	Argc= argc;
	Argv= argv;

	(void) pipe(m_s1);
	(void) pipe(s1_s2);
	(void) pipe(s2_m);

	if (fork() == 0) {
		/* Slave 1 */
		if (0) close(m_s1[0]);
		(void) close(m_s1[1]);
		(void) close(s1_s2[0]);
		if (0) close(s1_s2[1]);
		(void) close(s2_m[0]);
		(void) close(s2_m[1]);
		init_server(SOURCE, src_dst);
		life(SLAVE, m_s1[0], s1_s2[1]);
	} else
	if (fork() == 0) {
		/* Slave 2 */
		(void) close(m_s1[0]);
		(void) close(m_s1[1]);
		if (0) close(s1_s2[0]);
		(void) close(s1_s2[1]);
		(void) close(s2_m[0]);
		if (0) close(s2_m[1]);
		init_server(DESTINATION, src_dst);
		life(SLAVE, s1_s2[0], s2_m[1]);
	} else {
		/* Master */
		(void) close(m_s1[0]);
		if (0) close(m_s1[1]);
		(void) close(s1_s2[0]);
		(void) close(s1_s2[1]);
		if (0) close(s2_m[0]);
		(void) close(s2_m[1]);
		init_server(PATCHTREE, patchtree);
		init_server(MEDIATOR, mediator);
		life(MASTER, s2_m[0], m_s1[1]);
	}
	exit(ex);
}
/* Kees J. Bot 21-3-93. */

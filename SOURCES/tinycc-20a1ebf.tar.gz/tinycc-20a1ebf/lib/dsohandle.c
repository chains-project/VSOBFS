void * __dso_handle __attribute((visibility("hidden"))) = &__dso_handle;
